<?php $__env->startSection('title','Edit Family'); ?>

<?php $__env->startSection('styles'); ?>
  <style>
    .invalid-feedback{
      color: red
    }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="right-side">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <!-- Starting of Dashboard area -->
          <div class="section-padding add-product-1">
              <div class="row">
                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                      <div class="add-product-box">
                        <div class="product__header"  style="border-bottom: none;">
                            <div class="row reorder-xs">
                                <div class="col-lg-8 col-md-5 col-sm-5 col-xs-12">
                                    <div class="product-header-title">
                                        <h2>Edit Family <a href="<?php echo e(route('user-family.index')); ?>" style="padding: 5px 12px;" class="btn add-back-btn"><i class="fa fa-arrow-left"></i> Back</a></h2>
                                        <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i> My Family <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Edit
                                    </div>
                                </div>
                                  <?php echo $__env->make('includes.user-notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>   
                        </div>
                        <hr>
                        <div>
                          
                          <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      
                          <!-- Tab panes -->
                          <div class="tab-content">

                            <div class="tab-pane fade active in" id="digital">
                                    <form class="form-horizontal" action="<?php echo e(route('user-family.update',$member->id)); ?>" method="POST" id="form2">

                                        <?php echo e(csrf_field()); ?>

                          
                                        <div class="form-group">
                                            <label class="control-label col-sm-4"> First Name *<span></span></label>
                                            <div class="col-sm-6">
                                            <input class="form-control" name="firstname" value="<?php echo e($firstname); ?>" placeholder="First Name" required="" type="text" >
                                            <?php if($errors->has('name')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                            </div>
                                            
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label col-sm-4">Middle Name <span></span></label>
                                            <div class="col-sm-6">
                                            <input class="form-control" name="middlename" value="<?php echo e($member->middlename); ?>" placeholder="Middle Name" type="text" >
                                            <?php if($errors->has('name')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                            </div>
                                            
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label col-sm-4">Last Name *<span></span></label>
                                            <div class="col-sm-6">
                                            <input class="form-control" name="lastname" value="<?php echo e($lastname); ?>" placeholder="Last Name" required="" type="text" >
                                            <?php if($errors->has('name')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                            </div>
                                            
                                        </div>
                        
                                        

                                        <div class="form-group">
                                            <label class="control-label col-sm-4"> Date of Birth *<span></span></label>
                                            <div class="col-sm-6">
                                                <input class="form-control" name="dob" value="<?php echo e($member->dob); ?>" placeholder="Date of Birth" required="" type="date" >
                                                
                                            </div>
                                            
                                        </div>
                        
                                        <div class="form-group">
                                            <label class="control-label col-sm-4"> Gender *<span></span></label>
                                            <div class="col-sm-6">
                                                <select class="form-control" name="gender" required="" >
                                                <option value="" disabled>Choose an option</option>
                                                <option value="Male" <?php echo e($member->gender == 'Male' ? 'selected' : ''); ?>>Male</option>
                                                <option value="Female" <?php echo e($member->gender == 'Female' ? 'selected' : ''); ?>>Female</option>
                                                <option value="Other" <?php echo e($member->gender == 'Other' ? 'selected' : ''); ?>>Other</option>
                                                </select>
                                                <?php if($errors->has('gender')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('gender')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                            
                                        </div>
                        
                                        <div class="form-group">
                                            <label class="control-label col-sm-4"> Relation *<span></span></label>
                                            <div class="col-sm-6">
                                                <input class="form-control" name="relation" value="<?php echo e($member->relation); ?>" placeholder="Relation" required="" type="text">
                                                <?php if($errors->has('relation')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('relation')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                            
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label col-sm-4">Email<span></span></label>
                                            <div class="col-sm-6">
                                              <input class="form-control" name="email" value="<?php echo e($member->email); ?>" placeholder="Email"  type="text" >
                                            
                                            </div>
                                            
                                          </div>
                          
                                          <div class="form-group">
                                            <label class="control-label col-sm-4">Phone Number<span></span></label>
                                            <div class="col-sm-6">
                                              <input class="form-control" name="phone" value="<?php echo e($member->phone); ?>" placeholder="phone number"  type="text" >
                                          
                                            </div>
                                            
                                          </div>
                        
                                        <hr>
                                        <div class="add-product-footer">
                                            
                                            <button name="add_product_btn" type="submit" class="btn btn-success">Submit</button>
                                        </div>
                                    </form>
                            </div>

                          </div>

                        </div>

                      </div>
                  </div>
              </div>
          </div>
          <!-- Ending of Dashboard area --> 
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>