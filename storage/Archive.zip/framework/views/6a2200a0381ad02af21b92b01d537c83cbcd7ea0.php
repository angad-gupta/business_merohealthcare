<?php $__env->startSection('title','My Profile'); ?>
<?php $__env->startSection('content'); ?> 



    <style>
        .gj-datepicker-bootstrap [role=right-icon] button .gj-icon, .gj-datepicker-bootstrap [role=right-icon] button .material-icons {
            position: absolute;
            font-size: 21px;
            top: 9px;
            left: 9px;
            color: white;
        }  
        .gj-datepicker-bootstrap [role=right-icon] button {
    width: 38px;
    position: relative;
    border: 0px solid white;
}

        </style> 


<link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/'.$gs->favicon)); ?>">
<link href="<?php echo e(asset('assets/admin/css/jquery-ui.css')); ?>" rel="stylesheet" type="text/css">

    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard add-product-1 area -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                <div class="product__header">
                                    <div class="row reorder-xs">
                                        <div class="col-lg-8 col-md-5 col-sm-5 col-xs-12">
                                            <div class="product-header-title">
                                                <h2>Edit Profile</h2>
                                                <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Edit Profile</p>
                                            </div>
                                        </div>
                                            <?php echo $__env->make('includes.user-notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    </div>   
                                </div>
                                    <form class="form-horizontal" action="<?php echo e(route('user-profile-update',$user->id)); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo $__env->make('includes.form-error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        <?php echo e(csrf_field()); ?>

                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="admin_current_photo">Current Photo *</label>
                                            <div class="col-sm-2">
                                                <?php if($user->is_provider == 1): ?>
                                                <img style="width: 100%; height: auto;" src="<?php echo e($user->photo ? $user->photo:asset('assets/images/user.png')); ?>" alt="profile no image">
                                                <?php else: ?>
                                                <img  style="width: 100%; height: auto;" id="adminimg" src="<?php echo e($user->photo ? asset('assets/images/'.$user->photo):asset('assets/images/user.png')); ?>" alt="profile image">
                                                <?php endif; ?>

                                            </div>
                                            <?php if($user->is_provider != 1): ?>
                                            <div class="col-sm-4">
                                                <input type="file" id="uploadFile" class="hidden" name="photo" value="">
                                                <button  type="button" id="uploadTrigger" onclick="uploadclick()" class="btn btn-block add-product_btn adminImg-btn"><i class="fa fa-upload"></i> Change Photo</button>
                                                <button  type="button" id="deletebutton" onclick="deleteclick()" class="btn btn-block add-product_btn adminImg-btn" style="background-color:red;"><i class="fa fa-trash"></i> Delete Photo</button>
                                                <p>Max File Size : <strong>5 MB</strong> | Support Format : <strong>jpg, jpeg, png</strong></p>
                                                
                                                
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="dash_fname"><?php echo e($lang->fname); ?> *</label>
                                            <div class="col-sm-6">
                                                <input class="form-control" type="text" name="name" id="dash_fname" placeholder="<?php echo e($lang->fname); ?>" value="<?php echo e($user->name); ?>" required>
                                            </div>
                                        </div>
                                        <?php if($user->is_provider != 1): ?>
                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="dash_lname"><?php echo e($lang->doeml); ?> *</label>
                                            <div class="col-sm-6">
                                                <input class="form-control" id="dash_lname" placeholder="<?php echo e($lang->doeml); ?>" value="<?php echo e($user->email); ?>" readonly disabled>
                                            </div>
                                        </div>
                                        <?php endif; ?>


                                        <div class="form-group">
                                            <label class="control-label col-sm-4">Gender </label>
                                            <div class="col-sm-6">
                                                <select class="form-control" name="gender" style="    height: 40px;" required>
                                                 
                                                    <option value="Male" <?php echo e($user->gender == 'Male' ? 'selected' : ''); ?>>Male</option>
                                                    <option value="Female" <?php echo e($user->gender == 'Female' ? 'selected' : ''); ?>>Female</option>
                                                    <option value="Others" <?php echo e($user->gender == 'Others' ? 'selected' : ''); ?>>Others</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label col-sm-4">Date of Birth </label>
                                            <div class="col-sm-6">
                                                
                                                
                                                <input class="form-control" name="dob" value=<?php echo e($user->dob); ?> id="dob" placeholder="YYYY-MM-DD" type="text" value="">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label col-sm-4">PAN Number</label>
                                            <div class="col-sm-6">
                                                <input type="text" class="form-control" name="pan_number" value="<?php echo e($user->pan_number); ?>" placeholder="PAN Number">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label col-sm-4">Address Type *</label>
                                            <div class="col-sm-6">
                                                <select class="form-control" name="address_type" style="    height: 40px;" required>
                                                    <option value="" <?php echo e(!$user->address_type ? 'selected' : ''); ?> disabled>Select an option</option>
                                                    <option value="Home" <?php echo e($user->address_type == 'Home' ? 'selected' : ''); ?>>Home</option>
                                                    <option value="Office" <?php echo e($user->address_type == 'Office' ? 'selected' : ''); ?>>Office</option>
                                                </select>
                                            </div>
                                        </div>
                                        
                                        

                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="geolocation"><?php echo e($lang->doad); ?> *</label>
                                            <div class="col-sm-6">
                                                <input class="form-control" type="text" name="address" id="geolocation" placeholder="<?php echo e($lang->doad); ?>" value="<?php echo e($user->address); ?>" required onclick="$('.locationModal').modal('show');" autocomplete="off">
                                                <input id="latlong" type="hidden" name="latlong" value="<?php echo e($user->latlong); ?>">
                                            </div>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="dash_phone"><?php echo e($lang->doph); ?> *</label>
                                            <div class="col-sm-6">
                                                <input class="form-control" type="text" name="phone" id="dash_phone" placeholder="<?php echo e($lang->cop); ?>" value="<?php echo e($user->phone); ?>" required>
                                            </div>
                                        </div>
                                        

                                        <hr>
                                        <div class="add-product-footer">
                                            <button name="addProduct_btn" type="submit" class="btn add-product_btn"><?php echo e($lang->doupl); ?></button>
                                        </div>
                                    </form>

                                    <form id="deleteform" class="form-horizontal" action="<?php echo e(route('user-profile-image-delete',$user->id)); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo $__env->make('includes.form-error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        <?php echo e(csrf_field()); ?>


                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard add-product-1 area -->
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade locationModal" ng-app="locationSelector" ng-controller="LocationController" tabindex="-1" role="dialog" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog" role="document">
            <div class="modal-content" style="margin-top: 0;">
            <div class="modal-header text-center" style="border-bottom: none;padding-bottom: 0">
                <h4><strong>SET A LOCATION</strong></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="fa fa-times"></i>
                </button>
            </div>
            <h6 style="margin-left: 15px;">Drag the pin to your exact location</h6>
    
            <div class="modal-body text-center">
        
                <div class="input-group g-pb-13 g-px-0 g-mb-10">
              
                    <input 
                      places-auto-complete size=80
                      types="['geocode']"
                      component-restrictions="{country:'np'}"
                      on-place-changed="placeChanged()"
                      id="googleLocation" 
                      ng-model="address.Address" 
                      class="form-control g-brd-none g-brd-bottom g-brd-black g-brd-primary--focus g-color-black g-bg-transparent rounded-0" type="text" placeholder="Select Area" autocomplete="off">
                      
                    <button class="btn  u-btn-neutral rounded-0" type="button" ng-click="getLocation()"><i class="fa fa-crosshairs"></i></button>
                </div>
                <p ng-if="error" style="color:red;text-align: left">{{ error }}</p>
    
                
    
                <ng-map center="[27.7041765,85.3044636]" zoom="15" draggable="true">
                    <marker position="27.7041765,85.3044636" title="Drag Me!" draggable="true" on-dragend="dragEnd($event)"></marker>
                </ng-map>
            </div>
            <div class="modal-footer" style="border-top: none; text-align: center; display: block;">
                <button type="button" ng-disabled="!isValidGooglePlace" class="btn btn-primary" style="width:100%" ng-click="confirmLocation()">Confirm</button>
            </div>
            </div>
        </div>
    </div>
    <script>
        $('#datepicker').datepicker({
            uiLibrary: 'bootstrap4'
        });
    </script>

   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


    <script type="text/javascript">

        function uploadclick(){
            $("#uploadFile").click();
            $("#uploadFile").change(function(event) {
                readURL(this);
                $("#uploadTrigger").html($("#uploadFile").val());
            });

        }

        // function delclick(){
        //  document.getElementById('adminimg').src='<?php echo e(asset('assets/images/noimage.png')); ?>'
        //     // $("#uploadFile").click();
        //     // $("#uploadFile").change(function(event) {
        //     //     document.getElementById('adminimg').src='<?php echo e(asset('assets/images/noimage.png')); ?>'
        //     //     $("#delTrigger").html($("#uploadFile").val());
        //     // });

        // }

        // function deleteURL(input) {
        //     if (input.files && input.files[0]) {
        //         var reader = new FileReader();
        //         reader.onload = function (e) {
        //             $('#adminimg').attr('src', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQikVhGsLPMUq5TInJ--3ossfcT7ZyDUFM9e0mOgSQN6TEHQugJ' );
        //         }
        //         reader.readAsDataURL(input.files[0]);
        //     }
        // }

        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#adminimg').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

    </script>

<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script>
$(document).ready(function(){
    $("#deletebutton").click(function(){        
        $("#deleteform").submit(); // Submit the form
    });
});
</script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.7.8/angular.min.js"></script>
    <script src="/assets/front/js/ng-map.min.js"></script>
    <script src="https://maps.google.com/maps/api/js?key=AIzaSyAcvyYLSF2ngh8GM7hX7EQ3dIcQGbGnx5Q&libraries=places"></script>
    <script src="/assets/front/js/location.js"></script>



<script src="<?php echo e(asset('assets/admin/js/jqueryui.min.js')); ?>"></script>  



<script>
     $(function() {
        $( "#dob" ).datepicker({ 
            dateFormat: 'yy-mm-dd',
            yearRange: '1950:c+1' ,
            changeMonth: true,
            changeYear: true,
            minDate: new Date(1950, 10 - 1, 25),
            maxDate: '+30Y',
        });
    });

 </script>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>