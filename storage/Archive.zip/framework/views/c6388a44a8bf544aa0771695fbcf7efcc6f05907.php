      <?php 
        $user_notf = App\Notification::where('user_id','!=',null)->orWhere('vendor_id','!=',null)->where('is_read','=',0)->orderBy('id','desc')->get();
        $order_notf = App\Notification::where('order_id','!=',null)->where('vendor_id',null)->where('is_read','=',0)->orderBy('id','desc')->get();
        $prescription_notf = App\Notification::where('prescription_id','!=',null)->where('is_read','=',0)->orderBy('id','desc')->get();
        $product_notf = App\Notification::where('product_id','!=',null)->where('is_read','=',0)->orderBy('id','desc')->get();
        $conv_notf = App\Notification::where('conversation_id','!=',null)->where('is_read','=',0)->orderBy('id','desc')->get();
       ?>                                      

<link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-line/css/simple-line-icons.css">
<link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-etlinefont/style.css">
<link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-line-pro/style.css">
<link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-hs/style.css">


                                            <div class="col-lg-6 col-md-7 col-sm-7 col-xs-12">
                                                <div class="profile-info dropdown">
                                                    <div class="profile-comments" style="padding:0 15px;">
                                                        <a class="dropdown-toggle" id="conv_notf" href="" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                                            <i class="icon-envelope" style="font-size:32px;"></i>
                                                            <span id="notf_conv" style="top:-26px; background:green;"><?php echo e($conv_notf->count()); ?></span>
                                                        </a>

                                                        <div class="profile-notifi-content dropdown-menu">
                                                            
                                                        </div>
                                                    </div>
                                                    

                                                    <div class="profile-notifi"  style="padding:0 5px;">
                                                        <a class="dropdown-toggle" id="order_notf" href="" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                                            <i class="icon-bell" style="font-size:30px;"></i>
                                                            <span id="notf_order" style="top:-26px; background:#d9534f;" ><?php echo e($order_notf->count()); ?></span>
                                                        </a>

                                                        <div class="profile-notifi-content dropdown-menu">
                                                          
                                                        </div>
                                                    </div>

                                                    

                                                    <div class="profile-comments"  style="padding:0 15px;">
                                                        <a class="dropdown-toggle" id="product_notf" href="" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                                            <i class="fa fa-flag-o" style="font-size:30px;"></i>                                                        
                                                            <span id="notf_product" style="top:-23px;"><?php echo e($product_notf->count()); ?></span>
                                                        </a>

                                                        <div class="profile-comments-content dropdown-menu">
                                                            
                                                        </div>
                                                    </div>

                                                    <div class="view-profile">
                                                        <div class="profile__img dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                                            <img src="<?php echo e(Auth::guard('admin')->user()->photo ? asset('assets/images/'.Auth::guard('admin')->user()->photo):asset('assets/images/user.png')); ?>" alt="profile image"> <span><?php echo e(Auth::guard('admin')->user()->name); ?></span> <i class="icon-options-vertical"></i>
                                                        </div>
                                                        <div class="profile-content dropdown-menu">
                                                            <h5>Welcome!</h5>
                                                            <a style="margin-left: 4px;" href="<?php echo e(route('admin-profile')); ?>"><i class="icon-user"></i>Edit Profile</a>
                                                            <a href="<?php echo e(route('admin-password-reset')); ?>"><i class="icon-settings"></i>Change Password</a>
                                                            
                                                            <a href="<?php echo e(route('admin-logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><i class="icon-logout"></i>Logout</a>
                                                            <form id="logout-form" action="<?php echo e(route('admin-logout')); ?>" method="POST" style="display: none;">
                                                                <?php echo e(csrf_field()); ?>

                                                            </form>
                                                        </div>
                                                    </div>
                                                </div> 
                                            </div>