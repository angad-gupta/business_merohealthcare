<?php $__env->startSection('title','FAQs'); ?>
<?php $__env->startSection('content'); ?>

    <!-- Starting of Section title overlay area -->
    <div class="title-overlay-wrap overlay" style="background-image: url(<?php echo e(asset('assets/images/'.$gs->bgimg)); ?>);">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 text-center">
            <h1><?php echo e($lang->faqs); ?></h1>
          </div>
        </div>
      </div>
    </div>
    <!-- Ending of Section title overlay area -->

<!-- Starting of faq area -->
        <div class="container">
            <div class="section-padding">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="styled-faq">
                            <h3  dir="<?php echo e($lang->rtl == 1 ? 'rtl':''); ?>"><?php echo e($lang->maq); ?></h3>
                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="heading<?php echo e($fq->id); ?>">
                                        <h4  dir="<?php echo e($lang->rtl == 1 ? 'rtl':''); ?>" class="panel-title">
                                            <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($fq->id); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($fq->id); ?>">
                                                <span><?php echo e($fq->title); ?></span>
                                                <i class="fa fa-plus"></i>
                                                <i class="fa fa-minus"></i>
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapse<?php echo e($fq->id); ?>" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="heading<?php echo e($fq->id); ?>">
                                        <div class="panel-body"  dir="<?php echo e($lang->rtl == 1 ? 'rtl':''); ?>">
                                        <?php echo $fq->text; ?>

                                        </div>
                                    </div>
                                </div>
                                <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="heading<?php echo e($faq->id); ?>">
                                        <h4 dir="<?php echo e($lang->rtl == 1 ? 'rtl':''); ?>" class="panel-title">
                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($faq->id); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($faq->id); ?>">
                                                <span><?php echo e($faq->title); ?></span>
                                                <i class="fa fa-plus"></i>
                                                <i class="fa fa-minus"></i>
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapse<?php echo e($faq->id); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading<?php echo e($faq->id); ?>">
                                        <div class="panel-body"  dir="<?php echo e($lang->rtl == 1 ? 'rtl':''); ?>">
                                        <?php echo $faq->text; ?>

                                        </div>
                                    </div>
                                </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Ending of faq area -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>