<?php $__env->startSection('content'); ?>   

<link rel="shortcut icon" href="/frontend-assets/main-assets/favicon.ico">
  <!-- Google Fonts -->
  
  <!-- CSS Global Compulsory -->
  
  <!-- CSS Global Icons -->
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-line/css/simple-line-icons.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-etlinefont/style.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-line-pro/style.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-hs/style.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/slick-carousel/slick/slick.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/hs-megamenu/src/hs.megamenu.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/hamburgers/hamburgers.min.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/animate.css">
  <!-- CSS Unify -->


  <!-- CSS Customization -->


<style>
.title-stats {
    position: relative;
    display: block;
    background-color: #303641;
    color: #777;
    padding: 10px 20px 20px;
    margin-bottom: 30px;
    border-radius: 5px;
    transition: .4s;
}

.title-stats .icon {
    color: #2385aa;
    position: absolute;
    right: 5px;
    bottom: 8px;
}
.title-stats:hover {color: #2385aa;}

.title-stats .icon i {
    font-size: 80px;
    line-height: 0;
}

h4{
    width:80%;
}

</style>



        <div class="right-side">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <!-- Starting of Dashboard header items area -->
                        <div class="panel panel-default admin">
                            <div class="panel-heading admin-title">
                                <div class="product__header" style="border-bottom: none;">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-8 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title">
                                                    <h2 style="font-size: 25px;"><?php echo e($lang->user_dashboard); ?> </h2>
                                                </div>
                                            </div>
                                              <?php echo $__env->make('includes.user-notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </div>   
                                    </div></div>
                            <div class="panel-body dashboard-body">
                                <div class="dashboard-header-area">
                                    <div class="row">
                                        <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                            
                                            <a href="<?php echo e(route('user-wishlist')); ?>" class="title-stats title-red" style="background:transparent;">
                                                <div class="icon"><i class="icon-medical-022 u-line-icon-pro fa-5x"></i></div>
                                                <div class="number"><?php echo e(count($wishes)); ?></div>
                                                <h4><?php echo e($lang->favorite_product); ?></h4>
                                                
                                            </a>
                                        </div>

                                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                            <a href="<?php echo e(route('user-orders')); ?>" class="title-stats title-cyan" style="background:transparent;">
                                                <div class="icon"><i class="icon-transport-069 u-line-icon-pro fa-5x"></i></div>
                                                <div class="number"><?php echo e($process); ?> </div>
                                                <h4><?php echo e($lang->order_processing); ?></h4>
                                                
                                            </a>
                                        </div>

                                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                            <a href="<?php echo e(route('user-orders')); ?>" class="title-stats title-green" style="background:transparent;">
                                                <div class="icon"><i class="icon-check fa-5x"></i></div>
                                                <div class="number"><?php echo e($complete); ?></div>
                                                <h4><?php echo e($lang->order_completed); ?></h4>
                                                
                                            </a>
                                        </div>
                                        
                                        <?php if(Auth::guard('user')->user()->IsVendor()): ?> 
                                            
                                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                                <a class="title-stats title-purple" href="<?php echo e(route('vendor-lab-order-index')); ?>" style="background:transparent;">
                                                    <div class="icon"><i class="icon-medical-010 u-line-icon-pro fa-5x"></i></div>
                                                    <div class="number"><?php echo e(Modules\Lab\Entities\LabOrder::where('vendor_id','=',$user->id)->count()); ?></div>
                                                    <h4>Total Lab Orders</h4>
                                                    

                                                </a>
                                            </div>
                                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                                <a  class="title-stats title-blue" style="background:transparent;">
                                                    <div class="icon"><i class="icon-check fa-5x"></i></div>
                                                    <div style="font-size: 38px; font-weight: 600;"><?php echo e($currency_sign->sign); ?> <?php echo e(number_format(Modules\Lab\Entities\LabOrder::where('user_id','=',$user->id)->where('status','completed')->sum('pay_amount')  * $currency_sign->value,2)); ?></div>
                                                    <h4><?php echo e($lang->total_earning); ?></h4>
                                                    

                                                </a>
                                            </div>
                                        <?php else: ?>
                                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12" >
                                                <a class="title-stats title-purple" href="<?php echo e(route('user-lab-order-index')); ?>" style="background:transparent;">
                                                    <div class="icon"><i class="icon-medical-010 u-line-icon-pro fa-5x"></i></div>
                                                    <div class="number"><?php echo e(Modules\Lab\Entities\LabOrder::where('user_id','=',$user->id)->where('status','processing')->count()); ?></div>
                                                    <h4>Lab <?php echo e($lang->order_processing); ?></h4>
                                                    

                                                </a>
                                            </div>
                                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                                <a  class="title-stats title-blue" href="<?php echo e(route('user-lab-order-index')); ?>" style="background:transparent;">
                                                    <div class="icon"><i class="icon-check fa-5x"></i></div>
                                                    <div class="number"><?php echo e(Modules\Lab\Entities\LabOrder::where('user_id','=',$user->id)->where('status','completed')->count()); ?></div>
                                                    <h4>Lab <?php echo e($lang->order_completed); ?></h4>
                                                    

                                                </a>
                                            </div>

                                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12" >
                                                <a class="title-stats title-purple" href="<?php echo e(route('user-prescriptions.index')); ?>" style="background:transparent;">
                                                    <div class="icon"><i class="icon-medical-099 u-line-icon-pro fa-5x"></i></div>
                                                    <div class="number"><?php echo e(App\Prescription::where('user_id','=',$user->id)->where('status','processing')->count()); ?></div>
                                                    <h4>Prescription <?php echo e($lang->order_processing); ?></h4>
                                                    

                                                </a>
                                            </div>
                                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                                <a  class="title-stats title-blue" href="<?php echo e(route('user-prescriptions.index')); ?>" style="background:transparent;">
                                                    <div class="icon"><i class="icon-check fa-5x"></i></div>
                                                    <div class="number"><?php echo e(App\Prescription::where('user_id','=',$user->id)->where('status','completed')->count()); ?></div>
                                                    <h4>Prescription <?php echo e($lang->order_completed); ?></h4>
                                                    

                                                </a>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Ending of Dashboard header items area -->


                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>