<?php $__env->startSection('content'); ?>

<link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Marck+Script&display=swap" rel="stylesheet">
<style>
    .number{
        color:#2385aa;
    }
    h4{
        color:#999;
        font-size:15px;
    }

    .title-stats .icon i {
    font-size: 30px;
    line-height: 0;
    }
    .title-stats .icon {
    color: rgba(0, 0, 0, 0.1);
    position: absolute;
    right: 20px;
    bottom: 8px;
}
 
.u-block-hover:hover .u-block-hover__additional--jump,
.u-block-hover.u-block-hover__additional--jump:hover {
  transform: translate3d(0, -10px, 0);
}



.u-shadow-v19 {
    box-shadow: 0 5px 10px -6px rgba(0, 0, 0, 0.1);
}
.title-stats h4 {
    margin-bottom: 10px;
    font-weight: 300;
}
.title-stats .number {
    font-size: 22px;
    font-weight: 400;
}

/* Blue Shadow */
@-moz-keyframes blue {
  0%,
  100% {
    -moz-box-shadow: 1px 0px 19px 4px rgba(0, 130, 196, 0.7),
      inset 0px 0px 10px rgba(255, 255, 255, 0.5);
    box-shadow: 1px 0px 19px 4px rgba(0, 130, 196, 0.7),
      inset 0px 0px 10px rgba(255, 255, 255, 0.5);
  }

  50% {
    -moz-box-shadow: 0px 0px 0px 0px rgba(0, 130, 196, 0),
      inset 0px 0px 0px rgba(255, 255, 255, 0);
    box-shadow: 0px 0px 0px 0px rgba(0, 130, 196, 0),
      inset 0px 0px 0px rgba(255, 255, 255, 0);
  }
}

@-webkit-keyframes blue {
  0%,
  100% {
    -webkit-box-shadow: 1px 0px 19px 4px rgba(0, 130, 196, 0.7),
      inset 0px 0px 10px rgba(255, 255, 255, 0.5);
    box-shadow: 1px 0px 19px 4px rgba(0, 130, 196, 0.7),
      inset 0px 0px 10px rgba(255, 255, 255, 0.5);
  }

  50% {
    -webkit-box-shadow: 0px 0px 0px 0px rgba(0, 130, 196, 0),
      inset 0px 0px 0px rgba(255, 255, 255, 0);
    box-shadow: 0px 0px 0px 0px rgba(0, 130, 196, 0),
      inset 0px 0px 0px rgba(255, 255, 255, 0);
  }
}

@-o-keyframes blue {
  0%,
  100% {
    box-shadow: 1px 0px 19px 4px rgba(0, 130, 196, 0.7),
      inset 0px 0px 10px rgba(255, 255, 255, 0.5);
  }

  50% {
    box-shadow: 0px 0px 0px 0px rgba(0, 130, 196, 0),
      inset 0px 0px 0px rgba(255, 255, 255, 0);
  }
}

@keyframes  blue {
  0%,
  100% {
    box-shadow: 1px 0px 19px 4px rgba(0, 130, 196, 0.7),
      inset 0px 0px 10px rgba(255, 255, 255, 0.5);
  }

  50% {
    box-shadow: 0px 0px 0px 0px rgba(0, 130, 196, 0),
      inset 0px 0px 0px rgba(255, 255, 255, 0);
  }
}

@-moz-keyframes yellow {
  0%,
  100% {
    -moz-box-shadow: 1px 0px 19px 4px #fff503,
      inset 0px 0px 10px rgba(255, 255, 255, 0.5);
    box-shadow: 1px 0px 19px 4px #fff503,
      inset 0px 0px 10px rgba(255, 255, 255, 0.5);
  }

  50% {
    -moz-box-shadow: 0px 0px 0px 0px rgba(255, 245, 3, 0),
      inset 0px 0px 0px rgba(255, 255, 255, 0);
    box-shadow: 0px 0px 0px 0px rgba(255, 245, 3, 0),
      inset 0px 0px 0px rgba(255, 255, 255, 0);
  }
}

@-webkit-keyframes yellow {
  0%,
  100% {
    -webkit-box-shadow: 1px 0px 19px 4px #fff503,
      inset 0px 0px 10px rgba(255, 255, 255, 0.5);
    box-shadow: 1px 0px 19px 4px #fff503,
      inset 0px 0px 10px rgba(255, 255, 255, 0.5);
  }

  50% {
    -webkit-box-shadow: 0px 0px 0px 0px rgba(255, 245, 3, 0),
      inset 0px 0px 0px rgba(255, 255, 255, 0);
    box-shadow: 0px 0px 0px 0px rgba(255, 245, 3, 0),
      inset 0px 0px 0px rgba(255, 255, 255, 0);
  }
}

@-o-keyframes yellow {
  0%,
  100% {
    box-shadow: 1px 0px 19px 4px #fff503,
      inset 0px 0px 10px rgba(255, 255, 255, 0.5);
  }

  50% {
    box-shadow: 0px 0px 0px 0px rgba(255, 245, 3, 0),
      inset 0px 0px 0px rgba(255, 255, 255, 0);
  }
}

@keyframes  yellow {
  0%,
  100% {
    box-shadow: 1px 0px 19px 4px #fff503,
      inset 0px 0px 10px rgba(255, 255, 255, 0.5);
  }

  50% {
    box-shadow: 0px 0px 0px 0px rgba(255, 245, 3, 0),
      inset 0px 0px 0px rgba(255, 255, 255, 0);
  }
}

.blue {
  /* text-shadow: 0px 1px 0px #83e0f7; */
  /* background-image: -webkit-linear-gradient(top, #87e0fd, #53cbf1);
  background-image: -moz-linear-gradient(top, #87e0fd, #53cbf1);
  background-image: -o-linear-gradient(top, #87e0fd, #53cbf1);
  background-image: linear-gradient(to bottom, #87e0fd, #53cbf1); */
  -webkit-animation: blue 2s infinite;
  -moz-animation: blue 2s infinite;
  -o-animation: blue 2s infinite;
  animation: blue 4s infinite;
}
.yellow {
  text-shadow: 0px 1px 0px #faffc7;
  background-image: -webkit-linear-gradient(top, #fff966, #f3fd80);
  background-image: -moz-linear-gradient(top, #fff966, #f3fd80);
  background-image: -o-linear-gradient(top, #fff966, #f3fd80);
  background-image: linear-gradient(to bottom, #fff966, #f3fd80);
  -webkit-animation: yellow 2s infinite;
  -moz-animation: yellow 2s infinite;
  -o-animation: yellow 2s infinite;
  animation: yellow 4s infinite;
}

.title-stats {
    position: relative;
    display: block;
    background-color: #303641;
    color: #fff;
    padding: 10px 20px 20px;
    margin-bottom: 30px;
    border-radius: 25px;
    transition: .4s;
}


</style>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>

       <div class="right-side">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <!-- Starting of Dashboard header items area -->
                        <div class="panel panel-default admin">
                          <div class="panel-heading admin-title">
                                <div class="product__header" style="border-bottom: none;">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title" style="display: inline-flex;">
                                                    <span><h2 style="font-family: '', cursive;font-size:30px;color:#0583b5;">Business</h2></span> <span><h2 style="font-family: '', cursive;font-size:30px;color:#ea7272;">Meorohealthcare</h2></span> <span><h2 style="font-family: '', cursive;font-size:30px;color:#42a95e;">&nbsp;Admin</h2></span><span><h2 style="font-family: '', cursive;font-size:30px;color:#d49221;"> Dashboard</h2></span>
                                                </div>
                                            </div>
                                              <?php echo $__env->make('includes.notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </div>   
                                    </div>
                            </div>
                              <div class="panel-body dashboard-body" style="background-color:#eee;" >
                                  <div class="dashboard-header-area">


                                    <div class="row">
                                        <div class="col-sm-12">
                                            <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                            <?php if($activation_notify != ""): ?>
                                                <div class="alert alert-danger validation">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                                                    <h3 class="text-center"><?php echo $activation_notify; ?></h3>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <h4 class="h4 g-font-weight-200 g-mb-20" style="margin-left: 15px;font-weight:600;color:#555;">Sales</h4>
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                            <a href="#" class="title-stats title-teal u-block-hover u-block-hover__additional--jump u-shadow-v19" style="background-color:white; ">
                                                <div class="icon"><i class="icon-finance-260 u-line-icon-pro" style="color:green"></i></div>
                                                <?php 
                                                    $sales = App\Order::where('status','completed')->sum('pay_amount');
                            
                                                 ?>
                                                <div class="counting-sec"><div style="font-size: 22px;font-weight: 400;color:#2385aa">Rs.<span class="num"><?php echo e(number_format($sales)); ?></span></div></div>
                                                <h4>Total Sales!</h4>
                                           
                                            </a>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                            <a href="<?php echo e(route('admin-order-processing')); ?>" class="title-stats title-teal u-block-hover u-block-hover__additional--jump u-shadow-v19" style="background-color:white; ">
                                                <div class="icon"><i class="icon-finance-260 u-line-icon-pro" style="color:orange"></i></div>
                                                <?php 
                                                    $sales = App\Order::where('status','=','processing')->sum('pay_amount');
                            
                                                 ?>
                                                <div style="font-size: 22px;font-weight: 400;color:#2385aa">Rs.<span class="num"><?php echo e(number_format($sales)); ?></span></div>
                                                <h4>Processing Sales!</h4>
                                           
                                            </a>
                                        </div>

                                     
                                    </div>
                                  
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12" >
                                    <h4 class="h4 g-font-weight-200 g-mb-20" style="margin-left: 15px;font-weight:600;color:#555;">Overview</h4>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <a href="#" class="title-stats title-teal u-block-hover u-block-hover__additional--jump u-shadow-v19" style="background-color:white; ">
                                            <div class="icon"><i class="icon-finance-260 u-line-icon-pro" style="color:red"></i></div>
                                            <?php 
                                                $sales = App\Order::where('status','declined')->sum('pay_amount');
                        
                                             ?>
                                            <div style="font-size: 22px;font-weight: 400;color:#2385aa">Rs.<span class="num"><?php echo e(number_format($sales)); ?></span></div>
                                            <h4>Declined Sales!</h4>
                                       
                                        </a>
                                    </div>
                                  
                                    
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <a href="#" class="title-stats title-teal u-block-hover u-block-hover__additional--jump u-shadow-v19" style="background-color:white; ">
                                            <div class="icon"><i class="icon-chart" style="color:#696969"></i></div>
                                            <?php 
                                                $cod = App\Order::where('status','=','completed')->where('method','Cash On Delivery')->sum('pay_amount');
                                                $online = App\Order::where('status','=','completed')->where('method','!=','Cash On Delivery')->sum('pay_amount');
                                             ?>
                                            <div style="font-size: 15px;font-weight: 400;color:#2385aa">Rs.<span class="num" style="font-size:15px;"><?php echo e(number_format($cod)); ?></span><span style="font-size:12px; color:green"> Cash<br/></span> Rs.<span class="num" style="font-size:15px;"><?php echo e(number_format($online)); ?></span> <span style="font-size:12px;color:orange">Online</span></div>
                                            <h4>Payment Received</h4>
                                       
                                        </a>
                                    </div>
                              
                                    </div>
                                </div>
                                    
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                            <?php if($activation_notify != ""): ?>
                                                <div class="alert alert-danger validation">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                                                    <h3 class="text-center"><?php echo $activation_notify; ?></h3>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <h4 class="h4 g-font-weight-200 g-mb-20" style="margin-left: 15px;font-weight:600;color:#555;">Products</h4>
                                        <div class="col-lg-6 col-md-6 col-sm-4 col-xs-12 ">
                                            <a href="<?php echo e(route('admin-prod-index')); ?>" class="title-stats title-red u-block-hover u-block-hover__additional--jump u-shadow-v19" style="background-color:white; ">
                                                <?php 
                                                $admin_products = App\Product::where('user_id','=','0')->get();;
                                                 ?>
                                                <div class="icon"><i class="icon-finance-100 u-line-icon-pro" style="color: #2385aa"></i></div>
                                                <div class="number"><?php echo e(count($admin_products)); ?></div>
                                                <h4>Admin Products !</h4>
                                          
                                            </a>
                                        </div>

                                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                            <a href="<?php echo e(route('admin-user-index')); ?>" class="title-stats title-red u-block-hover u-block-hover__additional--jump u-shadow-v19" style="background-color:white; ">
                                                <div class="icon"><i class="icon-people" style="color:#f56954"></i></div>
                                                <div class="number"><?php echo e(count($users)); ?></div>
                                                <h4>Total!</h4>
                                          
                                            </a>
                                        </div>

                                        

                                        
                                    </div>
                                  
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12" >
                                        <h4 class="h4 g-font-weight-200 g-mb-20" style="margin-left: 15px;font-weight:600;color:#555;">Purchase Orders</h4>
                                            
                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                <a href="<?php echo e(route('admin-order-processing')); ?>" class="yellow title-stats title-orange u-block-hover u-block-hover__additional--jump u-shadow-v19" style="background: white">
                                                    <div class="icon"><i class="fa fa-truck fa-5x" style="color:orange"></i></div>
                                                    <div class="number"><?php echo e(count($processing)); ?></div>
                                                    <h4><i class="fa fa-spinner fa-spin"></i>
                                                        <span class="sr-only">Loading...</span>Orders Pending! </h4>
                                        
                                                </a>
                                            </div>
                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                <a href="<?php echo e(route('admin-order-completed')); ?>" class="title-stats title-green u-block-hover u-block-hover__additional--jump u-shadow-v19" style="background: white">
                                                    <div class="icon"><i class="fa fa-check fa-5x" style="color:green;"></i></div>
                                                    <div class="number"><?php echo e(count($completed)); ?></div>
                                                    <h4>Orders Completed!</h4>
                                               
                                                </a>
                                            </div>
                                        </div>
                                </div>
                                <div class="row">
                                 

                                  

                                  
                                </div>

                                   

                                    <div class="row">

                                        

                                        


                               
                                      
                                    </div>
                                    

                                  
                            </div>
                        </div>
                        <!-- Ending of Dashboard header items area -->

                    <!-- Starting of Dashboard Top reference + Most Used OS area -->
                    
                    <!-- Ending of Dashboard Top reference + Most Used OS area -->
                        <!-- Starting of Dashboard header items area -->
                        
                                        
            </div>
        </div>
    </div>
    <script type="text/javascript">
        $(".num").counterUp({delay:10,time:3000});
      </script>

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.js"></script>



    <script language="JavaScript">
        displayLineChart();
        function displayLineChart() {
            var data = {
                labels: [
                    <?php echo $days; ?>

                ],
                datasets: [
                    {
                        label: "Prime and Fibonacci",
                        fillColor: "#3dbcff",
                        strokeColor: "#0099ff",
                        pointColor: "rgba(220,220,220,1)",
                        pointStrokeColor: "#fff",
                        pointHighlightFill: "#fff",
                        pointHighlightStroke: "rgba(220,220,220,1)",
                        data: [
                            <?php echo $sales; ?>

                        ]
                    }
                ]
            };
            var ctx = document.getElementById("lineChart").getContext("2d");
            var options = {
                responsive: true
            };
            var lineChart = new Chart(ctx).Line(data, options);
        }
        </script>

<script type="text/javascript">
        var chart1 = new CanvasJS.Chart("chartContainer-topReference",
            {
                exportEnabled: true,
                animationEnabled: true,

                legend: {
                    cursor: "pointer",
                    horizontalAlign: "right",
                    verticalAlign: "center",
                    fontSize: 16,
                    padding: {
                        top: 20,
                        bottom: 2,
                        right: 20,
                    },
                },
                data: [
                    {
                        type: "pie",
                        showInLegend: true,
                        legendText: "",
                        toolTipContent: "{name}: <strong>{#percent%} (#percent%)</strong>",
                        indexLabel: "#percent%",
                        indexLabelFontColor: "white",
                        indexLabelPlacement: "inside",
                        dataPoints: [
                                <?php $__currentLoopData = $referrals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $browser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    {y:<?php echo e($browser->total_count); ?>, name: "<?php echo e($browser->referral); ?>"},
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        ]
                    }
                ]
            });
        chart1.render();

        var chart = new CanvasJS.Chart("chartContainer-os",
            {
                exportEnabled: true,
                animationEnabled: true,
                legend: {
                    cursor: "pointer",
                    horizontalAlign: "right",
                    verticalAlign: "center",
                    fontSize: 16,
                    padding: {
                        top: 20,
                        bottom: 2,
                        right: 20,
                    },
                },
                data: [
                    {
                        type: "pie",
                        showInLegend: true,
                        legendText: "",
                        toolTipContent: "{name}: <strong>{#percent%} (#percent%)</strong>",
                        indexLabel: "#percent%",
                        indexLabelFontColor: "white",
                        indexLabelPlacement: "inside",
                        dataPoints: [
                            <?php $__currentLoopData = $browsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $browser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                {y:<?php echo e($browser->total_count); ?>, name: "<?php echo e($browser->referral); ?>"},
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        ]
                    }
                ]
            });
        chart.render();    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>