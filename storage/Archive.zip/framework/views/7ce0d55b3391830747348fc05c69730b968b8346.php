
<?php $__env->startSection('title','Checkout'); ?>

<?php $__env->startSection('content'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" />
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
 <!-- Starting of checkOut area -->

 <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" rel="stylesheet" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>

<style>
#drop-zone {
  width: 100%;
  min-height: 150px;
  border: 1px dashed rgba(0, 0, 0, .3);
  border-radius: 5px;
  font-family: Arial;
  text-align: center;
  position: relative;
  font-size: 20px;
  color: #7E7E7E;
}
#drop-zone input {
  position: absolute;
  cursor: pointer;
  left: 0px;
  top: 0px;
  opacity: 0;
}
/*Important*/

#drop-zone.mouse-over {
  border: 3px dashed rgba(0, 0, 0, .3);
  color: #7E7E7E;
}
/*If you dont want the button*/

#clickHere {
  display: inline-block;
  cursor: pointer;
  color: white;
  font-size: 17px;
  width: 150px;
  border-radius: 4px;
  background-color: #2385aa;
  padding: 10px;
}
#clickHere:hover {
  background-color: #376199;
}
#filename {
  margin-top: 10px;
  margin-bottom: 10px;
  font-size: 14px;
  line-height: 1.5em;
}
.file-preview {
  background: #ccc;
  border: 1px solid #fff;
  box-shadow: 0 0 4px rgba(0, 0, 0, 0.5);
  display: inline-block;
  width: 60px;
  height: 60px;
  text-align: center;
  font-size: 14px;
  margin-top: 5px;
}
.closeBtn:hover {
  color: red;
  display:inline-block;
}
}
</style>

 <style>
    

.product-checkOut-wrap .form-group {
    margin-bottom: 8px;
}

.product-checkOut-wrap .form-control {
    box-shadow: none;
    border-radius: 30px;
    height: 30px;
}

hr {
    margin-top: 1rem;
    margin-bottom: 1rem;
}
 @media(min-width:320px) and (max-width:768px){
    #history-prescription{
      height:40px !important;
    }
    }
    </style>
    <?php 
        $user = Auth::guard('user')->user();
     ?>

<script type="text/javascript">
    function validateForm() {
      var a = document.forms["Form"]["filename[]"].value;
      var b = document.forms["Form"]["fileid[]"].value;
 
      if (a == "" && b == "") {
        alert("Please Select Prescription File");
        // document.getElementById("textbox1").required = true;
        return false;
      }

    
    }
  </script>
  
  


    <form name="Form" action="<?php echo e(route('payment.submit')); ?>" method="post" id="payment_form" onsubmit="return validateForm()" enctype="multipart/form-data" >

        <div class="section-padding product-checkOut-wrap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <h4 class="signIn-title"><?php echo e($lang->odetails); ?></h4>
                        <hr>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th><?php echo e($lang->cproduct); ?></th>
                                        <th></th>
                                        <th><?php echo e($lang->cupice); ?></th>
                                        <th><?php echo e($lang->cquantity); ?></th>
                                        <th><?php echo e($lang->cst); ?></th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        $priceDiscount = 0;
                                     ?>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                            
                                            $price = $product['item']['pprice'] ? : $product['item']['cprice'];
                                            
                                         ?>
                                        <tr>
                                            <td><a href="<?php echo e(route('front.product',[$product['item']['id'],str_slug($product['item']['name'],'-')])); ?>" target="_blank"><?php echo e($product['item']['name']); ?></a>
                                            
                                            
                                            </td>
                                            <?php if($user): ?>
                                                <td>
                                                
                                                  
                                                </td>
                                            <?php else: ?>
                                                <td></td>
                                            <?php endif; ?>

                                            
                                            <td><?php echo e($curr->sign); ?><?php echo e(round($price * $curr->value , 2)); ?></td>
                                            <td><?php echo e($product['qty']); ?>  <?php echo e($product['item']['measure']); ?>

                                                
                                                <?php if(App\Product::findOrFail($product['item']['id'])->prices()->where('min_qty','<=',$product['qty'])->exists()): ?>
                                                        <?php 
                                                        $p = App\Product::findOrFail($product['item']['id'])->prices()->where('min_qty','<=',$product['qty'])->orderBy('min_qty','desc')->first();
                                                        $quotient = (int)($product['qty'] / $p->min_qty);
                                                         ?>
                                                        <?php if(($quotient * $p->product_free_quantity) != 0): ?>
                                                            <span style="width:70px;">
                                                                + <?php echo e($quotient * $p->product_free_quantity); ?> <?php echo e($p->product_category); ?> Free             
                                                            </span> 
                                                        <?php endif; ?>
                                                <?php endif; ?>

                                            </td>
                                            <td>&nbsp;
                                                <?php if($gs->sign == 0): ?>
                                                    <?php echo e($curr->sign); ?><?php echo e(round($price * $product['qty'] * $curr->value , 2)); ?>

                                                <?php else: ?>
                                                    <?php echo e(round($price * $product['qty'] * $curr->value , 2)); ?><?php echo e($curr->sign); ?>

                                                <?php endif; ?>

                                                <?php 
                                                    $priceDiscount += round($price * $product['qty'] * $curr->value , 2) - round($product['price'] * $curr->value , 2);
                                                    
                                                 ?>
                                                
                                            </td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                                <tfoot>

                                    <?php if($priceDiscount > 0): ?>
                                        <tr id="">
                                            <th colspan="4">Price Discount:</th>
                                            <th>
                                                <?php if($gs->sign == 0): ?>
                                                    - <?php echo e($curr->sign); ?><span><?php echo e($priceDiscount); ?></span>
                                                <?php else: ?>
                                                    - <span><?php echo e($priceDiscount); ?></span><?php echo e($curr->sign); ?>

                                                <?php endif; ?>
                                            </th>
                                        </tr>
                                    <?php endif; ?>
                                    
                                    <tr id="discount" style="display: none;">
                                        <th colspan="4"><?php echo e($lang->ds); ?>(<span id="sign"></span>):</th>
                                        <th>
                                            <?php if($gs->sign == 0): ?>
                                            - <?php echo e($curr->sign); ?><span id="ds"></span>
                                            <?php else: ?>
                                            - <span id="ds"></span><?php echo e($curr->sign); ?>

                                            <?php endif; ?>
                                        </th>
                                    </tr>

                                    <tr id="shipshow">
                                        <th colspan="4"><?php echo e($lang->ship); ?>:</th>
                                        <th>&nbsp;
                                         
                                                <?php if($gs->sign == 0): ?>
                                                <?php echo e($curr->sign); ?><span id="ship-cost"><?php echo e(round($shipping_cost * $curr->value,2)); ?></span>
                                                <?php else: ?>
                                                <span id="ship-cost"><?php echo e(round($shipping_cost * $curr->value,2)); ?></span><?php echo e($curr->sign); ?>

                                                <?php endif; ?>
                                          
                                        </th>
                                    </tr>
                                    <?php if($gs->tax != 0): ?>
                                        <tr id="taxshow">
                                        <th colspan="4"><?php echo e($lang->tax); ?>(<?php echo e($gs->tax); ?>)%:</th>
                                            <th>
                                                &nbsp;
                                                <?php echo e($curr->sign); ?><?php echo e(round($vat,2)); ?>

                                              
                                              
                                            </th>
                                        </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <td colspan="4"><h5 style="font-weight:700;"><?php echo e($lang->vt); ?>:</h5></td>
                                        <td class="coupon-td">
                                            <h5 style="font-weight:700;">
                                                <?php if($gs->sign == 0): ?>
                                                &nbsp;&nbsp;<?php echo e($curr->sign); ?><span id="total-cost"><?php echo e(round($totalPrice * $curr->value ,2)); ?></span>
                                                <?php else: ?>
                                                    <span id="total-cost"> <?php echo e(round($totalPrice * $curr->value,2)); ?></span><?php echo e($curr->sign); ?>

                                                <?php endif; ?>
                                            </h5>
                                            <div class="coupon-click" id="coupon-click1">
                                                <p title="Get Discounts On Total Purchases Codes"><?php echo e($lang->cpn); ?> <span>*</span></p>
                                            </div>
                                        </td>
                                    </tr>

                                </tfoot>
                            </table>
                        </div>
                    </div>

                    <div class="col-lg-4 col-lg-offset-8 col-md-4 col-md-offset-8 col-sm-5 col-sm-offset-7">
                        <div class="coupon-code text-right">
                            
                                <div class="form form-group coupon-group" style="display: none;">
                                    <input class="form-control" type="text" id="code" placeholder="<?php echo e($lang->ecpn); ?>" autocomplete="off" style="text-transform:uppercase">
                                    <input type="hidden" id="">
                                    <button id="coupon" class="btn btn-md order-btn" type="button" style="border-radius:30px;"><?php echo e($lang->acpn); ?></button>
                                </div>
                            
                        </div>
                    </div>
                </div>


                

                

            
                
                    
                    
                    
                    
                    

                    
                                

              <br/>

                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                        <div class="billing-details-area">
                            <h4 class="signIn-title"><?php echo e($lang->bdetails); ?></h4>
                            <hr/>
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group" <?php echo $digital == 1 ? 'style="display:none;"' : ''; ?>>
                                    <select class="form-control" onchange="sHipping(this)" id="shipop" name="shipping" hidden required="">
                                        <option value="shipto" selected=""><?php echo e($lang->ships); ?></option>
                                        <option value="pickup"><?php echo e($lang->pickup); ?></option>
                                    </select>
                                </div>

                                <div id="pick" style="display:none;">
                                    <div class="form-group">
                                        <select class="form-control" name="pickup_location">
                                            <option value=""><?php echo e($lang->pickups); ?></option>
                                            <?php $__currentLoopData = $pickups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pickup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($pickup->location); ?>"><?php echo e($pickup->location); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <?php if(Auth::guard('user')->check()): ?>
                                    <?php 
                                        $user = Auth::guard('user')->user();
                                     ?>
                                    <div class="form-group">
                                        <label for="shippingFull_name"><?php echo e($lang->fname); ?> <span>*</span></label>
                                        <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" placeholder="<?php echo e($lang->fname); ?>" required="">
                                        
                                    </div>
                                    <div class="form-group">
                                        <label for="shippingFull_name"><?php echo e($lang->doph); ?>  <span>*</span></label>
                                        <input type="text" class="form-control" name="phone" value="<?php echo e($user->phone); ?>" placeholder="<?php echo e($lang->doph); ?> " required="">
                                    </div>
                                    <div class="form-group">
                                        <label for="shippingFull_name"><?php echo e($lang->doeml); ?> <span>*</span></label>
                                        <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>" placeholder="<?php echo e($lang->doeml); ?> " required="">
                                    </div>
                                    <div class="form-group">
                                        <label for="shippingFull_name">PAN Number *</label>
                                        <input type="text" class="form-control" name="pan_number" value="<?php echo e($user->pan_vat); ?>" placeholder="PAN Number" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Address Type  <span>*</span></label>
                                        <select class="form-control" name="address_type" required>
                                            <option value="" <?php echo e(!$user->address_type ? 'selected' : ''); ?> disabled>Select an option</option>
                                            <option value="Home" <?php echo e($user->address_type == 'Home' ? 'selected' : ''); ?>>Home</option>
                                            <option value="Office" <?php echo e($user->address_type == 'Office' ? 'selected' : ''); ?>>Office</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="geolocation"><?php echo e($lang->doad); ?> <i style="color:red;">(Delivery Within Nepal)</i> <span>*</span> </label>
                                        <input placeholder="<?php echo e($lang->doad); ?> " class="form-control" name="address" id="geolocation" style="resize: vertical;" required value="<?php echo e($user->address); ?>" onclick="$('#model-type').val('');$('.locationModal').modal('show');" autocomplete="off" />
                                        <input id="latlong" type="hidden" name="latlong" value="<?php echo e($user->latlong); ?>">

                                    </div>
                                    

                                    

                                    <div class="form-group">
                                        <label for="shippingFull_name"><?php echo e($lang->ctry); ?>  <span>*</span></label>
                                        <select class="form-control" required="" name="customer_country">
                                            <option value="Nepal" selected="selected">Nepal</option> 
                                            
                                            
                                        </select>
                                    </div>
                                    

                                    <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                                <?php else: ?>
                                    <div class="form-group">
                                        <label for="shippingFull_name"><?php echo e($lang->fname); ?> <span>*</span></label>
                                        <input type="text" class="form-control" name="name" value="" placeholder="<?php echo e($lang->fname); ?>" required="">
                                    </div>
                                    <div class="form-group">
                                        <label for="shippingFull_name"><?php echo e($lang->doph); ?>  <span>*</span></label>
                                        <input type="text" class="form-control" name="phone" value="" placeholder="<?php echo e($lang->doph); ?> " required="">
                                    </div>
                                    <div class="form-group">
                                        <label for="shippingFull_name"><?php echo e($lang->doeml); ?>  <span>*</span></label>
                                        <input type="email" class="form-control" name="email" value="" placeholder="<?php echo e($lang->doeml); ?> " required="">
                                    </div>

                                    <div class="form-group">
                                        <label for="shippingFull_name">PAN Number *</label>
                                        <input type="text" class="form-control" name="pan_number" value="" placeholder="PAN Number" >
                                    </div>
                                    <div class="form-group">
                                        <label for="shipping_addresss">Address Type  <span>*</span></label>
                                        <select class="form-control" name="address_type" required>
                                            <option value="" selected disabled>Select an option</option>
                                            <option value="Home">Home</option>
                                            <option value="Office">Office</option>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label for="geolocation"><?php echo e($lang->doad); ?>  <span>*</span> <i style="color:red;">(Delivery Within Nepal)</i></label>
                                        <input placeholder="<?php echo e($lang->doad); ?> " class="form-control" name="address" id="geolocation" style="resize: vertical;" onclick="$('#model-type').val('');$('.locationModal').modal('show');" autocomplete="off" />
                                        <input id="latlong" type="hidden" name="latlong" value="">
                                    </div>
                                    
                                    
                                    <div class="form-group">
                                        <label for="shippingFull_name"><?php echo e($lang->ctry); ?>  <span>*</span></label>
                                        <select class="form-control" required="" name="customer_country">
                                            
                                            <option value="Nepal" selected="selected">Nepal</option> 
                                        </select>
                                    </div>
                                    
                                    <input type="hidden" name="user_id" value="0">
                                <?php endif; ?>
                                
                                <input type="hidden" id="shipping-cost" name="shipping_cost" value="<?php echo e(round($shipping_cost * $curr->value,2)); ?>">
                                <input type="hidden" name="dp" value="<?php echo e($digital); ?>">
                                <input type="hidden" name="tax" value="<?php echo e($gs->tax); ?>">
                                <input type="hidden" name="totalQty" value="<?php echo e($totalQty); ?>">
                                <input type="hidden" name="total" id="grandtotal" value="<?php echo e(round($totalPrice * $curr->value,2)); ?>">
                                <input type="hidden" name="coupon_code" id="coupon_code" value="">
                                <input type="hidden" name="coupon_discount" id="coupon_discount" value="0">
                                <input type="hidden" name="coupon_id" id="coupon_id" value="">
                                
                        </div>
                    </div>

                    <div class="col-lg-6 col-md-6 colAuth-sm-12 col-xs-12" <?php echo $shipping_cost == 0 ? 'style="margin-top:0px;"' : ''; ?>>
                        
                        
                        <?php if(Auth::guard('user')->check()): ?>
                        <div class="shipping-title">
                            <span style="font-size:20px;">
                            <?php echo e($lang->shipss); ?>

                            </span>
                            <label class="form-check-inline u-check g-mr-20 mx-0 mb-0" id="ship-diff" style="top:-6px;">
                                <input class=" shippingCheck g-hidden-xs-up g-pos-abs g-top-0 g-right-0" name="shippingCheck" type="checkbox" value="check">
                                <div class="u-check-icon-radio-v7">
                                  <i class="fa" data-check-icon=""></i>
                                </div>
                              </label>
                              

                            
                            
                            <label id="pick-info" style="display: none;">
                                <?php echo e($lang->pickupss); ?>

                            </label>
                        </div>
                        <hr>
                        <?php endif; ?>
                        
                        <div class="shipping-details-area" style="display: none;">
                            <div class="form-group">
                                <label for="shippingFull_name"><?php echo e($lang->fname); ?>  <span>*</span></label>
                                <input class="form-control" type="text" name="shipping_name" id="shippingFull_name" placeholder="<?php echo e($lang->fname); ?> " >
                            </div>
                            <div class="form-group">
                                <label for="shipingPhone_number"><?php echo e($lang->doph); ?>  <span>*</span></label>
                                <input class="form-control" type="number" name="shipping_phone" id="shipingPhone_number" placeholder="<?php echo e($lang->doph); ?> ">
                            </div>
                            <div class="form-group">
                                <label for="ship_email"><?php echo e($lang->doeml); ?>  <span>*</span></label>
                                <input class="form-control" type="email" name="shipping_email" id="ship_email" placeholder="<?php echo e($lang->doeml); ?> ">
                            </div>
                            <div class="form-group">
                                <label for="shippingFull_name">PAN Number *</label>
                                <input type="text" class="form-control" name="shipping_pan_number" value="" placeholder="PAN Number">
                            </div>
                            <div class="form-group">
                                <label for="shipping_addresss">Address Type  <span>*</span></label>
                                <select class="form-control" name="shipping_address_type">
                                    <option value="" selected disabled>Select an option</option>
                                    <option value="Home">Home</option>
                                    <option value="Office">Office</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="shipping_geolocation"><?php echo e($lang->doad); ?>  <span>*</span> <i style="color:red;">(Delivery Within Nepal)</i></label>
                                <input placeholder="<?php echo e($lang->doad); ?> " class="form-control" name="shipping_address" id="shipping_geolocation" style="resize: vertical;" onclick="$('#model-type').val('shipping');$('.locationModal').modal('show');" autocomplete="off" />
                                <input id="shipping_latlong" type="hidden" name="shipping_latlong" value="">
                            </div>
                            
                            <div class="form-group">
                                <label for="shippingFull_name"><?php echo e($lang->ctry); ?>  <span>*</span></label>
                                <select class="form-control" name="shipping_country"> 
                                    
                                    <option value="Nepal" selected="selected">Nepal</option> 
                                    
                                </select>
                            </div>
                            
                            
                        </div>
                        <div class="form-group">
                            <label for="order_notes"><?php echo e($lang->onotes); ?></label>
                            <textarea class="form-control order-notes" name="order_notes" id="order_notes" cols="30" rows="5" style="resize: vertical;"></textarea>
                        </div>


                    
                            <div class="form-group text-center">
                                <input class="btn btn-md order-btn" style="border-radius:30px;" type="submit" value="Proceed To Make Payment">
                            </div>
                            
                     
                                        
                    </div>
                </div>
            </div>
        </div>
    </form>

    <div class="modal fade locationModal" ng-app="locationSelector" ng-controller="LocationController" tabindex="-1" role="dialog" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog" role="document">
          <div class="modal-content" style="margin-top: 0;">
            <div class="modal-header text-center" style="border-bottom: none;padding-bottom: 0">
                <h4><strong>SET A LOCATION</strong></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="fa fa-times"></i>
                </button>
            </div>
            <h6 style="margin-left: 15px;">Drag the pin to your exact location</h6>
            <h6 style="margin-left: 15px;">Or, Simply type your address below.</h6>
    
            <div class="modal-body text-center">
                <input type="hidden" id="model-type" value="" />
                <div class="input-group g-pb-13 g-px-0 g-mb-10">
              
                    <input style="background-color:#d8f4ff !important;"
                      places-auto-complete size=80
                      types="['establishment']"
                      component-restrictions="{country:'np'}"
                      on-place-changed="placeChanged()"
                      id="googleLocation" 
                      ng-model="address.Address" 
                      class="form-control g-brd-none g-brd-bottom g-brd-black g-brd-primary--focus g-color-black g-bg-transparent rounded-0" type="text" placeholder="Select Area" autocomplete="off">
                      
                    <button class="btn  u-btn-neutral rounded-0" type="button" ng-click="getLocation()"><i class="fa fa-crosshairs"></i></button>
                </div>
                <p ng-if="error" style="color:red;text-align: left">{{ error }}</p>
    
                <ng-map center="[27.7041765,85.3044636]" zoom="15" draggable="true">
                    <marker position="27.7041765,85.3044636" title="Drag Me!" draggable="true" on-dragend="dragEnd($event)"></marker>
                </ng-map>
            </div>
            <div class="modal-footer" style="border-top: none; text-align: center; display: block;">
              <button type="button" ng-disabled="!isValidGooglePlace" class="btn btn-primary" style="width:100%" ng-click="confirmLocation()">Confirm</button>
            </div>
          </div>
        </div>
    </div>

<!-- Ending of product shipping form -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.7.8/angular.min.js"></script>
    <script src="/assets/front/js/ng-map.min.js"></script>
    <script src="https://maps.google.com/maps/api/js?key=AIzaSyAcvyYLSF2ngh8GM7hX7EQ3dIcQGbGnx5Q&libraries=places"></script>
    <script src="/assets/front/js/location.js"></script>
    <?php if($user): ?>
        <script>
            $('.selectFamily').select2({
                width: '100%'
            });
        </script>
    <?php endif; ?>

    <?php if(count($errors->checkoutForm) > 0): ?>
        <script>
            $(document).ready(function(){
                $.notify("Please provide all the Information.","error");
            });

        </script>
    <?php endif; ?>
    <script type="text/javascript">
        
        $("#coupon").click( function () {
            val = $("#code").val();
            discount = parseFloat($("#coupon_discount").val());
            $.ajax({
                    type: "GET",
                    url:"<?php echo e(URL::to('/json/coupon')); ?>",
                    data:{code:val},
                    success:function(data){
                        if(data == 0)
                        {
                            $.notify("<?php echo e($gs->no_coupon); ?>","error");
                            $("#code").val("");
                        }
                        else if(data == 2)
                        {
                            $.notify("<?php echo e($gs->coupon_already); ?>","error");
                            $("#code").val("");
                        }
                        else
                        {
                            var shipcost = parseFloat($("#shipping-cost").val());

                            $("#coupon_code").val(data[1]);
                            $("#coupon_id").val(data[3]);
                            $("#coupon_discount").val(data[2]);
                            $("#discount").show("slow");
                            $("#ds").html(data[2]);
                            var total = parseFloat($("#total-cost").html());
                            $('#total-cost').html((data[0]+shipcost).toFixed(2))
                            // $("#ftotal").show("slow");
                            $("#sign").html(data[4]);
                            var x = $("#shipop").val();
                            // var y = data[0];
                            // $("#ft").html(y.toFixed(2));
                            $("#grandtotal").val(y);
                            $.notify("<?php echo e($gs->coupon_found); ?>","success");
                            $("#code").val("");
                            // $("#coupon-click1").hide();
                            // $("#coupon-click2").show();

                        }
                    },
                    error: function(data){
                        if(data.responseJSON)
                            $.notify(data.responseJSON.error,"error");
                        else
                            $.notify('Something went wrong',"error");

                    }
            }); 
            return false;
        });
    </script>

    <script type="text/javascript">

        function sHipping(val) {
            var shipcost = parseFloat($("#ship-cost").html());
            var totalcost = parseFloat($("#total-cost").html());
            // var finalcost = parseFloat($("#ft").html());
            var total = 0;
            var ft = 0;
            // var ck = $("#ft").html();
            if (val.value == "shipto") {
                
                total = shipcost + totalcost;
                $("#pick").hide();
                $("#ship-diff").show();
                $("#pick-info").hide();
                $("#shipshow").show();
                $("#shipping-cost").val(shipcost);
                $("#total-cost").html(total);
                $("#grandtotal").val(total);
                $("#shipto").find("input").prop('required',true);
                $("#pick").find("select").prop('required',false);
            }

            if (val.value == "pickup") {
                
                total = totalcost - shipcost;
                $("#pick").show();
                $("#pick-info").show();
                $("#ship-diff").hide();
                $("#shipshow").hide();
                $("#shipping-cost").val('0');
                $("#total-cost").html(total.toFixed(2));
                $("#grandtotal").val(total.toFixed(2));
                $("#shipto").find("input").prop('required',false);
                $("#pick").find("select").prop('required',true);
                
            }
        }
        $(document).on('click','#coupon-click1',function(){
            $('.coupon-code .form').slideToggle();
        });
        $(document).on('click','#coupon-click2',function(){
            $('.coupon-code .form').slideToggle();
        });

        $(document).on('change','.shippingCheck',function(){
            if(this.checked) {
                $(".shipping-details-area").show();
            }
            else
            {
                $(".shipping-details-area").hide();

            }
        });

        
    </script>

    
    <?php if(isset($checked)): ?>
    <script type="text/javascript">
        $(window).on('load',function(){
            $('#checkoutModal').modal('show');
        });

    </script>
    <?php endif; ?>

    <script type="text/javascript">
    
        // $(document).ready(function() {
           
        //  if (document.form.filename.value == "" && document.form.fileid.value="") {
        //     document.getElementById("textbox1").required = true;
        //   }
        // });

        

        $(document).ready(function() {
           

         


          $(".btn-success").click(function(){ 
              var html = $(".clone").html();
              $(".increment").after(html);
          });
      
          $("body").on("click",".btn-danger",function(){ 
              $(this).parents(".control-group").remove();
          });

      
      
    
        
});

        

      
            
      </script>

<script>
    var dropZoneId = "drop-zone";
      var buttonId = "clickHere";
      var mouseOverClass = "mouse-over";
    var dropZone = $("#" + dropZoneId);
     var inputFile = dropZone.find("input");
     var finalFiles = {};
    $(function() {
      
    
      
      var ooleft = dropZone.offset().left;
      var ooright = dropZone.outerWidth() + ooleft;
      var ootop = dropZone.offset().top;
      var oobottom = dropZone.outerHeight() + ootop;
     
      document.getElementById(dropZoneId).addEventListener("dragover", function(e) {
        e.preventDefault();
        e.stopPropagation();
        dropZone.addClass(mouseOverClass);
        var x = e.pageX;
        var y = e.pageY;
    
        if (!(x < ooleft || x > ooright || y < ootop || y > oobottom)) {
          inputFile.offset({
            top: y - 15,
            left: x - 100
          });
        } else {
          inputFile.offset({
            top: -400,
            left: -400
          });
        }
    
      }, true);
    
      if (buttonId != "") {
        var clickZone = $("#" + buttonId);
    
        var oleft = clickZone.offset().left;
        var oright = clickZone.outerWidth() + oleft;
        var otop = clickZone.offset().top;
        var obottom = clickZone.outerHeight() + otop;
    
        $("#" + buttonId).mousemove(function(e) {
          var x = e.pageX;
          var y = e.pageY;
          if (!(x < oleft || x > oright || y < otop || y > obottom)) {
            inputFile.offset({
              top: y - 15,
              left: x - 160
            });
          } else {
            inputFile.offset({
              top: -400,
              left: -400
            });
          }
        });
      }
    
      document.getElementById(dropZoneId).addEventListener("drop", function(e) {
        $("#" + dropZoneId).removeClass(mouseOverClass);
      }, true);
    
    
      inputFile.on('change', function(e) {
        finalFiles = {};
        $('#filename').html("");
        var fileNum = this.files.length,
          initial = 0,
          counter = 0;
    
        $.each(this.files,function(idx,elm){
           finalFiles[idx]=elm;
        });
    
        for (initial; initial < fileNum; initial++) {
          counter = counter + 1;
          $('#filename').append('<div id="file_'+ initial +'"><span class="fa-stack fa-lg"><i class="fa fa-file fa-stack-1x "></i><strong class="fa-stack-1x" style="color:#FFF; font-size:12px; margin-top:2px;">' + counter + '</strong></span> ' + this.files[initial].name + '&nbsp;&nbsp;<span class="fa fa-times-circle fa-lg closeBtn" onclick="removeLine(this)" title="remove"></span></div>');
        }
      });
    
    
    
    })
    
    function removeLine(obj)
    {
      inputFile.val('');
      var jqObj = $(obj);
      var container = jqObj.closest('div');
      var index = container.attr("id").split('_')[1];
      container.remove(); 
    
      delete finalFiles[index];
      //console.log(finalFiles);
    }
    
      </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>