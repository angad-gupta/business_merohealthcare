<?php $__env->startSection('body'); ?>

    <p style="font-size: 14px; font-weight: 600; line-height: 24px; color: #333333;">
        Hello <?php echo e($order->customer_name); ?>,
    </p>
    <p>Your order #<b><?php echo e($order->order_number); ?></b> is confirmed and will be soon on its way. Your expected date of delivery will be within 3 working days* from the date of order.</p>
    <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;">
        <tr> 
            <td align="center" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 25px;">
                <h2 style="font-size: 25px; font-weight: 500; line-height: 36px; color: #55555; margin: 0;"> Thank You For Your Order! </h2> 
            </td>
        </tr>
        <tr>
            <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;">
                
                <p style="text-align:center;font-size: 14px;margin-bottom: 0px;margin-top: 0px;color: #2385aa;text-transform:uppercase;">Order Number: <?php echo e($order->order_number); ?></p>
                <p style="text-align:center;font-size: 14px;margin-bottom: 0px;margin-top: 0px;color: #2385aa;">Order Date: <?php echo e(date('d-M-Y',strtotime($order->created_at))); ?></p>
            </td>
        </tr>
        <tr>
            <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 25px;"> 
                <p style="font-size: 13px;margin-bottom: 0px;margin-top: 0px;">
                    <span style="font-weight:600"><?php echo e($order->customer_name); ?></span><br>
                    <span><?php echo e($order->customer_email); ?></span><br>
                    <span><?php echo e($order->customer_phone); ?></span><br>
                    <span><?php echo e($order->customer_address); ?></span><br>
                    
                    
                    
                </p>
            </td>
        </tr>
       
    </table>
    <?php 
        $cart = unserialize(bzdecompress(utf8_decode($order->cart)));
     ?>
    <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;">
        <tr style="padding-top: 20px;">
            <td><h4 style="margin-bottom:5px">Invoice</h4></td>
        </tr>
        <tr>
            <td align="left" >
                <table class="table" cellspacing="0" cellpadding="0" border="0" width="100%">
                    <thead>
                        <tr>
                            <th width="5%" style="border-bottom: 1px solid #e3ebf3;border-top: 1px solid #e3ebf3;">#</th>
                            <th width="40%" style="border-bottom: 1px solid #e3ebf3;border-top: 1px solid #e3ebf3;">Item &amp; Description</th>
                            <th width="15%" style="border-bottom: 1px solid #e3ebf3;border-top: 1px solid #e3ebf3;">Variant</th>
                            <th width="15%" style="border-bottom: 1px solid #e3ebf3;border-top: 1px solid #e3ebf3;">Rate</th>
                            <th width="5%" style="border-bottom: 1px solid #e3ebf3;border-top: 1px solid #e3ebf3;">QTY</th>
                            <th width="20%" style="border-bottom: 1px solid #e3ebf3;border-top: 1px solid #e3ebf3;">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $i = 1;
                            $subtotal = 0;
                            $discountedsubtotal = 0;
                            $vat_sum = 0;
                            
                         ?>
                        <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php   
                            $price = $product['item']['pprice'] ? : $product['item']['cprice'];                        
                            $vat = App\Product::findOrFail($product['item']['id']);
                            $prod = App\Product::findORFail($product['item']['id']);
                             ?>
                            <tr>
                                <th width="5%" align="center"><?php echo e($i++); ?></th>
                                <td width="40%" align="center">
                                    <a target="_blank" href="<?php echo e(route('front.product',['id1' => $product['item']['id'], str_slug($product['item']['name'],'-')])); ?>"><?php echo e($product['item']['name']); ?></a>
                                    <?php if($vat->vat_status == 1): ?>
                                        <span style="font-style: italic;">*</span>
                                    <?php endif; ?>
                                </td>

                                <td width="15%" align="center">
                                    <?php echo e($vat->sub_title); ?>

                                </td>

                                <td width="15%" align="center">
                         
                                    <?php echo e($order->currency_sign); ?><?php echo e(round($price * $order->currency_value , 2)); ?>

                                  
                                </td>
                                <td width="5%" align="center">
                                    <?php echo e($product['qty']); ?>

                                    <?php if(App\Product::findOrFail($product['item']['id'])->prices()->where('min_qty','<=',$product['qty'])->exists()): ?>
                                    <?php 
                                    $p = App\Product::findOrFail($product['item']['id'])->prices()->where('min_qty','<=',$product['qty'])->orderBy('min_qty','desc')->first();
                                    $quotient = (int)($product['qty'] / $p->min_qty);
                                     ?>
                                    <?php if(($quotient * $p->product_free_quantity) != 0): ?>
                                        <span style="width:70px;">
                                            + <?php echo e($quotient * $p->product_free_quantity); ?> <?php echo e($p->product_category); ?> Free             
                                        </span> 
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <small style="display: block; color: #777;">(<?php echo e($prod->product_quantity); ?>)</small>
                                </td>
                                <td width="20%" align="center">
                                   
                                    
                                        <?php if($gs->sign == 0): ?>
                                        <?php echo e($order->currency_sign); ?><?php echo e(round($price * $product['qty'] * $order->currency_value , 2)); ?>

                                        <?php else: ?>
                                            <?php echo e(round($price * $product['qty'] * $order->currency_value , 2)); ?><?php echo e($order->currency_sign); ?>

                                        <?php endif; ?>
                                  
                                </td>
                            </tr>
                            <?php 
                                $subtotal += $product['qty'] * $price;
                                $discountedsubtotal += $product['price'];
                             ?>
                        <?php 
                        $now = Carbon\Carbon::now()->format('Y/m/d h:i A');
                            if($order->coupon_code != null){
                            $coupon_dis = App\Coupon::where('code',$order->coupon_code)->first();
                            }
                            if($vat->vat_status == 1){
                                if($order->coupon_code && $vat->sale_from && $vat->sale_from <= $now && $vat->sale_to >= $now){
                                  //percentage discount
                                  if($coupon_dis->type == 0){
                                    $vat_price = ($vat->cprice * (1 - ($vat->sale_percentage / 100) )) * (1 - ($coupon_dis->price / 100)) * $product['qty'] * $curr->value;
                                    $vat_sum = $vat_sum + $vat_price;
                                  }
                                  //price discount
                                  elseif($coupon_dis->type == 1){
                                    $vat_price = ($vat->cprice * (1 - ($vat->sale_percentage / 100) )) - ($coupon_dis->price) * $product['qty'] * $curr->value;
                                    $vat_sum = $vat_sum + $vat_price;
                                  }
                                    // dd($vat_sum);
                                }
                                
                                
                                elseif($vat->sale_from && $vat->sale_from <= $now && $vat->sale_to >= $now){
                                    $vat_price = ($vat->cprice * (1 - ($vat->sale_percentage / 100)) ) * $product['qty'] * $curr->value;
                                    $vat_sum = $vat_sum + $vat_price;
                                    // dd($vat_sum);

                                }
                                elseif($order->coupon_code){
                                    //percentage discount
                                    if($coupon_dis->type == 0){
                                      $vat_price = ($vat->cprice * (1 - ($coupon_dis->price / 100) )) * $product['qty'] * $curr->value;
                                      $vat_sum = $vat_sum + $vat_price;
                                    }
                                    //price discount
                                    elseif($coupon_dis->type == 1){
                                      $vat_price = ($vat->cprice * (1 - ($vat->sale_percentage / 100) )) - ($coupon_dis->price) * $product['qty'] * $curr->value;
                                      $vat_sum = $vat_sum + $vat_price;
                                    }
                                    //  dd($vat_sum);
                                }
                                else{
                                    $vat_price = ($vat->cprice) * $product['qty'] * $curr->value;
                                    $vat_sum = $vat_sum + $vat_price;
                                    // dd($vat_sum);
                                }
                            }
                         ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </td>
        </tr>
 
        <tr>
            <td align="left" style="padding-top: 20px;">
                
                <table class="table" cellspacing="0" cellpadding="0" border="0" width="100%">
                  
                    <tr>
                        <td width="40%"></td>
                        <td width="40%" align="right" style="font-weight:800;border-top: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee;">
                            Sub Total                       
                        </td>
                        <td width="20%" align="left" style="font-weight:800;border-top: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee;">
                            <?php echo e($order->currency_sign); ?><?php echo e(round($subtotal * $order->currency_value , 2)); ?>

                        </td>
                    </tr>
                    <?php if($subtotal > $discountedsubtotal): ?>
                        <tr>
                            <td width="40%"></td>
                            <td width="40%" align="right" style="font-weight:800;border-top: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee;">
                                Discount                       
                            </td>
                            <td width="20%" align="left" style="font-weight:800;border-top: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee;">
                                - <?php echo e($order->currency_sign); ?><?php echo e(round(($subtotal - $discountedsubtotal) * $order->currency_value , 2)); ?>

                            </td>
                        </tr>
                    <?php endif; ?>
                    
                    <?php if($order->coupon_code != null): ?>
                        <tr>
                            <td width="40%"></td>
                            <td width="40%" align="right" style="font-weight:800;border-top: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee;">
                                Discount Coupon (<?php echo e($order->coupon_code); ?>)                   
                            </td>
                            <td width="20%" align="left" style="font-weight:800;border-top: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee;">
                                - <?php echo e($order->currency_sign); ?><?php echo e($order->coupon_discount * $order->currency_value); ?>

                            </td>
                        </tr>
                    <?php endif; ?>

                    <?php if($order->discount > 0): ?>
                        <tr>
                            <td width="40%"></td>
                            <td width="40%" align="right" style="font-weight:800;border-top: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee;">
                                Payment Gateway Discount (<?php echo e($order->method); ?>)                  
                            </td>
                            <td width="20%" align="left" style="font-weight:800;border-top: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee;">
                                <?php echo e($order->currency_sign); ?><?php echo e($order->discount * $order->currency_value); ?>

                            </td>
                        </tr>
                    <?php endif; ?>

                    <?php if($order->shipping_cost != 0): ?>
                        <tr>
                            <td width="40%"></td>
                            <td width="40%" align="right" style="font-weight:800;border-top: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee;">
                                Delivery Fee                  
                            </td>
                            <td width="20%" align="left" style="font-weight:800;border-top: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee;">
                                <?php echo e($order->currency_sign); ?><?php echo e($order->shipping_cost * $order->currency_value); ?>

                            </td>
                        </tr>
                    <?php endif; ?>

                    <?php if($order->tax != 0): ?>
                        <tr>
                            <td width="40%"></td>
                            <td width="40%" align="right" style="font-weight:800;border-top: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee;">
                                Tax               
                            </td>
                            <td width="20%" align="left" style="font-weight:800;border-top: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee;">
                                <?php echo e($order->currency_sign); ?><?php echo e($order->tax * $order->currency_value); ?>

                            </td>
                        </tr>
                    <?php endif; ?>
                    <tr>
                        <td width="40%"></td>
                        <td width="40%" align="right" style="font-weight:800;border-top: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee;">
                            Grand Total                       
                        </td>
                        <td width="20%" align="left" style="font-weight:800;border-top: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee;">
                            <?php echo e($order->currency_sign); ?><?php echo e(round($order->pay_amount * $order->currency_value , 2)); ?>

                        </td>
                    </tr>
                    <tr>
                        <td width="40%"></td>
                        <td width="40%" align="right" style="font-weight:800;border-top: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee;">
                                               
                        </td>
                        <td width="20%" align="left" style="font-weight:800;border-top: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee;">
                           
                        </td>
                    </tr>

                       <tr style="color:red;">
                        <td width="40%"></td>
                        <td width="40%" align="right" style="font-weight:800;border-top: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee;">
                            Taxable Amount :                   
                        </td>
                        <td width="20%" align="left" style="font-weight:800;border-top: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee;">
                            &nbsp;&nbsp;<?php echo e($curr->sign); ?><span id=""><?php echo e(round((($vat_sum)/1.13) * $curr->value,2)); ?></span>
                        </td>
                    </tr>

                  

                    <?php if($gs->vat != 0): ?>
                    <tr style="color:red;">
                        <td width="40%"></td>
                        <td width="40%" align="right" style="font-weight:800;border-top: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee;">
                            VAT(<?php echo e($gs->vat); ?>%):                  
                        </td>
                        <td width="20%" align="left" style="font-weight:800;border-top: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee;">
                            &nbsp;&nbsp;<?php echo e($curr->sign); ?><span id=""><?php echo e(round((($vat_sum)/1.13) * 0.13 * $curr->value,2)); ?></span>
                        </td>

                    </tr>
                    <?php endif; ?>
                </table>
                <p style="font-style:italic; color:red;font-size:13px;">* All price subject to inclusive of VAT</p>
            </td>
        </tr>
        
        <tr style="padding-top: 20px;">
            <td align="left"><h4 style="margin-bottom:5px">Delivery & Payment:</h4></td>
        </tr>    
       
        <tr>
            
            <td>
                <p style="margin: 10px 0;">Payment Method: 
                    <?php echo e($order->method); ?>

                    <?php if($order->txnid): ?>
                        <br>TransactionId: <?php echo e($order->txnid); ?>

                    <?php endif; ?>
                </p>
            </td>
        </tr>
        <p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-size:14px;font-family:arial, 'helvetica neue', helvetica, sans-serif;line-height:21px;color:#333333">We are coming very soon on <a target="_blank" href="https://www.apple.com/ios/app-store/" style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial, 'helvetica neue', helvetica, sans-serif;font-size:14px;text-decoration:underline;color:#5B9BD5">iOS</a> and <a target="_blank" style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial, 'helvetica neue', helvetica, sans-serif;font-size:14px;text-decoration:underline;color:#5B9BD5" href="https://play.google.com/store/apps?hl=en">Android</a>.</p>
        <p style="font-size: 14px; font-weight: 600; line-height: 24px; color: #333333;">                              
            Regards,<br>
            MEROHEALTHCARE Team
        </p>
        
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.email', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>