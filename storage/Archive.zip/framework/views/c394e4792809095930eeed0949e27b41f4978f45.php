<?php $__env->startSection('title','Lab Order Invoice - '.$order->order_number); ?>

<?php $__env->startSection('content'); ?>
    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard area -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="product__header" style="border-bottom: none;">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-8 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title">
                                                    <h2>Order Invoice <a href="<?php echo e(url()->previous()); ?>" style="padding: 5px 12px;" class="btn add-back-btn"><i class="fa fa-arrow-left"></i> Back</a>  <a class="btn  add-newProduct-btn print" href="<?php echo e(route('user-lab-order-print',$order->id)); ?>" target="_blank" style="padding: 5px 12px;"><i class="fa fa-print"></i> Print Invoice</a></h2>
                                                    <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i>Lab Orders <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Order Invoice</p>
                                                </div>
                                            </div>
                                            <?php echo $__env->make('includes.user-notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </div>   
                                    </div>
                                    <main>
                                        <div class="invoice-wrap">
                                            <div class="invoice__title">
                                                <div class="row reorder-xs">
                                                    <div class="col-sm-6">
                                                        <div class="container text-center">
                                                            <img class="text-center" src="<?php echo e(url('assets/images/logo.jpg')); ?>" style="height:100px; width:175px; text-align:right;"/>
                                                            </div>
                                                    </div>
                                                    <div class="col-lg-6" style="text-align:right">
                                                        <?php if($order->status == "completed"): ?>
                                                            <span class="btn-lg btn-success" style="cursor:default; border-radius:0">Paid</span>
                                                        <?php else: ?>
                                                            <span class="btn-lg btn-danger" style="cursor:default; border-radius:0">Unpaid</span> 
                                                        <?php endif; ?>
                                                    </div>
                                                </div> 
                                            </div>
                                            <br>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="invoice__metaInfo">
                                                        <div class="buyer">
                                                            <p>User Details</p>
                                                            <strong><?php echo e($order->customer_name); ?></strong>
                                                            <address>
                                                                
                                                                <?php echo e($order->customer_email); ?><br>
                                                                <?php echo e($order->customer_phone); ?><br>
                                                            </address>
                                                        </div>

                                                        <div class="invoce__date">
                                                            <strong>Invoice Number</strong>
                                                            <p>Order Date</p>
                                                            <p>Provided By</p>
                                                        </div>

                                                        <div class="invoce__number">
                                                            <strong><?php echo e(sprintf("%'.08d", $order->id)); ?></strong>
                                                            <p><?php echo e(date('d-M-Y',strtotime($order->created_at))); ?></p>
                                                            <?php 
                                                                $vendor = $order->vendor;
                                                             ?>
                                                            
                                                            <?php echo e($vendor ? $vendor->name : '-'); ?>                                                             
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <?php 
                                                        $patient = json_decode($order->customer_details);
                                                        
                                                     ?>
                                                    <div class="invoice__metaInfo">
                                                        <div class="buyer">
                                                            <p>Patient Details</p>
                                                            <address>
                                                                <span>Name: <?php echo e($patient->name); ?></span><br>
                                                                <span>Date Of Birth: <?php echo e($patient->dob); ?></span><br>
                                                                <span>Gender: <?php echo e($patient->gender); ?></span><br>
                                                                <span>Address: <?php echo e($order->customer_address); ?></span><br>
                                                            </address>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="invoice__table">
                                                        <div class="table-responsive">
                                                            <table class="table table-hover">
                                                                <thead>
                                                                <tr>
                                                                    <th width="10%">#</th>
                                                                    <th>Test Name</th>
                                                                    <th>Test Cost</th>                                                                    
                                                                </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php 
                                                                        $subtotal = 0;
                                                                        $tax = 0;
                                                                     ?> 
                                                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <tr>
                                                                            <td><?php echo e($loop->iteration); ?></td>
                                                                            <td><?php echo e($product->test_name); ?></td>
                                                                            <td><?php echo e($order->currency_sign); ?> <?php echo e(round($product->test_price * $order->currency_value , 2)); ?></td>
                                                                        </tr>
                                                                        <?php 
                                                                            $subtotal += $product->test_price;
                                                                         ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </tbody>
                                                                <tfoot>
                                                                    <tr>
                                                                        <td colspan="2">Subtotal</td>
                                                                        <td><?php echo e($order->currency_sign); ?><?php echo e(round($subtotal * $order->currency_value, 2)); ?></td>
                                                                    </tr>
                                                                    <?php if($order->discount > 0): ?>
                                                                        <tr>
                                                                            <td colspan="2">Payment Gateway Discount (<?php echo e($order->method); ?>)</td>
                                                                            <td><?php echo e($order->currency_sign); ?><?php echo e(round($order->discount * $order->currency_value, 2)); ?></td>
                                                                        </tr>
                                                                    <?php endif; ?>
                                                
                                                                    <?php if($order->service_charge != 0): ?>
                                                                        <tr>
                                                                            <td colspan="2">Service Fee</td>
                                                                            <td><?php echo e($order->currency_sign); ?> <?php echo e($order->service_charge * $order->currency_value); ?></td>
                                                                        </tr>
                                                                    <?php endif; ?>
                                                                    
                                                                    <tr>
                                                                        <td colspan="1"></td>
                                                                        <td>Total</td>
                                                                        <td><?php echo e($order->currency_sign); ?><?php echo e(round($order->pay_amount * $order->currency_value , 2)); ?></td>
                                                                    </tr>
                                                                </tfoot>         
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="invoice__orderDetails">
                                                        <p><strong>Order Details</strong></p>
                                                        
                                                        <p>Payment Method: <?php echo e($order->method); ?></p>
                                                        <?php if($order->method != "Cash On Delivery"): ?>
                                                                    
                                                            <p><?php echo e($order->method); ?> Transaction ID: <?php echo e($order->txnid); ?></p>                        
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-sm-6">
                                                
                                                </div>
                                                <div class="col-sm-6 text-right">
                                                   
                                                </div>
                                            </div>
                                        </div>
                                    </main>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard area --> 
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>