
<style>
    .category_nav{
        padding:1rem;
        
    }
    .header-menu-wrap li a.active {
    color: black;
}
.header-menu-wrap ul {
    padding-top: 28px;
}
.header-search-box {
    margin-top: 19px;
}
    </style>
<body>
    <?php if($gs->is_loader == 1): ?>
    <div id="cover"></div>
    <?php endif; ?>
<?php if($gs->is_subscribe == 1): ?>
<?php if(isset($visited)): ?>
    <div style="display:none">
        <img src="<?php echo e(asset('assets/images/'.$gs->subscribe_image)); ?>">
    </div>
    <!--  Starting of subscribe-pre-loader Area   -->
    <div class="subscribe-preloader-wrap" id="subscriptionForm" style="display: none;">
        <div class="subscribePreloader__thumb" style="background-image: url(<?php echo e(asset('assets/images/'.$gs->subscribe_image)); ?>);">
            <span class="preload-close"><i class="fa fa-close"></i></span>
            <div class="subscribePreloader__text text-center">
                <h1><?php echo e($gs->subscribe_title); ?></h1>
                <p><?php echo e($gs->subscribe_text); ?></p>
                <form action="<?php echo e(route('front.subscribe.submit')); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <input type="email" name="email" id="" placeholder="<?php echo e($lang->supl); ?>" required="">
                        <button type="submit"><?php echo e($lang->s); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--  Ending of subscribe-pre-loader Area   -->

<?php endif; ?>
<?php endif; ?>
    <!--  Starting of header area   -->
    <header class="header-wrap">
        <div class="header-support-part">
            <div class="header-top-area">
                <div class="container">
                

                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="header-top-left-wrap">
                                <ul style="margin-bottom:0">
                                    <?php if($gs->email != null): ?>
                                    <li id="front-top-mail"><a style="padding-left: 0;"><i class="fa fa-envelope"></i> <?php echo e($gs->email); ?></a></li>
                                    <?php endif; ?>
                                    <?php if($gs->phone != null): ?>
                                    <li><a><i class="fa fa-phone"></i> <?php echo e($gs->phone); ?></a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="header-top-right-wrap text-right">
                                    
                            </div>
                        </div>
                    </div>

                
                </div>
            </div>
            <div class="header-middle-area">
                <div class="container">
                    <div class="row">

                    
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="header-middle-left-wrap">
                                <div class="logo">
                                    <a href="<?php echo e(route('front.index')); ?>">
                                        <img src="<?php echo e(asset('assets/images/'.$gs->logo)); ?>" style="height:4rem" alt="Logo">
                                    </a>
                                    <?php if($gs->reg_vendor == 1): ?>
                                        <span class="sell-btn">
                                            <?php if(Auth::guard('user')->check()): ?>
                                            <a href="<?php echo e(route('user-dashboard')); ?>"><?php echo e($lang->sale); ?></a>
                                            <?php else: ?>
                                            <a style="cursor: pointer;" data-toggle="modal" data-target="#vendorloginModal"><?php echo e($lang->sale); ?></a>
                                            <?php endif; ?>
                                        </span>
                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>

                        <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                            <div class="header-middle-right-wrap text-right">
                                <ul>
                                <li>
                                <?php if(Auth::guard('user')->check()): ?>
                                    <a href="<?php echo e(route('user-wishlists')); ?>"><i class="fa fa-heart"></i> <span><?php echo e($lang->wishlists); ?></span></a>
                                <?php else: ?>
                                    <a style="cursor: pointer;" class="no-wish" data-toggle="modal" data-target="#loginModal"><i class="fa fa-heart"></i> <span><?php echo e($lang->wishlists); ?></span></a>
                                <?php endif; ?>
                                </li>
                                    <li>
                                        <?php if(Auth::guard('user')->check()): ?>
                                            <a style="text-transform: uppercase" href="<?php echo e(route('user-dashboard')); ?>">
                                                <i class="fa fa-user"></i> <span><?php echo e(Auth::guard('user')->user()->name); ?></span>
                                            </a>
                                        <?php else: ?>
                                            <a style="text-transform: uppercase" href="<?php echo e(route('user-login')); ?>">
                                                <i class="fa fa-user"></i> <span><?php echo e($lang->signinup); ?></span>
                                            </a>
                                        <?php endif; ?>
                                    </li>




                                    <li class="myCart"><a href="javascript:void(0)"> <i class="fa fa-cart-plus"></i></a> <span class="cart-quantity"><?php echo e(Session::has('cart') ? count(Session::get('cart')->items) : '0'); ?></span>
                                        <div class="addToMycart">
                                            <div class="cart">
                                            <?php if(Session::has('cart')): ?>
                                            <?php $__currentLoopData = Session::get('cart')->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="single-myCart">
                                                <p class="cart-close" onclick="remove(<?php echo e($product['item']['id']); ?>)"><i class="fa fa-close"></i></p>
                                                <div class="cart-img">
                                                    <img src="<?php echo e(asset('assets/images/'.$product['item']['photo'])); ?>" alt="Product image">
                                                </div>
                                                <div class="cart-info">
                                                    <a href="<?php echo e(route('front.product',[$product['item']['id'],str_slug($product['item']['name'],'-')])); ?>" style="color: black; padding: 0 0;"><h5><?php echo e(strlen($product['item']['name']) > 45 ? substr($product['item']['name'],0,45).'...' : $product['item']['name']); ?></h5></a>
                                                <p><?php echo e($lang->cquantity); ?>: <span id="cqt<?php echo e($product['item']['id']); ?>"><?php echo e($product['qty']); ?></span> <span><?php echo e($product['item']['measure']); ?></span></p>
                                                <p>
                                                <?php if($gs->sign == 0): ?>
                                                    <?php echo e($curr->sign); ?><span id="prct<?php echo e($product['item']['id']); ?>"><?php echo e(round($product['price'] * $curr->value , 2)); ?></span>
                                                <?php else: ?>
                                                    <span id="prct<?php echo e($product['item']['id']); ?>"><?php echo e(round($product['price'] * $curr->value , 2)); ?></span><?php echo e($curr->sign); ?>

                                                <?php endif; ?>
                                                </p>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>                                            
                                            </div>
                                            <h5 class="empty"><?php echo e(Session::has('cart') ? '' :$lang->h); ?></h5>
                                            <hr/>
                                            <h4 class="text-right"><?php echo e($lang->vt); ?>

                                            <?php if($gs->sign == 0): ?>                                                   
                                             <?php echo e($curr->sign); ?><span class="total"><?php echo e(Session::has('cart') ? round(Session::get('cart')->totalPrice * $curr->value , 2) : '0.00'); ?></span>
                                            <?php else: ?>
                                             <span class="total"><?php echo e(Session::has('cart') ? round(Session::get('cart')->totalPrice * $curr->value , 2) : '0.00'); ?></span><?php echo e($curr->sign); ?>

                                            <?php endif; ?>
                                         </h4>
                                            <div class="addMyCart-btns">
                                                <a href="<?php echo e(route('front.cart')); ?>" class="black-btn"><?php echo e($lang->vdn); ?></a>
                                                <a href="<?php echo e(route('front.checkout')); ?>" class="black-btn"><?php echo e($lang->gt); ?></a>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="myCart1"><a href="javascript:void(0)"> <i class="fa fa-cart-plus"></i></a> <span class="cart-quantity"><?php echo e(Session::has('cart') ? count(Session::get('cart')->items) : '0'); ?></span>
                                        <div class="addToMycart1">
                                            <div class="cart">
                                            <?php if(Session::has('cart')): ?>
                                            <?php $__currentLoopData = Session::get('cart')->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="single-myCart">
                                                <p class="cart-close" onclick="remove(<?php echo e($product['item']['id']); ?>)"><i class="fa fa-close"></i></p>
                                                <div class="cart-img">
                                                    <img src="<?php echo e(asset('assets/images/'.$product['item']['photo'])); ?>" alt="Product image">
                                                </div>
                                                <div class="cart-info">
                                                    <a href="<?php echo e(route('front.product',[$product['item']['id'],str_slug($product['item']['name'],'-')])); ?>" style="color: black; padding: 0 0;"><h5><?php echo e(strlen($product['item']['name']) > 45 ? substr($product['item']['name'],0,45).'...' : $product['item']['name']); ?></h5></a>
                                                <p><?php echo e($lang->cquantity); ?>: <span id="cqt<?php echo e($product['item']['id']); ?>"><?php echo e($product['qty']); ?></span> <span><?php echo e($product['item']['measure']); ?></span></p>
                                                <p>
                                                <?php if($gs->sign == 0): ?>
                                                    <?php echo e($curr->sign); ?><span id="prct<?php echo e($product['item']['id']); ?>"><?php echo e(round($product['price'] * $curr->value , 2)); ?></span>
                                                <?php else: ?>
                                                    <span id="prct<?php echo e($product['item']['id']); ?>"><?php echo e(round($product['price'] * $curr->value , 2)); ?></span><?php echo e($curr->sign); ?>

                                                <?php endif; ?>
                                                </p>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>                                            
                                            </div>
                                            <h5 class="empty"><?php echo e(Session::has('cart') ? '' :$lang->h); ?></h5>
                                            <hr/>
                                            <h4 class="text-right"><?php echo e($lang->vt); ?> 
                                                <?php if($gs->sign == 0): ?>
                                                <?php echo e($curr->sign); ?><span class="total"><?php echo e(Session::has('cart') ? round(Session::get('cart')->totalPrice * $curr->value , 2) : '0.00'); ?></span>
                                                <?php else: ?>
                                                <span class="total"><?php echo e(Session::has('cart') ? round(Session::get('cart')->totalPrice * $curr->value , 2) : '0.00'); ?></span><?php echo e($curr->sign); ?>

                                                <?php endif; ?>
                                            </h4>
                                            <div class="addMyCart-btns">
                                                <a href="<?php echo e(route('front.cart')); ?>" class="black-btn"><?php echo e($lang->vdn); ?></a>
                                                <a href="<?php echo e(route('front.checkout')); ?>" class="black-btn"><?php echo e($lang->gt); ?></a>
                                            </div>
                                        </div>
                                    </li>

                                    <li class="circle-li"><a href="<?php echo e(route('front.compare')); ?>"><i class="fa fa-exchange"></i></a> <span class="compare-quantity"><?php echo e(Session::has('compare') ? count(Session::get('compare')->items) : '0'); ?></span>
                                    </li>
                                    <?php if($gs->reg_vendor == 1): ?>
                                        <li class="sell-btn">
                                            <?php if(Auth::guard('user')->check()): ?>
                                            <a href="<?php echo e(route('user-dashboard')); ?>"><?php echo e($lang->sale); ?></a>
                                            <?php else: ?>
                                            <a style="cursor: pointer;" data-toggle="modal" data-target="#vendorloginModal"><?php echo e($lang->sale); ?></a>
                                            <?php endif; ?>
                                        </li>
                                    <?php endif; ?>
                                    <li class="mobile-search"><a href="javascript:void(0)"><i class="fa fa-search"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    


                        <div class="col-lg-12">
                            <div class="header-search-box mobile">
                                    <div class="search-close">
                                    <i class="fa fa-times"></i>
                                </div>
                                <form action="<?php echo e(route('front.search')); ?>" method="GET">
                                    <input style="" type="text" class="ss" id="search_product" name="product" placeholder="<?php echo e($lang->ec); ?>" required>
                                    <button type="submit"><i class="fa fa-search"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="header-bottom-area">
            <div class="container">
                <div class="row">
                      
                </div>
                    
                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-5">
                        
                        <div class="header-bottom-left-wrap" style="cursor:unset">
                            <p class="text-center mb-0" style="color:white" ><i class="fa fa-upload"></i>&nbsp;&nbsp;<a href="<?php echo e(Auth::guard('user')->check() ? route('user-prescriptions.index') : '/upload-prescription'); ?>" style="color:white;font-size:17px;text-decoration:none">Upload Prescription</a></a>
                        </div>
                    </div>
                    <div class="mobileMenuActive"></div>
                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-5">
                        <div class="header-menu-wrap">
                            <ul>
                                
                                <li><a href="<?php echo e(route('lab.index')); ?>" style="text-transform: uppercase">Labs</a></li>

                                <li><a href="<?php echo e(route('front.promotions')); ?>" style="text-transform: uppercase">Promotions</a></li>
                                <li><a href="<?php echo e(route('front.blog')); ?>"><?php echo e($lang->blog); ?></a></li>
                                
                                
                            </ul>
                        </div>

                    </div>

                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                        <div class="header-search-box text-right">
                            <form action="<?php echo e(route('front.search')); ?>" method="GET">
                                <input type="text"  style="width:90%;border-radius: 5px" class="ss" id="" name="product" placeholder="<?php echo e($lang->ec); ?>" required autocomplete="off">
                                <button type="submit" style="width:10%;border-top-right-radius: 5px; border-bottom-right-radius: 5px;"><i class="fa fa-search"></i></button>
                            </form>
                        </div>
                        <div class="header-searched-item-list-wrap" style="display: none; z-index:1000">
                            <ul>

                            </ul>
                        </div>
                    </div>
                    <div class="mobileSlickMenuActive"></div>
                

                </div>
            </div>
        </div>
        
    </header>
    <?php if(Request::segment(1)!='lab'): ?>
    <header id="js-header" class="u-header u-header--static">
        <div class="u-header__section u-header__section--light g-bg-white g-transition-0_3 ">
            <nav class="js-mega-menu navbar navbar-expand-lg hs-menu-initialized hs-menu-horizontal g-pa-0 mb-0 justify-content-center">
            <div class="">
                <!-- Responsive Toggle Button -->
                <button class="navbar-toggler navbar-toggler-right btn g-line-height-1 g-brd-none g-pa-0 g-pos-abs g-top-3 g-right-0" type="button" aria-label="Toggle navigation" aria-expanded="false" aria-controls="navBar" data-toggle="collapse" data-target="#navBar">
                <span class="hamburger hamburger--slider">
                <span class="hamburger-box">
                <span class="hamburger-inner"></span>
                </span>
                </span>
                </button>
                <!-- End Responsive Toggle Button -->
    
                <div style="display:flex;margin:0rem 0rem">
                    <!-- Navigation -->
                    <div class="collapse navbar-collapse align-items-center flex-sm-row  g-mr-40--lg" id="navBar">
                        <ul class="navbar-nav  g-pos-rel g-font-weight-600 ml-auto">
                            <?php $__currentLoopData = $categories->sortBy('priority_no'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <li class="nav-item hs-has-sub-menu menu_hover g-px-10">
                                
                            <a id="nav-link--pages--about" class="nav-link g-color-black g-font-weight-400 g-font-size-14" href="#" aria-haspopup="true" aria-expanded="false" aria-controls="nav-submenu--pages--about"><?php echo e($category->cat_name); ?></a>
        
                            <!-- Submenu (level 2) -->
                            <ul class=" <?php echo e(count($category->subs) > 0?'hs-sub-menu':''); ?> list-unstyled g-bg-white u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2 animated" id="nav-submenu--pages--about" aria-labelledby="nav-link--pages--about" style="display: none;">
                                <?php $__currentLoopData = $category->subs()->where('status','=',1)->orderBy('priority_no')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
                                <li class="<?php echo e(count($subcategory->childs) > 0?'hs-has-sub-menu':''); ?> dropdown-item g-font-weight-600 g-px-10 g-py-7 menu_hover " aria-haspopup="true" aria-expanded="false" aria-controls="nav-submenu--pages--about">
                                <a class="nav-link  g-color-black g-font-weight-400 g-font-size-14" href="<?php echo e(route('front.subcategory',$subcategory->sub_slug)); ?>"><?php echo e($subcategory->sub_name); ?></a>
                                <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2 animated" id="nav-submenu--pages--about" aria-labelledby="nav-link--pages--about" style="display: none;">
                                        <?php $__currentLoopData = $subcategory->childs()->where('status','=',1)->orderBy('priority_no')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <li class="dropdown-item menu_hover ">
                                        <a class="nav-link g-color-black g-font-weight-400 g-font-size-14" href="<?php echo e(route('front.childcategory',$childcategory->child_slug)); ?>"><?php echo e($childcategory->child_name); ?></a>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    
                            
                                    </ul>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            
                    
                            </ul>
                            <!-- End Submenu (level 2) -->
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                        <!-- End Navigation -->
    
            
                </div>
            </div>
            </nav>
        </div>
    </header>
    <?php endif; ?>
            <?php 
            $i=1;
            $j=1;
             ?>