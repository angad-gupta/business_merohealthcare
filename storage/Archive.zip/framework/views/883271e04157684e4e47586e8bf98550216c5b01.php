<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td colspan="4">
            <p class=" product-name-header" title="<?php echo e($product['item']['name']); ?>"><?php echo e(strlen($product['item']['name']) > 30 ? substr($product['item']['name'],0,30).'...' : $product['item']['name']); ?></a></p>
        
        </td>
        
        <td>
            <?php if($gs->sign == 0): ?>
                <?php echo e($curr->sign); ?><?php echo e(round($product['price'] * $curr->value, 2)); ?>

            <?php else: ?>
                <?php echo e(round($product['price'] * $curr->value, 2)); ?><?php echo e($curr->sign); ?>

            <?php endif; ?>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>