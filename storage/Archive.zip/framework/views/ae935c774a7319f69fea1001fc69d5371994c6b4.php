<?php $__env->startSection('body'); ?>
    
    <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;">
        <tr> 
            <td align="center" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 25px;">
                <h2 style="font-size: 30px; font-weight: 800; line-height: 36px; color: #333333; margin: 0;"> Thank You For Your Order! </h2> 
            </td>
        </tr>
        <tr>
            <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;">
                
                <p style="text-align:center;font-size: 12px;margin-bottom: 0px;margin-top: 0px;color: #454282;">Order Number: <?php echo e($order->id); ?></p>
                <p style="text-align:center;font-size: 12px;margin-bottom: 0px;margin-top: 0px;color: #454282;">Order Date: <?php echo e(date('d-M-Y',strtotime($order->created_at))); ?></p>
            </td>
        </tr>
        <tr>
            <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 25px;"> 
                <p style="font-size: 12px;margin-bottom: 0px;margin-top: 0px;">
                    <span style="font-weight:800"><?php echo e($order->name); ?></span><br>
                    <span><?php echo e($order->email); ?></span><br>
                    <span><?php echo e($order->phone); ?></span><br>
                    <span><?php echo e($order->location); ?></span><br>
                    
                </p>
            </td>
        </tr>
    </table>
    <?php 
        $items = json_decode($invoice->items,true);
     ?>
    <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;">
        <tr style="padding-top: 20px;">
            <td><h4 style="margin-bottom:5px">Invoice</h4></td>
        </tr>
        <tr>
            <td align="left" >
                <table class="table" cellspacing="0" cellpadding="0" border="0" width="100%">
                    <thead>
                        <tr>
                            <th width="5%" style="border-bottom: 2px solid #e3ebf3;border-top: 1px solid #e3ebf3;">#</th>
                            <th width="30%" style="border-bottom: 2px solid #e3ebf3;border-top: 1px solid #e3ebf3;">Item &amp; Description</th>
                            <th style="border-bottom: 2px solid #e3ebf3;border-top: 1px solid #e3ebf3;">Batch No.(s)</th>
                            <th style="border-bottom: 2px solid #e3ebf3;border-top: 1px solid #e3ebf3;">Expiry Date(s)</th>
                            <th width="10%" style="border-bottom: 2px solid #e3ebf3;border-top: 1px solid #e3ebf3;">Rate</th>
                            <th width="8%" style="border-bottom: 2px solid #e3ebf3;border-top: 1px solid #e3ebf3;">QTY</th>
                            <th width="10%" style="border-bottom: 2px solid #e3ebf3;border-top: 1px solid #e3ebf3;">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $i = 1;
                            $subtotal = 0;
                         ?>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr>
                                <th align="center"><?php echo e($i++); ?></th>
                                <td align="center">
                                    
                                    <?php echo e($product['name']); ?>

                                </td>
                                <td>
                                    <?php if(isset($product['batch_nos'])): ?>
                                        <?php $__currentLoopData = explode(",",$product['batch_nos']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($item); ?><br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(isset($product['batch_nos'])): ?>

                                        <?php $__currentLoopData = explode(",",$product['exp_dates']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($item); ?><br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </td>
                                <td align="center"><?php echo e($invoice->currency_sign); ?><?php echo e(round($product['price'] * $invoice->currency_value,2)); ?></td>
                                <td align="center"><?php echo e($product['qty']); ?></td>
                                <td align="center"><?php echo e($invoice->currency_sign); ?><?php echo e(round($product['price'] * $product['qty'] * $invoice->currency_value,2)); ?></td>
                            </tr>
                            <?php 
                                $subtotal += $product['price'] * $product['qty'];
                             ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </td>
        </tr>
        <tr>
            <td align="left" style="padding-top: 20px;">
                
                <table class="table" cellspacing="0" cellpadding="0" border="0" width="100%">
                    
                    <tr>
                        <td width="40%"></td>
                        <td width="40%" align="right" style="font-weight:800;border-top: 3px solid #eeeeee; border-bottom: 3px solid #eeeeee;">
                            Sub Total                       
                        </td>
                        <td width="20%" align="left" style="font-weight:800;border-top: 3px solid #eeeeee; border-bottom: 3px solid #eeeeee;">
                            <?php echo e($invoice->currency_sign); ?><?php echo e(round($subtotal * $invoice->currency_value , 2)); ?>

                        </td>
                    </tr>

                    <?php if($invoice->shipping_cost != 0): ?>
                        <tr>
                            <td width="40%"></td>
                            <td width="40%" align="right" style="font-weight:800;border-top: 3px solid #eeeeee; border-bottom: 3px solid #eeeeee;">
                                Shipping Fee                  
                            </td>
                            <td width="20%" align="left" style="font-weight:800;border-top: 3px solid #eeeeee; border-bottom: 3px solid #eeeeee;">
                                <?php echo e($invoice->currency_sign); ?><?php echo e($invoice->shipping_cost * $invoice->currency_value); ?>

                            </td>
                        </tr>
                    <?php endif; ?>

                    <?php if($invoice->tax != 0): ?>
                        <tr>
                            <td width="40%"></td>
                            <td width="40%" align="right" style="font-weight:800;border-top: 3px solid #eeeeee; border-bottom: 3px solid #eeeeee;">
                                Tax               
                            </td>
                            <td width="20%" align="left" style="font-weight:800;border-top: 3px solid #eeeeee; border-bottom: 3px solid #eeeeee;">
                                <?php echo e($invoice->currency_sign); ?><?php echo e($invoice->tax * $invoice->currency_value); ?>

                            </td>
                        </tr>
                    <?php endif; ?>
                    <tr>
                        <td width="40%"></td>
                        <td width="40%" align="right" style="font-weight:800;border-top: 3px solid #eeeeee; border-bottom: 3px solid #eeeeee;">
                            Total                       
                        </td>
                        <td width="20%" align="left" style="font-weight:800;border-top: 3px solid #eeeeee; border-bottom: 3px solid #eeeeee;">
                            <?php echo e($invoice->currency_sign); ?><?php echo e(round($invoice->amount * $invoice->currency_value , 2)); ?>

                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.email', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>