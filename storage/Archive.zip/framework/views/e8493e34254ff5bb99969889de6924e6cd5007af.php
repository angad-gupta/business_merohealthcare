<?php $__env->startSection('content'); ?>
    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard add-product-1 area -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="product__header">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title">
                                                    <h2>Edit Customer <a href="<?php echo e(route('admin-user-index')); ?>" style="padding: 5px 12px;" class="btn add-back-btn"><i class="fa fa-arrow-left"></i> Back</a></h2>
                                                    <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Customers <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Customers List <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Edit</p>
                                                </div>
                                            </div>
                                              <?php echo $__env->make('includes.notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </div>   
                                    </div>
                                    <form class="form-horizontal" action="<?php echo e(route('admin-user-edit',$user->id)); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo $__env->make('includes.form-error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                            <div class="form-group">
                                                <label class="control-label col-sm-4" for="admin_current_photo">Current Photo *</label>
                                                <div class="col-sm-2">
                                                                                <?php if($user->is_provider == 1): ?>
                                    <img style="width: 100%; height: auto;" src="<?php echo e($user->photo ? $user->photo:asset('assets/images/noimage.png')); ?>" alt="profile image">
                                    <?php else: ?>
                                    <img  style="width: 100%; height: auto;" id="adminimg" src="<?php echo e($user->photo ? asset('assets/images/'.$user->photo):asset('assets/images/noimage.png')); ?>" alt="profile image">
                                    <?php endif; ?>

                                                </div>
                                                <?php if($user->is_provider != 1): ?>
                                                <div class="col-sm-4">
                                                    <input type="file" id="uploadFile" class="hidden" name="photo" value="">
                                                    
                                                    <button  type="button" id="uploadTrigger" onclick="uploadclick()" class="btn btn-block add-product_btn adminImg-btn"><i class="fa fa-upload"></i> Change Photo</button>
                                                    
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-sm-4" for="dash_fname">Full Name *</label>
                                                <div class="col-sm-6">
                                                    <input class="form-control" type="text" name="name" id="dash_fname" placeholder="Full Name" value="<?php echo e($user->name); ?>" required>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-sm-4" for="dash_lname">Email Address *</label>
                                                <div class="col-sm-6">
                                                    <input class="form-control" type="email" name="email" id="dash_lname" placeholder="Email Address" value="<?php echo e($user->email); ?>" disabled="">
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label class="control-label col-sm-4">Gender </label>
                                                <div class="col-sm-6">
                                                    <select class="form-control" name="gender" required>
                                                     
                                                        <option value="Male" <?php echo e($user->gender == 'Male' ? 'selected' : ''); ?>>Male</option>
                                                        <option value="Female" <?php echo e($user->gender == 'Female' ? 'selected' : ''); ?>>Female</option>
                                                        <option value="Others" <?php echo e($user->gender == 'Others' ? 'selected' : ''); ?>>Others</option>
                                                    </select>
                                                </div>
                                            </div>
    
                                            <div class="form-group">
                                                <label class="control-label col-sm-4">Date of Birth </label>
                                                <div class="col-sm-6">
                                                    <input type="date" class="form-control" name="dob" value="<?php echo e($user->dob); ?>" placeholder="DOB">
                                                </div>
                                            </div>
    
                                            <div class="form-group">
                                                <label class="control-label col-sm-4">PAN Number</label>
                                                <div class="col-sm-6">
                                                    <input type="text" class="form-control" name="pan_number" value="<?php echo e($user->pan_number); ?>" placeholder="PAN Number">
                                                </div>
                                            </div>
    
                                            <div class="form-group">
                                                <label class="control-label col-sm-4">Address Type *</label>
                                                <div class="col-sm-6">
                                                    <select class="form-control" name="address_type" required>
                                                        <option value="" <?php echo e(!$user->address_type ? 'selected' : ''); ?> disabled>Select an option</option>
                                                        <option value="Home" <?php echo e($user->address_type == 'Home' ? 'selected' : ''); ?>>Home</option>
                                                        <option value="Office" <?php echo e($user->address_type == 'Office' ? 'selected' : ''); ?>>Office</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label class="control-label col-sm-4" for="dash_email">Address *</label>
                                                <div class="col-sm-6">
                                                    <input class="form-control" type="text" name="address" id="dash_email" placeholder="Address" value="Address" required>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-sm-4" for="dash_phone">Phone Number *</label>
                                                <div class="col-sm-6">
                                                    <input class="form-control" type="text" name="phone" id="dash_phone" placeholder="Phone Number" value="<?php echo e($user->phone); ?>" required>
                                                </div>
                                            </div>
                                            
                                        <hr/>
                                        <div class="add-product-footer">
                                            <button name="addProduct_btn" type="submit" class="btn add-product_btn">Update</button>
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard add-product-1 area -->
                </div>
            </div>
        </div>
    </div>
    <!-- Ending of Account Dashboard area -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">

        function uploadclick(){
            $("#uploadFile").click();
            $("#uploadFile").change(function(event) {
                readURL(this);
                $("#uploadTrigger").html($("#uploadFile").val());
            });

        }


        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#adminimg').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>