<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('content'); ?>
<?php 
$i=1;
$j=1;
$now = Carbon\Carbon::now()->format('Y/m/d h:i A');

 ?>

<style>

    .product-price{
        font-size:18px;
    }
    
    


@media  only screen and (max-width: 767px){
.product-image-area {
    height: 175px !important;
    width: 100%;
    padding:1.5rem;
}
}

    .js-countdown {
          font-size:15px;
        }
    
      .g-color-black{
        color: 555 !important;
      }
    
    @media  only screen and (max-width: 1200px) and (min-width: 992px){
    .category-wrap .product-image-area {
        width: 100%;
        height: 220px;
    }
    }
    
    @media  only screen and (max-width: 991px) and (min-width: 768px){
    .category-wrap .product-image-area {
        width: 100%;
        height: 200px;
    }

    
    }

    @media (max-width: 1024px) and (min-width: 768px){
.g-mt-1 {
    margin-top: 0px!important;
}
    }

   
    
    
      @media  only screen and (max-width: 767px){

        
        .product-name{
            margin-bottom:50px !important;
        }
      .category-wrap .product-image-area {
          height: 175px;
          width: 100% ;
      }
      .js-countdown {
          font-size:12px !important;
        }
      }
      
      .gallery-overlay {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          z-index: 2;
          opacity: 0;
          transition: all .4s ease-in;
      }
      
      .product-hover-area {
          position: absolute;
          width: 101%;
          left: 0;
          bottom: -15%;
          opacity: 0;
          visibility: hidden;
          z-index: 3;
          -webkit-transition: all .4s ease-in;
          transition: all .4s ease-in;
          z-index: 36;
      }
      
      .single-product-area {
          border: 0px solid #e0e0e0;
          box-shadow: 0 0 0px 0px #dedede;
          display: block;
          -webkit-transform: perspective(1px) translateZ(0);
          transform: perspective(1px) translateZ(0);
          position: relative;
          overflow: hidden;
          -webkit-transition: all .3s ease-in;
          transition: all .3s ease-in;
          margin-bottom: 30px;
      }

      .product-image-area {
    height: 220px ;
    width: 100%;
    padding:1.5rem;
}
      </style>





<style>

.js-carousel.slick-initialized .js-next, .js-carousel.slick-initialized .js-prev {
    opacity: 1;
    background: transparent !important;

}



@media  only screen and (max-width: 768px){

    section {

  height: 15rem !important;}

  #slider-img{
      height: 15rem !important;
  }

.g-font-size-16{
    font-size: 10px !important;
}
.g-font-size-15{
    font-size: 10px !important;
}
.g-mt-1 {
    margin-top: 2px!important;
}
.et-icon-alarmclock{
    font-size: 10px;
}

#card-height{
    height: 24rem !important;
}

/* #jssor_1{
    height: 250px !important;
}
#slider-image{
    height: 250px !important;
} */

}

#card-height{
    height: 23rem ;
}

@media (min-width: 768px) and (max-width: 1024px){
.g-font-size-16{
    font-size: 10px !important;
}
.g-font-size-15{
    font-size: 10px !important;
}
.g-mt-1 {
    margin-top: 0px!important;
}
.et-icon-alarmclock{
    font-size: 10px;
}

.product-image-area {
    height: 170px !important;
    width: 100%;
    padding: 1.5rem;
}

.js-countdown{
  margin-top:1px !important;
  font-size:14px;
}

}


@media (min-width: 320px) and (max-width: 768px){
  .slider,
  .slide {
    height: 40vh;
    text-align: center !important;
  }

  .slide .slide__img {
 text-align: center;
  width: 100%;
  height: 20rem;
  overflow: auto;
}
}

@media (min-width: 992px) {
  .slider,
  .slide {
    height: 40vh;
    text-align: center !important;
  }
}
.slide {
  position: relative;
}
.slide .slide__img {
 text-align: center;
  width: 100%;
  height: auto;
  overflow: auto;
}
@media (min-width: 992px) {
  .slide .slide__img {
    position: absolute;
    top: 50%;
    left: 0%;
    -webkit-transform: translateY(-50%);
            transform: translateY(-50%);
  }
}
.slide .slide__img img {
  max-width: 100%;
  height: auto;
  opacity: 1 !important;
  -webkit-animation-duration: 3s;
          animation-duration: 3s;
  -webkit-transition: all 1s ease;
  transition: all 1s ease;
}
.slide .slide__content {
  position: absolute;
  top: 50%;
  left: 50%;
  -webkit-transform: translate(-50%, -50%);
          transform: translate(-50%, -50%);
}
.slide .slide__content--headings {
  text-align: center;
  color: #FFF;
}
.slide .slide__content--headings h2 {
  font-size: 4.5rem;
  margin: 10px 0;
}
.slide .slide__content--headings .animated {
  -webkit-transition: all 0.5s ease;
  transition: all 0.5s ease;
}
.slider [data-animation-in] {
  opacity: 0;
  -webkit-animation-duration: 1.5s;
          animation-duration: 1.5s;
  -webkit-transition: opacity 0.5s ease 0.3s;
  transition: opacity 0.5s ease 0.3s;
}
.slick-dotted .slick-slider {
  margin-bottom: 30px;
}
.slick-dots {
  position: absolute;
  bottom: 25px;
  list-style: none;
  display: block;
  text-align: center;
  padding: 0;
  margin: 0;
  width: 100%;
}
.slick-dots li {
  position: relative;
  display: inline-block;
  margin: 0 5px;
  padding: 0;
  cursor: pointer;
}
.slick-dots li button {
  border: 0;
  display: block;
  outline: none;
  line-height: 0px;
  font-size: 0px;
  color: transparent;
  padding: 5px;
  cursor: pointer;
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.slick-dots li button:hover,
.slick-dots li button:focus {
  outline: none;
}
.simple-dots .slick-dots li {
  width: 20px;
  height: 20px;
}
.simple-dots .slick-dots li button {
  border-radius: 50%;
  background-color: white;
  opacity: 0.25;
  width: 20px;
  height: 20px;
}
.simple-dots .slick-dots li button:hover,
.simple-dots .slick-dots li button:focus {
  opacity: 1;
}
.simple-dots .slick-dots li.slick-active button {
  color: white;
  opacity: 0.75;
}
.stick-dots .slick-dots li {
  height: 3px;
  width: 50px;
}
.stick-dots .slick-dots li button {
  position: relative;
  background-color: white;
  opacity: 0.25;
  width: 50px;
  height: 3px;
  padding: 0;
}
.stick-dots .slick-dots li button:hover,
.stick-dots .slick-dots li button:focus {
  opacity: 1;
}
.stick-dots .slick-dots li.slick-active button {
  color: white;
  opacity: 0.75;
}
.stick-dots .slick-dots li.slick-active button:hover,
.stick-dots .slick-dots li.slick-active button:focus {
  opacity: 1;
}
/* /////////// IMAGE ZOOM /////////// */
@-webkit-keyframes zoomInImage {
  from {
    -webkit-transform: scale3d(1, 1, 1);
            transform: scale3d(1, 1, 1);
  }
  to {
    -webkit-transform: scale3d(1.1, 1.1, 1.1);
            transform: scale3d(1.1, 1.1, 1.1);
  }
}
@keyframes  zoomInImage {
  from {
    -webkit-transform: scale3d(1, 1, 1);
            transform: scale3d(1, 1, 1);
  }
  to {
    -webkit-transform: scale3d(1.1, 1.1, 1.1);
            transform: scale3d(1.1, 1.1, 1.1);
  }
}
.zoomInImage {
  -webkit-animation-name: zoomInImage;
          animation-name: zoomInImage;
}
@-webkit-keyframes zoomOutImage {
  from {
    -webkit-transform: scale3d(1.1, 1.1, 1.1);
            transform: scale3d(1.1, 1.1, 1.1);
  }
  to {
    -webkit-transform: scale3d(1, 1, 1);
            transform: scale3d(1, 1, 1);
  }
}
@keyframes  zoomOutImage {
  from {
    -webkit-transform: scale3d(1.1, 1.1, 1.1);
            transform: scale3d(1.1, 1.1, 1.1);
  }
  to {
    -webkit-transform: scale3d(1, 1, 1);
            transform: scale3d(1, 1, 1);
  }
}
.zoomOutImage {
  -webkit-animation-name: zoomOutImage;
          animation-name: zoomOutImage;
}




section {
  width: 100%;
  height: 30rem;
  margin: 0 auto;
  overflow: hidden;
  background: #2980b9;
  -moz-border-radius: 0.5em;
  -webkit-border-radius: 0.5em;
  border-radius: 0.5em;
}
section img {
  position: relative;
  max-height: 100%;
  left: 50%;
  -moz-transform: translateX(-50%);
  -ms-transform: translateX(-50%);
  -webkit-transform: translateX(-50%);
  transform: translateX(-50%);
}
@media (min-width: 800px) {
  section img {
    top: 50%;
    left: 0;
    max-height: none;
    width: 100%;
    -moz-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
  }
}



</style>



<?php if($gs->slider == 1): ?>

<div class="row">
    <div class="col-md-12">
        <div class="js-carousel text-center g-pb-30" data-autoplay="true" data-ride="carousel" data-infinite="true" data-arrows-classes="u-arrow-v1 g-absolute-centered--y g-width-35 g-height-40 g-font-size-40 g-color-gray g-bg-white g-mt-minus-10" data-arrow-left-classes="fa fa-angle-left g-left-0" data-arrow-right-classes="fa fa-angle-right g-right-0">

                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="js-slide">
                        <a class="js-fancybox" href="javascript:;" data-slide="prev" data-fancybox="lightbox-gallery--07-1" data-src="/frontend-assets/main-assets/assets/img-temp/900x600/img5.jpg" data-caption="Lightbox Gallery" data-animate-in="bounceInDown" data-animate-out="bounceOutDown" data-speed="1000" data-overlay-blur-bg="true">
                          <section>
                              <div class="" style="width:100%;height:30rem ;">
                            <img id="slider-img" style="width:100%; height:40rem;" src="<?php echo e(asset('assets/images/'.$slider->photo)); ?>">
                              </div>
                          </section>

                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


    </div>
</div>

<?php endif; ?>

<script src="<?php echo e(url('/assets/front/js/jssor.slider-28.0.0.min.js')); ?>" type="text/javascript"></script>
<script type="text/javascript">
    window.jssor_1_slider_init = function() {

        var jssor_1_SlideoTransitions = [
          [{b:-1,d:1,ls:0.5},{b:0,d:1000,y:5,e:{y:6}}],
          [{b:-1,d:1,ls:0.5},{b:200,d:1000,y:25,e:{y:6}}],
          [{b:-1,d:1,ls:0.5},{b:400,d:1000,y:45,e:{y:6}}],
          [{b:-1,d:1,ls:0.5},{b:600,d:1000,y:65,e:{y:6}}],
          [{b:-1,d:1,ls:0.5},{b:800,d:1000,y:85,e:{y:6}}],
          [{b:-1,d:1,ls:0.5},{b:500,d:1000,y:195,e:{y:6}}],
          [{b:0,d:2000,y:30,e:{y:3}}],
          [{b:-1,d:1,rY:-15,tZ:100},{b:0,d:1500,y:30,o:1,e:{y:3}}],
          [{b:-1,d:1,rY:-15,tZ:-100},{b:0,d:1500,y:100,o:0.8,e:{y:3}}],
          [{b:500,d:1500,o:1}],
          [{b:0,d:1000,y:380,e:{y:6}}],
          [{b:300,d:1000,x:80,e:{x:6}}],
          [{b:300,d:1000,x:330,e:{x:6}}],
          [{b:-1,d:1,r:-110,sX:5,sY:5},{b:0,d:2000,o:1,r:-20,sX:1,sY:1,e:{o:6,r:6,sX:6,sY:6}}],
          [{b:0,d:600,x:150,o:0.5,e:{x:6}}],
          [{b:0,d:600,x:1140,o:0.6,e:{x:6}}],
          [{b:-1,d:1,sX:5,sY:5},{b:600,d:600,o:1,sX:1,sY:1,e:{sX:3,sY:3}}]
        ];

        var jssor_1_options = {
          $AutoPlay: 1,
          $LazyLoading: 1,
          $CaptionSliderOptions: {
            $Class: $JssorCaptionSlideo$,
            $Transitions: jssor_1_SlideoTransitions
          },
          $ArrowNavigatorOptions: {
            $Class: $JssorArrowNavigator$
          },
          $BulletNavigatorOptions: {
            $Class: $JssorBulletNavigator$,
            $SpacingX: 20,
            $SpacingY: 20
          }
        };

        var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);

        /*#region responsive code begin*/

        var MAX_WIDTH = 1600;

        function ScaleSlider() {
            var containerElement = jssor_1_slider.$Elmt.parentNode;
            var containerWidth = containerElement.clientWidth;

            if (containerWidth) {

                var expectedWidth = Math.min(MAX_WIDTH || containerWidth, containerWidth);

                jssor_1_slider.$ScaleWidth(expectedWidth);
            }
            else {
                window.setTimeout(ScaleSlider, 30);
            }
        }

        ScaleSlider();

        $Jssor$.$AddEvent(window, "load", ScaleSlider);
        $Jssor$.$AddEvent(window, "resize", ScaleSlider);
        $Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
        /*#endregion responsive code end*/
    };
</script>
<link href="//fonts.googleapis.com/css?family=Roboto+Condensed:300,300italic,regular,italic,700,700italic&subset=latin-ext,greek-ext,cyrillic-ext,greek,vietnamese,latin,cyrillic" rel="stylesheet" type="text/css" />
<style>
    /* jssor slider loading skin spin css */
    .jssorl-009-spin img {
        animation-name: jssorl-009-spin;
        animation-duration: 1.6s;
        animation-iteration-count: infinite;
        animation-timing-function: linear;
    }

    @keyframes  jssorl-009-spin {
        from {
            transform: rotate(0deg);
        }

        to {
            transform: rotate(360deg);
        }
    }


    /*jssor slider bullet skin 132 css*/
    .jssorb132 {position:absolute;}
    .jssorb132 .i {position:absolute;cursor:pointer;}
    .jssorb132 .i .b {fill:#fff;fill-opacity:0.8;stroke:#000;stroke-width:1600;stroke-miterlimit:10;stroke-opacity:0.7;}
    .jssorb132 .i:hover .b {fill:#000;fill-opacity:.7;stroke:#fff;stroke-width:2000;stroke-opacity:0.8;}
    .jssorb132 .iav .b {fill:#000;stroke:#fff;stroke-width:2400;fill-opacity:0.8;stroke-opacity:1;}
    .jssorb132 .i.idn {opacity:0.3;}

    .jssora051 {display:block;position:absolute;cursor:pointer;}
    .jssora051 .a {fill:none;stroke:#fff;stroke-width:360;stroke-miterlimit:10;}
    .jssora051:hover {opacity:.8;}
    .jssora051.jssora051dn {opacity:.5;}
    .jssora051.jssora051ds {opacity:.3;pointer-events:none;}
</style>
<svg viewbox="0 0 0 0" width="0" height="0" style="display:block;position:relative;left:0px;top:0px;">
    <defs>
        <filter id="jssor_1_flt_1" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stddeviation="4"></feGaussianBlur>
        </filter>
        <radialGradient id="jssor_1_grd_2">
            <stop offset="0" stop-color="#fff"></stop>
            <stop offset="1" stop-color="#000"></stop>
        </radialGradient>
        <mask id="jssor_1_msk_3">
            <path fill="url(#jssor_1_grd_2)" d="M600,0L600,400L0,400L0,0Z" x="0" y="0" style="position:absolute;overflow:visible;"></path>
        </mask>
    </defs>
</svg>

<?php if($gs->slider == 0): ?>
<div id="jssor_1" style="position:relative;margin:0 auto;top:0px;left:0px;width:1600px;height:400px;overflow:hidden;visibility:hidden;">
    <!-- Loading Screen -->
    <div data-u="loading" class="jssorl-009-spin" style="position:absolute;top:0px;left:0px;width:100%;height:100%;text-align:center;background-color:rgba(0,0,0,0.7);">
        <img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;" src="img/spin.svg" />
    </div>
    <div id="slider-image" data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:1600px;height:400px;overflow:hidden;">

      <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div style="background-color:#d3890e;">
            <img data-u="image" style="opacity:1; " data-src="<?php echo e(asset('assets/images/'.$slider->photo)); ?>" />
            <div data-ts="flat" data-p="1080" style="left:0px;top:0px;width:1600px;height:560px;position:absolute; background-color: rgba(0,0,0,0.25);">
                
                <svg viewbox="0 0 800 72" data-to="50% 50%" width="800" height="72" data-t="11" style="left:-800px;top:78px;display:block;position:absolute;font-family:'Roboto Condensed',sans-serif;font-size:84px;font-weight:900;overflow:visible;">
                    <text fill="white" text-anchor="middle" x="400" y="72">MERO HEALTH CARE
                    </text>
                </svg>
                <svg viewbox="0 0 800 72" data-to="50% 50%" width="800" height="72" data-t="12" style="left:1600px;top:153px;display:block;position:absolute;font-family:'Roboto Condensed',sans-serif;font-size:60px;font-weight:900;overflow:visible;">
                    <text fill="white" text-anchor="middle" x="400" y="72">MY HEALTHCARE PARTNER
                    </text>
                </svg>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div><a data-scale="0" href="https://www.jssor.com" style="display:none;position:absolute;">slider html</a>
    <!-- Bullet Navigator -->
    <div data-u="navigator" class="jssorb132" style="position:absolute;bottom:24px;right:16px;" data-autocenter="1" data-scale="0.5" data-scale-bottom="0.75">
        <div data-u="prototype" class="i" style="width:12px;height:12px;">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <circle class="b" cx="8000" cy="8000" r="5800"></circle>
            </svg>
        </div>
    </div>
    <!-- Arrow Navigator -->
    <div data-u="arrowleft" class="jssora051" style="width:55px;height:55px;top:0px;left:25px;" data-autocenter="2" data-scale="0.75" data-scale-left="0.75">
        <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
            <polyline class="a" points="11040,1920 4960,8000 11040,14080 "></polyline>
        </svg>
    </div>
    <div data-u="arrowright" class="jssora051" style="width:55px;height:55px;top:0px;right:25px;" data-autocenter="2" data-scale="0.75" data-scale-right="0.75">
        <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
            <polyline class="a" points="4960,1920 11040,8000 4960,14080 "></polyline>
        </svg>
    </div>
</div>

<?php endif; ?>
<script type="text/javascript">jssor_1_slider_init();
</script>






      <!-- End Products Block -->




 


<div class="g-mx-minus-15">
    <div class="section-title text-center g-mt-15">
        <h2 class="text-uppercase"><?php echo e($lang->featured_product); ?></h2>
    </div>
    <div class="js-carousel g-pb-40" style="padding:2rem;" data-autoplay="false" data-slides-show="6" data-slides-scroll="1" data-arrows-classes="u-arrow-v1 g-pos-abs g-bottom-0 g-width-45 g-height-45 g-font-size-default g-color-gray-dark-v5 g-bg-gray-light-v5 g-color-white--hover g-bg-primary--hover g-rounded-30" data-arrow-left-classes="fa fa-angle-left g-left-35x--lg g-left-15" data-arrow-right-classes="fa fa-angle-right g-right-35x--lg g-right-15" data-pagi-classes="u-carousel-indicators-v1 g-absolute-centered--x g-bottom-20 text-center"
        data-responsive='[{
            "breakpoint": 1050,
            "settings": {
            "slidesToShow": 4
            }
        },{
            "breakpoint": 992,
            "settings": {
            "slidesToShow": 4
            }
        }, {
            "breakpoint": 768,
            "settings": {
            "slidesToShow": 2
            }
        }, {
            "breakpoint": 554,
            "settings": {
            "slidesToShow": 2
            }
        }]'>



    <?php $__currentLoopData = $fproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



    <div class="js-slide g-px-5" >
        <!-- Article -->
        <div class="u-shadow-v19 u-shadow-v20--hover">
            <?php 
                $name = str_replace(" ","-",$prod->name);
             ?>
            <div class="single-product-area text-center" style="margin-bottom:0px;" >
              <div class="product-image-area">
                <?php if($prod->features!=null && $prod->colors!=null): ?>
                  <?php 
                  $title = explode(',', $prod->features);
                  $details = explode(',', $prod->colors);
                   ?>
                  
                <?php endif; ?>
                <img src="<?php echo e(asset('assets/images/'.$prod->photo)); ?>" alt="featured product">
                <?php if($prod->youtube != null): ?>
                  <div class="product-hover-top">
                    <span class="fancybox" data-fancybox href="<?php echo e($prod->youtube); ?>"><i class="fa fa-play-circle"></i></span>
                  </div>
                <?php endif; ?>

                <div class="gallery-overlay"></div>
                <div class="gallery-border"></div>
                <div class="product-hover-area">
            

            
                 
                  <?php if(Auth::guard('user')->check()): ?>
                        <input type="hidden" value="<?php echo e($prod->id); ?>">
                        <span class="hovertip addcart text-center" rel-toggle="tooltip" title="<?php echo e($lang->hcs); ?>"><a class="productDetails-addCart-btn" id="addcrt" href="javascript:;" style="cursor: pointer;">
                        </a>
                        <i class="icon-finance-100 u-line-icon-pro"></i> 
                        </span>
                    <?php else: ?>
            

                <a class="productDetails-addCart-btn" href="<?php echo e(route('business-login')); ?>" style="cursor: pointer;">
                    <span class="hovertip text-center" rel-toggle="tooltip" title="<?php echo e($lang->hcs); ?>">
                        <i class="icon-finance-100 u-line-icon-pro"></i> 
                    </span>
                </a>
                   
                    <?php endif; ?>
                </div>



              </div>
            </div>
              <div class="product-description text-center single-product-area" style="margin-top:0px;">
                <div class="product-name" style="margin-bottom: 35px;"><a href="<?php echo e(route('front.product',['id' => $prod->id, 'slug' => str_slug($name,'-')])); ?>" class="text-center"><?php echo e(strlen($prod->name) > 65 ? substr($prod->name,0,65)."..." : $prod->name); ?></a>
                  <?php if($prod->sale_from && $prod->sale_from <= $now && $prod->sale_to >= $now): ?>
                 
                      <div class="js-countdown u-countdown-v3 g-line-height-1_2 g-font-weight-300 g-color-black text-center text-uppercase" data-end-date="<?php echo e($prod->sale_to); ?>" data-month-format="%m" data-days-format="%D" data-hours-format="%H" data-minutes-format="%M" data-seconds-format="%S" style="margin-top:5px;">
      
      
      
                     <i class="et-icon-alarmclock u-icon-effect-v4--hover"></i>
                    <div class="d-inline-block" style="font-weight:600; font-size:14px;">
                      <div class="js-cd-days mb-0" id="dayss" style="color:green;">00 </div>
                 
                    </div>
      
                    <div class="hidden-down d-inline-block align-top g-mt-1 " style="font-weight:600; ">D :</div>
      
                    <div class="d-inline-block " style="font-weight:600; font-size:14px;">
                      <div class="js-cd-hours mb-0" id="hourss">00 H</div>
                      
                    </div>
      
                    <div class="hidden-down d-inline-block align-top g-mt-1" style="font-weight:600;">H :</div>
      
                    <div class="d-inline-block " style="font-weight:600; font-size:14px;">
                      <div class="js-cd-minutes mb-0" id="minutess">00 M</div>
                      
                    </div>
      
                    <div class="hidden-down d-inline-block align-top g-mt-1" style="font-weight:600;">M :</div>
      
                    <div class="d-inline-block " style="font-weight:600; font-size:14px;">
                      <div class="js-cd-seconds mb-0" id="secondss" style="color:red;">00 </div>
                      
                    </div>
                    <div class="hidden-down d-inline-block align-top g-mt-1" style="font-weight:600; color:red;">S </div>
                  </div>
      
                  <!--  Ending of countdown area   -->
              <?php endif; ?>

                </div>
         
                <?php if($gs->sign == 0): ?>
                    <div class="product-price"><?php echo e($curr->sign); ?>

                      <?php echo e(round($prod->cprice * $curr->value,2)); ?>

                      <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?> 
                        <span style="display:inline; font-size:12px; color:green;"><del style="color:red;" class="offer-price"><?php echo e($curr->sign); ?><?php echo e(round($prod->pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>

                      <?php endif; ?>

                    </div>
                <?php else: ?>
                    <div class="product-price">
                      <?php echo e(round($prod->cprice * $curr->value,2)); ?>

                      <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?> 
                        <span style="display:inline; font-size:12px; color:green;"><del style="color:red;" class="offer-price"><?php echo e($curr->sign); ?><?php echo e(round($prod->pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>

                      <?php endif; ?>
                      <?php echo e($curr->sign); ?>

                    </div>
                <?php endif; ?>
              </div>
              </div>
        <!-- End Article -->

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<div class="g-mx-minus-5">
    <div class="section-title text-center">
        <h2 class="text-uppercase"><?php echo e($lang->lm); ?></h2>
    </div>
    <div class="js-carousel g-pb-40" style="padding:2rem;" data-autoplay="true" data-slides-show="6" data-slides-scroll="1" data-arrows-classes="u-arrow-v1 g-pos-abs g-bottom-0 g-width-45 g-height-45 g-font-size-default g-color-gray-dark-v5 g-bg-gray-light-v5 g-color-white--hover g-bg-primary--hover g-rounded-30" data-arrow-left-classes="fa fa-angle-left g-left-35x--lg g-left-15" data-arrow-right-classes="fa fa-angle-right g-right-35x--lg g-right-15" data-pagi-classes="u-carousel-indicators-v1 g-absolute-centered--x g-bottom-20 text-center"
        data-responsive='[{
            "breakpoint": 1050,
            "settings": {
            "slidesToShow": 4
            }
        },{
            "breakpoint": 992,
            "settings": {
            "slidesToShow": 4
            }
        }, {
            "breakpoint": 768,
            "settings": {
            "slidesToShow": 2
            }
        }, {
            "breakpoint": 554,
            "settings": {
            "slidesToShow": 2
            }
        }]'>
        <?php $__currentLoopData = $beproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php 
        $prod->pprice = $prod->pprice ? : $prod->cprice;
        $prod->cprice = $prod->getPrice(1);
         ?>

        <div class="js-slide g-px-5">
        <!-- Article -->
        <div class="u-shadow-v19 u-shadow-v20--hover">
            <?php 
                $name = str_replace(" ","-",$prod->name);
             ?>
            <div class="single-product-area text-center" style="margin-bottom:0px;" >
              <div class="product-image-area" >
                <?php if($prod->features!=null && $prod->colors!=null): ?>
                  <?php 
                  $title = explode(',', $prod->features);
                  $details = explode(',', $prod->colors);
                   ?>
                  
                <?php endif; ?>
                <img src="<?php echo e(asset('assets/images/'.$prod->photo)); ?>" alt="featured product">
                <?php if($prod->youtube != null): ?>
                  <div class="product-hover-top">
                    <span class="fancybox" data-fancybox href="<?php echo e($prod->youtube); ?>"><i class="fa fa-play-circle"></i></span>
                  </div>
                <?php endif; ?>

                <div class="gallery-overlay"></div>
                <div class="gallery-border"></div>
                <div class="product-hover-area">
            

            
                 
                  <?php if(Auth::guard('user')->check()): ?>
                        <input type="hidden" value="<?php echo e($prod->id); ?>">
                        <span class="hovertip addcart text-center" rel-toggle="tooltip" title="<?php echo e($lang->hcs); ?>"><a class="productDetails-addCart-btn" id="addcrt" href="javascript:;" style="cursor: pointer;">
                        </a>
                        <i class="icon-finance-100 u-line-icon-pro"></i> 
                        </span>
                    <?php else: ?>
            

                <a class="productDetails-addCart-btn" href="<?php echo e(route('business-login')); ?>" style="cursor: pointer;">
                    <span class="hovertip text-center" rel-toggle="tooltip" title="<?php echo e($lang->hcs); ?>">
                        <i class="icon-finance-100 u-line-icon-pro"></i> 
                    </span>
                </a>
                   
                    <?php endif; ?>
                </div>



              </div>
            </div>
              <div class="product-description text-center single-product-area" style="margin-top:0px;">
                <div class="product-name" style="margin-bottom: 35px;"><a href="<?php echo e(route('front.product',['id' => $prod->id, 'slug' => str_slug($name,'-')])); ?>" class="text-center"><?php echo e(strlen($prod->name) > 65 ? substr($prod->name,0,65)."..." : $prod->name); ?></a>
                  <?php if($prod->sale_from && $prod->sale_from <= $now && $prod->sale_to >= $now): ?>
                 
                      <div class="js-countdown u-countdown-v3 g-line-height-1_2 g-font-weight-300 g-color-black text-center text-uppercase" data-end-date="<?php echo e($prod->sale_to); ?>" data-month-format="%m" data-days-format="%D" data-hours-format="%H" data-minutes-format="%M" data-seconds-format="%S" style="margin-top:5px;">
      
      
      
                     <i class="et-icon-alarmclock u-icon-effect-v4--hover"></i>
                    <div class="d-inline-block" style="font-weight:600; font-size:14px;">
                      <div class="js-cd-days mb-0" id="dayss" style="color:green;">00 </div>
                 
                    </div>
      
                    <div class="hidden-down d-inline-block align-top g-mt-1 " style="font-weight:600; ">D :</div>
      
                    <div class="d-inline-block " style="font-weight:600; font-size:14px;">
                      <div class="js-cd-hours mb-0" id="hourss">00 H</div>
                      
                    </div>
      
                    <div class="hidden-down d-inline-block align-top g-mt-1" style="font-weight:600;">H :</div>
      
                    <div class="d-inline-block " style="font-weight:600; font-size:14px;">
                      <div class="js-cd-minutes mb-0" id="minutess">00 M</div>
                      
                    </div>
      
                    <div class="hidden-down d-inline-block align-top g-mt-1" style="font-weight:600;">M :</div>
      
                    <div class="d-inline-block " style="font-weight:600; font-size:14px;">
                      <div class="js-cd-seconds mb-0" id="secondss" style="color:red;">00 </div>
                      
                    </div>
                    <div class="hidden-down d-inline-block align-top g-mt-1" style="font-weight:600; color:red;">S </div>
                  </div>
      
                  <!--  Ending of countdown area   -->
              <?php endif; ?>

                </div>
         
                <?php if($gs->sign == 0): ?>
                    <div class="product-price"><?php echo e($curr->sign); ?>

                      <?php echo e(round($prod->cprice * $curr->value,2)); ?>

                      <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?> 
                        <span style="display:inline; font-size:12px; color:green;"><del style="color:red;" class="offer-price"><?php echo e($curr->sign); ?><?php echo e(round($prod->pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>

                      <?php endif; ?>

                    </div>
                <?php else: ?>
                    <div class="product-price">
                      <?php echo e(round($prod->cprice * $curr->value,2)); ?>

                      <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?> 
                        <span style="display:inline; font-size:12px; color:green;"><del style="color:red;" class="offer-price"><?php echo e($curr->sign); ?><?php echo e(round($prod->pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>

                      <?php endif; ?>
                      <?php echo e($curr->sign); ?>

                    </div>
                <?php endif; ?>
              </div>
              </div>
        <!-- End Article -->

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<div class="g-mx-minus-5">
    <div class="section-title text-center">
        <h2 class="text-uppercase"><?php echo e($lang->rds); ?></h2>
    </div>
    <div class="js-carousel g-pb-40" style="padding:2rem;" data-autoplay="true" data-slides-show="6" data-slides-scroll="1" data-arrows-classes="u-arrow-v1 g-pos-abs g-bottom-0 g-width-45 g-height-45 g-font-size-default g-color-gray-dark-v5 g-bg-gray-light-v5 g-color-white--hover g-bg-primary--hover g-rounded-30" data-arrow-left-classes="fa fa-angle-left g-left-35x--lg g-left-15" data-arrow-right-classes="fa fa-angle-right g-right-35x--lg g-right-15" data-pagi-classes="u-carousel-indicators-v1 g-absolute-centered--x g-bottom-20 text-center"
        data-responsive='[{
            "breakpoint": 1050,
            "settings": {
            "slidesToShow": 4
            }
        },{
            "breakpoint": 992,
            "settings": {
            "slidesToShow": 4
            }
        }, {
            "breakpoint": 768,
            "settings": {
            "slidesToShow": 2
            }
        }, {
            "breakpoint": 554,
            "settings": {
            "slidesToShow": 2
            }
        }]'>
    <?php $__currentLoopData = $tproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php 
    $prod->pprice = $prod->pprice ? : $prod->cprice;
    $prod->cprice = $prod->getPrice(1);
     ?>

    <div class="js-slide g-px-5">
        <!-- Article -->
        <div class="u-shadow-v19 u-shadow-v20--hover">
            <?php 
                $name = str_replace(" ","-",$prod->name);
             ?>
            <div class="single-product-area text-center" style="margin-bottom:0px;" >
              <div class="product-image-area">
                <?php if($prod->features!=null && $prod->colors!=null): ?>
                  <?php 
                  $title = explode(',', $prod->features);
                  $details = explode(',', $prod->colors);
                   ?>
                  
                <?php endif; ?>
                <img src="<?php echo e(asset('assets/images/'.$prod->photo)); ?>" alt="featured product">
                <?php if($prod->youtube != null): ?>
                  <div class="product-hover-top">
                    <span class="fancybox" data-fancybox href="<?php echo e($prod->youtube); ?>"><i class="fa fa-play-circle"></i></span>
                  </div>
                <?php endif; ?>

                <div class="gallery-overlay"></div>
                <div class="gallery-border"></div>
                <div class="product-hover-area">
            

            
                 
                  <?php if(Auth::guard('user')->check()): ?>
                        <input type="hidden" value="<?php echo e($prod->id); ?>">
                        <span class="hovertip addcart text-center" rel-toggle="tooltip" title="<?php echo e($lang->hcs); ?>"><a class="productDetails-addCart-btn" id="addcrt" href="javascript:;" style="cursor: pointer;">
                        </a>
                        <i class="icon-finance-100 u-line-icon-pro"></i> 
                        </span>
                    <?php else: ?>
            

                <a class="productDetails-addCart-btn" href="<?php echo e(route('business-login')); ?>" style="cursor: pointer;">
                    <span class="hovertip text-center" rel-toggle="tooltip" title="<?php echo e($lang->hcs); ?>">
                        <i class="icon-finance-100 u-line-icon-pro"></i> 
                    </span>
                </a>
                   
                    <?php endif; ?>
                </div>



              </div>
            </div>
              <div class="product-description text-center single-product-area" style="margin-top:0px;">
                <div class="product-name" style="margin-bottom: 35px;"><a href="<?php echo e(route('front.product',['id' => $prod->id, 'slug' => str_slug($name,'-')])); ?>" class="text-center"><?php echo e(strlen($prod->name) > 65 ? substr($prod->name,0,65)."..." : $prod->name); ?></a>
                  <?php if($prod->sale_from && $prod->sale_from <= $now && $prod->sale_to >= $now): ?>
                 
                      <div class="js-countdown u-countdown-v3 g-line-height-1_2 g-font-weight-300 g-color-black text-center text-uppercase" data-end-date="<?php echo e($prod->sale_to); ?>" data-month-format="%m" data-days-format="%D" data-hours-format="%H" data-minutes-format="%M" data-seconds-format="%S" style="margin-top:5px;">
      
      
      
                     <i class="et-icon-alarmclock u-icon-effect-v4--hover"></i>
                    <div class="d-inline-block" style="font-weight:600; font-size:14px;">
                      <div class="js-cd-days mb-0" id="dayss" style="color:green;">00 </div>
                 
                    </div>
      
                    <div class="hidden-down d-inline-block align-top g-mt-1 " style="font-weight:600; ">D :</div>
      
                    <div class="d-inline-block " style="font-weight:600; font-size:14px;">
                      <div class="js-cd-hours mb-0" id="hourss">00 H</div>
                      
                    </div>
      
                    <div class="hidden-down d-inline-block align-top g-mt-1" style="font-weight:600;">H :</div>
      
                    <div class="d-inline-block " style="font-weight:600; font-size:14px;">
                      <div class="js-cd-minutes mb-0" id="minutess">00 M</div>
                      
                    </div>
      
                    <div class="hidden-down d-inline-block align-top g-mt-1" style="font-weight:600;">M :</div>
      
                    <div class="d-inline-block " style="font-weight:600; font-size:14px;">
                      <div class="js-cd-seconds mb-0" id="secondss" style="color:red;">00 </div>
                      
                    </div>
                    <div class="hidden-down d-inline-block align-top g-mt-1" style="font-weight:600; color:red;">S </div>
                  </div>
      
                  <!--  Ending of countdown area   -->
              <?php endif; ?>

                </div>
         
                <?php if($gs->sign == 0): ?>
                    <div class="product-price"><?php echo e($curr->sign); ?>

                      <?php echo e(round($prod->cprice * $curr->value,2)); ?>

                      <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?> 
                        <span style="display:inline; font-size:12px; color:green;"><del style="color:red;" class="offer-price"><?php echo e($curr->sign); ?><?php echo e(round($prod->pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>

                      <?php endif; ?>

                    </div>
                <?php else: ?>
                    <div class="product-price">
                      <?php echo e(round($prod->cprice * $curr->value,2)); ?>

                      <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?> 
                        <span style="display:inline; font-size:12px; color:green;"><del style="color:red;" class="offer-price"><?php echo e($curr->sign); ?><?php echo e(round($prod->pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>

                      <?php endif; ?>
                      <?php echo e($curr->sign); ?>

                    </div>
                <?php endif; ?>
              </div>
              </div>
        <!-- End Article -->

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


      <!-- End Products Block -->
    

    

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
    $(document).on("click", ".addcart" , function(){
        var pid = $(this).parent().find('input[type=hidden]').val();
            $.ajax({
                    type: "GET",
                    url:"<?php echo e(URL::to('/json/addcart')); ?>",
                    data:{id:pid},
                    success:function(data){
                        if(data == 0)
                        {
                            $.notify("<?php echo e($gs->cart_error); ?>","error");
                        }
                        else
                        {
                        $(".empty").html("");
                        $(".total").html((data[0] * <?php echo e($curr->value); ?>).toFixed(2));
                        $(".cart-quantity").html(data[2]);
                        var arr = $.map(data[1], function(el) {
                        return el });
                        $(".cart").html("");
                        for(var k in arr)
                        {
                            var x = arr[k]['item']['name'];
                            var p = x.length  > 45 ? x.substring(0,45)+'...' : x;
                            var measure = arr[k]['item']['measure'] != null ? arr[k]['item']['measure'] : "";
                            $(".cart").append(
                            '<div class="single-myCart">'+
            '<p class="cart-close" onclick="remove('+arr[k]['item']['id']+')"><i class="fa fa-close"></i></p>'+
                            '<div class="cart-img">'+
                    '<img src="<?php echo e(asset('assets/images/')); ?>/'+arr[k]['item']['photo']+'" alt="Product image">'+
                            '</div>'+
                            '<div class="cart-info">'+
        '<a href="<?php echo e(url('/')); ?>/product/'+arr[k]['item']['id']+'/'+arr[k]['item']['name']+'" style="color: black; padding: 0 0;">'+'<h5>'+p+'</h5></a>'+
                        '<p><?php echo e($lang->cquantity); ?>: <span id="cqt'+arr[k]['item']['id']+'">'+arr[k]['qty']+'</span> '+measure+'</p>'+
                        <?php if($gs->sign == 0): ?>
                        '<p><?php echo e($curr->sign); ?><span id="prct'+arr[k]['item']['id']+'">'+(arr[k]['price'] * <?php echo e($curr->value); ?>).toFixed(2)+'</span></p>'+
                        <?php else: ?>
                        '<p><span id="prct'+arr[k]['item']['id']+'">'+(arr[k]['price'] * <?php echo e($curr->value); ?>).toFixed(2)+'</span><?php echo e($curr->sign); ?></p>'+
                        <?php endif; ?>
                        '</div>'+
                        '</div>');
                          }
                        $.notify("<?php echo e($gs->cart_success); ?>","success");
                        }
                    },
                    error: function(data){
                        if(data.responseJSON)
                        $.notify(data.responseJSON.error,"error");
                        else
                        $.notify('Something went wrong',"error");
  
                    }
              }); 
        return false;
    });
  
    $(document).on("click", ".addcartforSearch" , function(){
        
        var pid = $(this).parent().parent().find('input[type=hidden]').val();
        var quantityDiv = $(this).parent();
  
        $.ajax({
            type: "GET",
            url:"<?php echo e(URL::to('/json/addcart')); ?>",
            data:{id:pid},
            success:function(data){
                if(data == 0)
                {
                    $.notify("<?php echo e($gs->cart_error); ?>","error");
                }
                else
                {
                    var qty = 1;
  
                    $(".empty").html("");
                    $(".total").html((data[0] * <?php echo e($curr->value); ?>).toFixed(2));
                    $(".cart-quantity").html(data[2]);
                    var arr = $.map(data[1], function(el) {
                        return el 
                    });
                    $(".cart").html("");
                    for(var k in arr)
                    {
                        if(arr[k]['item']['id'] == pid) qty = arr[k]['qty'];
  
                        var x = arr[k]['item']['name'];
                        var p = x.length  > 45 ? x.substring(0,45)+'...' : x;
                        var measure = arr[k]['item']['measure'] != null ? arr[k]['item']['measure'] : "";
                        $(".cart").append(
                            '<div class="single-myCart">'+
                                '<p class="cart-close" onclick="remove('+arr[k]['item']['id']+')"><i class="fa fa-close"></i></p>'+
                                '<div class="cart-img">'+
                                    '<img src="<?php echo e(asset('assets/images/')); ?>/'+arr[k]['item']['photo']+'" alt="Product image">'+
                                '</div>'+
                                '<div class="cart-info">'+
                                    '<a href="<?php echo e(url('/')); ?>/product/'+arr[k]['item']['id']+'/'+arr[k]['item']['name']+'" style="color: black; padding: 0 0;">'+'<h5>'+p+'</h5></a>'+
                                    '<p><?php echo e($lang->cquantity); ?>: <span id="cqt'+arr[k]['item']['id']+'">'+arr[k]['qty']+'</span> '+measure+'</p>'+
                                    <?php if($gs->sign == 0): ?>
                                    '<p><?php echo e($curr->sign); ?> <span id="prct'+arr[k]['item']['id']+'">'+(arr[k]['price'] * <?php echo e($curr->value); ?>).toFixed(2)+'</span></p>'+
                                    <?php else: ?>
                                    '<p><span id="prct'+arr[k]['item']['id']+'">'+(arr[k]['price'] * <?php echo e($curr->value); ?>).toFixed(2)+'</span><?php echo e($curr->sign); ?></p>'+
                                    <?php endif; ?>
                                '</div>'+
                            '</div>'
                        );
                    }
                    
                    quantityDiv.html(
                        '<span class="quantity-btn reducingforSearch"><i class="fa fa-minus"></i></span>'+
                        '<span class="qtyforSearch">'+qty+'</span>'+
                        '<span class="quantity-btn addingforSearch"><i class="fa fa-plus"></i></span>'
                    );
                    $.notify("<?php echo e($gs->cart_success); ?>","success");
                }
            },
            error: function(data){
                if(data.responseJSON)
                $.notify(data.responseJSON.error,"error");
              else
                $.notify('Something went wrong',"error");
  
            }
        }); 
        return false;
    });
  
    $(document).on("click", ".addingforSearch" , function(e){
        e.preventDefault()
        var pid =  $(this).parent().parent().find('input[type=hidden]').val();
        var qty = $(this).parent().find(".qtyforSearch").html();
        var quantityDiv = $(this).parent();
  
        $.ajax({
            type: "GET",
            url:"<?php echo e(URL::to('/json/addbyone')); ?>",
            data:{id:pid},
            success:function(data){
                if(data == 0)
                {
                    $.notify("<?php echo e($gs->cart_error); ?>","error");
                }
                else
                {
                    $(".total").html((data[0] * <?php echo e($curr->value); ?>).toFixed(2));                        
                    $(".cart-quantity").html(data[3]);
                    $("#cqty"+pid).val("1");
                    $("#prc"+pid).html((data[2] * <?php echo e($curr->value); ?>).toFixed(2));
                    $('.cart-info').find("#prct"+pid).html((data[2] * <?php echo e($curr->value); ?>).toFixed(2));
                    $('.cart-info').find("#cqt"+pid).html(data[1]);
                    quantityDiv.find(".qtyforSearch").html(data[1]);
                }
            },
            error: function(data){
            if(data.responseJSON)
                $.notify(data.responseJSON.error,"error");
              else
                $.notify('Something went wrong',"error");
  
            }
        }); 
    });
  
    $(document).on("click", ".reducingforSearch" , function(e){
        e.preventDefault()
        var id =  $(this).parent().parent().find('input[type=hidden]').val();
        var qty = $(this).parent().find(".qtyforSearch").html();
        var quantityDiv = $(this).parent();
        qty--;
        if(qty < 1)
        {
            remove(id);
            quantityDiv.html('<button class="btn btn-sm btn-primary addcartforSearch">Add to Cart</button>');
        }
        else{
         
            $.ajax({
                type: "GET",
                url:"<?php echo e(URL::to('/json/reducebyone')); ?>",
                data:{id:id},
                success:function(data){
                    $(".total").html((data[0] * <?php echo e($curr->value); ?>).toFixed(2));
                    $(".cart-quantity").html(data[3]);
                    $("#cqty"+id).val("1");
                    $("#prc"+id).html((data[2] * <?php echo e($curr->value); ?>).toFixed(2));
                    
                    $('.cart-info').find("#prct"+id).html((data[2] * <?php echo e($curr->value); ?>).toFixed(2));
                    $('.cart-info').find("#cqt"+id).html(data[1]);
                    quantityDiv.find(".qtyforSearch").html(data[1]);
                    
                },
                error: function(data){
                    $.notify('Something went wrong',"error");
  
                }
            }); 
        }
    });
  
    </script>


<?php if($prod->sale_from && $prod->sale_from <= $now && $prod->sale_to >= $now): ?>
  <script type="text/javascript">
    function makeTimer() {

      var endTime = new Date("<?php echo e($prod->sale_to); ?>");
        endTime = (Date.parse(endTime) / 1000);

        var now = new Date();
        now = (Date.parse(now) / 1000);

        var timeLeft = endTime - now;

        if(timeLeft<0) return;

        var days = Math.floor(timeLeft / 86400);
        var hours = Math.floor((timeLeft - (days * 86400)) / 3600);
        var minutes = Math.floor((timeLeft - (days * 86400) - (hours * 3600 )) / 60);
        var seconds = Math.floor((timeLeft - (days * 86400) - (hours * 3600) - (minutes * 60)));

        if (hours < "10") { hours = "0" + hours; }
        if (minutes < "10") { minutes = "0" + minutes; }
        if (seconds < "10") { seconds = "0" + seconds; }

        $("#dayss").html(days);
        $("#hourss").html(hours);
        $("#minutess").html(minutes);
        $("#secondss").html(seconds);

    }

    setInterval(function() { makeTimer(); }, 1000);

  </script>
<?php endif; ?>

<script  src="<?php echo e(asset('frontend-assets/main-assets/assets/vendor/jquery.countdown.min.js')); ?>"></script>

              <!-- JS Unify -->
              <script  src="<?php echo e(asset('frontend-assets/main-assets/assets/js/components/hs.countdown.js')); ?>"></script>

              <!-- JS Plugins Init. -->
              <script >
                $(document).on('ready', function () {
                  // initialization of countdowns
                  var countdowns = $.HSCore.components.HSCountdown.init('.js-countdown', {
                    yearsElSelector: '.js-cd-years',
                    monthElSelector: '.js-cd-month',
                    daysElSelector: '.js-cd-days',
                    hoursElSelector: '.js-cd-hours',
                    minutesElSelector: '.js-cd-minutes',
                    secondsElSelector: '.js-cd-seconds'
                  });
                });
              </script>


    <script>
        $(window).on('load',function() {
            setTimeout(function(){

                $('#extraData').load('<?php echo e(route('front.extraIndex')); ?>');

            }, 500);
        });
        //---------Countdown-----------
        // $('#clock').countdown('<?php echo e($gs->count_date); ?>', function(event) {
        //     $(this).html(event.strftime('<span class="countdown-timer-wrap"></span><span class="single-countdown-item">%w <br/><span><?php echo e($lang->week); ?></span></span> <span class="single-countdown-item">%d <br/><span><?php echo e($lang->day); ?></span></span> <span class="single-countdown-item">%H <br/><span><?php echo e($lang->hour); ?></span></span> <span class="single-countdown-item">%M <br/><span><?php echo e($lang->minute); ?></span></span> <span class="single-countdown-item">%S <br/><span><?php echo e($lang->second); ?></span></span> </span>'));
        // });

        $('.slider').slick({
  autoplay: false,
  speed: 1600,
  lazyLoad: 'progressive',
  arrows: false,
  dots: true,
}).slickAnimation();

    </script>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>