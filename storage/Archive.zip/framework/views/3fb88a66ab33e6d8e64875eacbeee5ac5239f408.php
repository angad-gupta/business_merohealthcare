<?php $__env->startSection('content'); ?>
<div class="section-padding blog-wrap">
    <div class="container">
            <div class="row">
                    <div class="col-lg-4 g-mb-30">
                      <!-- Icon Blocks -->
                      <div class="media g-mb-15">
                        <div class="d-flex mr-4">
                          <span class="u-icon-v4 u-icon-v4-rounded-10 u-icon-v4-bg-primary g-color-white">
                            <span class="u-icon-v4-inner">
                              <i class="icon-education-087 u-line-icon-pro"></i>
                            </span>
                          </span>
                        </div>
                        <div class="media-body">
                          <h3 class="h5 g-color-black mb-15">Upload Prescription</h3>
                          <p class="g-color-gray-dark-v4">Upload image of prescription given by your doctor.</p>
                        </div>
                      </div>
                      <!-- End Icon Blocks -->
                    </div>
                  
                    <div class="col-lg-4 g-mb-30">
                      <!-- Icon Blocks -->
                      <div class="media g-mb-15">
                        <div class="d-flex mr-4">
                          <span class="u-icon-v4 u-icon-v4-rounded-10 u-icon-v4-bg-primary g-color-white">
                            <span class="u-icon-v4-inner">
                              <i class="icon-education-035 u-line-icon-pro"></i>
                            </span>
                          </span>
                        </div>
                        <div class="media-body">
                          <h3 class="h5 g-color-black mb-15">Analyze</h3>
                          <p class="g-color-gray-dark-v4">We analyze your prescription and process your order</p>
                        </div>
                      </div>
                      <!-- End Icon Blocks -->
                    </div>
                  
                    <div class="col-lg-4 g-mb-30">
                      <!-- Icon Blocks -->
                      <div class="media g-mb-15">
                        <div class="d-flex mr-4">
                          <span class="u-icon-v4 u-icon-v4-rounded-10 u-icon-v4-bg-primary g-color-white">
                            <span class="u-icon-v4-inner">
                              <i class="icon-education-141 u-line-icon-pro"></i>
                            </span>
                          </span>
                        </div>
                        <div class="media-body">
                          <h3 class="h5 g-color-black mb-15">Delivery</h3>
                          <p class="g-color-gray-dark-v4">We deliver your medicine at your doorsteps.</p>
                        </div>
                      </div>
                      <!-- End Icon Blocks -->
                    </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-12" style="background: white; padding:1rem 3rem">
                  <h3 class="g-color-black g-font-weight-600 text-center mb-5">Send us your prescription</h3>
                  <form method="POST" action="/upload-prescription-submit" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                        <div class="col-md-6 form-group g-mb-20">
                            <label class="g-color-gray-dark-v2 g-font-size-13">Name</label>
                            <input class="form-control g-color-black g-bg-white g-bg-white--focus g-brd-gray-light-v4 g-brd-primary--hover rounded-3 g-py-13 g-px-15" type="text" name="name" value="" placeholder="Enter Your Name" required="">
                        </div>
        
                        <div class="col-md-6 form-group g-mb-20">
                            <label class="g-color-gray-dark-v2 g-font-size-13">Email</label>
                            <input class="form-control g-color-black g-bg-white g-bg-white--focus g-brd-gray-light-v4 g-brd-primary--hover rounded-3 g-py-13 g-px-15" type="email" name="email" placeholder="Enter Your Email" value="" required="">
                        </div>
        
                        <div class="col-md-6 form-group g-mb-20">
                            <label class="g-color-gray-dark-v2 g-font-size-13">Location</label>
                            <input class="form-control g-color-black g-bg-white g-bg-white--focus g-brd-gray-light-v4 g-brd-primary--hover rounded-3 g-py-13 g-px-15" type="text" placeholder="Feedback" name="location" value="" required="">
                        </div>
      
                        <div class="col-md-6 form-group g-mb-20">
                            <label class="g-color-gray-dark-v2 g-font-size-13">Phone</label>
                            <input class="form-control g-color-black g-bg-white g-bg-white--focus g-brd-gray-light-v4 g-brd-primary--hover rounded-3 g-py-13 g-px-15" type="text" name="phone" placeholder="Your Phone" value="" required="">
                        </div>
      
                        <div class="col-md-12 form-group g-mb-40">
                            <label class="g-color-gray-dark-v2 g-font-size-13">Prescription</label>
                            <input type="file" name="file" class="form-control-file" id="exampleInputFile" aria-describedby="fileHelp">
    
                        </div>
                    </div>
      
                    <div class="text-center">
                      <button class="btn u-btn-primary g-font-weight-600 g-font-size-13 text-uppercase g-rounded-25 g-py-15 g-px-30" type="submit" role="button">Submit</button>
                    </div>
                  </form>
                </div>
              </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>