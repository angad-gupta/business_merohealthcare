<?php $__env->startSection('title','My Cart'); ?>
<?php $__env->startSection('content'); ?>

    <!-- Starting of ViewCart area -->
    <div class="section-padding product-shoppingCart-wrapper">
        <div class="container">
            <div class="row">
              <div class="col-lg-12">
                <div class="view-cart-title">
                  <a style="color:black;" href="<?php echo e(route('front.index')); ?>"><?php echo e(ucfirst(strtolower($lang->home))); ?></a>
                  <i class="fa fa-angle-right"></i>
                  <a style="color:black;" href="<?php echo e(route('front.cart')); ?>"><?php echo e(ucfirst(strtolower($lang->fht))); ?></a>
                </div>
              </div>
              <div class="col-md-12 col-sm-12">
                <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="table-responsive">
                  <table class="table " style="width:100%">
                    <thead>
                      <tr>
                        <th><?php echo e($lang->cimage); ?></th>
                        <th colspan="4"><?php echo e($lang->cproduct); ?></th>
                        <th><?php echo e($lang->cquantity); ?></th>
                        <th><?php echo e($lang->cupice); ?></th>
                        <th><?php echo e($lang->cst); ?></th>
                        <th><?php echo e($lang->cremove); ?></th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php if(Session::has('cart')): ?>
                          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="del<?php echo e($product['item']['id']); ?>">
                              <td><img src="<?php echo e(asset('assets/images/'.$product['item']['photo'])); ?>" style="height: 150px; width: 150px;" alt="table image"></td>
                          
                            
                              <td colspan="4">
                                <p class="text-center product-name-header"><a href="<?php echo e(route('front.product',[$product['item']['id'],str_slug($product['item']['name'],'-')])); ?>"><?php echo e(strlen($product['item']['name']) > 30 ? substr($product['item']['name'],0,30).'...' : $product['item']['name']); ?></a></p>
                                <p class="table-product-review">
                                  
                                  <?php 
                                  $prod =App\Product::findOrFail($product['item']['id']);

                                   ?>
                                  
                                </p>
                              </td>
                              <td>
                                <div class="productDetails-quantity">
                                  <p><?php echo e($lang->cquantity); ?></p>
                                  <span class="quantity-btn reducing"><i class="fa fa-minus"></i></span>
                                  <span id="qty<?php echo e($product['item']['id']); ?>"><?php echo e($product['qty']); ?></span>
                                  <input type="hidden" value="<?php echo e($product['item']['id']); ?>">    
                                  <span class="quantity-btn adding"><i class="fa fa-plus"></i></span>
                                  
                                </div>
                              </td>
                              <input type="hidden" id="stock<?php echo e($product['item']['id']); ?>" value="<?php echo e($product['stock']); ?>">
                              <td>
                                <?php if($gs->sign == 0): ?>
                                <?php echo e($curr->sign); ?><?php echo e(round($product['item']['cprice'] * $curr->value, 2)); ?>

                                <?php else: ?>
                                <?php echo e(round($product['item']['cprice'] * $curr->value, 2)); ?><?php echo e($curr->sign); ?>

                                <?php endif; ?>
                              </td>
                              <td>
                                <?php if($gs->sign == 0): ?>
                                  <?php echo e($curr->sign); ?><span id="prc<?php echo e($product['item']['id']); ?>"><?php echo e(round($product['price'] * $curr->value, 2)); ?></span>
                                  <span style="font-size:12px;color:red" id="reduced<?php echo e($product['item']['id']); ?>">
                                    <?php if($product['item']['cprice'] != $product['item']['price']): ?> 
                                      <del><?php echo e($curr->sign); ?><?php echo e(round($product['item']['cprice'] * $product['qty'] * $curr->value, 2)); ?></del> 
                                    <?php endif; ?>
                                  </span>
                                <?php else: ?>
                                  <span id="prc<?php echo e($product['item']['id']); ?>"><?php echo e(round($product['price'] * $curr->value, 2)); ?></span><?php echo e($curr->sign); ?>

                                  <span style="font-size:12px;color:red" id="reduced<?php echo e($product['item']['id']); ?>">
                                    <?php if($product['item']['cprice'] != $product['item']['price']): ?> 
                                      <del><?php echo e(round($product['item']['cprice'] * $product['qty'] * $curr->value, 2)); ?><?php echo e($curr->sign); ?></del>
                                    <?php endif; ?>
                                  </span>
                                <?php endif; ?>
                              </td>
                              <td><button class="btn btn-danger" style="border-radius:30px;"><i class="fa fa-trash-o" aria-hidden="true" style="cursor: pointer;" onclick="remove(<?php echo e($product['item']['id']); ?>)"></i></button></td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                          <tr>
                            <td colspan="9"><h2 class="text-center"><?php echo e($lang->h); ?></h2></td>
                          </tr>
                        <?php endif; ?>
                    </tbody>
                    <tfoot>
                      <?php if(Session::has('cart')): ?>
                        <tr>
                          <td colspan="7"></td>
                          <td><h3 style="text-align: right;"><?php echo e($lang->vt); ?></h3></td>
                          <td><h3 style="text-align: right;">
                            <?php if($gs->sign == 0): ?>
                            <?php echo e($curr->sign); ?><span class="total" id="grandtotal"><?php echo e(round($totalPrice * $curr->value, 2)); ?></span>
                            <?php else: ?>
                            <span class="total" id="grandtotal"><?php echo e(round($totalPrice * $curr->value, 2)); ?></span><?php echo e($curr->sign); ?>

                            <?php endif; ?>
                          </h3>
                          </td>
                        </tr>
                      <?php endif; ?>
                      <tr>
                        <td colspan="5">
                          <a href="<?php echo e(route('front.index')); ?>" class="shopping-btn"><?php echo e($lang->ccs); ?></a>
                        </td>
                        <td colspan="4">
                          <a href="<?php echo e(route('front.checkout')); ?>" class="update-shopping-btn"><?php echo e($lang->cpc); ?></a>
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            </div>
        </div>
    </div>
    <!-- Ending of ViewCart area -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script type="text/javascript">
      $(document).on("click", ".adding" , function(){
        var pid =  $(this).parent().find('input[type=hidden]').val();
        var stck = $("#stock"+pid).val();
        var qty = $("#qty"+pid).html();
        if(stck != "")
        {
          var stk = parseInt(stck);
          if(qty <= stk)
          {
             qty++;
            $("#qty"+pid).html(qty);            
          }
        }
        else{
          qty++;
          $("#qty"+pid).html(qty);      
        }
          $.ajax({
            type: "GET",
            url:"<?php echo e(URL::to('/json/addbyone')); ?>",
            data:{id:pid},
            success:function(data){
              if(data == 0)
              {
                $.notify("<?php echo e($gs->cart_error); ?>","error");
              }
              else
              {
                $(".total").html((data[0] * <?php echo e($curr->value); ?>).toFixed(2));                        
                $(".cart-quantity").html(data[3]);
                $("#cqty"+pid).val("1");
                $("#prc"+pid).html((data[2] * <?php echo e($curr->value); ?>).toFixed(2));
                $("#prct"+pid).html((data[2] * <?php echo e($curr->value); ?>).toFixed(2));
                $("#cqt"+pid).html(data[1]);
                $("#qty"+pid).html(data[1]);
                if(data[2] == data[4]) $('#reduced'+id).html('')
                else {
                  if(<?php echo e($gs->sign == 0); ?>) $('#reduced'+pid).html("<del><?php echo e($curr->sign); ?>"+(data[4] * data[1] * <?php echo e($curr->value); ?>).toFixed(2)+"</del>");
                  else $('#reduced'+pid).html("<del>"+(data[4] * data[1] * <?php echo e($curr->value); ?>).toFixed(2)+"<?php echo e($curr->sign); ?></del>");
                }
              }
            },
            error: function(data){
              qty--;
              $("#qty"+pid).html(qty); 

              if(data.responseJSON)
                $.notify(data.responseJSON.error,"error");
              else
                $.notify('Something went wrong',"error");

            }
          }); 
      });

      $(document).on("click", ".reducing" , function(e){
        var id =  $(this).parent().find('input[type=hidden]').val();
        var stck = $("#stock"+id).val();
        var qty = $("#qty"+id).html();
        qty--;
        if(qty < 1)
        {
          $("#qty"+id).html("1"); 
        }
        else{
            $("#qty"+id).html(qty);
            $.ajax({
              type: "GET",
              url:"<?php echo e(URL::to('/json/reducebyone')); ?>",
              data:{id:id},
              success:function(data){
                  $(".total").html((data[0] * <?php echo e($curr->value); ?>).toFixed(2));
                  $(".cart-quantity").html(data[3]);
                  $("#cqty"+id).val("1");
                  $("#prc"+id).html((data[2] * <?php echo e($curr->value); ?>).toFixed(2));
                  $("#prct"+id).html((data[2] * <?php echo e($curr->value); ?>).toFixed(2));
                  $("#cqt"+id).html(data[1]);
                  $("#qty"+id).html(data[1]);
                  if(data[2] == data[4]) $('#reduced'+id).html('')
                  else {
                    if(<?php echo e($gs->sign == 0); ?>) $('#reduced'+id).html("<del><?php echo e($curr->sign); ?>"+(data[4] * data[1] * <?php echo e($curr->value); ?>).toFixed(2)+"</del>");
                    else $('#reduced'+id).html("<del>"+(data[4] * data[1] * <?php echo e($curr->value); ?>).toFixed(2)+"<?php echo e($curr->sign); ?></del>");
                  }
              },
              error: function(data){
                qty++;
                $("#qty"+pid).html(qty); 
                
                if(data.responseJSON)
                  $.notify(data.responseJSON.error,"error");
                else
                  $.notify('Something went wrong',"error");

              }
            }); 
         }
      });
  </script>

  <script type="text/javascript">
       $(document).on("click", ".delcart" , function(){
        $(this).parent().parent().hide();
       });
  </script>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>