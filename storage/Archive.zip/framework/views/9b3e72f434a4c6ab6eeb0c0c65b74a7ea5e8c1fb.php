
<?php $__env->startSection('title','Contact Us'); ?>

<?php $__env->startSection('styles'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Starting of Section title overlay area -->
    <div class="title-overlay-wrap overlay" style="background-image: url(<?php echo e(asset('assets/images/'.$gs->bgimg)); ?>);">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 text-center">
            <h1><?php echo e($lang->contact); ?></h1>
          </div>
        </div>
      </div>
    </div>
    <!-- Ending of Section title overlay area -->


    <!-- Starting of contact us area -->
    <div class="section-padding contact-area-wrapper">
        <div class="container">
            <div class="row">
                <?php if($lang->rtl == 1): ?>
                <div class="col-md-4 col-md-offset-1 col-sm-5">
                    <div class="contact-info pt-100">
                            <?php if($gs->street != null): ?>   
                          <p class="contact-info">
                                <i class="fa fa-map-marker" aria-hidden="true"></i>
                                <?php echo e($gs->street); ?>

                            </p>
                            <?php endif; ?>

                            <?php if($gs->phone != null || $gs->fax != null ): ?> 
                            <p class="contact-info">

                                <i class="fa fa-phone" aria-hidden="true"></i>
                                <?php if($gs->phone != null && $gs->fax != null): ?>
                                <a dir="rtl" href="tel:<?php echo e($gs->phone); ?>">+<?php echo e($gs->phone); ?></a>
                                <br>
                                <a dir="rtl" href="tel:<?php echo e($gs->fax); ?>">+<?php echo e($gs->fax); ?></a>
                                <?php elseif($gs->phone != null): ?>
                            <a dir="rtl" href="tel:<?php echo e($gs->phone); ?>">+<?php echo e($gs->phone); ?></a>

                                <?php else: ?>
                                <a dir="rtl" href="tel:<?php echo e($gs->fax); ?>">+<?php echo e($gs->fax); ?></a>
                                <?php endif; ?>

                            </p>
                            <?php endif; ?>

                            <?php if($gs->site != null || $gs->email != null ): ?>
                            <p class="contact-info">                               
                                <i class="fa fa-globe" aria-hidden="true"></i>
                                <?php if($gs->site != null && $gs->email != null): ?> 
                                <a href="<?php echo e($gs->site); ?>"><?php echo e($gs->site); ?></a>
                                <br>
                                <a href="mailto:<?php echo e($gs->email); ?>"><?php echo e($gs->email); ?></a>
                                <?php elseif($gs->site != null): ?>
                                <a href="<?php echo e($gs->site); ?>"><?php echo e($gs->site); ?></a>
                                <?php else: ?>
                                <a href="mailto:<?php echo e($gs->email); ?>"><?php echo e($gs->email); ?></a>
                                <?php endif; ?>                                                                
                            </p>
                            <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-7 col-sm-7">
                        <h3 dir="<?php echo e($lang->rtl == 1 ? 'rtl':''); ?>"><?php echo e($ps->contact_title); ?></h3>
                        <p  dir="<?php echo e($lang->rtl == 1 ? 'rtl':''); ?>"><?php echo $ps->contact_text; ?></p>
                    <div class="comments-area">
                        <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo $__env->make('includes.form-error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <div class="comments-form">
                            <form action="<?php echo e(route('front.contact.submit')); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <div class="row">
                                    <div class="col-md-6">
                                        <input name="name" placeholder="<?php echo e($lang->con); ?>" required="" type="text">
                                    </div>
                                    <div class="col-md-6">
                                        <input name="phone" placeholder="<?php echo e($lang->cop); ?>" type="tel">
                                    </div>
                                </div>
                                <div class="row">
                                        <div class="col-md-12">
                                            <input name="email" placeholder="<?php echo e($lang->coe); ?>" required="" type="email">
                                        </div>
                                </div>
                                    <p><textarea name="text" id="comment" placeholder="<?php echo e($lang->cor); ?>" cols="30" rows="10" style="resize: vertical;" required=""></textarea></p>
                                    <div class="row">
                                        <?php if($lang->rtl == 1): ?>
                                        <div class="col-md-2 col-md-offset-6 col-sm-2 col-sm-offset-4 col-xs-2 col-xs-offset-4">
                                            <span style="cursor: pointer; float: right;" class="refresh_code"><i class="fa fa-refresh fa-2x" style="margin-top: 10px;"></i></span>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <img id="codeimg" src="<?php echo e(url('assets/images')); ?>/capcha_code.png">
                                        </div>
                                        <?php else: ?>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <img id="codeimg" src="<?php echo e(url('assets/images')); ?>/capcha_code.png">
                                        </div>
                                        <div class="col-md-2 col-sm-2 col-xs-2">
                                            <span style="cursor: pointer;" class="refresh_code"><i class="fa fa-refresh fa-2x" style="margin-top: 10px;"></i></span>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php if($lang->rtl == 1): ?>
                                    <div class="row">
                                    <div class="col-md-4 col-md-offset-8 col-sm-6 col-sm-offset-6 col-xs-8 col-xs-offset-4">

                                            <input name="codes" placeholder="<?php echo e($lang->enter_code); ?>" required="" type="text">
                                           <input style="float: <?php echo e($lang->rtl == 1 ? 'right':''); ?>;" name="contact_btn" value="<?php echo e($lang->sm); ?>" type="submit">
                                        </div>
                                    </div>
                                    <?php else: ?>
                                    <div class="row">
                                    <div class="col-md-4 col-sm-6 col-xs-8">

                                            <input name="codes" placeholder="<?php echo e($lang->enter_code); ?>" required="" type="text">
                                           <input  name="contact_btn" value="<?php echo e($lang->sm); ?>" type="submit">
                                        </div>
                                    </div>
                                    <?php endif; ?>

                            </form>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <div class="col-md-7 col-sm-7">
                        <h3 dir="<?php echo e($lang->rtl == 1 ? 'rtl':''); ?>"><?php echo e($ps->contact_title); ?></h3>
                        <p  dir="<?php echo e($lang->rtl == 1 ? 'rtl':''); ?>"><?php echo $ps->contact_text; ?></p>
                    <div class="comments-area">
                        <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo $__env->make('includes.form-error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <div class="comments-form">
                            <form action="<?php echo e(route('front.contact.submit')); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <div class="row">
                                    <div class="col-md-6">
                                        <input name="name" placeholder="<?php echo e($lang->con); ?>" required="" type="text">
                                    </div>
                                    <div class="col-md-6">
                                        <input name="phone" placeholder="<?php echo e($lang->cop); ?>" type="tel">
                                    </div>
                                </div>
                                <div class="row">
                                        <div class="col-md-12">
                                            <input name="email" placeholder="<?php echo e($lang->coe); ?>" required="" type="email">
                                        </div>
                                </div>
                                    <p><textarea name="text" id="comment" placeholder="<?php echo e($lang->cor); ?>" cols="30" rows="10" style="resize: vertical;" required=""></textarea></p>
                                    <div class="row">
                                        <?php if($lang->rtl == 1): ?>
                                        <div class="col-md-2 col-md-offset-6 col-sm-2 col-sm-offset-4 col-xs-2 col-xs-offset-4">
                                            <span style="cursor: pointer; float: right;" class="refresh_code"><i class="fa fa-refresh fa-2x" style="margin-top: 10px;"></i></span>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <img id="codeimg" src="<?php echo e(url('assets/images')); ?>/capcha_code.png">
                                        </div>
                                        <?php else: ?>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <img id="codeimg" src="<?php echo e(url('assets/images')); ?>/capcha_code.png">
                                        </div>
                                        <div class="col-md-2 col-sm-2 col-xs-2">
                                            <span style="cursor: pointer;" class="refresh_code"><i class="fa fa-refresh fa-2x" style="margin-top: 10px;"></i></span>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php if($lang->rtl == 1): ?>
                                    <div class="row">
                                    <div class="col-md-4 col-md-offset-8 col-sm-6 col-sm-offset-6 col-xs-8 col-xs-offset-4">

                                            <input name="codes" placeholder="<?php echo e($lang->enter_code); ?>" required="" type="text">
                                           <input style="float: <?php echo e($lang->rtl == 1 ? 'right':''); ?>;" name="contact_btn" value="<?php echo e($lang->sm); ?>" type="submit">
                                        </div>
                                    </div>
                                    <?php else: ?>
                                    <div class="row">
                                    <div class="col-md-4 col-sm-6 col-xs-8">

                                            <input name="codes" placeholder="<?php echo e($lang->enter_code); ?>" required="" type="text">
                                           <input  name="contact_btn" value="<?php echo e($lang->sm); ?>" type="submit">
                                        </div>
                                    </div>
                                    <?php endif; ?>

                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-md-offset-1 col-sm-5">
                    <div class="contact-info pt-100">
                            <?php if($gs->street != null): ?>   
                          <p class="contact-info">
                                <i class="fa fa-map-marker" aria-hidden="true"></i>
                                <?php echo e($gs->street); ?>

                            </p>
                            <?php endif; ?>

                            <?php if($gs->phone != null || $gs->fax != null ): ?> 
                            <p class="contact-info">

                                 <i class="fa fa-phone" aria-hidden="true"></i>
                                <?php if($gs->phone != null && $gs->fax != null): ?>
                                <a href="tel:<?php echo e($gs->phone); ?>">+<?php echo e($gs->phone); ?></a>
                                <br>
                                <a href="tel:<?php echo e($gs->fax); ?>">+<?php echo e($gs->fax); ?></a>
                                <?php elseif($gs->phone != null): ?>
                            <a href="tel:<?php echo e($gs->phone); ?>">+<?php echo e($gs->phone); ?></a>

                                <?php else: ?>
                                <a href="tel:<?php echo e($gs->fax); ?>">+<?php echo e($gs->fax); ?></a>
                                <?php endif; ?>

                            </p>
                            <?php endif; ?>

                            <?php if($gs->site != null || $gs->email != null ): ?>
                            <p class="contact-info">                               
                                <i class="fa fa-globe" aria-hidden="true"></i>
                                <?php if($gs->site != null && $gs->email != null): ?> 
                                <a href="<?php echo e($gs->site); ?>"><?php echo e($gs->site); ?></a>
                                <br>
                                <a href="mailto:<?php echo e($gs->email); ?>"><?php echo e($gs->email); ?></a>
                                <?php elseif($gs->site != null): ?>
                                <a href="<?php echo e($gs->site); ?>"><?php echo e($gs->site); ?></a>
                                <?php else: ?>
                                <a href="mailto:<?php echo e($gs->email); ?>"><?php echo e($gs->email); ?></a>
                                <?php endif; ?>                                                                
                            </p>
                            <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
    <!-- Ending of contact us area -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $('.refresh_code').click(function () {
            $.get('<?php echo e(url('contact/refresh_code')); ?>', function(data, status){
                $('#codeimg').attr("src","<?php echo e(url('assets/images')); ?>/capcha_code.png?time="+ Math.random());
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>