<?php $__env->startSection('title','Lab Tests'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/dzsparallaxer/dzsparallaxer.css">
<link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/dzsparallaxer/dzsscroller/scroller.css">
<link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/dzsparallaxer/advancedscroller/plugin.css">


  <style>
    #lab{
  font-weight: 700 !important;
  color:#2385aa !important; 

}
  
  .u-shadow-v21 {
    box-shadow: 0 5px 7px -1px rgba(0, 0, 0, 0.2);
    transition-property: all;
    transition-timing-function: ease;
    transition-delay: 0s;
  }
  </style>
<section class="dzsparallaxer auto-init height-is-based-on-content use-loading mode-scroll dzsprx-readyall loaded" data-options="{direction: 'reverse', settings_mode_oneelement_max_offset: '150'}">
    <div class="divimage dzsparallaxer--target w-100 u-bg-overlay g-bg-bluegray-opacity-0_5--after" style="height: 130%; background-image: url('/medimage/lb2.jpg'); transform: translate3d(0px, -47.0242px, 0px);"></div>

    <!-- Promo Block Content -->
    <div class="container u-bg-overlay__inner text-center g-py-70">
      <h2 class="h1 g-color-white g-font-weight-600 text-uppercase g-mb-30">Mero Health Lab</h2>

      <!-- Search Form -->
      <form action="/lab/tests/search" method="GET">
        <!-- Search Field -->
        <div class=" mx-auto g-mb-20">
          <div class="input-group">
            <input list="alltest" name="searchkey" type="text" class="form-control g-font-size-16 border-0" style="height:52px;margin:0 10px" value="<?php echo e(Request::get('searchkey')); ?>" placeholder="Search test here. eg (Lipid Profile)" aria-label="Search your test">
            <datalist id="alltest">
              
                <?php $__currentLoopData = Modules\Lab\Entities\LabProduct::where('status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->name); ?>">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </datalist>
            <input list="allcities" name="city" type="text" class="form-control g-font-size-16 border-0" style="height:52px;margin:0 10px" value="<?php echo e(Request::get('city')); ?>" placeholder="Search location" aria-label="Search by location" autocomplete="off">
            <datalist id="allcities">
            
                <?php echo $__env->make('includes.cities', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </datalist>
            <span class="input-group-btn">
              <button class="btn btn-primary g-font-size-18 g-py-12 g-px-25" type="submit">
                <i class="fa fa-search"></i>
              </button>
            </span>
          </div>
        </div>
              <a href="/lab/compare" class="btn btn-primary">Compare Prices</a>

        <!-- End Search Field -->

        <!-- Checkboxes -->
        
        <!-- End Checkboxes -->
      </form>
      <!-- End Search Form -->
    </div>
    <!-- End Promo Block Content -->
  </section>
 
  <div class="container g-mt-20">
        <label class="d-block g-color-gray-dark-v2 g-font-size-20">Available Tests:</label>

      <ul class="nav u-nav-v2-1 u-nav-primary g-mb-20" role="tablist" data-target="nav-2-1-primary-hor-left" data-tabs-mobile-type="slide-up-down" data-btn-classes="btn btn-md btn-block rounded-0 u-btn-outline-primary g-mb-20">

          <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item">
              <a class="nav-link <?php echo e($loop->index==0?'active':''); ?>" data-toggle="tab" href="#<?php echo e($c->id); ?>" role="tab"><?php echo e($c->name); ?></a>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    <!-- End Nav tabs -->
    
    <!-- Tab panes -->

    <div id="nav-2-1-primary-hor-left" class="tab-content">

        <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="tab-pane fade <?php echo e($loop->index==0?'show active':''); ?>" id="<?php echo e($c->id); ?>" role="tabpanel">
                <div class="row">
                    <?php 
                        $prods = $c->options()->whereHas('vendor',function($q){
                            $q->where('users.is_vendor','=',2);
                        })->where('status',1)->get();

                        if(\Request::get('city')){
                            $products = [];
                            foreach($prods as $product){
                                $vendor =  $product->vendor;
                                $areas = $vendor->service_areas ? json_decode($vendor->service_areas) : [];

                                if(in_array(\Request::get('city'),$areas)) $products []= $product;
                            }
                        }else $products = $prods;
                     ?>
                  <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <div class="col-lg-4 g-mb-30">
                        <!-- Article -->
                        <article class="u-shadow-v21 g-bg-white rounded">
                        <div class="g-pa-30">
                            <h3 class="g-font-weight-300 g-mb-15">
                            <a class="u-link-v5 g-color-main g-color-primary--hover" href="#"><?php echo e($product->vendor->name); ?></a>
                            </h3>
                            <p style="font-size: 1.25rem;"><?php echo e($c->name); ?></p>
                            <p style="font-size: 1.25rem;">Price: Rs. <?php echo e($product->cprice); ?></p>

                        </div>
                    
                        <div class=" g-font-size-12 g-brd-top g-brd-gray-light-v4 g-pa-15-30">
                        <input type="hidden" value="<?php echo e($product->id); ?>" />

                                <button class="btn btn-md u-btn-primary g-font-weight-600 g-font-size-11 text-uppercase g-py-10 addTest">
                                    <i class="g-mr-5 fa fa-heart"></i>
                                    Book Now
                                </button>
                                
                        </div>
                        </article>
                        <!-- End Article -->
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p style="margin: 20px; font-weight: 600; text-align:center;">No Tests found</p>
                  <?php endif; ?>
                  
                </div> 
                <hr>
                <div>
                  <?php echo $c->description; ?>

                </div>
           
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script src="/frontend-assets/main-assets/assets/vendor/dzsparallaxer/dzsparallaxer.js"></script>
<script src="/frontend-assets/main-assets/assets/vendor/dzsparallaxer/dzsscroller/scroller.js"></script>
<script src="/frontend-assets/main-assets/assets/vendor/dzsparallaxer/advancedscroller/plugin.js"></script>
<script >
    $(document).ready(function () {
    
      // initialization of carousel
      $.HSCore.components.HSCarousel.init('.js-carousel');
    });
  </script>
<script>
  $(document).on("click", ".addTest" , function(){
      var pid = $(this).parent().find('input[type=hidden]').val();
      var button = $(this);
      button.attr('disabled','disabled');

      $.ajax({
          type: "POST",
          url:"<?php echo e(URL::to('/lab/json/addcart')); ?>",
          data:{ test_id: pid, reset_cart: true, _token: '<?php echo e(csrf_token()); ?>' },
          success:function(data){
            if(data == 0)
            {
                $.notify("<?php echo e($gs->cart_error); ?>","error");
            }
            else
            {
              location.href = "<?php echo e(route('lab.cart')); ?>";
            }
          },
          error: function(data){
            button.removeAttr('disabled');

            $.notify("Something went wrong.","error");
          }
      }); 
      return false;
  });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>