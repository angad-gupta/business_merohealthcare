<?php $__env->startSection('body'); ?>
    
    <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;">
        <tr> 
            <td align="center" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 25px;">
                <h2 style="font-size: 30px; font-weight: 800; line-height: 36px; color: #333333; margin: 0;"> Thank You For Your Order! </h2> 
            </td>
        </tr>
        <tr>
            <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;">
                
                <p style="text-align:center;font-size: 12px;margin-bottom: 0px;margin-top: 0px;color: #454282;">Order Number: <?php echo e($order->order_number); ?></p>
                <p style="text-align:center;font-size: 12px;margin-bottom: 0px;margin-top: 0px;color: #454282;">Order Date: <?php echo e(date('d-M-Y',strtotime($order->created_at))); ?></p>
            </td>
        </tr>
        <tr>
            <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 25px;"> 
                <p style="font-size: 12px;margin-bottom: 0px;margin-top: 0px;">
                    <span style="font-weight:800"><?php echo e($order->customer_name); ?></span><br>
                    <span><?php echo e($order->customer_email); ?></span><br>
                    
                    <span><?php echo e($order->customer_phone); ?></span>
                    
                </p>
            </td>
        </tr>
        <tr>
            <td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 25px;"> 
                <p style="font-size: 12px;margin-bottom: 0px;margin-top: 0px;">
                    <?php 
                        $patient = json_decode($order->customer_details);
                        
                     ?>
                    <span style="font-weight:800">Patient Details</span><br>
                    <span>Name: <?php echo e($patient->name); ?></span><br>
                    
                    <span>Gender: <?php echo e($patient->gender); ?></span><br>
                    
                </p>
            </td>
        </tr>
    </table>
    <?php 
        $items = $order->items;
     ?>
    <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;">
        <tr style="padding-top: 20px;">
            <td><h4 style="margin-bottom:5px">Invoice</h4></td>
        </tr>
        <tr>
            <td align="left" >
                <table class="table" cellspacing="0" cellpadding="0" border="0" width="100%">
                    <thead>
                        <tr>
                            <th width="5%" style="border-bottom: 2px solid #e3ebf3;border-top: 1px solid #e3ebf3;">#</th>
                            <th style="border-bottom: 2px solid #e3ebf3;border-top: 1px solid #e3ebf3;">Item &amp; Description</th>
                            <th width="20%" style="border-bottom: 2px solid #e3ebf3;border-top: 1px solid #e3ebf3;">Rate</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $i = 1;
                            $subtotal = 0;
                         ?>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr>
                                <th width="5%" align="center"><?php echo e($i++); ?></th>
                                <td align="center">
                                    <?php echo e($product->test_name); ?></a>
                                </td>
                                <td width="20%" align="center"><?php echo e($order->currency_sign); ?><?php echo e(round($product->test_price * $order->currency_value,2)); ?></td>
                            </tr>
                            <?php 
                                $subtotal += $product->test_price;
                             ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </td>
        </tr>
        <tr>
            <td align="left" style="padding-top: 20px;">
                
                <table class="table" cellspacing="0" cellpadding="0" border="0" width="100%">
                    
                    <tr>
                        <td width="40%"></td>
                        <td width="40%" align="right" style="font-weight:800;border-top: 3px solid #eeeeee; border-bottom: 3px solid #eeeeee;">
                            Sub Total                       
                        </td>
                        <td width="20%" align="left" style="font-weight:800;border-top: 3px solid #eeeeee; border-bottom: 3px solid #eeeeee;">
                            <?php echo e($order->currency_sign); ?><?php echo e(round($subtotal * $order->currency_value , 2)); ?>

                        </td>
                    </tr> 

                    <?php if($order->discount > 0): ?>
                        <tr>
                            <td width="40%"></td>
                            <td width="40%" align="right" style="font-weight:800;border-top: 3px solid #eeeeee; border-bottom: 3px solid #eeeeee;">
                                Payment Gateway Discount (<?php echo e($order->method); ?>)                   
                            </td>
                            <td width="20%" align="left" style="font-weight:800;border-top: 3px solid #eeeeee; border-bottom: 3px solid #eeeeee;">
                                <?php echo e($order->currency_sign); ?> <?php echo e($order->discount * $order->currency_value); ?>

                            </td>
                        </tr>
                    <?php endif; ?>

                    <?php if($order->service_charge != 0): ?>
                        <tr>
                            <td width="40%"></td>
                            <td width="40%" align="right" style="font-weight:800;border-top: 3px solid #eeeeee; border-bottom: 3px solid #eeeeee;">
                                Service Charge                 
                            </td>
                            <td width="20%" align="left" style="font-weight:800;border-top: 3px solid #eeeeee; border-bottom: 3px solid #eeeeee;">
                                <?php echo e($order->currency_sign); ?><?php echo e($order->service_charge * $order->currency_value); ?>

                            </td>
                        </tr>
                    <?php endif; ?>

                    <tr>
                        <td width="40%"></td>
                        <td width="40%" align="right" style="font-weight:800;border-top: 3px solid #eeeeee; border-bottom: 3px solid #eeeeee;">
                            Total                       
                        </td>
                        <td width="20%" align="left" style="font-weight:800;border-top: 3px solid #eeeeee; border-bottom: 3px solid #eeeeee;">
                            <?php echo e($order->currency_sign); ?><?php echo e(round($order->pay_amount * $order->currency_value , 2)); ?>

                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr style="padding-top: 20px;">
            <td align="left"><h4 style="margin-bottom:5px">Payment:</h4></td>
        </tr>    
        <tr>
            
            <td>
                <p style="margin: 10px 0;">Payment Method: 
                    <?php echo e($order->method); ?>

                    <?php if($order->txnid): ?>
                        <br>TransactionId: <?php echo e($order->txnid); ?>

                    <?php endif; ?>
                </p>
            </td>
        </tr>
        
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.email', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>