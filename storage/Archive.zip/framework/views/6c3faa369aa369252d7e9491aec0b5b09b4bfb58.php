<?php $__env->startSection('styles'); ?>
<style type="text/css">
.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
    border-top: none;
}
.add-product-box {
    box-shadow: none;
}
.add-product-1
{
    padding-bottom: 30px;
}

.tabbable-panel {
  border:1px solid #eee;
  padding: 10px;
}

.tabbable-line > .nav-tabs {
  border: none;
  margin: 0px;
}
.tabbable-line > .nav-tabs > li {
  margin-right: 2px;
}
.tabbable-line > .nav-tabs > li > a {
  border: 0;
  margin-right: 0;
  color: #737373;
}
.tabbable-line > .nav-tabs > li > a > i {
  color: #a6a6a6;
}
.tabbable-line > .nav-tabs > li.open, .tabbable-line > .nav-tabs > li:hover {
  border-bottom: 4px solid rgb(80,144,247);
}
.tabbable-line > .nav-tabs > li.open > a, .tabbable-line > .nav-tabs > li:hover > a {
  border: 0;
  background: none !important;
  color: #333333;
}
.tabbable-line > .nav-tabs > li.open > a > i, .tabbable-line > .nav-tabs > li:hover > a > i {
  color: #a6a6a6;
}
.tabbable-line > .nav-tabs > li.open .dropdown-menu, .tabbable-line > .nav-tabs > li:hover .dropdown-menu {
  margin-top: 0px;
}
.tabbable-line > .nav-tabs > li.active {
  border-bottom: 4px solid #32465B;
  position: relative;
}
.tabbable-line > .nav-tabs > li.active > a {
  border: 0;
  color: #333333;
}
.tabbable-line > .nav-tabs > li.active > a > i {
  color: #404040;
}
.tabbable-line > .tab-content {
  margin-top: -3px;
  background-color: #fff;
  border: 0;
  border-top: 1px solid #eee;
  padding: 15px 0;
}
.portlet .tabbable-line > .tab-content {
  padding-bottom: 0;
}
</style>

<link rel="stylesheet" href="/frontend-assets/main-assets/assets/css/unify-globals.css">


<?php $__env->stopSection(); ?>
        
<?php $__env->startSection('content'); ?>

<div class="right-side">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <!-- Starting of Dashboard area -->
                        <div class="section-padding add-product-1">
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="add-product-box">
                                    <div class="product__header"  style="border-bottom: none;">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title">
                                                    <h2>Customer Details <a href="<?php echo e(route('admin-user-index')); ?>" style="padding: 5px 12px;" class="btn add-back-btn"><i class="fa fa-arrow-left"></i> Back</a></h2>
                                                    <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Customers <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Customer Details
                                                </div>
                                            </div>
                                              <?php echo $__env->make('includes.notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </div>   
                                    </div>
                                    <?php 
                                      $orders = App\Order::where('user_id','=',$user->id)->orderBy('id','desc')->get();
                                     ?>

                                        <div class="">
                                            <div class="row">
                                              <div class="col-md-12">
                                                      <div class="tabbable-panel">
                                                          <div class="tabbable-line">
                                                              <ul class="nav nav-tabs ">
                                                                  <li class="active">
                                                                      <a href="#tab_default_1" data-toggle="tab" style="padding-right:35px;">
                                                                           Customer Details </a>
                                                                  </li>
                                                                  <li>
                                                                      <a href="#tab_default_2" data-toggle="tab" style="padding-right:35px;">
                                                                        Orders <span class="label label-primary" style="border-radius: 20px;"> <?php echo e(count($orders)); ?></span> </a>
                                                                  </li>
                                                           
                                                              </ul>
                                                              <div class="tab-content">
                                                                  <div class="tab-pane active" id="tab_default_1">
                                                                    <table class="table" style="border-color: transparent;">
                                                                        <tbody>
                                            
                                                                            <tr>
                                                                                <td width="49%" style="text-align: right;"><strong>Customer Image :</strong></td>
                                                                                <td>
                                                                                    <?php if($user->is_provider == 1): ?>
                                                                                    <img style="width: 100px; height: 100px;border-radius:50%;" src="<?php echo e($user->photo ? $user->photo:asset('assets/images/user.png')); ?>" alt="profile no image">
                                                                                    <?php else: ?>
                                                                                    <img  style="width: 100px; height: 100px;border-radius:50%;" id="adminimg" src="<?php echo e($user->photo ? asset('assets/images/'.$user->photo):asset('assets/images/user.png')); ?>" alt="profile image">
                                                                                    <?php endif; ?>
                                                                                </td>
                                                                            </tr>
                                            
                                                                         
                                                                        <tr>
                                                                            <td width="49%" style="text-align: right;"><strong>Customer ID#</strong></td>
                                                                            <td><?php echo e($user->id); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td width="49%" style="text-align: right;"><strong>Name:</strong></td>
                                                                            <td><?php echo e($user->name); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td width="49%" style="text-align: right;"><strong>Email:</strong></td>
                                                                            <td><?php echo e($user->email); ?></td>
                                                                        </tr>
                                                                        <?php if($user->phone != ""): ?>
                                                                        <tr>
                                                                            <td width="49%" style="text-align: right;"><strong>Phone:</strong></td>
                                                                            <td><?php echo e($user->phone); ?></td>
                                                                        </tr>
                                                                        <?php endif; ?>
                                            
                                                                       
                                            
                                                                        <?php if($user->fax != ""): ?>
                                                                        <tr>
                                                                            <td width="49%" style="text-align: right;"><strong>Fax:</strong></td>
                                                                            <td><?php echo e($user->fax); ?></td>
                                                                        </tr>
                                                                        <?php endif; ?>
                                                                        <?php if($user->address != ""): ?>
                                                                        <tr>
                                                                            <td width="49%" style="text-align: right;"><strong>Address:</strong></td>
                                                                            <td><?php echo e($user->address); ?></td>
                                                                        </tr>
                                                                        <?php endif; ?>
                                            
                                                    
                                            
                                                                        
                                            
                                                                        <?php if($user->dob != ""): ?>
                                                                        <tr>
                                                                            <td width="49%" style="text-align: right;"><strong>Date Of Birth:</strong></td>
                                                                            <td><?php echo e($user->dob); ?></td>
                                                                        </tr>
                                                                        <?php endif; ?>
                                                                        <?php if($user->city != ""): ?>
                                                                        <tr>
                                                                            <td width="49%" style="text-align: right;"><strong>City:</strong></td>
                                                                            <td><?php echo e($user->city); ?></td>
                                                                        </tr>
                                                                        <?php endif; ?>
                                                                        <?php if($user->zip != ""): ?>
                                                                        <tr>
                                                                            <td width="49%" style="text-align: right;"><strong>Zip:</strong></td>
                                                                            <td><?php echo e($user->zip); ?></td>
                                                                        </tr>
                                                                        <?php endif; ?>

                                                                        <tr>
                                                                          <td width="49%" style="text-align: right;"><strong>Registration Certificates:</strong></td>
                                                                          <td>
                                                                            <?php 
                                                                              $decoded = json_decode($user->registration_file, true);
                                                                             ?>
                                                                            <?php $__currentLoopData = (array)$decoded; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <a href="<?php echo e(route('admin-businesscustomer-reg-file',[$user->id,$d])); ?>" target="_blank"><i class="fa fa-image" style="font-size:18px;"></i></a>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                          </td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td width="49%" style="text-align: right;"><strong>Joined:</strong></td>
                                                                            <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                                                                        </tr>
                                                                        <?php if($user->is_provider == 1): ?>
                                                                        <?php  
                                                                            $social = App\SocialProvider::where('user_id','=',$user->id)->first();
                                                                    
                                                                         ?>
                                                                        <tr>
                                                                            <td width="49%" style="text-align: right;"><strong>Social Login:</strong></td>
                                                                            <?php if($social->provider == 'google'): ?>
                                                                                <td>
                                                                                    <a class="u-icon-v3 g-bg-google-plus g-rounded-30x g-color-white g-color-white--hover g-mr-0 g-mb-20" style="padding:5px;border-radius:30%;" href="#!">
                                                                                        <i class="fa fa-google"></i>
                                                                                      </a>
                                                                                </td>
                                                                            <?php elseif(($social->provider == 'facebook')): ?> 
                                                                            <td>
                                                                                <a class="u-icon-v3 g-bg-facebook g-rounded-30x g-color-white g-color-white--hover g-mr-15 g-mb-20" style="padding:5px;border-radius:30%;" href="#!">
                                                                                    <i class="fa fa-facebook"></i>
                                                                                  </a>
                                                                            </td>
                                                                            <?php endif; ?>
                                                                        </tr>
                                                                        <?php endif; ?>
                                            
                                                                        </tbody>
                                                                    </table>
                                            
                                                                                
                                                                        <div class="text-center">
                                                                            <input type="hidden" value="<?php echo e($user->email); ?>"><a style="cursor: pointer;" data-toggle="modal" data-target="#emailModal1" class="btn btn-primary email1"><i class="fa fa-send"></i> Contact Customer</a>
                                                                        </div>
                                            
                                                                      </div>
                                                                  <div class="tab-pane" id="tab_default_2">
                                                                    <div class="table-responsive" style="margin-top:20px;">
                                                                     
                                                            
                                                                        <table id="product-table_wrapper" class="table table-striped table-hover products dt-responsive" cellspacing="0" width="100%">
                                                                                <thead>
                                                                                    <tr>
                                                                                      <th style="">Date</th>
                                                                                      <th style="">Invoice Number</th>
                                                                                      <th style="">Status</th>
                                                                              
                                                                                    </tr>
                                                                                </thead>
                                                            
                                                                                <tbody>
                                                                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                                                                                <tr role="row" class="odd">
                                                                                  <td> <?php echo e(date('d M Y',strtotime($order->created_at))); ?> </td>
                                                                                  <td>
                                                                                    <a href="<?php echo e(route('admin-order-invoice',$order->id)); ?>"><?php echo e(sprintf("%'.08d", $order->id)); ?></a>
                                                                                    <small style="display: block; color: #777; text-transform:uppercase;">[<?php echo e($order->order_number); ?>]</small>
                                                                                  </td>
                                                                                  <td>
                                                                                      <?php if($order->status == 'completed'): ?>
                                                                                    <span class="label label-success" style="border-radius: 20px;"> <?php echo e($order->status); ?></span>
                                                                                    <?php elseif($order->status == 'pending'): ?>
                                                                                    <span class="label label-warning" style="border-radius: 20px;"> <?php echo e($order->status); ?></span>
                                                                                    <?php elseif($order->status == 'declined'): ?>
                                                                                    <span class="label label-danger" style="border-radius: 20px;"> <?php echo e($order->status); ?></span>
                                                                                    <?php else: ?>
                                                                                    <span class="label label-primary" style="border-radius: 20px;"> <?php echo e($order->status); ?></span>
                                                                                    <?php endif; ?>
                                                                                </td>
                                                                                </tr>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                </tbody>
                                                                            </table>
                                                                        </div>
                                                                </div>
                                          
                                                                  </div>
                                                                  
                                                              </div>
                                                          </div>
                                                      </div>
                                          
                                              </div>
                                            </div>
                                          </div>

                    

                                    
                        </div>
                    </div>
                    <!-- Ending of Dashboard area --> 

                    
                </div>
            </div>
        </div>


      
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>