<?php $__env->startSection('styles'); ?>
  <style type="text/css">
  .productDetails-size span.pselected-size {
    border: 3px #2485a9 solid;
  }
    .replay-btn, .replay-btn-edit, .replay-btn-delete, .replay-btn-edit1, .replay-btn-delete1, .replay-btn-edit2, .replay-btn-delete2, .subreplay-btn, .view-replay-btn {
      color: <?php echo e($gs->colors == null ? 'gray' : $gs->colors); ?>;
      font-weight: 700;
    }
    #comments .reply {
      padding-left: 52px;
    }
    .product-details-wrapper .productDetails-size a {
      display: inline-block;
      height: 40px;
      line-height: 40px;
      border: 1px #d9d9d9 solid;
      text-align: center;
      font-size: 12px;
      color: #4c4c4c;
      font-weight: 500;
      margin-right: 12px;
      position: relative;
      cursor: pointer;
      margin-bottom: 12px;
    }
  </style>
  <?php if($lang->rtl == 1): ?>
    <style>
      #comments .reply {
        padding-left: 0;
        padding-right: 52px;
      }
      .single-blog-comments-wrap.replay {margin-left: 0; margin-right: 40px;}
    </style>
  <?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <?php 
  $i=1;
  $j=1;
  $now = Carbon\Carbon::now()->format('m/d/Y h:i A');
  $product->pprice = $product->pprice ? : $product->cprice;
  $product->cprice = $product->getPrice(1);
   ?>
    <!--  Starting of product description area   -->
    <div class="section-padding product-details-wrapper" style="padding-top: 20px; padding-bottom: 15px;">
      <div class="container">
        <div class="breadcrumb-box" style="margin-bottom: 15px;">
            <a href="<?php echo e(route('front.index')); ?>"><?php echo e(ucfirst(strtolower($lang->home))); ?></a>
            <a href="<?php echo e(route('front.category',$product->categories()->first()->cat_slug)); ?>"><?php echo e($product->categories()->first()->cat_name); ?></a>
            <?php if(count($product->subcategories) > 0): ?>
            <a href="<?php echo e(route('front.subcategory',$product->subcategories()->first()->sub_slug)); ?>"><?php echo e($product->subcategories()->first()->sub_name); ?></a>
            <?php endif; ?>
            <?php if(count($product->childcategories) > 0): ?>
            <a href="<?php echo e(route('front.childcategory',$product->childcategories()->first()->child_slug)); ?>"><?php echo e($product->childcategories()->first()->child_name); ?></a>
            <?php endif; ?>
            <a href="<?php echo e(route('front.product',['id1' => $product->id , 'id2' => str_slug($product->name,'-')])); ?>"><?php echo e($product->name); ?></a>
        </div>

       
          
          <div class="row">
            <div class="col-md-5 col-sm-5 col-xs-12">
           
                <div id="carousel-08-1" class="js-carousel text-center g-mb-20" data-infinite="true" data-arrows-classes="u-arrow-v1 g-absolute-centered--y g-width-35 g-height-40 g-font-size-18 g-color-gray g-bg-white g-mt-minus-10" data-arrow-left-classes="fa fa-angle-left g-left-0" data-arrow-right-classes="fa fa-angle-right g-right-0" data-nav-for="#carousel-08-2">
                  <?php $__currentLoopData = $product->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                  <div class="js-slide">
                    <a class="js-fancybox d-block g-pos-rel" href="javascript:;" data-fancybox="lightbox-gallery--08-1" data-src="<?php echo e(asset('assets/images/'.$product->photo)); ?>" data-caption="Lightbox Gallery" data-animate-in="bounceInDown" data-animate-out="bounceOutDown" data-speed="1000" data-overlay-blur-bg="true">
                      <img class="img-fluid" style="height:30rem;" src="<?php echo e(asset('assets/images/'.$product->photo)); ?>" alt="Image Description">
                    </a>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
                </div>
                
                <div id="carousel-08-2" class="js-carousel text-center g-mx-minus-10 u-carousel-v3" data-infinite="true" data-center-mode="true" data-slides-show="4" data-is-thumbs="true" data-nav-for="#carousel-08-1">
                  <?php $__currentLoopData = $product->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                  <div class="js-slide g-px-10">
                    <img class="img-fluid" style="height:6rem" src="<?php echo e(asset('assets/images/'.$product->photo)); ?>" alt="Image Description">
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>

            <div class="col-md-7 col-sm-7 col-xs-12">
              <?php if(strlen($product->name) > 40): ?>
                <h3 class="productDetails-header"><?php echo e($product->name); ?></h3>
              <?php else: ?>
                <h3 class="productDetails-header"><?php echo e($product->name); ?></h3>
              <?php endif; ?>
              
              <h6><?php echo e($product->company_name); ?></h6>
              <?php if($product->user_id != 0): ?>

                <?php if(isset($product->user)): ?>
                  

                    
                    


                  
                <?php endif; ?>
              <?php else: ?>

                


                

              <?php endif; ?>
              <?php if($product->youtube != null): ?>                    
                <div class="productVideo__title">
                  <?php echo e($lang->watch_video); ?>: <a style=" color:<?php echo e($gs->colors == null ? '#337ab7':$gs->colors); ?>;" class="fancybox" data-fancybox="" href="<?php echo e($product->youtube); ?>"><i class="fa fa-play-circle"></i></a>
                </div>

              <?php endif; ?>
              <?php if($product->type == 2): ?>
                  <div class="productVideo__title">
                      <?php echo e($lang->platform); ?><?php echo e($product->platform); ?>

                  </div>
                  <div class="productVideo__title">
                      <?php echo e($lang->region); ?><?php echo e($product->region); ?>

                  </div>
                  <div class="productVideo__title">
                      <?php echo e($lang->licence_type); ?><?php echo e($product->licence_type); ?>

                  </div>
              <?php endif; ?>
              <?php if($product->product_condition != 0): ?>
                <div class="productDetails-header-info">

                          <div class="product-headerInfo__title">
                    <?php echo e($lang->product_condition); ?>: <span style="font-weight: 400;"><?php echo e($product->product_condition == 1 ?'Used' : 'New'); ?>.<span>
                  </div>
                </div>
              <?php endif; ?>
              <?php if($product->ship != null): ?>
                <div class="productDetails-header-info">

                  <div class="product-headerInfo__title">
                    <?php echo e($lang->shipping_time); ?>: <span style="font-weight: 400;"><?php echo e($product->ship); ?>.</span>
                  </div>
                </div>
              <?php endif; ?>
                  
              <?php 
                $stk = (string)$product->stock;
               ?>

              
              

              <p><?php echo $product->highlights; ?></p>

              <?php if($similars->count() > 0): ?>
                <div class="productDetails-size">
                  <p>Available Variants: </p>

                  <?php $__currentLoopData = $similars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($similar->id == $product->id): ?>
                      <span class="psize pselected-size" style="width: auto;padding: 5px;cursor:default;line-height: 27px; font-size: 16px;"><?php echo e($product->sub_title); ?></span>
                    <?php else: ?>
                      <a href="<?php echo e(route('front.product',[$similar->id,str_slug($similar->name,'-')])); ?>" class="psize" style="text-decoration:none;width: auto;padding: 5px; line-height: 27px; font-size: 16px; border: 3px #d9d9d9 solid"><?php echo e($similar->sub_title); ?></a>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              <?php endif; ?>
              <div class="productDetails-size">

                <p class="mb-0">Price: </p>
               

                <?php if($gs->sign == 0): ?>
                
                  <h3 class="productDetails-price">
                    <?php echo e($curr->sign); ?>

                    
                    <?php if($product->user_id != 0): ?>

                      <?php 
                      $price = $product->cprice + $gs->fixed_commission + ($product->cprice/100) * $gs->percentage_commission ;
                       ?>
                      <?php echo e(round($price * $curr->value,2)); ?>

                      <?php if($product->pprice != null && $product->pprice != 0  && $product->pprice > $product->cprice): ?>
                        <?php 
                          $pprice = $product->pprice + $gs->fixed_commission + ($product->pprice/100) * $gs->percentage_commission ;
                            
                         ?>
                        <span style="display:inline"><del><?php echo e($curr->sign); ?><?php echo e(round($pprice * $curr->value,2)); ?></del> -<?php echo e($product->discount_percent); ?>%</span>
                      <?php endif; ?>
                    <?php else: ?>
                      <?php echo e(round($product->cprice * $curr->value,2)); ?>

                      <?php if($product->pprice != null && $product->pprice != 0  && $product->pprice > $product->cprice): ?>
                        <span style="display:inline"><del><?php echo e($curr->sign); ?><?php echo e(round($product->pprice * $curr->value,2)); ?></del> -<?php echo e($product->discount_percent); ?>%</span>
                      <?php endif; ?>
                    <?php endif; ?>                   

                    
                  </h3>
                <?php else: ?>
                  <h3 class="productDetails-price">
                    <?php if($product->user_id != 0): ?>
                      <?php 
                      $price = $product->cprice + $gs->fixed_commission + ($product->cprice/100) * $gs->percentage_commission ;
                       ?>
                      <?php echo e(round($price * $curr->value,2)); ?>

                    <?php else: ?>
                      <?php echo e(round($product->cprice * $curr->value,2)); ?>

                    <?php endif; ?>                   
                    <?php echo e($curr->sign); ?>

                    
                  </h3>                 
                  <?php endif; ?>
              </div>

              
              <?php if($product->sale_from && $product->sale_from <= $now && $product->sale_to >= $now): ?>
                  <!--  Starting of countdown area   -->
                    
                  <div class="countdown-timer-wrap">
                      <span id="days"></span>
                      <span id="hours"></span>
                      <span id="minutes"></span>
                      <span id="seconds"></span>
                  </div>
                  
                  <!--  Ending of countdown area   -->
              <?php endif; ?>
               
              <?php if($product->adv_price): ?>
              <div class="OtcPage__combo-pack___P9Cwj">
                <div class="ComboPack__combo-heading___SnepS">
                  <h3 style="font-size: 16px;font-weight: 700;">Combo packs:</h3>
                </div>
                <ul class="list-unstyled">

                <?php $__currentLoopData = $product->prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <?php 
                      $product->price = $product->getTotalPrice($pro->min_qty)
                   ?>
                    <li class="d-flex justify-content-start g-brd-around g-brd-gray-light-v4 g-pa-10 g-mb-minus-1">
                       <div class="align-self-center g-px-10">
                        <h5 class="h6 g-font-weight-600 g-color-black g-mb-3">
                          <span class="g-mr-5 mb-0">Pack of <?php echo e($pro->min_qty); ?></span>
                          
                        </h5>
                        <p class="m-0">
                            <?php if($gs->sign == 0): ?>
                            <h3 class="productDetails-price">
                              <?php echo e($curr->sign); ?>

                              
                              <?php if($product->user_id != 0): ?>
                                <?php 
                                $price = $product->price + $gs->fixed_commission + ($product->price/100) * $gs->percentage_commission ;
                                 ?>
                                <?php echo e(round($price * $curr->value,2)); ?>

                              <?php else: ?>
                                <?php echo e(round($product->price * $curr->value,2)); ?>

                              <?php endif; ?>                   
            
                              <?php if($product->price != round($product->cprice*$pro->min_qty,2)): ?>
                                <span><del> <?php echo e($curr->sign); ?><?php echo e(round($product->cprice *$pro->min_qty* $curr->value,2)); ?></del></span>
                              <?php endif; ?>
                            </h1>
                          <?php else: ?>
                            <h3 class="productDetails-price">
                              <?php if($product->user_id != 0): ?>
                                <?php 
                                $price = $product->price + $gs->fixed_commission + ($product->price/100) * $gs->percentage_commission ;
                                 ?>
                                <?php echo e(round($price * $curr->value,2)); ?>

                              <?php else: ?>
                                <?php echo e(round($product->price * $curr->value,2)); ?>

                              <?php endif; ?>                   
                              <?php echo e($curr->sign); ?>


                              <?php if($product->price != round($product->cprice*$pro->min_qty,2)): ?>
                                <span><del><?php echo e(round($product->cprice *$pro->min_qty * $curr->value,2)); ?><?php echo e($curr->sign); ?></del></span>
                              <?php endif; ?>
                            </h1>
                          <?php endif; ?>
                        </p>
                      </div>
                      <div class="align-self-center ml-auto">
                        <?php if($stk >= $pro->min_qty): ?>
                          <button class="btn btn-primary" onclick="addToCart(<?php echo e($pro->min_qty); ?>)">Buy Pack</button>
                        <?php else: ?>
                          <button class="btn btn-primary" disabled>Unavailable</button>
                        <?php endif; ?>

                        
                      </div>
                    </li>
                  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
            <?php endif; ?>
              <?php if($product->size != null): ?>
                <div class="productDetails-size">
                  <p><?php echo e($lang->doo); ?></p>
                  <?php $__currentLoopData = $size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <span class="psize"><?php echo e($sz); ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              <?php endif; ?>
              <?php if($product->color != null): ?>
                <div class="productDetails-color">
                  <p><?php echo e($lang->colors); ?></p>
                  <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <span class="pcolor" style="background: <?php echo e($cl); ?>;"><?php echo e($cl); ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              <?php endif; ?>
 
             
              
              <div class="productDetails-quantity">
                <p class="mb-0"><?php echo e($lang->cquantity); ?></p>
                <input type="hidden" id="stock" value="<?php echo e($product->stock); ?>">
                <span class="quantity-btn" id="qsub"><i class="fa fa-minus"></i></span>
                <span id="qval">1</span>
                <span class="quantity-btn" id="qadd"><i class="fa fa-plus"></i></span>
                <span style="padding-left: 5px; border: none; font-weight: 700; font-size: 15px;"><?php echo e($product->measure); ?></span>
              </div>
              <?php if($stk == "0"): ?>
              <a class="productDetails-addCart-btn" style="cursor: no-drop;color:white;">
                <i class="fa fa-cart-plus"></i> <span><?php echo e($lang->dni); ?></span>
              </a>
              <?php else: ?>
              <a class="productDetails-addCart-btn" id="addcrt" style="cursor: pointer;color:white">
                <i class="fa fa-cart-plus"></i> <span><?php echo e($lang->hcs); ?></span>
              </a>
              <?php endif; ?>
              <input type="hidden" id="pid" value="<?php echo e($product->id); ?>">
              <?php if(Auth::guard('user')->check()): ?>
                  <a style="cursor: pointer;color:white;" class="productDetails-addCart-btn" id="wish"><i class="fa fa-heart"></i> <span><?php echo e($lang->wishlist_add); ?></span></a>
              <?php else: ?>
                <a style="cursor: pointer;color:white;" class="productDetails-addCart-btn no-wish"    data-toggle="modal" data-target="#loginModal"><i class="fa fa-heart"></i> <span><?php echo e($lang->wishlist_add); ?></span></a>
              <?php endif; ?>
              

             
              <script async src="https://static.addtoany.com/menu/page.js"></script>
            </div>
          </div>



      </div>
    </div>
    <!--  Ending of product description area   -->

    <!--  Starting of product detail tab area   -->
    <div class="container g-mt-20">

        <div class="row">
            <div class="col-md-3">
              <!-- Nav tabs -->
              <ul class="nav flex-column u-nav-v1-1 u-nav-primary" role="tablist" data-target="nav-1-1-primary-ver" data-tabs-mobile-type="slide-up-down" data-btn-classes="btn btn-md btn-block rounded-0 u-btn-outline-primary g-mb-20">
                <li class="nav-item ">
                  <a class="nav-link  active " data-toggle="tab" href="#nav-1-1-primary-ver--1" role="tab">Full Description</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link " data-toggle="tab" href="#nav-1-1-primary-ver--2" role="tab">Reviews</a>
                </li>
              </ul>
              <!-- End Nav tabs -->
            </div>
          
            <div class="col-md-9">
              <!-- Tab panes -->
              <div id="nav-1-1-primary-ver" class="tab-content">

                
                <div class="tab-pane fade show active" id="nav-1-1-primary-ver--1" role="tabpanel">
                    <?php if(strlen($product->description) > 70): ?>

                          <p <?php echo $lang->rtl == 1 ? 'dir="rtl"' : ''; ?>><?php echo $product->description; ?></p>
                      
                    <?php else: ?>
                          <p <?php echo $lang->rtl == 1 ? 'dir="rtl"' : ''; ?>><?php echo $product->description; ?></p>
                    
                    <?php endif; ?>
                
                
                </div>
          
                <div class="tab-pane fade" id="nav-1-1-primary-ver--2" role="tabpanel">
                    <div>
                        <?php if(Auth::guard('user')->check()): ?>

                          <?php if(Auth::guard('user')->user()->orders()->count() > 0): ?>
                            <h1><?php echo e($lang->fpr); ?></h1>
                            <hr>
                            <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <p class="product-reviews">
                                <div class="review-star">
                                  <div class='starrr' id='star1'></div>
                                    <div>
                                        <span class='your-choice-was' style='display: none;'>
                                          <?php echo e($lang->dofpl); ?>: <span class='choice'></span>.
                                        </span>
                                    </div>
                                </div>
                            </p>
                            <form class="product-review-form" action="<?php echo e(route('front.review.submit')); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="user_id" value="<?php echo e(Auth::guard('user')->user()->id); ?>">
                                  <input type="hidden" name="rating" id="rate" value="5">
                                  <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                  <div class="form-group">
                                    <textarea name="review" id="" rows="5" placeholder="<?php echo e($lang->suf); ?>" class="form-control" style="resize: vertical;" required></textarea>
                                  </div>
                              <div class="form-group text-center">
                                <input name="btn" type="submit" class="btn-review" value="Submit Review">
                              </div>
                            </form>
                          <?php else: ?>
                            <h3><?php echo e($lang->product_review); ?>.</h3>
                          <?php endif; ?>
                          <hr>
                            <h1><?php echo e($lang->dttl); ?>: </h1>
                          <hr>
                          <?php $__empty_1 = true; $__currentLoopData = $product->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>       
                            <div class="review-rating-description">
                              <div class="row">
                                <div class="col-md-3 col-sm-3">
                                  <p><?php echo e($review->user->name); ?></p>
                                  
                                  <p><?php echo e(Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $review->review_date)->diffForHumans()); ?></p>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                  <p><?php echo e($review->review); ?></p>
                                </div>
                              </div>
                            </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <h4><?php echo e($lang->md); ?></h4>
                                </div>
                            </div>
                          <?php endif; ?>
                          <hr>

                        <?php else: ?>


                            <div class="col-lg-12 pt-50">
                              <div class="blog-comments-area product">
                                <hr>
                                <h3  class="text-center"><a style="color:white;cursor: pointer; background-color: <?php echo e($gs->colors == null ? '#007bff':$gs->colors); ?>; border-color: <?php echo e($gs->colors == null ? '#007bff':$gs->colors); ?>; padding: 8px 12px;"  class="no-wish btn btn-primary g-color-white" data-toggle="modal" data-target="#loginModal"><?php echo e($lang->comment_login); ?></a> <?php echo e($lang->to_review); ?> </h3>
                                <hr>
                              </div>
                            </div>
                            <hr>
                              <h1><?php echo e($lang->dttl); ?>: </h1>
                            <hr>
                            <?php $__empty_1 = true; $__currentLoopData = $product->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>       
                              <div class="review-rating-description">
                                <div class="row">
                                  <div class="col-md-3 col-sm-3">
                                    <p><?php echo e($review->user->name); ?></p>
                                    
                                    <p><?php echo e(Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $review->review_date)->diffForHumans()); ?></p>
                                  </div>
                                  <div class="col-md-9 col-sm-9">
                                    <p><?php echo e($review->review); ?></p>
                                  </div>
                                </div>
                              </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                              <div class="row">
                                  <div class="col-md-12">
                                      <h4><?php echo e($lang->md); ?></h4>
                                  </div>
                              </div>
                            <?php endif; ?>
                            <hr>
                        <?php endif; ?>

                      </div>
              
              
              
                </div>
          
              </div>
              <!-- End Tab panes -->
            </div>
          </div>
    </div>
    <!--  Ending of product detail tab area   -->

    <br>

    

    <?php 
      // $related = $product->childcategories()->first()->products()->where('status','=',1)->where('products.id','!=',$product->id)->distinct()->get();
      $related = collect();
      foreach($product->childcategories()->where('status',1)->get() as $cat){
        $related = $related->merge($cat->products()->where('status','=',1)->where('products.id','!=',$product->id)->distinct()->get());
      }
      $related = $related->unique('id')->take(10);

     ?>
    <?php if($related->count() > 0): ?>
      <!--  Starting of product detail carousel area   -->
      <div class="section-padding productDetails-carousel-wrap">
        <div class="container">
            <div class="section-title">
                <h2><?php echo e($lang->amf); ?></h2>
            </div>
            <div class="js-carousel g-pb-40" data-autoplay="true" data-slides-show="6" data-slides-scroll="6" data-arrows-classes="u-arrow-v1 g-pos-abs g-bottom-0 g-width-45 g-height-45 g-font-size-default g-color-gray-dark-v5 g-bg-gray-light-v5 g-color-white--hover g-bg-primary--hover rounded" data-arrow-left-classes="fa fa-angle-left g-left-35x--lg g-left-15" data-arrow-right-classes="fa fa-angle-right g-right-35x--lg g-right-15" data-pagi-classes="u-carousel-indicators-v1 g-absolute-centered--x g-bottom-20 text-center" 
              data-responsive='[{
                "breakpoint": 992,
                "settings": {
                "slidesToShow": 5
                  }
              }, {
                  "breakpoint": 768,
                  "settings": {
                  "slidesToShow": 2
                  }
              }, {
                  "breakpoint": 554,
                  "settings": {
                  "slidesToShow": 1
                  }
              }]'>
              
              <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="js-slide g-px-15">
                  <!-- Article -->
                  <article class="u-shadow-v19 g-bg-white text-center rounded g-px-20 g-py-40 g-mb-5">
                    <?php 
                        $name = str_replace(" ","-",$prod->name);
                     ?>
                    <a href="<?php echo e(route('front.product',['id' => $prod->id, 'slug' => str_slug($name,'-')])); ?>">
                            <!-- Article Image -->
                        <img class="d-inline-block img-fluid mb-4" style="height:7rem;" src="<?php echo e(asset('assets/images/'.$prod->photo)); ?>" alt="">
            
                    <!-- End Article Image -->
                    </a>
                    <!-- Article Content -->
                  
                    <h4 class="h5 g-color-black g-font-weight-600 g-mb-10"><a href="<?php echo e(route('front.product',['id' => $prod->id, 'slug' => str_slug($name,'-')])); ?>"><?php echo e($prod->name); ?></a></h4>
                    <span class="d-block g-color-primary g-font-size-16">
                            <?php echo e($curr->sign); ?>

                            
                            <?php if($prod->user_id != 0): ?>
                            <?php 
                                $price = $prod->cprice + $gs->fixed_commission + ($prod->cprice/100) * $gs->percentage_commission ;
                             ?>
                            <?php echo e(round($price * $curr->value,2)); ?>

                            <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?>
                                <?php 
                                  $pprice = $prod->pprice + $gs->fixed_commission + ($prod->pprice/100) * $gs->percentage_commission ;
                                    
                                 ?>
                                <span style="display:inline; font-size:12px"><del><?php echo e($curr->sign); ?><?php echo e(round($pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php echo e(round($prod->cprice * $curr->value,2)); ?>

                            <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?>
                                <span style="display:inline; font-size:12px"><del><?php echo e($curr->sign); ?><?php echo e(round($prod->pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>
                            <?php endif; ?>
                        <?php endif; ?>
                    </span>
                    <!-- End Article Content -->
                  </article>
                  <!-- End Article -->
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        
        </div>
      </div>
      <!--  Ending of product detail carousel area   -->
    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php if($product->sale_from && $product->sale_from <= $now && $product->sale_to >= $now): ?>
  <script type="text/javascript">
    function makeTimer() {

      var endTime = new Date("<?php echo e($product->sale_to); ?>");			
        endTime = (Date.parse(endTime) / 1000);

        var now = new Date();
        now = (Date.parse(now) / 1000);

        var timeLeft = endTime - now;

        var days = Math.floor(timeLeft / 86400); 
        var hours = Math.floor((timeLeft - (days * 86400)) / 3600);
        var minutes = Math.floor((timeLeft - (days * 86400) - (hours * 3600 )) / 60);
        var seconds = Math.floor((timeLeft - (days * 86400) - (hours * 3600) - (minutes * 60)));

        if (hours < "10") { hours = "0" + hours; }
        if (minutes < "10") { minutes = "0" + minutes; }
        if (seconds < "10") { seconds = "0" + seconds; }

        $("#days").html(days + " <span>Days</span> ");
        $("#hours").html(hours + " <span>Hours</span> ");
        $("#minutes").html(minutes + " <span>Minutes</span> ");
        $("#seconds").html(seconds + " <span>Seconds</span> ");		

    }

    setInterval(function() { makeTimer(); }, 1000);
    
  </script>
<?php endif; ?>

<style type="text/css">
 img#imageDiv {
    height: 460px;
    width: 460px;
  }
  @media  only screen and (max-width: 768px) { 

  img#imageDiv {
      height: 280px;
      width: 280px;
    }
    
      }
  @media  only screen and (max-width: 767px) { 
  .product-review-carousel-img
  {
    max-width: 300px;
    margin: 30px auto;
  }
 img#imageDiv {
    height: 300px;
    width: 300px;
  }
   
    }
</style>

<script type="text/javascript">

  function productGallery(file){
    var image = $("#"+file).attr('src');
    $('#imageDiv').attr('src',image);
    $('.zoomImg').attr('src',image);
  }


    // var size = $(this).html();
    // $('#size').val(size);

    $('#star1').starrr({
        rating: 5,
        change: function(e, value){
            if (value) {
                $('.your-choice-was').show();
                $('.choice').text(value);
                $('#rate').val(value);
            } else {
                $('.your-choice-was').hide();
            }
        }
    });

</script>

<script type="text/javascript">
    var sizes = "";
    var colors = "";
    var stock = $("#stock").val();

  //   $(document).on("click", ".psize" , function(){
  //    $('.psize').removeClass('pselected-size');
  //    $(this).addClass('pselected-size');
  //    sizes = $(this).html();
  // });

    $(document).on("click", ".pcolor" , function(){
     $('.pcolor').removeClass('pselected-color');
     $(this).addClass('pselected-color');
     colors = $(this).html();
  });

    $(document).on("click", "#qsub" , function(){
         var qty = $("#qval").html();
         qty--;
         if(qty < 1)
         {
         $("#qval").html("1");            
         }
         else{
         $("#qval").html(qty);
         }
    });
    $(document).on("click", "#qadd" , function(){
        var qty = $("#qval").html();
        if(stock != "")
        {
        var stk = parseInt(stock);
          if(qty < stk)
          {
             qty++;
             $("#qval").html(qty);               
          }

        }
        else{
         qty++;
         $("#qval").html(qty);          
        }

    });

    $(document).on("click", "#addcrt" , function(){
      var qty = $("#qval").html();
      $(".empty").html("");
      addToCart(qty);

    });

    function addToCart(qty){
      var pid = $("#pid").val();

      $.ajax({
          type: "GET",
          url:"<?php echo e(URL::to('/json/addnumcart')); ?>",
          data:{id:pid,qty:qty,size:sizes,color:colors},
          success:function(data){
              if(data == 0)
              {
                $.notify("<?php echo e($gs->cart_error); ?>","error");
              }
              else{
                $(".empty").html("");
                $(".total").html((data[0] * <?php echo e($curr->value); ?>).toFixed(2));
                $(".cart-quantity").html(data[2]);
                var arr = $.map(data[1], function(el) {
                return el 
              });
              $(".cart").html("");
              for(var k in arr)
              {
                  var x = arr[k]['item']['name'];
                  var p = x.length  > 45 ? x.substring(0,45)+'...' : x;
                  var measure = arr[k]['item']['measure'] != null ? arr[k]['item']['measure'] : "";
                  $(".cart").append(
                    '<div class="single-myCart">'+
                    '<p class="cart-close" onclick="remove('+arr[k]['item']['id']+')"><i class="fa fa-close"></i></p>'+
                  '<div class="cart-img">'+
                    '<img src="<?php echo e(asset('assets/images/')); ?>/'+arr[k]['item']['photo']+'" alt="Product image">'+
                  '</div>'+
                  '<div class="cart-info">'+
                    '<a href="<?php echo e(url('/')); ?>/product/'+arr[k]['item']['id']+'/'+arr[k]['item']['name']+'" style="color: black; padding: 0 0;">'+'<h5>'+p+'</h5></a>'+
                    '<p><?php echo e($lang->cquantity); ?>: '+arr[k]['qty']+' '+measure+'</p>'+
                    <?php if($gs->sign == 0): ?>
                    '<p><?php echo e($curr->sign); ?>'+(arr[k]['price'] * <?php echo e($curr->value); ?>).toFixed(2)+'</p>'+
                    <?php else: ?>
                    '<p>'+(arr[k]['price'] * <?php echo e($curr->value); ?>).toFixed(2)+'<?php echo e($curr->sign); ?></p>'+
                    <?php endif; ?>
                    '</div>'+
                    '</div>');
                }
                $.notify("<?php echo e($gs->cart_success); ?>","success");
                $("#qval").html("1");
              }
          },
          error: function(data){
            if(data.responseJSON)
                $.notify(data.responseJSON.error,"error");
            else
              $.notify('Something went wrong',"error");

          }
      }); 
    }

</script>


    <script>
        $(document).on("click", "#wish" , function(){
            var pid = $("#pid").val();
            $.ajax({
                    type: "GET",
                    url:"<?php echo e(URL::to('/json/wish')); ?>",
                    data:{id:pid},
                    success:function(data){
                        if(data == 1)
                        {
                            $.notify("<?php echo e($gs->wish_success); ?>","success");
                        }
                        else {
                            $.notify("<?php echo e($gs->wish_error); ?>","error");
                        }
                    },
                    error: function(data){
                      if(data.responseJSON)
                        $.notify(data.responseJSON.error,"error");
                      else
                        $.notify('Something went wrong',"error");

                    }
              }); 

            return false;
        });
    </script>
    <script>
        $(document).on("click", "#favorite" , function(){
          $("#favorite").hide();
            var pid = $("#fav").val();
            $.ajax({
                    type: "GET",
                    url:"<?php echo e(URL::to('/json/favorite')); ?>",
                    data:{id:pid},
                    success:function(data){
                      $('.product-headerInfo__btns').html('<a class="headerInfo__btn colored"><i class="fa fa-check"></i> <?php echo e($lang->product_favorite); ?></a>');
                    },
                    error: function(data){
                      if(data.responseJSON)
                        $.notify(data.responseJSON.error,"error");
                      else
                        $.notify('Something went wrong',"error");

                    }
              }); 

        });
    </script>



<script type="text/javascript">
//*****************************COMMENT******************************  
        $("#cmnt").submit(function(){
          var uid = $("#user_id").val();
          var pid = $("#product_id").val();
          var cmnt = $("#txtcmnt").val();
          $("#txtcmnt").prop('disabled', true);
          $('.btn blog-btn comments').prop('disabled', true);
     $.ajax({
            type: 'post',
            url: "<?php echo e(URL::to('json/comment')); ?>",
            data: {
                '_token': $('input[name=_token]').val(),
                'uid'   : uid,
                'pid'   : pid,
                'cmnt'  : cmnt
                  },
            success: function(data) {
              $("#comments").prepend(
                    '<div id="comment'+data[3]+'">'+
                        '<div class="row single-blog-comments-wrap">'+
                            '<div class="col-lg-12">'+
                              '<h4><a class="comments-title">'+data[0]+'</a></h4>'+
                                '<div class="comments-reply-area">'+data[1]+'</div>'+
                                 '<p id="cmntttl'+data[3]+'">'+data[2]+'</p>'+
                                '<div class="replay-form">'+
                    '<p class="text-right"><input type="hidden" value="'+data[3]+'"><button class="replay-btn"><?php echo e($lang->reply_button); ?> <i class="fa fa-reply-all"></i></button><button class="replay-btn-edit"><?php echo e($lang->edit_button); ?> <i class="fa fa-edit"></i></button><button class="replay-btn-delete"><?php echo e($lang->remove); ?> <i class="fa fa-trash"></i></button>'+
                    '</p>'+'<form action="" method="POST" class="comment-edit">'+
                                      '<?php echo e(csrf_field()); ?>'+
                                '<input type="hidden" name="comment_id" value="'+data[3]+'">'+
                                      '<div class="form-group">'+
                            '<textarea rows="2" id="editcmnt'+data[3]+'" name="text" class="form-control"'+ 
                            'placeholder="<?php echo e($lang->edit_comment); ?>" style="resize: vertical;" required=""></textarea>'+
                                      '</div>'+
                                      '<div class="form-group">'+
                    '<button type="submit" class="btn btn-no-border hvr-shutter-out-horizontal"><?php echo e($lang->update_comment); ?></button>&nbsp;'+
                        '<button type="button" class="btn btn-no-border hvr-shutter-out-horizontal cancel"><?php echo e($lang->cancel_edit); ?></button>'+
                                      '</div>'+
                                    '</form>'+
                                '</div>'+
                            '</div>'+
                        '</div>'+
                      '</div>');
                    $("#comment"+data[3]).append('<div id="replies'+data[3]+'" style="display: none;"></div>');
                     $("#replies"+data[3]).append('<div class="rapper" style="display: none;"></div>');
                     $("#replies"+data[3]).append('<form action="" method="POST" class="reply" style="display: none;">'+
                      '<?php echo e(csrf_field()); ?>'+
                      '<input type="hidden" name="comment_id" id="comment_id'+data[3]+'" value="'+data[3]+'">'+
                      '<input type="hidden" name="user_id" id="user_id'+data[4]+'" value="'+data[4]+'">'+
                        '<div class="form-group">'+
                          '<textarea rows="2" name="text" id="txtcmnt'+data[3]+'" class="form-control"'+ 'placeholder="<?php echo e($lang->write_reply); ?>" required="" style="resize: vertical;"></textarea>'+
                        '</div>'+
                      '<div class="form-group">'+
                        '<button type="submit" class="btn btn-no-border hvr-shutter-out-horizontal"><?php echo e($lang->reply_button); ?></button>'+
                      '</div>'+'</form>');                      
                      
                      



                    
                      //-----------Replay button details-----------
              if (data[5] > 1){
                $("#cmnt-text").html("<?php echo e($lang->comments); ?>(<span id='cmnt_count'>"+ data[5]+"</span>)");
              }
              else{
                $("#cmnt-text").html("<?php echo e($lang->comment); ?> (<span id='cmnt_count'>"+ data[5]+"</span>)");              
              }
              $("#txtcmnt").prop('disabled', false);
              $("#txtcmnt").val("");
              $('.btn blog-btn comments').prop('disabled', false);
            },
            error: function(data){
              if(data.responseJSON)
                $.notify(data.responseJSON.error,"error");
              else
                $.notify('Something went wrong',"error");

            }
        });          
          return false;
        });
//*****************************COMMENT ENDS******************************  
</script>

<script type="text/javascript">

//***************************** REPLY TOGGLE******************************
          $(document).on("click", ".replay-form p button.view-replay-btn" , function(){
          var id = $(this).parent().next().find('input[name=comment_id]').val();
          $("#replies"+id+" .rapper").show();
          $("#replies"+id).show();
          });

          $(document).on("click", ".replay-form p button.replay-btn, .replay-form p button.subreplay-btn" , function(){
          var id = $(this).parent().find('input[type=hidden]').val();
          $("#replies"+id).show();
          $("#replies"+id).find('.reply').show();
          $("#replies"+id).find('.reply textarea').focus();
          });
//*****************************REPLY******************************  
          $(document).on("submit", ".reply" , function(){
          var uid = $(this).find('input[name=user_id]').val();
          var cid = $(this).find('input[name=comment_id]').val();
          var rpl = $(this).find('textarea').val();
          $(this).find('textarea').prop('disabled', true);
          $('.btn btn-no-border hvr-shutter-out-horizontal').prop('disabled', true);
     $.ajax({
            type: 'post',
            url: "<?php echo e(URL::to('json/reply')); ?>",
            data: {
                '_token': $('input[name=_token]').val(),
                'uid'   : uid,
                'cid'   : cid,
                'rpl'  : rpl
                  },
            success: function(data) {
              $("#replies"+cid).prepend('<div id="reply'+data[3]+'">'+
                        '<div class="row single-blog-comments-wrap replay">'+
                            '<div class="col-lg-12">'+
                              '<h4><a class="comments-title">'+data[0]+'</a></h4>'+
                                '<div class="comments-reply-area">'+data[1]+'</div>'+
                                 '<p id="rplttl'+data[3]+'">'+data[2]+'</p>'+
                                '<div class="replay-form">'+
                    '<p class="text-right"><input type="hidden" value="'+cid+'"><button class="subreplay-btn"><?php echo e($lang->reply_button); ?> <i class="fa fa-reply-all"></i></button><button class="replay-btn-edit1"><?php echo e($lang->edit_button); ?> <i class="fa fa-edit"></i></button><button class="replay-btn-delete1"><?php echo e($lang->remove); ?> <i class="fa fa-trash"></i></button></p>'+
                                    '<form action="" method="POST" class="reply-edit">'+
                                      '<?php echo e(csrf_field()); ?>'+
                                  '<input type="hidden" name="reply_id" value="'+data[3]+'">'+
                                      '<div class="form-group">'+
                                    '<textarea rows="2" id="editrpl'+data[3]+'" name="text" class="form-control"'+ 'placeholder="<?php echo e($lang->edit_reply); ?>"  style="resize: vertical;" required=""></textarea>'+
                                      '</div>'+
                                      '<div class="form-group">'+
                                      '<button type="submit" class="btn btn-no-border hvr-shutter-out-horizontal">'+'<?php echo e($lang->update_comment); ?></button>&nbsp;'+
                                      '<button type="button" class="btn btn-no-border hvr-shutter-out-horizontal cancel"><?php echo e($lang->cancel_edit); ?></button>'+
                                      '</div>'+
                                    '</form>'+
                                '</div>'+
                            '</div>'+
                        '</div>'+
                        '</div>');
                      //-----------REPLY button details-----------
              $("#txtcmnt"+cid).prop('disabled', false);
              $("#txtcmnt"+cid).val("");
              $('.btn btn-no-border hvr-shutter-out-horizontal').prop('disabled', false);
            },
            error: function(data){
              if(data.responseJSON)
                $.notify(data.responseJSON.error,"error");
              else
                $.notify('Something went wrong',"error");

            }
        });          
          return false;
        });
//*****************************REPLY ENDS******************************  

</script>



<script>

  $(document).on("click", ".replay-btn-edit" , function(){
          var id = $(this).parent().find('input[type=hidden]').val();
          var txt = $("#cmntttl"+id).html(); 
          $(this).parent().parent().parent().find('.comment-edit textarea').val(txt);
          $(this).parent().parent().parent().find('.comment-edit').toggle();
  });
  $(document).on("click", ".cancel" , function(){
          $(this).parent().parent().hide();
  });
  //*****************************SUB REPLY******************************  
          $(document).on("submit", ".comment-edit" , function(){
          var cid = $(this).find('input[name=comment_id]').val();
          var text = $(this).find('textarea').val();
           $(this).find('textarea').prop('disabled', true);
          $('.hvr-shutter-out-horizontal').prop('disabled', true);
     $.ajax({
            type: 'post',
            url: "<?php echo e(URL::to('json/comment/edit')); ?>",
            data: {
                '_token': $('input[name=_token]').val(),
                'cid'   : cid,
                'text'  : text
                  },
            success: function(data) {
              $("#cmntttl"+cid).html(data);
              $("#editcmnt"+cid).prop('disabled', false);
              $("#editcmnt"+cid).val("");
              $('.hvr-shutter-out-horizontal').prop('disabled', false);
            },
            error: function(data){
              if(data.responseJSON)
                $.notify(data.responseJSON.error,"error");
              else
                $.notify('Something went wrong',"error");

            }
        });          
          return false;
        });

</script>

<script type="text/javascript">
  $(document).on("click", ".replay-btn-delete" , function(){
              var id = $(this).parent().next().find('input[name=comment_id]').val();
              $("#comment"+id).hide();
              var count = parseInt($("#cmnt_count").html());
              count--;
              if(count <= 1)
              {
              $("#cmnt-text").html("COMMENT (<span id='cmnt_count'>"+ count+"</span>)");
              }
              else
              {
              $("#cmnt-text").html("COMMENTS (<span id='cmnt_count'>"+ count+"</span>)");
              }
     $.ajax({
            type: 'get',
            url: "<?php echo e(URL::to('json/comment/delete')); ?>",
            data: {'id': id}
        }); 
  });
</script>


<script type="text/javascript">
  $(document).on("click", ".replay-btn-edit1" , function(){
          var id = $(this).parent().parent().parent().find('.reply-edit input[name=reply_id]').val();
          var txt = $("#rplttl"+id).html(); 
          $(this).parent().parent().parent().find('.reply-edit textarea').val(txt);
          $(this).parent().parent().parent().find('.reply-edit').toggle();
          var txt = $("#cmntttl"+id).html(); 
  });

  //*****************************SUB REPLY******************************  
          $(document).on("submit", ".reply-edit" , function(){
          var cid = $(this).find('input[name=reply_id]').val();
          var text = $(this).find('textarea').val();
           $(this).find('textarea').prop('disabled', true);
          $('.hvr-shutter-out-horizontal').prop('disabled', true);
     $.ajax({
            type: 'post',
            url: "<?php echo e(URL::to('json/reply/edit')); ?>",
            data: {
                '_token': $('input[name=_token]').val(),
                'cid'   : cid,
                'text'  : text
                  },
            success: function(data) {
              $("#rplttl"+cid).html(data);
              $("#editrpl"+cid).prop('disabled', false);
              $("#editrpl"+cid).val("");
              $('.hvr-shutter-out-horizontal').prop('disabled', false);
            },
            error: function(data){
              if(data.responseJSON)
                $.notify(data.responseJSON.error,"error");
              else
                $.notify('Something went wrong',"error");

            }
        });          
          return false;
        });

</script>

<script type="text/javascript">
  $(document).on("click", ".replay-btn-delete1" , function(){
              var id = $(this).parent().next().find('input[name=reply_id]').val();
              $("#reply"+id).hide();
     $.ajax({
            type: 'get',
            url: "<?php echo e(URL::to('json/reply/delete')); ?>",
            data: {'id': id}
        }); 
  });
</script>

<script >
    $(document).on('ready', function () {
      // initialization of tabs
      $.HSCore.components.HSTabs.init('[role="tablist"]');
    });

    $(window).on('resize', function () {
      setTimeout(function () {
        $.HSCore.components.HSTabs.init('[role="tablist"]');
      }, 200);
    });
  </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.product', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>