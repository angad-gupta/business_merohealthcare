
<?php $__env->startSection('content'); ?>


<style>
  #drop-zone {
    width: 100%;
    min-height: 80px;
    border: 1px dashed rgba(0, 0, 0, .3);
    border-radius: 5px;
    font-family: Arial;
    text-align: center;
    position: relative;
    font-size: 20px;
    color: #7E7E7E;
  }
  #drop-zone input {
    position: absolute;
    cursor: pointer;
    left: 0px;
    top: 0px;
    opacity: 0;
  }
  /*Important*/
  
  #drop-zone.mouse-over {
    border: 3px dashed rgba(0, 0, 0, .3);
    color: #7E7E7E;
  }
  /*If you dont want the button*/
  
  #clickHere {
    display: inline-block;
      cursor: pointer;
      color: white;
      font-size: 17px;
      width: 50px;
      border-radius: 4px;
      background-color: #2385aa;
      padding: 10px;
      border-radius: 30px;
  
  }
  #clickHere:hover {
    background-color: #376199;
  }
  #filename {
    margin-top: 10px;
    margin-bottom: 10px;
    font-size: 14px;
    line-height: 1.5em;
  }
  .file-preview {
    background: #ccc;
    border: 1px solid #fff;
    box-shadow: 0 0 4px rgba(0, 0, 0, 0.5);
    display: inline-block;
    width: 60px;
    height: 60px;
    text-align: center;
    font-size: 14px;
    margin-top: 5px;
  }
  .closeBtn:hover {
    color: red;
    display:inline-block;
  }
  }
  </style>



    <!-- Starting of Login/registration area -->

    
    <div class="section-padding login-wrap">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2 col-xs-12">
          <div class="login-tab">
            <ul class="nav nav-tabs">
              <li class="active"><a data-toggle="tab" href="#login" style="font-size:18px;"><?php echo e($lang->signin); ?></a></li>
              <li><a data-toggle="tab" href="#signup" style="font-size:18px;"><?php echo e($lang->signup); ?></a></li>
            </ul>
            
            <div class="tab-content">
              <div id="login" class="tab-pane fade in active">
                
                  <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="login-form">
                  <form action="<?php echo e(route('business-login-submit')); ?>" method="POST">
                              <?php echo e(csrf_field()); ?>


                    <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                      <label for="login_email"><?php echo e($lang->doeml); ?></label>
            <input type="email" name="email" class="form-control" id="login_email" placeholder="<?php echo e($lang->doeml); ?>" required>
                    </div>
                    <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                      <label for="login_pwd"><?php echo e($lang->sup); ?></label>
                  <input type="password" name="password" class="form-control" id="login_pwd" placeholder="<?php echo e($lang->sup); ?>" required>
                  <i id="pass-status" class="fa fa-eye field-icon" aria-hidden="true" onClick="viewPassword1();"></i>
                  
                  
                        </div>
                      <div class="text-center">
                    <button type="submit" class="btn btn-default " style="border-radius:30px;"><?php echo e($lang->sie); ?></button>
                      </div>
                    <div class="forgot-area text-center">
                      <a href="<?php echo e(route('user-forgot')); ?>" target="_blank"><?php echo e($lang->fpw); ?></a>
                    </div>
                    <?php if($sl->fcheck == 1  || $sl->gcheck == 1): ?>
                    
                    <?php endif; ?>
                  </form>
                </div>
              </div>
              <div id="signup" class="tab-pane fade">
                <div class="login-title text-center">
                  
                </div>
                  <?php echo $__env->make('includes.form-error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="login-form">
                  <form action="<?php echo e(route('business-register-submit')); ?>" method="POST" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>


                      <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                          <label for="reg_email"><?php echo e($lang->doeml); ?> <span>*</span></label>
                          <input class="form-control" placeholder="<?php echo e($lang->doeml); ?>" type="email" name="email" id="reg_email" required>
                      </div>

                      <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                        <label for="reg_name">First Name <span>*</span></label>
                        <input class="form-control" placeholder="First Name" type="text" name="firstname" id="reg_name" required>
                    </div>

                    <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                      <label for="reg_name">Middle Name <span></span></label>
                      <input class="form-control" placeholder="Middle Name" type="text" name="middlename" id="reg_name" >
                  </div>

                  <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                    <label for="reg_name">Last Name <span>*</span></label>
                    <input class="form-control" placeholder="Last Name" type="text" name="lastname" id="reg_name" required>
                </div>
                
                      

                      <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                        <label for="reg_name">Date of Birth <span>*</span></label>
                        <input class="form-control" placeholder="Date of Birth" id="datepicker" name="dob" id="reg_name" required>
                    </div>


                      <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?> ">
                        <label for="reg_usertype">Gender <span>*</span></label>
                        <select id="reg_usertype" name="gender" placeholder="Select gender" class="form-control" id="" style="height:40px;">
                            
                          <option>Male</option>
                          <option>Female</option>
                          <option>Others</option>
                       
                        </select>
                      </div>

                    
                      <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                        <label for="reg_name">Company Name <span>*</span></label>
                        <input class="form-control" placeholder="Company Name" type="text" name="companyname" id="reg_name" required>
                    </div>

                    <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                        <label for="reg_name">Registration Number <span>*</span></label>
                        <input class="form-control" placeholder="Registration Number" type="text" name="registrationname" id="reg_name" required>
                    </div>

                    <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                        <label for="reg_name">PAN / VAT <span>*</span></label>
                        <input class="form-control" placeholder="PAN / VAT" type="text" name="panvat" id="reg_name" required>
                    </div>

                    

                    

                    

                    <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                        <label for="reg_name">Company details <span>*</span></label>
                        <input class="form-control" placeholder="Company details" type="text" name="companydetails" id="reg_name" required>
                    </div>

                      <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?> ">
                        
                        <select id="reg_usertype" name="user_type" class="form-control rounded-0" id="" hidden>
                          
                          <option selected>Business</option>
                       
                        </select>
                      </div>
                      <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                          <label for="reg_Pnumber"><?php echo e($lang->doph); ?> <span>*</span></label>
                          <input class="form-control" placeholder="<?php echo e($lang->doph); ?>" type="text" name="phone" id="reg_Pnumber" required>
                      </div>
                      <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                          <label for="reg_Padd"><?php echo e($lang->doad); ?> <span>*</span></label>
                          <input class="form-control" placeholder="<?php echo e($lang->doad); ?>" type="text" name="address" id="reg_Padd" required>
                      </div>


                      <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                        <label for="reg_name">Upload Registration Certificate<span></span></label>
                        <label for="reg_name">(PAN,VAT and business supporting documents)<span>*</span></label>
                        <input class="form-control" placeholder="Company Name" type="file" name="filenames[]" id="reg_name" multiple="multiple" required>
                        

                        
                    </div>

                      <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                          <label for="reg_password"><?php echo e($lang->sup); ?> <span>*</span></label>
                          <input class="form-control" placeholder="<?php echo e($lang->sup); ?>" type="password" name="password" id="reg_password" required>
                          <i id="pass-status-create" class="fa fa-eye field-icon" aria-hidden="true" onClick="viewPasswordCreate1()"></i>
                      </div>
                      <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                          <label for="confirm_password"><?php echo e($lang->sucp); ?> <span>*</span></label>
                          <input class="form-control" placeholder="<?php echo e($lang->sucp); ?>" type="password" name="password_confirmation" id="confirm_password" required>
                          <i id="pass-status-create-confirm" class="fa fa-eye field-icon" aria-hidden="true" onClick="viewPasswordCreateConfirm1()"></i>
                        </div>

                        <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                          <div class="container row">

                            <label class="form-check-inline u-check g-pl-25">
                              <input class="g-hidden-xs-up g-pos-abs g-top-0 g-left-0" type="checkbox" onchange="document.getElementById('send').disabled = !this.checked;" checked>
                              <div class="u-check-icon-checkbox-v6 g-absolute-centered--y g-left-0">
                                <i class="fa" data-check-icon=""></i>
                              </div>
                             Signing up you agreed our <a href=""> Terms and Condition</a>
                           
                            </label>

                   
                          </div>
                        </div>

                        
                        <div class="text-center">
                        <button type="submit" id="send" class="btn btn-default"><?php echo e($lang->spe); ?></button>
                        </div>

                       


                  </form>
                </div>
              </div>
            </div>
          </div>    
                </div>
            </div>
        </div>
    </div>


    <script>
      var dropZoneId = "drop-zone";
        var buttonId = "clickHere";
        var mouseOverClass = "mouse-over";
      var dropZone = $("#" + dropZoneId);
       var inputFile = dropZone.find("input");
       var finalFiles = {};
      $(function() {
        
      
        
        var ooleft = dropZone.offset().left;
        var ooright = dropZone.outerWidth() + ooleft;
        var ootop = dropZone.offset().top;
        var oobottom = dropZone.outerHeight() + ootop;
       
        document.getElementById(dropZoneId).addEventListener("dragover", function(e) {
          e.preventDefault();
          e.stopPropagation();
          dropZone.addClass(mouseOverClass);
          var x = e.pageX;
          var y = e.pageY;
      
          if (!(x < ooleft || x > ooright || y < ootop || y > oobottom)) {
            inputFile.offset({
              top: y - 15,
              left: x - 100
            });
          } else {
            inputFile.offset({
              top: -400,
              left: -400
            });
          }
      
        }, true);
      
        if (buttonId != "") {
          var clickZone = $("#" + buttonId);
      
          var oleft = clickZone.offset().left;
          var oright = clickZone.outerWidth() + oleft;
          var otop = clickZone.offset().top;
          var obottom = clickZone.outerHeight() + otop;
      
          $("#" + buttonId).mousemove(function(e) {
            var x = e.pageX;
            var y = e.pageY;
            if (!(x < oleft || x > oright || y < otop || y > obottom)) {
              inputFile.offset({
                top: y - 15,
                left: x - 160
              });
            } else {
              inputFile.offset({
                top: -400,
                left: -400
              });
            }
          });
        }
      
        document.getElementById(dropZoneId).addEventListener("drop", function(e) {
          $("#" + dropZoneId).removeClass(mouseOverClass);
        }, true);
      
      
        inputFile.on('change', function(e) {
          finalFiles = {};
          $('#filename').html("");
          var fileNum = this.files.length,
            initial = 0,
            counter = 0;
      
          $.each(this.files,function(idx,elm){
             finalFiles[idx]=elm;
          });
      
          for (initial; initial < fileNum; initial++) {
            counter = counter + 1;
            $('#filename').append('<div id="file_'+ initial +'"><span class="fa-stack fa-lg"><i class="fa fa-file fa-stack-1x "></i><strong class="fa-stack-1x" style="color:#FFF; font-size:12px; margin-top:2px;">' + counter + '</strong></span> ' + this.files[initial].name + '&nbsp;&nbsp;<span class="fa fa-times-circle fa-lg closeBtn" onclick="removeLine(this)" title="remove"></span></div>');
          }
        });
      
      
      
      })
      
      function removeLine(obj)
      {
        inputFile.val('');
        var jqObj = $(obj);
        var container = jqObj.closest('div');
        var index = container.attr("id").split('_')[1];
        container.remove(); 
      
        delete finalFiles[index];
        //console.log(finalFiles);
      }
      
        </script>



    
  <script>
      $('#datepicker').datepicker({
          uiLibrary: 'bootstrap4'
      });
  </script>

<script src="https://unpkg.com/filepond/dist/filepond.js"></script>
    <!-- Ending of Login/registration area -->

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script>
function viewPassword1()
{
  var passwordInput = document.getElementById('login_pwd');
  var passStatus = document.getElementById('pass-status');
 
  if (passwordInput.type == 'password'){
    passwordInput.type='text';
    passStatus.className='fa fa-eye-slash field-icon';
    
  }
  else{
    passwordInput.type='password';
    passStatus.className='fa fa-eye field-icon';
  }
}

function viewPasswordCreate1()
{
  var passwordInput = document.getElementById('reg_password');
  var passStatus = document.getElementById('pass-status-create');
 
  if (passwordInput.type == 'password'){
    passwordInput.type='text';
    passStatus.className='fa fa-eye-slash field-icon';
    
  }
  else{
    passwordInput.type='password';
    passStatus.className='fa fa-eye field-icon';
  }
}

function viewPasswordCreateConfirm1()
{
  var passwordInput = document.getElementById('confirm_password');
  var passStatus = document.getElementById('pass-status-create-confirm');
 
  if (passwordInput.type == 'password'){
    passwordInput.type='text';
    passStatus.className='fa fa-eye-slash field-icon';
    
  }
  else{
    passwordInput.type='password';
    passStatus.className='fa fa-eye field-icon';
  }
}

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>