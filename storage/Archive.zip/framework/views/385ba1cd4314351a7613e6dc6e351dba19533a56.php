
<?php $__env->startSection('title','Procceed to Payment'); ?>
<?php $__env->startSection('content'); ?>

<style>
    


.radio-tile-group {
  display: -webkit-box;
  display: flex;
  flex-wrap: wrap;
  -webkit-box-pack: center;
          justify-content: center;
}
.radio-tile-group .input-container {
  position: relative;
  height: 7rem;
  width: 7rem;
  margin: 0.5rem;
}
.radio-tile-group .input-container .radio-button {
  opacity: 0;
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  margin: 0;
  cursor: pointer;
}
.radio-tile-group .input-container .radio-tile {
  display: -webkit-box;
  display: flex;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
          flex-direction: column;
  -webkit-box-align: center;
          align-items: center;
  -webkit-box-pack: center;
          justify-content: center;
  width: 100%;
  height: 100%;
  border: 1px solid #2385aa;
  border-radius: 5px;
  padding: 1rem;
  -webkit-transition: -webkit-transform 300ms ease;
  transition: -webkit-transform 300ms ease;
  transition: transform 300ms ease;
  transition: transform 300ms ease, -webkit-transform 300ms ease;
}
.radio-tile-group .input-container .icon svg {
  fill: #2385aa;
  width: 3rem;
  height: 3rem;
}
.radio-tile-group .input-container .radio-tile-label {
  text-align: center;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
  color: #2385aa;
}
.radio-tile-group .input-container .radio-button:checked + .radio-tile {
  background-color: #2385aa;
  border: 2px solid #2385aa;
  color: white;
  -webkit-transform: scale(1.1, 1.1);
          transform: scale(1.1, 1.1);
}
.radio-tile-group .input-container .radio-button:checked + .radio-tile .icon svg {
  fill: white;
  background-color: #2385aa;
}
.radio-tile-group .input-container .radio-button:checked + .radio-tile .radio-tile-label {
  color: white;
  background-color: #2385aa;
}

    .table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
    padding: 5px;
    line-height: 1.42857143;
    vertical-align: top;
    border-top: 1px solid #ddd;
}
    .box{
        
        padding: 20px;
        display: none;
        margin-top: 20px;
    }
    .Cash{ background: #f7f7f7 }

    @media (min-width: 1200px){
    .container {
        max-width: 1168px;
        }
    }
   
</style>
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>

<link  rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/fancybox/jquery.fancybox.min.css">

    
 <!-- Starting of checkOut area -->
    <?php 
        $user = $order->user;
        $cart = unserialize(bzdecompress(utf8_decode($order->cart)));
        $products = $cart->items;
     ?>
    <div>

        <div class="section-padding product-checkOut-wrap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                        <h4 class="signIn-title"><?php echo e($lang->odetails); ?></h4>
                        
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th><?php echo e($user ? 'For Whom' : ''); ?></th>
                                        <th>Price</th>
                                        <th>Qty</th>
                                        <th>Total</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        $priceDiscount = 0;
                                     ?>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                            
                                            $price = $product['item']['pprice'] ? : $product['item']['cprice'];
                                            
                                         ?>
                                        <tr>
                                            <td><a href="<?php echo e(route('front.product',[$product['item']['id'],str_slug($product['item']['name'],'-')])); ?>" target="_blank" title="<?php echo e($product['item']['name']); ?>"><?php echo e($product['item']['name']); ?></a></td>
                                            <?php if($user): ?>
                                                <td><?php echo e($product['family']); ?></td>
                                            <?php else: ?>
                                                <td></td>
                                            <?php endif; ?>
                                            <td><?php echo e($order->currency_sign); ?><?php echo e(round($price * $order->currency_value , 2)); ?></td>
                                            <td><?php echo e($product['qty']); ?>  <?php echo e($product['item']['measure']); ?>


                                                <?php if(App\Product::findOrFail($product['item']['id'])->prices()->where('min_qty','<=',$product['qty'])->exists()): ?>
                                                        <?php 
                                                        $p = App\Product::findOrFail($product['item']['id'])->prices()->where('min_qty','<=',$product['qty'])->orderBy('min_qty','desc')->first();
                                                        $quotient = (int)($product['qty'] / $p->min_qty);
                                                         ?>
                                                        <?php if(($quotient * $p->product_free_quantity) != 0): ?>
                                                            <span style="width:70px;">
                                                                + <?php echo e($quotient * $p->product_free_quantity); ?> <?php echo e($p->product_category); ?> Free             
                                                            </span> 
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                            
                                            </td>
                                            <td>&nbsp;
                                                <?php if($gs->sign == 0): ?>
                                                    <?php echo e($order->currency_sign); ?><?php echo e(round($price * $product['qty'] * $order->currency_value , 2)); ?>

                                                <?php else: ?>
                                                    <?php echo e(round($price * $product['qty'] * $order->currency_value , 2)); ?><?php echo e($order->currency_sign); ?>

                                                <?php endif; ?>

                                                <?php 
                                                    $priceDiscount += round($price * $product['qty'] * $order->currency_value , 2) - round($product['price'] * $order->currency_value , 2);
                                                    
                                                 ?>
                                                
                                            </td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                                <tfoot>

                                    <?php if($priceDiscount > 0): ?>
                                        <tr id="">
                                            <th colspan="4">Price Discount:</th>
                                            <th>
                                                <?php if($gs->sign == 0): ?>
                                                    - <?php echo e($order->currency_sign); ?><span><?php echo e($priceDiscount); ?></span>
                                                <?php else: ?>
                                                    - <span><?php echo e($priceDiscount); ?></span><?php echo e($order->currency_sign); ?>

                                                <?php endif; ?>
                                            </th>
                                        </tr>
                                    <?php endif; ?>
                                    
                                    <?php if($order->coupon_code): ?>
                                        <tr id="discount">
                                            <th colspan="4"><?php echo e($lang->ds); ?>(<span id="sign"><?php echo e($order->coupon_code); ?></span>):</th>
                                            <th>
                                                <?php if($gs->sign == 0): ?>
                                                - <?php echo e($order->currency_sign); ?><span id="ds"><?php echo e($order->coupon_discount); ?></span>
                                                <?php else: ?>
                                                - <span id="ds"><?php echo e($order->coupon_discount); ?></span><?php echo e($order->currency_sign); ?>

                                                <?php endif; ?>
                                            </th>
                                        </tr>
                                    <?php endif; ?>

                                    <tr id="gatewaydiscount" style="display: none;">
                                        <th colspan="4">Payment Gateway Discount:</th>
                                        <th>
                                            <?php if($gs->sign == 0): ?>
                                            - <?php echo e($order->currency_sign); ?><span id="gatewayds">0</span>
                                            <?php else: ?>
                                            - <span id="gatewayds">0</span><?php echo e($order->currency_sign); ?>

                                            <?php endif; ?>
                                        </th>
                                    </tr>

                                    <tr id="shipshow">
                                        <th colspan="4"><?php echo e($lang->ship); ?>:</th>
                                        <th>&nbsp;
                                            <?php if($gs->sign == 0): ?>
                                            <?php echo e($order->currency_sign); ?><span id="ship-cost"><?php echo e(round($order->shipping_cost * $order->currency_value,2)); ?></span>
                                            <?php else: ?>
                                            <span id="ship-cost"><?php echo e(round($order->shipping_cost * $order->currency_value,2)); ?></span><?php echo e($order->currency_sign); ?>

                                            <?php endif; ?>
                                        </th>
                                    </tr>
                                    <?php if($order->tax != 0): ?>
                                        <tr id="taxshow">
                                            <th colspan="4"><?php echo e($lang->tax); ?>(<?php echo e($gs->tax); ?>%):</th>
                                            <th>
                                                &nbsp;
                                                <?php if($gs->sign == 0): ?>
                                                    <?php echo e($order->currency_sign); ?><span><?php echo e(round($order->tax * $order->currency_value,2)); ?></span>
                                                <?php else: ?>
                                                    <span><?php echo e(round($order->tax * $order->currency_value,2)); ?></span><?php echo e($order->currency_sign); ?>

                                                <?php endif; ?>
                                            </th>
                                        </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <td colspan="4"><h6><strong style="font-weight:700;"><?php echo e($lang->vt); ?>:</strong></h6></td>
                                        <td>
                                            <h6>
                                                <?php if($gs->sign == 0): ?>
                                                <strong style="font-weight:700;">&nbsp;&nbsp;<?php echo e($order->currency_sign); ?><span id="total-cost"><?php echo e(round($order->pay_amount * $order->currency_value ,2)); ?></span></strong>
                                                <?php else: ?>
                                                    <span id="total-cost"><?php echo e(round($order->pay_amount * $order->currency_value,2)); ?></span><?php echo e($order->currency_sign); ?>

                                                <?php endif; ?>
                                            </h6>
                                        </td>
                                    </tr>

                                </tfoot>
                            </table>
                        </div>

                        <hr style="margin-top:2px; margin-bottom:10px;">

                        <h4 class="signIn-title"><?php echo e($lang->bdetails); ?></h4>
                        <span><?php echo e($order->customer_name); ?></span><br>
                        <span><?php echo e($order->customer_email); ?></span><br>
                        <span><?php echo e($order->customer_phone); ?></span><br>
                        
                        <span><?php echo e($order->customer_address); ?></span><br>
                        
                        <span><?php echo e($order->customer_country); ?></span><br>
                    </div>

                    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                        <div class="">
                            <h4 class="signIn-title text-center">Payment Options</h4>
                            
                            

                          

                            <div class="container">
                                <div class="radio-tile-group" name="method" id="paymentMethod" >

                                    <div class="input-container">
                                        <input id="Cash" class="radio-button" type="radio" name="radio" value="Cash" />
                                        <div class="radio-tile">
                                          <div class="icon walk-icon">
                                          
                                            <img src="http://icons.iconarchive.com/icons/graphicloads/folded/256/bank-folded-icon.png"/>
                                          </div>
                                          <label for="cod" class="radio-tile-label">Bank </label>
                                        </div>
                                      </div>

                                  <div class="input-container">
                                    <input id="walk" class="radio-button" type="radio" name="radio" value="Khalti" />
                                    <div class="radio-tile">
                                      <div class="icon walk-icon">
                                       
                                        <img src="https://lh3.googleusercontent.com/vtoxj9t4UWl6qxWUPGpv7ndJuJs_W3UTnQYpBwJ7xBMuRJ2TE6d71NrwWU6Nkbq0Zs8"/>
                                      </div>
                                      <label for="walk" class="radio-tile-label">Khalti</label>
                                    </div>
                                  </div>
                              
                                  
                              
                                  <div class="input-container">
                                    <input id="drive" class="radio-button" type="radio" name="radio" value="FonePay"/>
                                    <div class="radio-tile">
                                      <div class="icon car-icon">
                                        <img src="https://media-exp1.licdn.com/dms/image/C510BAQE-gVAYFB4FUg/company-logo_200_200/0?e=2159024400&v=beta&t=oJy0sDDwzrx3cH5KCmGMYsy7FotUix4drGCTJX4kfAA"/>
                                      </div>
                                      <label for="drive" class="radio-tile-label">fone pay</label>
                                    </div>
                                  </div>
                              
                                  
                                </div>
                              </div>

                           
                              

                            

                                    
                                    

                                    


                    
                                
                                
                                    
                                    

                             <div id="gateway" style="display: none;"></div>

                             

                                <div class="Cash box" style="background: white;" >
                                     <h4 >Please deposit the amount in bank details given below </h4> 
                                    

                                     <li class="media g-brd-around g-brd-gray-light-v4 g-pa-20 g-mb-minus-1">
                                        <div class="d-flex g-mt-2 g-mr-15">
                                          <img class="g-width-75 g-height-80 " src="https://www.collegenp.com/uploads/2018/12/Sanima-Bank.jpg" alt="Image Description">
                                        </div>
                                        <div class="media-body">
                                          <div class="d-flex justify-content-between">
                                            <strong class="g-color-teal">Sanima Bank</strong>
                                            
                                          </div>
                                          <span class="d-block"><strong>Account name : </strong> Web Health Company Pvt Ltd</span>
                                          <span class="d-block"><strong>AC. No.</strong> 909010020000028</span>
                                        </div>
                                      </li>

                                 

                                      
                                 
                                
                                </div>

                                <div class="text-center" style="    margin-top: 20px;">
                                    <div class="form-group">
                                        <button class="btn btn-md order-btn "  id="pay-btn" type="button" disabled title="Proceed to make Purchase" style="border-radius:30px;">Proceed</button>
                                    </div>
                                    
                                </div>
                          
                       
                            
                               
                         

                          

                            
                                
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!-- Ending of product shipping form -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://khalti.com/static/khalti-checkout.js"></script>
    
    <script type="text/javascript">
        var total = <?php echo e($order->pay_amount); ?>;
        var id = '<?php echo e($order->order_number); ?>';
        // var discount = option.attr('discount');
        // $('#total-cost').html((total - discount).toFixed(2))
        $("#paymentMethod").on('click',function(){
            
            var option = $('input[name="radio"]:checked', this);
            var discount = option.attr('discount');
            var gateway = option.val();
    
            // $('#total-cost').html((total - discount).toFixed(2))
            $('#pay-btn').attr('disabled','disabled');

            if(discount > 0){

                $("#gatewaydiscount").show("slow");
                $("#gatewayds").text(discount);

            }else{
                $("#gatewaydiscount").hide();

                $("#gatewayds").text(0);                       
            }

            // $('#total-cost').html((total - discount).toFixed(2))

            if(gateway == 'Cash'){
                $('#pay-btn').removeAttr('disabled');
                $('#gateway').html('');
                

                var btn = document.getElementById("pay-btn");
                btn.onclick = function (e) {
                    e.preventDefault();
                    var form = '<form action="/checkout/<?php echo e($order->order_number); ?>/gateway/cod" method="POST"><?php echo e(csrf_field()); ?></form>';
                    $(form).appendTo('body').submit();
                }
                return;
            }
            else if(gateway == 'FonePay'){
                $('#pay-btn').removeAttr('disabled');
                $('#gateway').html('');

                var btn_fonepay = document.getElementById("pay-btn");
                btn_fonepay.onclick = function (e) {
                    e.preventDefault();
                    $('#pay-btn').attr('disabled','disabled');

                    $('#overlay').css('display','block');
                    $.ajax({
                        type: "POST",
                        url:"/checkout/"+id+"/gateway/fonepay",
                        data:{_token: "<?php echo e(csrf_token()); ?>"},
                        success:function(result){
                            location.href = result.url;
                            $('#pay-btn').removeAttr('disabled');
                        },
                        error: function(data){
                            $('#pay-btn').removeAttr('disabled');

                            $.notify("Something went wrong.","error");
                        }
                    });
                }
            }
            else if(gateway == 'IMEPay'){
                $('#pay-btn').removeAttr('disabled');
                $('#gateway').html('');

                var btn_imepay = document.getElementById("pay-btn");
                btn_imepay.onclick = function (e) {
                    e.preventDefault();
                    $('#overlay').css('display','block');
                    $('#pay-btn').attr('disabled','disabled');

                    $.ajax({
                        type: "POST",
                        url:"/checkout/"+id+"/gateway/imepay",
                        data:{_token: "<?php echo e(csrf_token()); ?>"},
                        success:function(result){
                            var html = '<form action="'+result.url+'" method="POST">'+
                                    '  <input type="hidden" name="TokenId" value="'+result.TokenId+'">'+
                                    '  <input type="hidden" name="MerchantCode" value="'+result.MerchantCode+'">'+
                                    '  <input type="hidden" name="RefId" value="'+result.RefId+'">'+
                                    '  <input type="hidden" name="TranAmount" value="'+result.TranAmount+'">'+
                                    '  <input type="hidden" name="Source" value="'+result.Source+'"></input>'+
                                    '</form>';
                            var form = $interpolate(html)($scope);
                        
                            jQuery(form).appendTo('body').submit();
                            $('#pay-btn').removeAttr('disabled');
                        },
                        error: function(data){
                            $('#pay-btn').removeAttr('disabled');

                            $.notify("Something went wrong.","error");
                        }
                    });  
                }
            }
            else if(gateway == 'Khalti'){
                $.ajax({
                    type: "POST",
                    url:"/checkout/"+id+"/gateway/khalti",
                    data:{_token: "<?php echo e(csrf_token()); ?>"},
                    success:function(data){
                        $('#gateway').html(data);
                        $("#gateway").show();
                        $('#pay-btn').removeAttr('disabled');
                    },
                    error: function(data){
                        $('#gateway').html('');
                        $.notify("Something went wrong.","error");
                    }
                });  
            }
            else
                $.notify('Select a valid payment gateway.','error')
        });

        var showErrors=function(response){
            

            if(response.message){
                $.notify(response.message,"error");
            }
            else if(response.error){
                $.notify(response.error,"error");
            }
        }

    </script>

<script>
    // $(document).ready(function(){
    //     $("select").change(function(){
    //         $(this).find("option:selected").each(function(){
    //             var optionValue = $(this).attr("value");
    //             if(optionValue){
    //                 $(".box").not("." + optionValue).hide();
    //                 $("." + optionValue).show();
    //             } else{
    //                 $(".box").hide();
    //             }
    //         });
    //     }).change();
    // });


    $(document).ready(function(){
    $('input[type="radio"]').click(function(){
        var inputValue = $(this).attr("value");
        var targetBox = $("." + inputValue);
        $(".box").not(targetBox).hide();
        $(targetBox).show();
    });
});
    </script>

         <!-- JS Implementing Plugins -->
         <script  src="/frontend-assets/main-assets/assets/vendor/fancybox/jquery.fancybox.min.js"></script>

         <!-- JS Unify -->
         <script  src="/frontend-assets/main-assets/assets/js/components/hs.popup.js"></script>

         <!-- JS Plugins Init. -->
         <script >
           $(document).on('ready', function () {
             // initialization of popups
             $.HSCore.components.HSPopup.init('.js-fancybox');
           });
         </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>