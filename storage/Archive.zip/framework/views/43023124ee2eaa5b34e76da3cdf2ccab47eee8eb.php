<?php $__env->startSection('content'); ?>


<?php if($gs->slider == 1): ?>

<div class="row">
    <div class="col-md-12">
        <div class="js-carousel text-center g-pb-30" data-autoplay="true" data-ride="carousel" data-infinite="true" data-arrows-classes="u-arrow-v1 g-absolute-centered--y g-width-35 g-height-40 g-font-size-40 g-color-gray g-bg-white g-mt-minus-10" data-arrow-left-classes="fa fa-angle-left g-left-0" data-arrow-right-classes="fa fa-angle-right g-right-0">

                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="js-slide">
                        <a class="js-fancybox" href="javascript:;" data-slide="prev" data-fancybox="lightbox-gallery--07-1" data-src="/frontend-assets/main-assets/assets/img-temp/900x600/img5.jpg" data-caption="Lightbox Gallery" data-animate-in="bounceInDown" data-animate-out="bounceOutDown" data-speed="1000" data-overlay-blur-bg="true">
                          <section>
                              <div class="" style="width:100%;height:30rem ;">
                            <img id="slider-img" style="width:100%; height:40rem;" src="<?php echo e(asset('assets/images/'.$slider->photo)); ?>">
                              </div>
                          </section>

                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


    </div>
</div>

<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>