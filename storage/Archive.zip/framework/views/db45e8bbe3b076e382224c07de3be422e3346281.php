<?php $__env->startSection('title','Proceed to Payment - Lab'); ?>
<?php $__env->startSection('content'); ?>
<link  rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/animate.css">
<link  rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/custombox/custombox.min.css">
<style>
    #lab{
  font-weight: 700 !important;
  color:#2385aa !important; 

}
    .section-padding {
        padding: 20px 0;
    }
        .select2-selection__rendered{
        
        height:35px !important;
    }
    .select2-container--default .select2-selection--single .select2-selection__arrow {
        height: 26px;
        position: absolute;
        top: 9px !important;
        right: 1px;
        width: 20px;
    }
    .select2-selection__arrow{
        height:35px !important;
    }
    .select2-container .select2-selection--single {
        box-sizing: border-box;
        cursor: pointer;
        display: block;
        height: 35px !important;
        user-select: none;
        -webkit-user-select: none;
    }
    .section-padding.product-shoppingCart-wrapper .table>tbody>tr>td {
        padding: 10px 0;
        vertical-align: middle;
        color: #555;
        font-size: 16px;
        border: none;
        text-align: left;
    }
    .section-padding.product-shoppingCart-wrapper .table>thead>tr>th {
        padding: 30px 0px;
        text-align: left;
        color: #333;
    }
    
    .section-padding.product-shoppingCart-wrapper .table>thead>tr>th {
        padding: 15px 0px;
        text-align: left;
        color: #333;
    }
    .product-shoppingCart-wrapper .table>tfoot>tr>td {
        padding: 10px 0;
    } 
</style>
<style>
    .section-padding {
        padding: 20px 0;
    }
        .select2-selection__rendered{
        
        height:35px !important;
    }
    .select2-container--default .select2-selection--single .select2-selection__arrow {
        height: 26px;
        position: absolute;
        top: 9px !important;
        right: 1px;
        width: 20px;
    }
    .select2-selection__arrow{
        height:35px !important;
    }
    .select2-container .select2-selection--single {
        box-sizing: border-box;
        cursor: pointer;
        display: block;
        height: 35px !important;
        user-select: none;
        -webkit-user-select: none;
    }
    .section-padding.product-shoppingCart-wrapper .table>tbody>tr>td {
        padding: 10px 0;
        vertical-align: middle;
        color: #555;
        font-size: 16px;
        border: none;
        text-align: left;
    }
    .section-padding.product-shoppingCart-wrapper .table>thead>tr>th {
        padding: 30px 0px;
        text-align: left;
        color: #333;
    }

    .section-padding.product-shoppingCart-wrapper .table>thead>tr>th {
        padding: 15px 0px;
        text-align: left;
        color: #333;
    }
    .product-shoppingCart-wrapper .table>tfoot>tr>td {
        padding: 10px 0;
    } 
</style>
<div class="section-padding product-shoppingCart-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 g-mb-20">
                <div class="view-cart-title pull-right">
                    <a style="color:black;" href="<?php echo e(route('front.index')); ?>"><?php echo e(ucfirst(strtolower($lang->home))); ?></a>
                    <i class="fa fa-angle-right"></i>
                    <a style="color:black;" href="<?php echo e(route('lab.cart')); ?>">Lab Test</a>
                    <i class="fa fa-angle-right"></i>
                    <a style="color:black;" href="<?php echo e(route('lab.checkout')); ?>">Checkout</a>
                    <i class="fa fa-angle-right"></i>
                    <a style="color:black;" >Payment</a>
                </div>
                <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

            </div>

            <div class="col-md-4 col-sm-12">

                <label class="d-block g-color-gray-dark-v2 g-font-size-20">Order Number: <?php echo e($order->order_number); ?></label>
                <hr class="g-my-10">
                
                <div class="table-responsive">
                    <table class="table ">
                        <thead>
                            <tr>
                                <th colspan="4"><?php echo e($lang->cproduct); ?></th>
                                <th><?php echo e($lang->cupice); ?></th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="4">
                                    <p class=" product-name-header" title="<?php echo e($product->test_name); ?>"><?php echo e(strlen($product->test_name) > 30 ? substr($product->test_name,0,30).'...' : $product->test_name); ?></a></p>
                                
                                </td>
                                
                                <td>
                                    <?php if($gs->sign == 0): ?>
                                        <?php echo e($order->currency_sign); ?><?php echo e(round($product->test_price * $order->currency_value, 2)); ?>

                                    <?php else: ?>
                                        <?php echo e(round($product->test_price * $order->currency_value, 2)); ?><?php echo e($order->currency_sign); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                        <tfoot>
                            <tr id="gatewaydiscount" style="display: none;">
                                <th colspan="4">Payment Gateway Discount:</th>
                                <th>
                                    <?php if($gs->sign == 0): ?>
                                    - <?php echo e($order->currency_sign); ?><span id="gatewayds">0</span>
                                    <?php else: ?>
                                    - <span id="gatewayds">0</span><?php echo e($order->currency_sign); ?>

                                    <?php endif; ?>
                                </th>
                            </tr>
                            <tr>
                                <th colspan="4"><h3><?php echo e($lang->vt); ?>: </h3></th>
                                <th>
                                    <?php if($gs->sign == 0): ?>
                                        <h3><?php echo e($order->currency_sign); ?><span class="lab-total"><?php echo e(round($order->pay_amount * $order->currency_value, 2)); ?></span></h3>
                                    <?php else: ?>
                                        <span class="lab-total"><?php echo e(round($order->pay_amount * $order->currency_value, 2)); ?></span><?php echo e($order->currency_sign); ?>

                                    <?php endif; ?>
                                </th>
                            </tr>
                        </tfoot>
                    </table>
                    
                </div>
            
            </div>
            <div class="col-md-8 col-sm-12">

                <label class="d-block g-color-gray-dark-v2 g-font-size-20">Payment Options</label>
                <hr class="g-my-10">
                        
                <div class="form-group">
                    <label><?php echo e($lang->cup); ?> <span>*</span></label>
                    <select name="method" id="paymentMethod" class="form-control" required="">
                        <option value="" disabled selected=""><?php echo e($lang->cup); ?></option>
                        
                        <?php if($gs->ccheck != 0): ?>
                                        <option value="Cash" discount="0"><?php echo e($lang->dolpl); ?></option>
                        <?php endif; ?>

                        <?php $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($gt->title); ?>" discount="<?php echo e($gt->discount); ?>">
                                <?php echo e($gt->title); ?> <?php echo e($gt->discount > 0 ? '('.$gt->discount_text.')' : ''); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="Cash box" >
                    <h4 >Get Discounts on online Payment </h4> 
                    <br/> 
                    <img src="https://blog.khalti.com/wp-content/uploads/2019/09/%E0%A4%A0%E0%A5%82%E0%A4%B2%E0%A5%8B-%E0%A4%A6%E0%A4%B6%E0%A5%88%E0%A4%81%E0%A4%95%E0%A5%8B-%E0%A4%A0%E0%A5%82%E0%A4%B2%E0%A5%8B-%E0%A4%A7%E0%A4%AE%E0%A4%BE%E0%A4%95%E0%A4%BE_Order-online-at-thulo.com-and-pay-with-Khalti-and-get-cashback-instantly.jpg" style="height:120px;"/> 
                    <img src="https://www.agmwebhosting.com/blog/wp-content/uploads/2020/01/Instant-cashback-blog-740x414.png" style="height:120px;"/> 
                    <img src="https://www.offerayo.com/wp-content/uploads/2019/09/miniso-10_-3-outlets-fonepay.png" style="height:120px;"/> 
               </div>


                <div id="gateway" style="display: none;"></div>

                <div class="text-right">
                    <div class="form-group">
                        <button class="btn btn-md order-btn" id="pay-btn" type="button" disabled>Pay</button>
                    </div>
                    
                </div>
                
            </div>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://khalti.com/static/khalti-checkout.js"></script>
    
    <script type="text/javascript">
        var total = <?php echo e($order->pay_amount); ?>;
        var id = '<?php echo e($order->order_number); ?>';
       
        $("#paymentMethod").on('click',function(){
            
            var option = $('option:selected', this);
            var discount = option.attr('discount');
            var gateway = option.val();

            $('#pay-btn').attr('disabled','disabled');

            if(discount > 0){

                $("#gatewaydiscount").show("slow");
                $("#gatewayds").text(discount);

            }else{
                $("#gatewaydiscount").hide();

                $("#gatewayds").text(0);                       
            }

            $('.lab-total').html((total - discount).toFixed(2))

            if(gateway == 'FonePay'){
                $('#pay-btn').removeAttr('disabled');
                $('#gateway').html('');

                var btn_fonepay = document.getElementById("pay-btn");
                btn_fonepay.onclick = function (e) {
                    e.preventDefault();
                    $('#pay-btn').attr('disabled','disabled');

                    $('#overlay').css('display','block');
                    $.ajax({
                        type: "POST",
                        url:"/lab/payment/"+id+"/gateway/fonepay",
                        data:{_token: "<?php echo e(csrf_token()); ?>"},
                        success:function(result){
                            location.href = result.url;
                            $('#pay-btn').removeAttr('disabled');
                        },
                        error: function(data){
                            $('#pay-btn').removeAttr('disabled');

                            $.notify("Something went wrong.","error");
                        }
                    });
                }
            }

            else if(gateway == 'Cash'){
                $('#pay-btn').removeAttr('disabled');
                $('#gateway').html('');

                var btn = document.getElementById("pay-btn");
                btn.onclick = function (e) {
                    e.preventDefault();
                    var form = '<form action="/lab/payment/<?php echo e($order->order_number); ?>/gateway/cod" method="POST"><?php echo e(csrf_field()); ?></form>';
                    $(form).appendTo('body').submit();
                }
                return;
            }
            else if(gateway == 'IMEPay'){
                $('#pay-btn').removeAttr('disabled');
                $('#gateway').html('');

                var btn_imepay = document.getElementById("pay-btn");
                btn_imepay.onclick = function (e) {
                    e.preventDefault();
                    $('#overlay').css('display','block');
                    $('#pay-btn').attr('disabled','disabled');

                    $.ajax({
                        type: "POST",
                        url:"/lab/payment/"+id+"/gateway/imepay",
                        data:{_token: "<?php echo e(csrf_token()); ?>"},
                        success:function(result){
                            var html = '<form action="'+result.url+'" method="POST">'+
                                    '  <input type="hidden" name="TokenId" value="'+result.TokenId+'">'+
                                    '  <input type="hidden" name="MerchantCode" value="'+result.MerchantCode+'">'+
                                    '  <input type="hidden" name="RefId" value="'+result.RefId+'">'+
                                    '  <input type="hidden" name="TranAmount" value="'+result.TranAmount+'">'+
                                    '  <input type="hidden" name="Source" value="'+result.Source+'"></input>'+
                                    '</form>';
                            var form = $interpolate(html)($scope);
                        
                            jQuery(form).appendTo('body').submit();
                            $('#pay-btn').removeAttr('disabled');
                        },
                        error: function(data){
                            $('#pay-btn').removeAttr('disabled');

                            $.notify("Something went wrong.","error");
                        }
                    });  
                }
            }
            else if(gateway == 'Khalti'){
                $.ajax({
                    type: "POST",
                    url:"/lab/payment/"+id+"/gateway/khalti",
                    data:{_token: "<?php echo e(csrf_token()); ?>"},
                    success:function(data){
                        $('#gateway').html(data);
                        $("#gateway").show();
                        $('#pay-btn').removeAttr('disabled');
                    },
                    error: function(data){
                        $('#gateway').html('');
                        $.notify("Something went wrong.","error");
                    }
                });  
            }
            else
                $.notify('Select a valid payment gateway.','error')
        });

        var showErrors=function(response){
            

            if(response.message){
                $.notify(response.message,"error");
            }
            else if(response.error){
                $.notify(response.error,"error");
            }
        }

    </script>

<script>
    $(document).ready(function(){
        $("select").change(function(){
            $(this).find("option:selected").each(function(){
                var optionValue = $(this).attr("value");
                if(optionValue){
                    $(".box").not("." + optionValue).hide();
                    $("." + optionValue).show();
                } else{
                    $(".box").hide();
                }
            });
        }).change();
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>