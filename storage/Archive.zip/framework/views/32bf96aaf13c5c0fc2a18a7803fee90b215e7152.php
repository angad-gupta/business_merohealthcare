<?php $__env->startSection('content'); ?>   

<link rel="shortcut icon" href="/frontend-assets/main-assets/favicon.ico">
  <!-- Google Fonts -->
  
  <!-- CSS Global Compulsory -->
  
  <!-- CSS Global Icons -->
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-line/css/simple-line-icons.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-etlinefont/style.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-line-pro/style.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-hs/style.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/slick-carousel/slick/slick.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/hs-megamenu/src/hs.megamenu.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/hamburgers/hamburgers.min.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/animate.css">
  <!-- CSS Unify -->


  <!-- CSS Customization -->


<style>
.title-stats {
    position: relative;
    display: block;
    background-color: #303641;
    color: #777;
    padding: 10px 20px 20px;
    margin-bottom: 30px;
    border-radius: 5px;
    transition: .4s;
}

.title-stats .icon {
    color: #2385aa;
    position: absolute;
    right: 5px;
    bottom: 8px;
}
.title-stats:hover {color: #2385aa;}

.title-stats .icon i {
    font-size: 80px;
    line-height: 0;
}

h4{
    width:80%;
}

h4{
    font-size: 15px;
}

.title-stats .icon i {
    font-size: 57px;
    line-height: 0;
    position: relative;
    top: -13px;
    right: 8px;

}
.title-stats{
    border-radius:20px;
    background: #f9f9f9 !important;

}

</style>



        <div class="right-side">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <!-- Starting of Dashboard header items area -->
                        <div class="panel panel-default admin">
                            <div class="panel-heading admin-title">
                                <div class="product__header" style="border-bottom: none;">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-8 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title">
                                                    <?php if(Auth::guard('user')->user()->is_vendor == 2): ?> 
                                                    <h2 style="font-size: 25px;">Lab Vendor Dashboard </h2>
                                                    <?php elseif(Auth::guard('user')->user()->is_vendor == 3): ?>
                                                    <h2 style="font-size: 25px;">Product Vendor Dashboard</h2>
                                                    <?php else: ?>
                                                    <h2 style="font-size: 25px;font-weight:300;"><?php echo e($user->name); ?>'s Dashboard </h2>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                              <?php echo $__env->make('includes.user-notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </div>   
                                    </div></div>

                                

                            <div class="panel-body dashboard-body">
                                <div class="dashboard-header-area">
                                    
                                        <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        
                                        
                                        <?php if(Auth::guard('user')->user()->is_vendor == 2): ?> 
                                        <div class="row">
                                           
                                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                                <a class="title-stats title-purple" href="<?php echo e(route('vendor-lab-order-index')); ?>" style="background:transparent;    border: 1px solid;
                                                border-color: #e3e3e3;">
                                                    <div class="icon"><i class="icon-medical-010 u-line-icon-pro fa-5x"></i></div>
                                                    <div class="number"><?php echo e(Modules\Lab\Entities\LabOrder::where('vendor_id','=',$user->id)->count()); ?></div>
                                                    <h4>Total Lab Orders</h4>
                                                   

                                                </a>
                                            </div>
                                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                                <a  class="title-stats title-blue" style="background:transparent;    border: 1px solid;
                                                border-color: #e3e3e3;">
                                                    <div class="icon"><i class="icon-check fa-5x"></i></div>
                                                    <div style="font-size: 38px; font-weight: 600;"><?php echo e($currency_sign->sign); ?> <?php echo e(number_format(Modules\Lab\Entities\LabOrder::where('user_id','=',$user->id)->where('status','completed')->sum('pay_amount')  * $currency_sign->value,2)); ?></div>
                                                    <h4><?php echo e($lang->total_earning); ?></h4>
                                                  

                                                </a>
                                            </div>
                                        </div>

                                        <?php elseif(Auth::guard('user')->user()->is_vendor == 3): ?>
                                        <div class="row">
                                           
                                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                                <a class="title-stats title-purple" href="<?php echo e(route('user-vendor-product.index')); ?>" style="background:transparent; border: 1px solid;
                                                border-color: #e3e3e3;">
                                                    <div class="icon"><i class="icon-basket-loaded u-line-icon-pro fa-5x"></i></div>
                                                    <div class="number"><?php echo e(App\Product::where('user_id','=',$user->id)->count()); ?></div>
                                                    <h4>Total Product </h4>
                                                   

                                                </a>
                                            </div>
                       
                                        </div>

                                        <?php else: ?>

                                        <div class="row">
                                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                            <h2 class="h4" style="color:#555; margin-left:15px;font-weight:600;">Wishlist</h2>
                                                <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12">
                                                  
                                                    <a href="<?php echo e(route('user-wishlist')); ?>" class="title-stats title-red" style="background:#ffd5d5 !important;border: 1px solid;
                                                    border-color: #e3e3e3;">
                                                        <div class="icon"><i class="icon-medical-022 u-line-icon-pro fa-5x"></i></div>
                                                        <div class="number"><?php echo e(count($wishes)); ?></div>
                                                        <h4><?php echo e($lang->favorite_product); ?></h4>
                                                        
                                                    </a>
                                                </div>
                                           </div>

                                           <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12" >
                                            <h2 class="h4" style="color:#555; margin-left:15px;font-weight:600;">Purchased Order</h2>
                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                            
                                                <a href="<?php echo e(route('user-orders')); ?>" class="title-stats title-cyan" style="background:#ffeed0 !important; border: 1px solid;
                                                border-color: #e3e3e3;">
                                                    <div class="icon"><i class="icon-transport-069 u-line-icon-pro fa-5x"></i></div>
                                                    <div class="number"><?php echo e($process); ?> </div>
                                                    <h4><?php echo e($lang->order_processing); ?></h4>
                                                    
                                                </a>
                                            </div>

                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                <a href="<?php echo e(route('user-orders')); ?>" class="title-stats title-green" style="background:#d3f3d3 !important;border: 1px solid;
                                                border-color: #e3e3e3;">
                                                    <div class="icon"><i class="icon-check fa-5x"></i></div>
                                                    <div class="number"><?php echo e($complete); ?></div>
                                                    <h4><?php echo e($lang->order_completed); ?></h4>
                                                    
                                                </a>
                                            </div>
                                            </div>

                                           
                                           
                                           

                                           
                                        </div>

                                        <div class="row">
                                       
                                            
                                        </div>

                                      
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Ending of Dashboard header items area -->


                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>