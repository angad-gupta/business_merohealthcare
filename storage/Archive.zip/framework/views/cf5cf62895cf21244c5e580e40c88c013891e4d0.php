<?php $__env->startSection('title',$lang->wish_head); ?>
<?php $__env->startSection('content'); ?>
<style>

  @media  only screen and (max-width: 1200px) and (min-width: 992px){
  .category-wrap .product-image-area {
      width: 100%;
      height: 220px;
  }
  }
  
  @media  only screen and (max-width: 991px) and (min-width: 768px){
  .category-wrap .product-image-area {
      width: 100%;
      height: 200px;
  }
  }
  
  
    @media  only screen and (max-width: 767px){
    .category-wrap .product-image-area {
        height: 175px;
        width: 100%;
    }
    }
    
    .gallery-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 2;
        opacity: 0;
        transition: all .4s ease-in;
    }
    
    .product-hover-area {
        position: absolute;
        width: 101%;
        left: 0;
        bottom: -15%;
        opacity: 0;
        visibility: hidden;
        z-index: 3;
        -webkit-transition: all .4s ease-in;
        transition: all .4s ease-in;
        z-index: 36;
    }
    
    .single-product-area {
        border: 0px solid #e0e0e0;
        box-shadow: 0 0 5px #f2f2f2;
        display: block;
        -webkit-transform: perspective(1px) translateZ(0);
        transform: perspective(1px) translateZ(0);
        position: relative;
        overflow: hidden;
        -webkit-transition: all .3s ease-in;
        transition: all .3s ease-in;
        margin-bottom: 30px;
    }
    </style>
<?php 
$i=1;
$j=1;
 ?>
    <!-- Starting of Section title overlay area -->
    <div class="title-overlay-wrap overlay" style="background-image: url(<?php echo e(asset('assets/images/'.$gs->bgimg)); ?>);">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 text-center">
            <h1><?php echo e($lang->wish_head); ?></h1>
          </div>
        </div>
      </div>
    </div>

   
    <!-- Ending of Section title overlay area -->

   <!-- Starting of product search area -->
    <div class="section-padding product-search-wrap">
        <div class="container">
           
            <div class="row">
                <?php echo $__env->make('includes.catalog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="col-lg-9 col-md-8 col-sm-12 col-xs-12">

                    <div class="category-wrap">
                      <h1 class="text-center">Wishlists</h1>
                        <div class="row">
                <?php $__currentLoopData = $wproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                                
                                <?php if($prod->user_id != 0): ?>

                                
                                <?php if($prod->user->is_vendor == 2): ?>
                      <?php 
                      $price = $prod->cprice + $gs->fixed_commission + ($prod->cprice/100) * $gs->percentage_commission ;
                       ?>

                            <?php if(isset($max)): ?>  
                            <?php if($price < $max): ?>
                            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12" style="width:50%;" >
                                      <?php 
                                          $name = str_replace(" ","-",$prod->name);
                                       ?>
                        <div class="single-product-area text-center" style="margin-bottom:0px;">
                          <div class="product-image-area">
                                            <?php if($prod->features!=null && $prod->colors!=null): ?>
                                            <?php 
                                            $title = explode(',', $prod->features);
                                            $details = explode(',', $prod->colors);
                                             ?>
                                            <div class="featured-tag" style="width: 100%;">
                                              <?php $__currentLoopData = array_combine($title,$details); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ttl => $dtl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <style type="text/css">
                                                span#d<?php echo e($j++); ?>:after {
                                                    border-left: 10px solid <?php echo e($dtl); ?>;
                                                }
                                              </style>
                                              <span id="d<?php echo e($i++); ?>" style="background: <?php echo e($dtl); ?>"><?php echo e($ttl); ?></span>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <?php endif; ?>
                            <img src="<?php echo e(asset('assets/images/'.$prod->photo)); ?>" alt="featured product">
                            <?php if($prod->youtube != null): ?>
                            <div class="product-hover-top">
                              <span class="fancybox" data-fancybox href="<?php echo e($prod->youtube); ?>"><i class="fa fa-play-circle"></i></span>
                            </div>
                            <?php endif; ?>

                            <div class="gallery-overlay"></div>
<div class="gallery-border"></div>
<div class="product-hover-area">
                    <input type="hidden" value="<?php echo e($prod->id); ?>">
                    <?php if(Auth::guard('user')->check()): ?>
                      <span class="wishlist hovertip uwish" rel-toggle="tooltip" title="<?php echo e($lang->wishlist_add); ?>"><i class="icon-heart"></i>
                                <span class="wish-number"><?php echo e(App\Wishlist::where('product_id','=',$prod->id)->get()->count()); ?></span>
                              </span>
                    <?php else: ?>
                      <span class="wishlist hovertip no-wish" data-toggle="modal" data-target="#loginModal" rel-toggle="tooltip" title="<?php echo e($lang->wishlist_add); ?>"><i class="icon-heart"></i>
                                <span class="wish-number"><?php echo e(App\Wishlist::where('product_id','=',$prod->id)->get()->count()); ?></span>
                              </span>
                    <?php endif; ?>
                    <span class="wish-list hovertip wish-listt" data-toggle="modal" data-target="#myModal" rel-toggle="tooltip" title="<?php echo e($lang->quick_view); ?>"><i class="fa fa-eye"></i>
                              </span>
                              <span class="hovertip addcart" rel-toggle="tooltip" title="<?php echo e($lang->hcs); ?>"><a class="productDetails-addCart-btn" id="addcrt" href="javascript:;" style="cursor: pointer;">
                              </a>
                              <i class="icon-finance-100 u-line-icon-pro"></i> 
                              </span>
                              
                            </div>
                          </div>



                          </div>
                          <div class="product-description text-center single-product-area" style="margin-top:0px;">
                            <div class="product-name" style="margin-bottom: 35px;"><a href="<?php echo e(route('front.product',['id' => $prod->id, 'slug' => str_slug($name,'-')])); ?>" class="text-center"><?php echo e(strlen($prod->name) > 65 ? substr($prod->name,0,65)."..." : $prod->name); ?></a></div>
                            

                                    <?php if($gs->sign == 0): ?>
                                        <div class="product-price"><?php echo e($curr->sign); ?>

                      <?php echo e(round($price * $curr->value,2)); ?>

                    <?php if($prod->pprice != 0): ?>
                      <del class="offer-price" style="color:red;"><?php echo e($curr->sign); ?><?php echo e(round($prod->pprice * $curr->value,2)); ?></del>  
                      <?php endif; ?>

                                        </div>
                                    <?php else: ?>
                                        <div class="product-price">
                      <?php echo e(round($price * $curr->value,2)); ?>

                    <?php if($prod->pprice != 0): ?>
                      <del class="offer-price" style="color:red;"><?php echo e($curr->sign); ?><?php echo e(round($prod->pprice * $curr->value,2)); ?></del>  
                      <?php endif; ?>
<?php echo e($curr->sign); ?>

                                        </div>
                                    <?php endif; ?>
                          </div>
                       

                            </div>
                            <?php endif; ?>
                            <?php else: ?>                  
                            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12" style="width:50%;">
                                      <?php 
                                          $name = str_replace(" ","-",$prod->name);
                                       ?>
                        <div class="single-product-area text-center" style="margin-bottom:0px;">
                          <div class="product-image-area">
                                            <?php if($prod->features!=null && $prod->colors!=null): ?>
                                            <?php 
                                            $title = explode(',', $prod->features);
                                            $details = explode(',', $prod->colors);
                                             ?>
                                            <div class="featured-tag" style="width: 100%;">
                                              <?php $__currentLoopData = array_combine($title,$details); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ttl => $dtl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <style type="text/css">
                                                span#d<?php echo e($j++); ?>:after {
                                                    border-left: 10px solid <?php echo e($dtl); ?>;
                                                }
                                              </style>
                                              <span id="d<?php echo e($i++); ?>" style="background: <?php echo e($dtl); ?>"><?php echo e($ttl); ?></span>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <?php endif; ?>
                            <img src="<?php echo e(asset('assets/images/'.$prod->photo)); ?>" alt="featured product">
                            <?php if($prod->youtube != null): ?>
                            <div class="product-hover-top">
                              <span class="fancybox" data-fancybox href="<?php echo e($prod->youtube); ?>"><i class="fa fa-play-circle"></i></span>
                            </div>
                            <?php endif; ?>

                            <div class="gallery-overlay"></div>
<div class="gallery-border"></div>
<div class="product-hover-area">
                    <input type="hidden" value="<?php echo e($prod->id); ?>">
                    <?php if(Auth::guard('user')->check()): ?>
                      <span class="wishlist hovertip uwish" rel-toggle="tooltip" title="<?php echo e($lang->wishlist_add); ?>"><i class="icon-heart"></i>
                                <span class="wish-number"><?php echo e(App\Wishlist::where('product_id','=',$prod->id)->get()->count()); ?></span>
                              </span>
                    <?php else: ?>
                      <span class="wishlist hovertip no-wish" data-toggle="modal" data-target="#loginModal" rel-toggle="tooltip" title="<?php echo e($lang->wishlist_add); ?>"><i class="icon-heart"></i>
                                <span class="wish-number"><?php echo e(App\Wishlist::where('product_id','=',$prod->id)->get()->count()); ?></span>
                              </span>
                    <?php endif; ?>
                    <span class="wish-list hovertip wish-listt" data-toggle="modal" data-target="#myModal" rel-toggle="tooltip" title="<?php echo e($lang->quick_view); ?>"><i class="fa fa-eye"></i>
                              </span>
                              <span class="hovertip addcart" rel-toggle="tooltip" title="<?php echo e($lang->hcs); ?>"><a class="productDetails-addCart-btn" id="addcrt" href="javascript:;" style="cursor: pointer;">
                              </a>
                              <i class="icon-finance-100 u-line-icon-pro"></i> 
                              </span>
                              
                            </div>
                          </div>



                          </div>
                          <div class="product-description text-center single-product-area" style="margin-top:0px;">
                            <div class="product-name" style="margin-bottom: 35px;"><a href="<?php echo e(route('front.product',['id' => $prod->id, 'slug' => str_slug($name,'-')])); ?>" class="text-center"><?php echo e(strlen($prod->name) > 65 ? substr($prod->name,0,65)."..." : $prod->name); ?></a></div>
                            

                                    <?php if($gs->sign == 0): ?>
                                        <div class="product-price"><?php echo e($curr->sign); ?>

                      <?php echo e(round($price * $curr->value,2)); ?>

                    <?php if($prod->pprice != 0): ?>
                      <del class="offer-price" style="color:red;"><?php echo e($curr->sign); ?><?php echo e(round($prod->pprice * $curr->value,2)); ?></del>  
                      <?php endif; ?>

                                        </div>
                                    <?php else: ?>
                                        <div class="product-price">
                      <?php echo e(round($price * $curr->value,2)); ?>

                    <?php if($prod->pprice != 0): ?>
                      <del class="offer-price" style="color:red;"><?php echo e($curr->sign); ?><?php echo e(round($prod->pprice * $curr->value,2)); ?></del>  
                      <?php endif; ?>
<?php echo e($curr->sign); ?>

                                        </div>
                                    <?php endif; ?>
                          </div>
                  

                            </div>
                            <?php endif; ?>
                            <?php endif; ?>

                                

                                <?php else: ?>


                            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12" style="width:50%;">
                                      <?php 
                                          $name = str_replace(" ","-",$prod->name);
                                       ?>
                        <div class="single-product-area text-center" style="margin-bottom:0px;">
                          <div class="product-image-area">
                                            <?php if($prod->features!=null && $prod->colors!=null): ?>
                                            <?php 
                                            $title = explode(',', $prod->features);
                                            $details = explode(',', $prod->colors);
                                             ?>
                                            <div class="featured-tag" style="width: 100%;">
                                              <?php $__currentLoopData = array_combine($title,$details); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ttl => $dtl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <style type="text/css">
                                                span#d<?php echo e($j++); ?>:after {
                                                    border-left: 10px solid <?php echo e($dtl); ?>;
                                                }
                                              </style>
                                              <span id="d<?php echo e($i++); ?>" style="background: <?php echo e($dtl); ?>"><?php echo e($ttl); ?></span>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <?php endif; ?>
                            <img src="<?php echo e(asset('assets/images/'.$prod->photo)); ?>" alt="featured product">
                            <?php if($prod->youtube != null): ?>
                            <div class="product-hover-top">
                              <span class="fancybox" data-fancybox href="<?php echo e($prod->youtube); ?>"><i class="fa fa-play-circle"></i></span>
                            </div>
                            <?php endif; ?>

                            <div class="gallery-overlay"></div>
<div class="gallery-border"></div>
<div class="product-hover-area">
                    <input type="hidden" value="<?php echo e($prod->id); ?>">
                    <?php if(Auth::guard('user')->check()): ?>
                      <span class="wishlist hovertip uwish" rel-toggle="tooltip" title="<?php echo e($lang->wishlist_add); ?>"><i class="icon-heart"></i>
                                <span class="wish-number"><?php echo e(App\Wishlist::where('product_id','=',$prod->id)->get()->count()); ?></span>
                              </span>
                    <?php else: ?>
                      <span class="wishlist hovertip no-wish" data-toggle="modal" data-target="#loginModal" rel-toggle="tooltip" title="<?php echo e($lang->wishlist_add); ?>"><i class="icon-heart"></i>
                                <span class="wish-number"><?php echo e(App\Wishlist::where('product_id','=',$prod->id)->get()->count()); ?></span>
                              </span>
                    <?php endif; ?>
                    <span class="wish-list hovertip wish-listt" data-toggle="modal" data-target="#myModal" rel-toggle="tooltip" title="<?php echo e($lang->quick_view); ?>"><i class="fa fa-eye"></i>
                              </span>
                              <span class="hovertip addcart" rel-toggle="tooltip" title="<?php echo e($lang->hcs); ?>"><a class="productDetails-addCart-btn" id="addcrt" href="javascript:;" style="cursor: pointer;">
                              </a>
                              <i class="icon-finance-100 u-line-icon-pro"></i> 
                              </span>
                              
                            </div>
                          </div>


                          </div>
                          <div class="product-description text-center single-product-area" style="margin-top:0px;">
                            <div class="product-name" style="margin-bottom: 35px;"><a href="<?php echo e(route('front.product',['id' => $prod->id, 'slug' => str_slug($name,'-')])); ?>" class="text-center"><?php echo e(strlen($prod->name) > 65 ? substr($prod->name,0,65)."..." : $prod->name); ?></a></div>
                            
                                    <?php if($gs->sign == 0): ?>
                                        <div class="product-price"><?php echo e($curr->sign); ?>

                      <?php echo e(round($prod->cprice * $curr->value,2)); ?>

                    <?php if($prod->pprice != 0): ?>
                      <del class="offer-price" style="color:red;"><?php echo e($curr->sign); ?><?php echo e(round($prod->pprice * $curr->value,2)); ?></del>  
                      <?php endif; ?>

                                        </div>
                                    <?php else: ?>
                                        <div class="product-price">
                      <?php echo e(round($prod->cprice * $curr->value,2)); ?>

                    <?php if($prod->pprice != 0): ?>
                      <del class="offer-price" style="color:red;"><?php echo e($curr->sign); ?><?php echo e(round($prod->pprice * $curr->value,2)); ?></del>  
                      <?php endif; ?>
<?php echo e($curr->sign); ?>

                                        </div>
                                    <?php endif; ?>
                          </div>
                  
                            </div>

                            <?php endif; ?>
                                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($min) || isset($max)): ?>
                    <div class="row">
                        <div class="col-md-12 text-center"> 
                            <?php echo $wproducts->appends(['min' => $min, 'max' => $max])->links(); ?>               
                        </div>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <div class="col-md-12 text-center"> 
                            <?php echo $wproducts->links(); ?>               
                        </div>
                    </div>
                <?php endif; ?>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
    <!-- Ending of product search area -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
            $("#ex2").slider({});
        $("#ex2").on("slide", function(slideRange) {
            var totals = slideRange.value;
            var value = totals.toString().split(',');
            $("#price-min").val(value[0]);
            $("#price-max").val(value[1]);
        });
</script>

<script type="text/javascript">
        $("#sortby").change(function () {
        var sort = $("#sortby").val();
        window.location = "<?php echo e(url('/user/wishlists')); ?>/"+sort;
    });
</script>

<script type="text/javascript">
    $('.removewish').click(function(){
        $(this).parent().parent().parent().parent().hide();
            var pid = $(this).parent().find('input[type=hidden]').val();
            $.ajax({
                    type: "GET",
                    url:"<?php echo e(URL::to('/json/removewish')); ?>",
                    data:{id:pid},
                    success:function(data){
        $.notify("<?php echo e($gs->wish_remove); ?>","success"); 
                      }
              });        
        return false;
    });
</script>

<script>
  $(document).on("click", ".addcart" , function(){
      var pid = $(this).parent().find('input[type=hidden]').val();
          $.ajax({
                  type: "GET",
                  url:"<?php echo e(URL::to('/json/addcart')); ?>",
                  data:{id:pid},
                  success:function(data){
                      if(data == 0)
                      {
                          $.notify("<?php echo e($gs->cart_error); ?>","error");
                      }
                      else
                      {
                      $(".empty").html("");
                      $(".total").html((data[0] * <?php echo e($curr->value); ?>).toFixed(2));
                      $(".cart-quantity").html(data[2]);
                      var arr = $.map(data[1], function(el) {
                      return el });
                      $(".cart").html("");
                      for(var k in arr)
                      {
                          var x = arr[k]['item']['name'];
                          var p = x.length  > 45 ? x.substring(0,45)+'...' : x;
                          var measure = arr[k]['item']['measure'] != null ? arr[k]['item']['measure'] : "";
                          $(".cart").append(
                          '<div class="single-myCart">'+
          '<p class="cart-close" onclick="remove('+arr[k]['item']['id']+')"><i class="fa fa-close"></i></p>'+
                          '<div class="cart-img">'+
                  '<img src="<?php echo e(asset('assets/images/')); ?>/'+arr[k]['item']['photo']+'" alt="Product image">'+
                          '</div>'+
                          '<div class="cart-info">'+
      '<a href="<?php echo e(url('/')); ?>/product/'+arr[k]['item']['id']+'/'+arr[k]['item']['name']+'" style="color: black; padding: 0 0;">'+'<h5>'+p+'</h5></a>'+
                      '<p><?php echo e($lang->cquantity); ?>: <span id="cqt'+arr[k]['item']['id']+'">'+arr[k]['qty']+'</span> '+measure+'</p>'+
                      <?php if($gs->sign == 0): ?>
                      '<p><?php echo e($curr->sign); ?><span id="prct'+arr[k]['item']['id']+'">'+(arr[k]['price'] * <?php echo e($curr->value); ?>).toFixed(2)+'</span></p>'+
                      <?php else: ?>
                      '<p><span id="prct'+arr[k]['item']['id']+'">'+(arr[k]['price'] * <?php echo e($curr->value); ?>).toFixed(2)+'</span><?php echo e($curr->sign); ?></p>'+
                      <?php endif; ?>
                      '</div>'+
                      '</div>');
                        }
                      $.notify("<?php echo e($gs->cart_success); ?>","success");
                      }
                  },
                  error: function(data){
                      if(data.responseJSON)
                      $.notify(data.responseJSON.error,"error");
                      else
                      $.notify('Something went wrong',"error");

                  }
            }); 
      return false;
  });

  

  </script>
  <script>
  $(document).on("click", ".removecart" , function(e){
      $(".addToMycart").show();
  });
  </script>
 



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>