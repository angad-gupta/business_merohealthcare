


<?php $__env->startSection('body'); ?>

    <div style="font-size: 16px; font-weight: 400; line-height: 24px; color: #333333;">

        <?php echo $email_body; ?>


    </div>
    <p style="font-size: 16px; font-weight: 600; line-height: 24px; color: #333333;">                              
    Thanks,<br>
    MHC Team
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.email', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>