<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keywords" content="<?php echo e($seo->meta_keys); ?>">
        <meta name="author" content="GeniusOcean">

        <title><?php echo e($gs->title); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/print/bootstrap/dist/css/bootstrap.min.css')); ?>">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/print/font-awesome/css/font-awesome.min.css')); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/print/Ionicons/css/ionicons.min.css')); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/print/css/style.css')); ?>">
  <link href="<?php echo e(asset('assets/admin/css/style.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
        <link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/'.$gs->favicon)); ?>"> 
  <style type="text/css">
@page  { size: auto;  margin: 0mm; }
@page  {
  size: A4;
  margin: 5mm;
}
@media  print {
  html, body {
    width: 210mm;
    height: 287mm;
  }
}

/* html {
    overflow: scroll;
    overflow-x: hidden;
} */
::-webkit-scrollbar {
    width: 0px;  /* remove scrollbar space */
    background: transparent;  /* optional: just make scrollbar invisible */
}
  </style>
</head>
<body onload="window.print();">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard data-table area -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                                    <div class="container text-center">
                                    <img class="text-center" src="<?php echo e(url('assets/images/logo.jpg')); ?>" style="height:100px; width:175px; "/>
                                    
                                    </div>

                                    

                                    <div class="product__header">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-8 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title">
                                                    <h4>PAN : 609680496</h4>
                                                    <h2 style="text-transform:uppercase;">Order #<?php echo e($order->order_number); ?> [<?php echo e($order->status); ?>] 
                                                         <?php if($order->payment_status == "paid"): ?>
                                                        <span class="btn-sm btn-success" style="cursor:default">Paid</span>
                                                    <?php else: ?>
                                                        <span class="btn-sm btn-danger" style="cursor:default">Unpaid</span> 
                                                    <?php endif; ?>
                                                </h2>
                                                    
                                        </div>   
                                    </div>
                                        <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        <div class="row">
                                            <div class="col-md-10" style="margin-left: 2.5%;">
                                                <div class="dashboard-content">
                                                    <div class="view-order-page" id="print">
                                                        <p class="order-date">Order Date <?php echo e(date('d-M-Y',strtotime($order->created_at))); ?></p>


<?php if($order->dp == 1): ?>

                                                        <div class="billing-add-area">
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <h5>Billing Address</h5>
                                                                    <address>
                                                                        Name: <?php echo e($order->customer_name); ?><br>
                                                                        Email: <?php echo e($order->customer_email); ?><br>
                                                                        Phone: <?php echo e($order->customer_phone); ?><br>
                                                                        Address: <?php echo e($order->customer_address); ?><br>
                                                                        
                                                                    </address>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <h5>
                                                                        Payment Method
                                                                        <?php if($order->payment_status == "paid"): ?>
                                                                            <span class="btn-sm btn-success" style="cursor:default">Paid</span>
                                                                        <?php else: ?>
                                                                            <span class="btn-sm btn-danger" style="cursor:default">Unpaid</span> 
                                                                        <?php endif; ?>
                                                                    </h5>
                                                                    <p><?php echo e($order->method); ?></p>

                                                                    <?php if($order->method != "Cash On Delivery"): ?>
                                                                        <?php if($order->method=="Stripe"): ?>
                                                                            <?php echo e($order->method); ?> Charge ID: <p><?php echo e($order->charge_id); ?></p>
                                                                        <?php endif; ?>
                                                                        <?php echo e($order->method); ?> Transaction ID: <p id="ttn"><?php echo e($order->txnid); ?></p>

                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>

<?php else: ?>
                                                        <div class="shipping-add-area">
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <?php if($order->shipping == "shipto"): ?>
                                                                        <h5>Delivery Address</h5>
                                                                        <address>
                Name: <?php echo e($order->shipping_name == null ? $order->customer_name : $order->shipping_name); ?><br>
                Email: <?php echo e($order->shipping_email == null ? $order->customer_email : $order->shipping_email); ?><br>
                Phone: <?php echo e($order->shipping_phone == null ? $order->customer_phone : $order->shipping_phone); ?><br>
                Address: <?php echo e($order->shipping_address == null ? $order->customer_address : $order->shipping_address); ?><br>

                                                                        </address>
                                                                    <?php else: ?>
                                                                        <h5>PickUp Location</h5>
                                                                        <address>
                                                                            Address: <?php echo e($order->pickup_location); ?><br>
                                                                        </address>
                                                                    <?php endif; ?>

                                                                </div>
                                                                <div class="col-md-6">
                                                                    <h5>Delivery Method</h5>
                                                                    <?php if($order->shipping == "shipto"): ?>
                                                                        <p>Delivery To Address</p>
                                                                    <?php else: ?>
                                                                        <p>Pick Up</p>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="billing-add-area">
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <h5>Billing Address</h5>
                                                                    <address>
                                                                        Name: <?php echo e($order->customer_name); ?><br>
                                                                        Email: <?php echo e($order->customer_email); ?><br>
                                                                        Phone: <?php echo e($order->customer_phone); ?><br>
                                                                        Address: <?php echo e($order->customer_address); ?><br>
                                                                        
                                                                    </address>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <h5>
                                                                        Payment Method
                                                                       
                                                                    </h5>
                                                                    <p><?php echo e($order->method); ?></p>

                                                                    <?php if($order->method != "Cash On Delivery"): ?>
                                                                        <?php if($order->method=="Stripe"): ?>
                                                                            <?php echo e($order->method); ?> Charge ID: <p><?php echo e($order->charge_id); ?></p>
                                                                        <?php endif; ?>
                                                                        <?php echo e($order->method); ?> Transaction ID: <p id="ttn"><?php echo e($order->txnid); ?></p> 

                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
<?php endif; ?>
                                                        <br>
                      <div class="table-responsive">
                            <table id="example" class="table">
                                <h4 class="text-center">Products Ordered</h4><hr>
                                <thead>
                                <tr>
                                    <th width="10%">ID#</th>
                                    <th>Product Title</th>
                                    <th width="15%">Variants</th>
                                    <th width="15%">Quantity</th>
                                    <th width="20%">Product Price</th>
                                    <th width="20%">Total Price</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        $subtotal = 0;
                                        $discountedsubtotal = 0;
                                        $tax = 0;
                                        $vat_sum = 0;
                                     ?> 
                                    <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php         
                                    $price = $product['item']['pprice'] ? $product['item']['pprice'] : $product['item']['cprice'];                  
                                    $vat = App\Product::findOrFail($product['item']['id']);
                                    $prod = App\Product::findORFail($product['item']['id']);
                                     ?>

                                        

                                        <tr>
                                            <td><?php echo e($product['item']['id']); ?></td>
                                            <td>
                                                <?php echo e(strlen($product['item']['name']) > 25 ? substr($product['item']['name'],0,25).'...' : $product['item']['name']); ?>

                                                <?php if($vat->vat_status == 1): ?>
                                                    <span style="font-style: italic;">*</span>
                                                <?php endif; ?>
                                                <small style="display: block; color: #777;"><?php echo e($vat->company_name); ?></small>
                                            </td>
                                            <td><?php echo e($vat->sub_title); ?></td>
                                            <td><?php echo e($product['qty']); ?> <?php echo e($product['item']['measure']); ?>

                                                <?php if(App\Product::findOrFail($product['item']['id'])->prices()->where('min_qty','<=',$product['qty'])->exists()): ?>
                                                <?php 
                                                $p = App\Product::findOrFail($product['item']['id'])->prices()->where('min_qty','<=',$product['qty'])->orderBy('min_qty','desc')->first();
                                                $quotient = (int)($product['qty'] / $p->min_qty);
                                                 ?>
                                                <?php if(($quotient * $p->product_free_quantity) != 0): ?>
                                                    <span style="width:70px;">
                                                        + <?php echo e($quotient * $p->product_free_quantity); ?> <?php echo e($p->product_category); ?> Free             
                                                    </span> 
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <small style="display: block; color: #777;">(<?php echo e($prod->product_quantity); ?>)</small>
                                            </td>
                                            <td>
                                                
                                                
                                                <?php echo e($order->currency_sign); ?><?php echo e(round($price * $order->currency_value , 2)); ?>

                                                
                                            </td>
                                            <td>
                                                
                                            
                                                <?php if($gs->sign == 0): ?>
                                                <?php echo e($order->currency_sign); ?><?php echo e(round($price * $product['qty'] * $order->currency_value , 2)); ?>

                                                <?php else: ?>
                                                    <?php echo e(round($price * $product['qty'] * $order->currency_value , 2)); ?><?php echo e($order->currency_sign); ?>

                                                <?php endif; ?>
                                          
                                            </td>

                                        </tr>
                                        <?php 
                                            $subtotal += $product['qty'] * $price;
                                            $discountedsubtotal += $product['price'];
                                         ?>
                                       <?php 
                                       $now = Carbon\Carbon::now()->format('Y/m/d h:i A');
                                           if($order->coupon_code != null){
                                           $coupon_dis = App\Coupon::where('code',$order->coupon_code)->first();
                                           }
                                           if($vat->vat_status == 1){
                                               if($order->coupon_code && $vat->sale_from && $vat->sale_from <= $now && $vat->sale_to >= $now){
                                                 //percentage discount
                                                 if($coupon_dis->type == 0){
                                                   $vat_price = ($vat->cprice * (1 - ($vat->sale_percentage / 100) )) * (1 - ($coupon_dis->price / 100)) * $product['qty'] * $curr->value;
                                                   $vat_sum = $vat_sum + $vat_price;
                                                 }
                                                 //price discount
                                                 elseif($coupon_dis->type == 1){
                                                   $vat_price = ($vat->cprice * (1 - ($vat->sale_percentage / 100) )) - ($coupon_dis->price) * $product['qty'] * $curr->value;
                                                   $vat_sum = $vat_sum + $vat_price;
                                                 }
                                                   // dd($vat_sum);
                                               }
                                               
                                               
                                               elseif($vat->sale_from && $vat->sale_from <= $now && $vat->sale_to >= $now){
                                                   $vat_price = ($vat->cprice * (1 - ($vat->sale_percentage / 100)) ) * $product['qty'] * $curr->value;
                                                   $vat_sum = $vat_sum + $vat_price;
                                                   // dd($vat_sum);
       
                                               }
                                               elseif($order->coupon_code){
                                                   //percentage discount
                                                   if($coupon_dis->type == 0){
                                                     $vat_price = ($vat->cprice * (1 - ($coupon_dis->price / 100) )) * $product['qty'] * $curr->value;
                                                     $vat_sum = $vat_sum + $vat_price;
                                                   }
                                                   //price discount
                                                   elseif($coupon_dis->type == 1){
                                                     $vat_price = ($vat->cprice * (1 - ($vat->sale_percentage / 100) )) - ($coupon_dis->price) * $product['qty'] * $curr->value;
                                                     $vat_sum = $vat_sum + $vat_price;
                                                   }
                                                   //  dd($vat_sum);
                                               }
                                               else{
                                                   $vat_price = ($vat->cprice) * $product['qty'] * $curr->value;
                                                   $vat_sum = $vat_sum + $vat_price;
                                                   // dd($vat_sum);
                                               }
                                           }
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td align="right" colspan="5" style="font-weight:600;border-top:0">
                                            Sub Total :                     
                                        </td>
                                        <td align="left" style="font-weight:600;border-top:0">
                                            <?php echo e($order->currency_sign); ?> <?php echo e(round($subtotal * $order->currency_value , 2)); ?>

                                        </td>
                                    </tr>
                                    <?php if($subtotal > $discountedsubtotal): ?>
                                        <tr>
                                            
                                            
                                            <td align="right" colspan="5" style="font-weight:600;border-top:0">
                                                Price Discount :                       
                                            </td>
                                            <td align="left" style="font-weight:600;border-top:0">
                                                - <?php echo e($order->currency_sign); ?> <?php echo e(round(($subtotal - $discountedsubtotal) * $order->currency_value , 2)); ?>

                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    
                                    <?php if($order->coupon_code != null): ?>
                                        <tr>
                                            
                                            
                                            <td align="right" colspan="5" style="font-weight:600;border-top:0">
                                                Discount Coupon (<?php echo e($order->coupon_code); ?>):                 
                                            </td>
                                            <td align="left" style="font-weight:600;border-top:0">
                                                - <?php echo e($order->currency_sign); ?> <?php echo e($order->coupon_discount * $order->currency_value); ?>

                                            </td>
                                        </tr>
                                    <?php endif; ?>

                                    <?php if($order->discount > 0): ?>
                                        <tr>
                                            
                                            
                                            <td align="right" colspan="5" style="font-weight:600;border-top:0">
                                                Payment Gateway Discount : (<?php echo e($order->method); ?>)                  
                                            </td>
                                            <td align="left" style="font-weight:600;border-top:0">
                                                <?php echo e($order->currency_sign); ?> <?php echo e($order->discount * $order->currency_value); ?>

                                            </td>
                                        </tr>
                                    <?php endif; ?>
                
                                    <?php if($order->shipping_cost != 0): ?>
                                        <tr>
                                            
                                            
                                            <td align="right" colspan="5" style="font-weight:600;border-top:0">
                                                Delivery Fee :              
                                            </td>
                                            <td align="left" style="font-weight:600;border-top:0">
                                                <?php echo e($order->currency_sign); ?> <?php echo e($order->shipping_cost * $order->currency_value); ?>

                                            </td>
                                        </tr>
                                    <?php endif; ?>
                
                                    <?php if($order->tax != 0): ?>
                                        <tr>
                                            
                                            
                                            <td align="right" colspan="5" style="font-weight:600;border-top:0">
                                                VAT (13%) :              
                                            </td>
                                            <td align="left" style="font-weight:600;border-top:0">
                                                <?php echo e($order->currency_sign); ?> <?php echo e($order->tax * $order->currency_value); ?>

                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <tr>
                                        
                                        
                                        <td align="right" colspan="5" style="font-weight:600;border-top:0">
                                           Grand Total :                      
                                        </td>
                                        <td align="left" style="font-weight:600;border-top:0">
                                            <?php echo e($order->currency_sign); ?> <?php echo e(round($order->pay_amount * $order->currency_value , 2)); ?>

                                        </td>
                                    </tr>

                                    <tr>
                                        <th colspan="5" class="text-right"></th>
                                        <th>
                                         
                                        </th>
                                    </tr>
            
                                       <tr id="" style="color:red;">
                                        <th colspan="5" class="text-right g-font-weight-500" style="font-style: italic;font-weight:400;">Taxable Amount :</th>
                                        <th class="g-font-weight-500" style="font-style: italic;font-weight:400;">
                                            &nbsp;&nbsp;<?php echo e($curr->sign); ?><span id=""><?php echo e(round((($vat_sum)/1.13) * $curr->value,2)); ?></span>
                                        </th>
                                    </tr>
            
                                  
            
                                    <?php if($gs->vat != 0): ?>
                                    <tr id="" style="color:red;">
                                        <th colspan="5" class="text-right" style="font-style: italic;font-weight:400;">VAT(<?php echo e($gs->vat); ?>%):</th>
                                        <th style="font-style: italic;font-weight:400;">
                                            &nbsp;&nbsp;<?php echo e($curr->sign); ?><span id=""><?php echo e(round((($vat_sum)/1.13) * 0.13 * $curr->value,2)); ?></span>
                                        </th>
                                    </tr>
                                    <?php endif; ?>
                                </tfoot>
                            </table>
                            <h6 style="font-style:italic; color:red;">* All price subject to inclusive of VAT</h6>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                        </div>
                    </div>
                </div>
                <!-- Ending of Dashboard data-table area -->
            </div>
<!-- ./wrapper -->
<!-- ./wrapper -->

<script type="text/javascript">
setTimeout(function () {
        window.close();
      }, 500);
</script>
</body>
</html>
