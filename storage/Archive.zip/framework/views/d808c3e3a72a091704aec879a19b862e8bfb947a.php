

<?php $__env->startSection('content'); ?>
<div class="right-side">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <!-- Starting of Dashboard area -->
                        <div class="section-padding add-product-1">
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="add-product-box">
                                    <div class="product__header"  style="border-bottom: none;">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title">
                                                    <h2>Update Payment Gateway <a href="<?php echo e(route('admin-payment-index')); ?>" style="padding: 5px 12px;" class="btn add-back-btn"><i class="fa fa-arrow-left"></i> Back</a></h2>
                                                    <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Payment Settings <i class="fa fa-angle-right" style="margin: 0 2px;"></i>  Payment Gateways <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Update
                                                </div>
                                            </div>
                                              <?php echo $__env->make('includes.notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </div>   
                                    </div>
                                        <hr>
                                        <form class="form-horizontal" action="<?php echo e(route('admin-payment-update',$payment->id)); ?>" method="POST">
                                          <?php echo $__env->make('includes.form-error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                          <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                          <?php echo e(csrf_field()); ?>

                                          <div class="form-group">
                                            <label class="control-label col-sm-4" for="blood_group_display_name">Payment Title* <span>(In Any Language)</span></label>
                                            <div class="col-sm-6">
                                              <input class="form-control" name="title" id="blood_group_display_name" placeholder="Enter Payment Title  Name" required="" type="text" value="<?php echo e($payment->title); ?>">
                                            </div>
                                          </div>

                                          <div class="form-group">
                                            <label class="control-label col-sm-4" for="blood_group_slug">Payment Details <span>(In Any Language)</span></label>
                                            <div class="col-sm-6">
                                              <textarea class="form-control" name="text" id="edit_profile_description" rows="10" style="resize: vertical;" placeholder="Enter Payment Description"><?php echo e($payment->text); ?></textarea>
                                            </div>
                                          </div>

                                          <div class="form-group">
                                              <label class="control-label col-sm-4"></label>
                                              <div class="col-sm-6">
                                                <div class="checkbox2">
                                                <input type="checkbox" id="discountCheck" name="discountCheck" <?php echo e($payment->discount_value ? 'checked' :''); ?> value="1"> 
                                                <label for="check11">Add Discount</label>
                                                </div>
                                              </div>          
                                          </div> 
                                          <div id="discountSection"  style="display:<?php echo e($payment->discount_value ? 'block' :'none'); ?>">
                                            <div class="form-group">
                                              <label class="control-label col-sm-4">Discount Type*</label>
                                              <div class="col-sm-6">
                                                <select class="form-control discountCheck" name="discount_type" <?php echo e($payment->discount_type ? 'required' : ''); ?>>
                                                  <option disabled <?php echo e(!$payment->discount_type ? 'selected' : ''); ?> value="">Choose a type</option>
                                                  <option value="0" <?php echo e($payment->discount_type === 0 ? 'selected' : ''); ?>>By Percentage</option>
                                                  <option value="1" <?php echo e($payment->discount_type === 1 ? 'selected' : ''); ?>>By Amount</option>
                                                </select>
                                              </div>
                                            </div>
                                            
                                            <div class="form-group">
                                              <label class="control-label col-sm-4" <?php echo e($payment->discount_value ? 'required' : ''); ?>>Discount Value*</label>
                                              <div class="col-sm-6">
                                                  <input class="form-control discountCheck" name="discount_value" placeholder="Discount Amount/Percentage" type="number" value="<?php echo e($payment->discount_value); ?>" min="1">
                                              </div>
                                            </div>

                                            <div class="form-group">
                                              <label class="control-label col-sm-4">Minimum Purchase Amount <span>(Optional)</span></label>
                                              <div class="col-sm-6">
                                                  <input class="form-control" name="min_purchase_amount" placeholder="Minimum Purchase Amount" type="number" value="<?php echo e($payment->min_purchase_amount); ?>" min="1">
                                                
                                              </div>
                                            </div>
                                          </div>

                                          <hr>
                                          <div class="add-product-footer">
                                              <button name="addProduct_btn" type="submit" class="btn add-product_btn">Submit</button>
                                          </div>
                                        </form>
                                    </div>
                                </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard area --> 
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('assets/admin/js/nicEdit.js')); ?>"></script> 
<script type="text/javascript">
//<![CDATA[
        bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
  //]]>
  $("#discountCheck").change(function() {
      if(this.checked) {
          $("#discountSection").show();
          $('.discountCheck').attr('required','required')
      }
      else
      {
          $("#discountSection").hide();
          $('.discountCheck').removeAttr('required')

      }
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>