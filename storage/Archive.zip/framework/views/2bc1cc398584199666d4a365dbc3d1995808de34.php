
<?php $__env->startSection('title','Reset Password'); ?>
<?php $__env->startSection('content'); ?>
<style>
    .invalid-feedback{
        color: red;
    }
</style>

<div class="section-padding login-area-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1  col-xs-12">
                <div class="signIn-area">
                    <h2 class="signIn-title text-center">Reset Password</h2>
                    <hr>
                    
                    <div class="login-form">
                    <form action="<?php echo e(route('password.update')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="token" value="<?php echo e($token); ?>">

                        <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                            <label for="forgot_email"><?php echo e($lang->fpe); ?> <span>*</span></label>
                            <input class="form-control" placeholder="<?php echo e($lang->fpe); ?>" type="email" name="email" id="forgot_email" value="<?php echo e(old('email')); ?>" required="">

                            <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                            <label><?php echo e($lang->np); ?> <span>*</span></label>
                            <input class="form-control" placeholder="<?php echo e($lang->np); ?>" name="password" required type="password">

                            <?php if($errors->has('password')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                            <label for="forgot_email"><?php echo e($lang->rnp); ?> <span>*</span></label>
                            <input class="form-control" placeholder="<?php echo e($lang->rnp); ?>" type="password" placeholder="Confirm Password" name="password_confirmation" required>

                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-default btn-block"><?php echo e($lang->fpb); ?></button>
                        </div>
                    </form>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>