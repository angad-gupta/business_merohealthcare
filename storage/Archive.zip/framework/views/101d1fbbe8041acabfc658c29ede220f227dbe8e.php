<?php $__env->startSection('body'); ?>

    <p style="font-size: 14px; font-weight: 600; line-height: 24px; color: #333333;">
        Hello <?php echo e($order->customer_name); ?>,
    </p>
    <p>Your order #<b><?php echo e($order->order_number); ?></b> is delivered to <?php echo e($order->customer_address); ?> and delivery received by <?php echo e($order->delivery_received_by); ?> at <?php echo e(date('d M Y h:i A',strtotime($order->delivery_datetime))); ?>.</p>
    <p>Thankyou.</p>
    
        <p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-size:14px;font-family:arial, 'helvetica neue', helvetica, sans-serif;line-height:21px;color:#333333">We are coming very soon on <a target="_blank" href="https://www.apple.com/ios/app-store/" style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial, 'helvetica neue', helvetica, sans-serif;font-size:14px;text-decoration:underline;color:#5B9BD5">iOS</a> and <a target="_blank" style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial, 'helvetica neue', helvetica, sans-serif;font-size:14px;text-decoration:underline;color:#5B9BD5" href="https://play.google.com/store/apps?hl=en">Android</a>.</p>
        <p style="font-size: 14px; font-weight: 600; line-height: 24px; color: #333333;">                              
            Regards,<br>
            MEROHEALTHCARE Team
        </p>
        
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.email', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>