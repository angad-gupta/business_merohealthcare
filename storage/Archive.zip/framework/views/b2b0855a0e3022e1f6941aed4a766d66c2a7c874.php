<?php $__env->startSection('title',$blog->title.' - Blog'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Starting of Section title overlay area -->
    <div class="title-overlay-wrap overlay" style="background-image: url(<?php echo e(asset('assets/images/'.$gs->bgimg)); ?>);">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 text-center">
            <h1><?php echo e($lang->blogss); ?></h1>
          </div>
        </div>
      </div>
    </div>
    <!-- Ending of Section title overlay area -->
<div class="section-padding blog-post-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="section-title">
            <?php if(strlen($blog->title) > 50): ?>
              <?php if($lang->rtl == 1): ?>
              <h1 dir="rtl"><?php echo e($blog->title); ?></h1>
              <?php else: ?>
              <h1><?php echo e($blog->title); ?></h1>
              <?php endif; ?>
            <?php else: ?>
              <?php if($lang->rtl == 1): ?>
              <h1 dir="rtl"><?php echo e($blog->title); ?></h1>
              <?php else: ?>
              <h1><?php echo e($blog->title); ?></h1>
              <?php endif; ?>
            <?php endif; ?>
                            <ul>
                                <li><i class="fa fa-clock-o"></i> <?php echo e($blog->created_at->diffForHumans()); ?></li>
                                <li><?php echo e($lang->bs); ?>: <?php echo e($blog->source); ?></li>
                                <li><i class="fa fa-eye"></i> <?php echo e($blog->views); ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row">
                  <?php if($lang->rtl == 1): ?>
                    <div class="col-md-4">
                       <div class="post-sidebar-area">
                           <h2 class="post-heading" dir="rtl"><?php echo e($lang->blogsss); ?></h2>
                           <ul>
                              <?php $__currentLoopData = $lblogs->where('id','!=',$blog->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lblog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <li>
                                   <div class="row post-row">
                                       <div class="col-xs-8">
                                           <p class="post-meta-date"><?php echo e(date('d M Y',(strtotime($lblog->created_at)))); ?></p>
                                           <a href="<?php echo e(route('front.blogshow',$lblog->slug)); ?>"><?php echo e(strlen($lblog->title) > 30 ? substr($lblog->title,0,30)."..." : $lblog->title); ?></a>
                                       </div>
                                       <div class="col-xs-4">

                                           <img src="<?php echo e(asset('assets/images/'.$lblog->photo)); ?>" alt="">
                                       </div>
                                   </div>
                               </li>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </ul>
                       </div>
                   </div>
                    <div class="col-md-8">
                        <p><img src="<?php echo e(asset('assets/images/'.$blog->photo)); ?>" alt=""></p>
                        <div class="entry-content" dir="<?php echo e($lang->rtl == 1 ? 'rtl':''); ?>">
                          <?php echo $blog->details; ?>

                        </div>

                        <div class="social-sharing a2a_kit a2a_kit_size_32" dir="rtl">
                            <a class="facebook a2a_button_facebook" href=""><i class="fa fa-facebook"></i> Share </a>
                            <a class="twitter a2a_button_twitter" href=""><i class="fa fa-twitter"></i> Tweet</a>
                            <a class="pinterest a2a_button_google_plus" href=""><i class="fa fa-pinterest"></i> Pinterest</a>
                            <a class="a2a_dd" href="https://www.addtoany.com/share" style="position: absolute; background-color: rgb(1, 102, 255); "></a>
                        </div>
                            <script async src="https://static.addtoany.com/menu/page.js"></script>

                        <div dir="rtl" class="blog-comments-msg-area">
                            <h2><?php echo e($lang->contacts); ?></h2>
                            <hr>
                             <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
                            <form action="<?php echo e(route('front.contact.submit')); ?>" method="POST">
                                <input type="hidden" name="to" value="<?php echo e($ps->contact_email); ?>">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="name"><?php echo e($lang->con); ?></label>
                                    <input class="form-control" name="name" placeholder="" required="" type="text">
                                </div>
                                <div class="form-group">
                                    <label for="email"><?php echo e($lang->coe); ?></label>
                                    <input class="form-control" name="email" placeholder="" required="" type="email">
                                </div>
                                <div class="form-group">
                                    <label for="message"><?php echo e($lang->cor); ?></label>
                                    <textarea name="message" class="form-control" id="comments-msg" rows="5" style="resize: vertical;" required=""></textarea>
                                </div>
                                    <div class="row">
                                      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
                                            <span style="cursor: pointer;" class="refresh_code"><i class="fa fa-refresh fa-2x" style="margin-top: 10px;"></i></span>
                                        </div>
                                      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                                            <img id="codeimg" src="<?php echo e(url('assets/images')); ?>/capcha_code.png">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4 col-lg-push-8 col-md-4 col-md-push-8 col-sm-4 col-sm-push-8">

                                            <input class="form-control" name="codes" placeholder="Enter Code" required="" type="text">
                                        </div>
                                    </div>
                                    <br>
                                <div class="form-group">
                                    <button class="btn blog-btn comments" type="submit"><?php echo e($lang->sm); ?></button>
                                </div>
                            </form>
                        </div>  
                        </div>
                  <?php else: ?>
                    <div class="col-md-8">
                        <p><img src="<?php echo e(asset('assets/images/'.$blog->photo)); ?>" alt=""></p>
                        <div class="entry-content" dir="<?php echo e($lang->rtl == 1 ? 'rtl':''); ?>">
                          <?php echo $blog->details; ?>

                        </div>

                        <div class="social-sharing a2a_kit a2a_kit_size_32">
                            <a class="facebook a2a_button_facebook" href=""><i class="fa fa-facebook"></i> Share </a>
                            <a class="twitter a2a_button_twitter" href=""><i class="fa fa-twitter"></i> Tweet</a>
                            <a class="pinterest a2a_button_google_plus" href=""><i class="fa fa-pinterest"></i> Pinterest</a>
                            <a class="a2a_dd" href="https://www.addtoany.com/share" style="position: absolute; background-color: rgb(1, 102, 255); "></a>
                        </div>
                            <script async src="https://static.addtoany.com/menu/page.js"></script> 
                        </div>

                    <div class="col-md-4">
                       <div class="post-sidebar-area">
                           <h2 class="post-heading"><?php echo e($lang->blogsss); ?></h2>
                           <ul style="direction: ltr;">
                              <?php $__currentLoopData = $lblogs->where('id','!=',$blog->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lblog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <li>
                                   <div class="row post-row">
                                       <div class="col-xs-4">

                                           <img src="<?php echo e(asset('assets/images/'.$lblog->photo)); ?>" alt="">
                                       </div>
                                       <div class="col-xs-8">
                                           <p class="post-meta-date"><?php echo e(date('d M Y',(strtotime($lblog->created_at)))); ?></p>
                                           <a href="<?php echo e(route('front.blogshow',$lblog->slug)); ?>"><?php echo e(strlen($lblog->title) > 30 ? substr($lblog->title,0,30)."..." : $lblog->title); ?></a>
                                       </div>
                                   </div>
                               </li>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </ul>
                       </div>
                   </div>
                  <?php endif; ?>

                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>