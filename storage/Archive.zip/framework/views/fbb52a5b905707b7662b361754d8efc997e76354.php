<?php $__env->startSection('title','Lab'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/dzsparallaxer/dzsparallaxer.css">
<link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/dzsparallaxer/dzsscroller/scroller.css">
<link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/dzsparallaxer/advancedscroller/plugin.css">
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" />

<style>

@media(min-width:320px) and (max-width:768px){
  #labsearch{
    display: block !important;
    
  }
  .labsearchdesktop{
    display:none;
  }

  #cities{
    width:100% !important;
    margin-top: 15px !important;
  }
}

#labsearch{
  display: none ;
}

#cities{
  width: 90%;
}

#lab{
  font-weight: 700 !important;
  color:#2385aa !important; 

}

  .u-shadow-v21 {
      box-shadow: 0 5px 7px -1px rgba(0, 0, 0, 0.2);
      transition-property: all;
      transition-timing-function: ease;
      transition-delay: 0s;
  }

  .select2-container--default.select2-container--focus .select2-selection--multiple {
    border: 0px;
    outline: 0;
}

.select2-container--default .select2-selection--multiple {
    background-color: white;
    border: 1px solid #aaa;
    border-radius: 0px;
    cursor: text;
}

.select2-container--default .select2-search--inline .select2-search__field {
    background: transparent;
    border: none;
    outline: 0;
    box-shadow: none;
    -webkit-appearance: textfield;
    height: 2.3rem;

   
}
@media (min-width:320px) and (max-width:768px){
#comparecity{
      margin-top:20px;
    }
}
</style>

  <section class="dzsparallaxer auto-init height-is-based-on-content use-loading mode-scroll dzsprx-readyall loaded" data-options="{direction: 'reverse', settings_mode_oneelement_max_offset: '150'}">
    <div class="divimage dzsparallaxer--target w-100 u-bg-overlay g-bg-bluegray-opacity-0_5--after" style="height: 130%; background-image: url('/medimage/lb2.jpg'); transform: translate3d(0px, -47.0242px, 0px);"></div>

    <!-- Promo Block Content -->
    <div class="container u-bg-overlay__inner text-center g-py-70">
      
      <h2 class="h1 g-color-white g-font-weight-600 text-uppercase g-mb-30">Mero Health Lab</h2>

      <!-- Search Form -->
      <form action="/lab/tests/search" method="GET">
         
        <!-- Search Field -->
        <div class="mx-auto g-mb-20">
          
          

          <div class="mx-auto g-mb-20">
            
              <div class="row">
                <div class="col-md-6 col-sm-12">
                  
                <select class="form-control selectTests" multiple="multiple" style="height:15px;">
                    <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($test->id); ?>"><?php echo e($test->name); ?></option>
    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </select>
                
              </div>
              <div class="col-md-6 col-sm-12" style="display:inline-flex;">
                <input id="cities" list="allcities" id="comparecity" type="text" class="form-control g-font-size-16" style="height:3rem; border-radius:0px;" placeholder="Search location" aria-label="Search by location" autocomplete="off" required="">
                <button class="btn btn-primary text-center labsearchdesktop" type="button" id="addTests" class="btn" style="padding: 10px 10px; width:10%;"><i class="fa fa-search"></i> </button>
                <datalist id="allcities">
            
                  <?php echo $__env->make('includes.cities', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              </datalist>
              </div>
              </div>

              
              <div id="labsearch" class="text-center" style="margin-top: 15px;">
              <button class="btn btn-primary btn-block text-center" type="button" id="addTests" class="btn" style="padding: 10px 100px; "><i class="fa fa-search"></i> Search</button>                          
              </div>

              <div class="container text-center" style="margin-top:50px;">
                <a class="btn btn-primary " style="border-radius:0px; cursor: pointer; backgound-color:2385aa; color:white;" data-toggle="modal" data-target="#vendorloginModal"> <i class="fa fa-user-md" aria-hidden="true"></i> Vendor Login</a>
            </div>
             

              
          
        </div>

   
              
              

        <!-- End Search Field -->

        <!-- Checkboxes -->
        
        <!-- End Checkboxes -->
      </form>
      <!-- End Search Form -->
    </div>
    <!-- End Promo Block Content -->
  </section>
  
  <div class="container g-mt-20">
    
   

    <div id="compareList" style="min-height:100px">
            
    </div>

</div>


 
  <div class="container g-mt-20">
    

      
      
      <div class="text-center">
        <h2>Categories:</h2>
      </div>
      <div class="g-mx-minus-15">
          <div class="row">
            <?php $__currentLoopData = $labcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-md-6 col-lg-3 g-pt-20 g-mb-30">
              <!-- Article -->
              <article class="u-block-hover u-block-hover--uncroped text-center">
                <!-- Article Image -->
              <a class="d-block u-block-hover__additional--jump g-mb-10" href="/lab/category/<?php echo e($c->cat_slug); ?>">
                <img  style="height:6rem;" src="/assets/images/<?php echo e($c->photo); ?>" alt="Image Description">
                </a>
                <!-- End Article Image -->
          
                <!-- Article Info -->
                <em class="d-block g-color-gray-dark-v5 g-font-style-normal g-font-size-12 g-mb-0">(<?php echo e($c->products->count()); ?> tests)</em>
                <h3 class="h5">
                  <a class="g-color-main g-color-primary--hover g-text-underline--none--hover" href="/lab/category/<?php echo e($c->cat_slug); ?>"><?php echo e($c->cat_name); ?></a>
                </h3>
                <!-- End Article Info -->
              </article>
              <!-- End Article -->
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          </div>
         
      </div>

      <?php if($packages->count() > 0): ?>
        <div class="text-center">
          <h2>Packages:</h2>
        </div>
        <div class="g-mx-minus-15">
          <div class="row">
            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <div class="col-lg-4 g-mb-30">
                  <!-- Article -->
                  <article class="u-shadow-v21 g-bg-white rounded">
                    <div class="g-pa-30">
                        <h3 class="g-font-weight-300 g-mb-15">
                        <a class="u-link-v5 g-color-main g-color-primary--hover" id="test-vendor-<?php echo e($product->id); ?>" href="#"><?php echo e($product->vendor->name); ?></a>
                        </h3>
                        <p style="font-size: 1.25rem;" id="test-name-<?php echo e($product->id); ?>"><?php echo e($product->type->name); ?></p>
                        <p style="font-size: 1.25rem;">Price: Rs. <?php echo e($product->cprice); ?></p>

                    </div>
                    <div style="display: none" id="test-details-<?php echo e($product->id); ?>">
                      <?php echo $product->type->description; ?>

                    </div>
                
                    <div class=" g-font-size-12 g-brd-top g-brd-gray-light-v4 g-pa-15-30">
                      <input type="hidden" value="<?php echo e($product->id); ?>" />

                      <button class="btn btn-md u-btn-primary g-font-weight-600 g-font-size-11 text-uppercase g-py-10 addTest">
                          <i class="g-mr-5 fa fa-heart"></i>
                          Book Now
                      </button>
                      <button class="btn btn-md u-btn-orange pull-right g-font-weight-600 g-font-size-11 text-uppercase g-py-10 viewDetails">
                          <i class="g-mr-5 fa fa-eye"></i>
                          View Details
                      </button>
                    </div>
                  </article>
                  <!-- End Article -->
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      <?php endif; ?>


  </div>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script src="/frontend-assets/main-assets/assets/vendor/dzsparallaxer/dzsparallaxer.js"></script>
<script src="/frontend-assets/main-assets/assets/vendor/dzsparallaxer/dzsscroller/scroller.js"></script>
<script src="/frontend-assets/main-assets/assets/vendor/dzsparallaxer/advancedscroller/plugin.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>

<script >
    $(document).ready(function () {
    
      // initialization of carousel
      $.HSCore.components.HSCarousel.init('.js-carousel');

      $(document).on("click", ".viewDetails" , function(){
          var pid = $(this).parent().find('input[type=hidden]').val();

          var html = '<div class="row" style="padding: 10px;">'+
                      '  <div class="col-md-12 col-sm-12">'+
                      '    <div class="product-review-details-description">'+
                      '      <h3>'+$('#test-name-'+pid).html()+'</h3>'+
                      '      <h5 class="modal-product-review">'+$('#test-vendor-'+pid).html()+'</h5>'+
                      '      <div class="product-review-description">'+
                      '        <p style="text-align:justify;">'+$('#test-details-'+pid).html()+'</p>'+
                      '      </div>'+
                      '    </div>'+
                      '  </div>'+
                      '</div>'
          $("#myModal .modal-content").html(html);
          $("#myModal").modal('show');
              
      });
    });
  </script>
<script>
  $(document).on("click", ".addTest" , function(){
      var pid = $(this).parent().find('input[type=hidden]').val();
      var button = $(this);
      button.attr('disabled','disabled');

      $.ajax({
          type: "POST",
          url:"<?php echo e(URL::to('/lab/json/addcart')); ?>",
          data:{ test_id: pid, reset_cart: true, _token: '<?php echo e(csrf_token()); ?>' },
          success:function(data){
            if(data == 0)
            {
                $.notify("<?php echo e($gs->cart_error); ?>","error");
            }
            else
            {
              location.href = "<?php echo e(route('lab.cart')); ?>";
            }
          },
          error: function(data){
            button.removeAttr('disabled');

            $.notify("Something went wrong.","error");
          }
      }); 
      return false;
  });

</script>

<script >
  $(document).ready(function () {
      var selected = [];
      // initialization of carousel
      $.HSCore.components.HSCarousel.init('.js-carousel');

      $('.selectTests').select2({
          width: '100%',
          placeholder: 'Select Tests'
      });


      $(document).on("click", "#addTests" , function(){
          selected = $('.selectTests').select2('val');
          if(selected.length == 0){
              $.notify("Select a test first","error");
              return;
          }

          var city = $('#comparecity').val();

          $('#addTests').attr('disabled','disabled');

          $.ajax({
              type: "POST",
              url:"<?php echo e(URL::to('/lab/json/compare')); ?>",
              data:{test_ids: selected, city: city, _token: '<?php echo e(csrf_token()); ?>'},
              success:function(data){
                  $('#addTests').removeAttr('disabled');

                  console.log(data)
                  $('#compareList').html(data);
                  
              },
              error: function(data){
                  $('#addTests').removeAttr('disabled');

                  if(data.status == 422 && data.responseJSON.error)
                      $.notify(data.responseJSON.error,"error");
                  else
                      $.notify("Something went wrong.","error");
              }
          }); 
          return false;
      });

      $(document).on("click", ".addTestsCart" , function(){
          var btn = $(this);

          if(selected.length == 0){
              $.notify("Select a test first","error");
              return;
          }

          var vendor_id =  $(this).parent().find('input[type=hidden]').val();

          btn.attr('disabled','disabled');

          $.ajax({
              type: "POST",
              url:"<?php echo e(URL::to('/lab/json/addpackage')); ?>",
              data:{ vendor_id: vendor_id, test_ids: selected, _token: '<?php echo e(csrf_token()); ?>'},
              success:function(data){
                  location.href = "<?php echo e(route('lab.cart')); ?>";

              },
              error: function(data){
                  btn.removeAttr('disabled');

                  if(data.status == 422 && data.responseJSON.error)
                      $.notify(data.responseJSON.error,"error");
                  else
                      $.notify("Something went wrong.","error");
              }
          }); 
          return false;
      });
  });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>