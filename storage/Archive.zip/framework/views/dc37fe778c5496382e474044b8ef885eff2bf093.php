      <?php 
        $order_notff = App\Notification::where('order_id','!=',null)->where('vendor_id',null)->orderBy('id','desc')->get();
        if($order_notff->count() > 0){
          foreach($order_notff as $notf){
            $notf->is_read = 1;
            $notf->update();
          }
        }
       ?>   

<link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-line/css/simple-line-icons.css">
<link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-etlinefont/style.css">
<link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-line-pro/style.css">
<link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-hs/style.css">

                  <div class="profile-notifi-title">
                      <h5>New Orders.</h5>
                      <?php if($order_notff->count() > 0): ?>
                      <p style="cursor: pointer;" id="order_clear">Clear All</p>
                      <?php endif; ?>
                  </div>

                  
                    <?php if($order_notff->count() > 0): ?>
                      <?php $__currentLoopData = $order_notff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="single-notifi-area" >
                      <div class="notifi-img" style="background-color:#2385aa;">
                          <i class="icon-basket-loaded"></i>
                      </div>
                      <div class="single-notifi-text">
                          <h5><a href="<?php echo e(route('admin-order-show',$notf->order_id)); ?>" style="color: #333;">You Have a new order.</a></h5>
                          <p><?php echo e($notf->created_at->diffForHumans()); ?></p>
                      </div>
                    </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <div class="single-notifi-area">
                    <h5>No New Order(s).</h5>
                  </div>
                    <?php endif; ?>