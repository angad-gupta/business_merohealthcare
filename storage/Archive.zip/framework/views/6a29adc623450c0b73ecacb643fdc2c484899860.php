      <?php 
        $conv_notff = App\Notification::where('conversation_id','!=',null)->orderBy('id','desc')->get();
        if($conv_notff->count() > 0){
          foreach($conv_notff as $notf){
            $notf->is_read = 1;
            $notf->update();
          }
        }
       ?>   

                                                            <div class="profile-notifi-title">
                                                                <h5>New Conversations.</h5>
                                                                <?php if($conv_notff->count() > 0): ?>
                                                                <p  style="cursor: pointer;" id="conv_clear">Clear All</p>
                                                                <?php endif; ?>
                                                            </div>

                                                            <?php if($conv_notff->count() > 0): ?>
                                                            <?php $__currentLoopData = $conv_notff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="single-notifi-area">
                                                               <div class="notifi-img">
                                                                    <i class="fa fa-envelope"></i>
                                                               </div>
                                                               <div class="single-notifi-text">
                                                                   <h5><a href="<?php echo e(route('admin-message-show',$notf->conversation_id)); ?>" style="color: #333;">You Have a New Message.</a></h5>
                                                               </div>
                                                               </div>
                                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php else: ?>
                                                            <div class="single-notifi-area">
                                                            <h5>You Have No New Message.</h5> 
                                                            </div>  
                                                            <?php endif; ?>