<?php $__env->startSection('title','Prescription Invoice - '.$prescription->id); ?>
        
<?php $__env->startSection('content'); ?>
    <style>
        .text-bold-800{
            font-weight: 800;
        }
    </style>
    <?php 
        $items = json_decode($invoice->items,true);
        $total = 0;
     ?>
    <div class="right-side">
        <div class="container-fluid">
            <!-- Starting of Dashboard area -->
            <div class="section-padding add-product-1">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="add-product-box">
                            <div class="product__header">
                                <div class="row reorder-xs">
                                    <div class="col-lg-8 col-md-5 col-sm-5 col-xs-12">
                                        <div class="product-header-title">
                                            <h2>Prescription Invoice
                                                <a href="<?php echo e(route('user-prescriptions.family-filter',$prescription->family_id)); ?>"  class="btn add-newProduct-btn" style="padding: 5px 12px;"  class="print-order-btn">
                                                    <i class="fa fa-arrow-left"></i> Back
                                                </a> 
                                            </h2>
                                            <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Prescriptions <i class="fa fa-angle-right" style="margin: 0 2px;"></i>Invoice</p>
                                        </div>
                                    </div>
                                        <?php echo $__env->make('includes.user-notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </div>   
                            </div>
                            <main style="padding: 15px;">
                                <div class="order-table-wrap">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="table-responsive">
                                                <table class="table">
                                                    <tbody><tr class="tr-head">
                                                        <th class="order-th" width="45%">Order ID</th>
                                                        <th width="10%">:</th>
                                                        <th class="order-th" width="45%"><?php echo e($prescription->id); ?></th>
                                                    </tr>
                                                    <tr>
                                                        <th width="45%">Total Product</th>
                                                        <th width="10%">:</th>
                                                        <td width="45%"><?php echo e(count($items)); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th width="45%">Total Cost</th>
                                                        <th width="10%">:</th>
                                                        <td width="45%"><?php echo e($invoice->currency_sign); ?> <?php echo e(round($invoice->amount * $invoice->currency_value , 2)); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th width="45%">Ordered Date</th>
                                                        <th width="10%">:</th>
                                                        <td width="45%"><?php echo e(date('d-M-Y H:i:s a',strtotime($prescription->created_at))); ?></td>
                                                    </tr>
                                                    
                                                    <tr>
                                                        <th width="45%">Prescription File</th>
                                                        <th width="10%">:</th>
                                                        <td width="45%">
                                                            <?php $__currentLoopData = $prescription->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <a href="<?php echo e(route('user-prescriptions.file',[$prescription->id,$file->file,$file->id])); ?>" target="_blank" title="<?php echo e($file->file); ?>"><i class="fa fa-picture-o" aria-hidden="true" style="font-size:25px;"></i></a>
                                                              <br/>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            
                                                        </td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="table-responsive">
                                                <table class="table">
                                                    <tbody><tr class="tr-head">
                                                        <th class="order-th" width="45%">Billing Address</th>
                                                        <th width="10%"></th>
                                                        <th width="45%"></th>
                                                    </tr>
                                                    <tr>
                                                        <th width="45%">Name</th>
                                                        <th width="10%">:</th>
                                                        <td width="45%"><?php echo e($prescription->name); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th width="45%">Email</th>
                                                        <th width="10%">:</th>
                                                        <td width="45%"><?php echo e($prescription->email); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th width="45%">Phone</th>
                                                        <th width="10%">:</th>
                                                        <td width="45%"><?php echo e($prescription->phone); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th width="45%">Address</th>
                                                        <th width="10%">:</th>
                                                        <td width="45%"><?php echo e($prescription->location); ?></td>
                                                    </tr>
                                                    <?php if($prescription->additional_info): ?>
                                                        <tr>
                                                            <th width="45%">Additional Note</th>
                                                            <th width="10%">:</th>
                                                            <td width="45%"><?php echo e($prescription->additional_info); ?></td>
                                                        </tr>
                                                    <?php endif; ?>
                        
                                                </tbody></table>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                        
                                <br>
                                <table id="example" class="table">
                                    <h4 class="text-center">Products Ordered</h4><hr>
                                    <thead>
                                        <tr>
                                            <th width="5%">#</th>
                                            <th>Product Name</th>
                                            <th>Batch No.(s)</th>
                                            <th>Expiry Date(s)</th>
                                            <th width="8%">Quantity</th>
                                            <th width="10%">Product Price</th>
                                            <th width="10%">Total Price</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td scope="row">
                                                    <?php if($item['id']): ?>
                                                        <a href="<?php echo e(route('front.product',['id1' => $item['id'], str_slug($item['name'],'-')])); ?>" target="_blank"><?php echo e($item['name']); ?></a>
                                                    <?php else: ?>
                                                        <?php echo e($item['name']); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if(isset($item['batch_nos'])): ?>
                                                        <?php $__currentLoopData = explode(",",$item['batch_nos']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php echo e($i); ?><br>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if(isset($item['batch_nos'])): ?>

                                                        <?php $__currentLoopData = explode(",",$item['exp_dates']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php echo e($i); ?><br>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php echo e($item['qty']); ?>

                                                </td>
                                                <td><?php echo e($invoice->currency_sign); ?> <?php echo e(round($item['price'] * $invoice->currency_value , 2)); ?></td>
                                                <td><?php echo e($invoice->currency_sign); ?> <?php echo e(round($item['qty'] * $item['price'] * $invoice->currency_value , 2)); ?></td>
                                            </tr>
                                            <?php 
                                                $total += $item['qty'] * $item['price']; 
                                             ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                                <table class="table">
                                    <tbody>
                                        <tr>
                                            <td width="5%"></td>
                                            <td></td>
                                            <td width="10%"></td>

                                            <td style="width: 20%;text-align: right;" class="text-bold-800">Sub Total</td>
                                            <td width="20%"><span id="subtotal"><?php echo e($invoice->currency_sign); ?> <?php echo e(round($total * $invoice->currency_value , 2)); ?></span></td>
                                        </tr>
                                        
                                        <tr>
                                            <td width="5%" style="border-top: 0"></td>
                                            <td style="border-top: 0"></td>
                                            <td width="10%" style="border-top: 0"></td>

                                            <td style="width: 20%;text-align: right;border-top: 0" class="text-bold-800">Delivery Fee</td>
                                            <td width="20%" style="border-top: 0" class=" text-xs-right"> <?php echo e($invoice->currency_sign); ?> <?php echo e(round($invoice->shipping_cost * $invoice->currency_value , 2)); ?></td>
                                        </tr>
    
                                        <tr>
                                            <td width="5%" style="border-top: 0"></td> 
                                            <td style="border-top: 0"></td>             
                                            <td width="10%" style="border-top: 0"></td>

                                            <td style="width: 20%;text-align: right;border-top: 0" class="text-bold-800">Total</td>
                                            <td width="20%" style="border-top: 0" class="text-bold-800 text-xs-right"><span id="totalAmount"><?php echo e($invoice->currency_sign); ?> <?php echo e(round($invoice->amount * $invoice->currency_value , 2)); ?></span></td>
                                        </tr>
                                    </tbody>
                                </table>

                                <?php if($invoice->note): ?>
                                    <h5>Note:</h5>

                                    <?php echo e($invoice->note); ?>

                                <?php endif; ?>
                            </main>
                
                        </div>
                    </div>
                </div>
            </div>
            <!-- Ending of Dashboard area --> 
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>