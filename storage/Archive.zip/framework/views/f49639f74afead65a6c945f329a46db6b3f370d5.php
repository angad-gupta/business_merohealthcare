
<style>

.u-btn-outline-bluegray.u-btn-hover-v1-4::after, .u-btn-outline-bluegray.u-btn-hover-v1-4:hover::after {
  background-color: #2385aa !important;
}


    
#lab:hover {
    transform:scale(1.1);
   
    color:#2385aa;
    font-weight: 700;
    transition:all 0.3s;
 
}

#promotion:hover {
    transform:scale(1.1);

    color:#2385aa;
    font-weight: 700;
    transition:all 0.2s;
 
 
}

#ask:hover {
    transform:scale(1.1);

    color:#2385aa;
    font-weight: 700;
    transition:all 0.3s;
 
}


.header-menu-wrap li {
    display: inline-block;
    margin-right: 10px !important;
    position: relative;
}

[class*="u-badge"]:not([class*="--top-left"]):not([class*="--bottom-left"]):not([class*="--bottom-right"]) {
    top: 4px;
    right: 0;
    -ms-transform: translate(50%, -50%);
    transform: translate(104%, -17%);
}
    a{
        text-decoration: none !important;
    }

    .header-menu-wrap li {
    display: inline-block;
    margin-right: 20px;
    position: relative;
}

@media  only screen and (max-width: 767px){
.header-middle-right-wrap ul li a i {
    height: 30px;
    width: 30px;
    background: transparent;
    border-radius: 100%;
    line-height: 30px;
    text-align: center;
    color: #fff;
    display: inline-block;
    margin-right: 0;
}





#doctor{
    text-align: center;
}
}

@media  only screen and (max-width: 767px){
.cart-quantity {
    right: 0;
    top: -12px;
    left:34px !important;
}

#categories{
    display:block !important;
}

#navbarmenu{
    text-align:center !important;
}
#business-text{
    display:none;
}
#login-text{
    display:none;
}
}

@media (min-width: 320px) and (max-width: 767px){


    .header-middle-right-wrap li a span {
    display: block;

    }
.header-searched-item-list-wrap {
    right: 20%;
    width: 560%;
    top: 65px;
   
    position: absolute;
    background: red;

  
    top: 65px;
    z-index: 9 !important;
    padding: 10px;
    box-shadow: 0 0 5px #ddd;
    border-bottom: 5px solid #0163d2;
    display: block;

    max-height: 500px;
    overflow: hidden scroll;
}

#lab{
    display:block !important;
}
}





/* ::-webkit-scrollbar {
    width: 0.75em;
    height: 1em
}
::-webkit-scrollbar-button {
    background: #888
}
::-webkit-scrollbar-track-piece {
    background: #ccc
}
::-webkit-scrollbar-thumb {
    background: #aaa
}​ */

@media  only screen and (max-width: 767px){
li.myCart {
    display: inline-block !important;
}


}

@media  only screen and (max-width: 767px){
.cart-quantity1 {
    right: 0;
    top: -11px !important;
    left:22px !important;
}
}

.cart-quantity1 {
    position: absolute;
    left: 30px;
    top: -5px;
    background: #2385aa;
    color: #fff;
    width: auto;
    text-align: center;
    border-radius: 30px;
    display: block;
    line-height: 1;
    padding: 5px;
    font-size: 10px;
}
    .category_nav{
        padding:1rem;
        
    }
    .header-menu-wrap li a.active {
    color: black;
}
.header-menu-wrap ul {
    padding-top: 28px;
}

@media  only screen and (max-width: 991px) and (min-width: 768px){
.header-menu-wrap ul {
    padding-top: 20px;
}
}
.header-search-box {
    margin-top: 19px;
}

.header-middle-right-wrap li a {
     border-color: transparent !important; 
    color: #0163d2;
    font-weight: 700;
    font-size: 12px;
    display: inline-block;
}


    </style>


<style>
 
    
    .overlay {
      height: 100%;
      width: 0;
      position: fixed;
      z-index: 1;
      top: 0;
      left: 0;
      background-color: rgb(0,0,0);
      background-color: rgba(0,0,0, 0.9);
      overflow-x: hidden;
      transition: 0.5s;
    }
    
    .overlay-content {
      position: relative;
      top: 25%;
      width: 100%;
      text-align: center;
      margin-top: 30px;
    }
    
    .overlay a {
      padding: 8px;
      text-decoration: none;
      font-size: 36px;
      color: #818181;
      display: block;
      transition: 0.3s;
    }
    
    .overlay a:hover, .overlay a:focus {
      color: #f1f1f1;
    }
    
    .overlay .closebtn {
      position: absolute;
      top: 20px;
      right: 45px;
      font-size: 60px;
    }
    
    @media  screen and (max-height: 450px) {
      .overlay a {font-size: 20px}
      .overlay .closebtn {
      font-size: 40px;
      top: 15px;
      right: 35px;
      }
    }
    </style>

    
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
    <?php if($gs->is_loader == 1): ?>
    <div id="cover"></div>
    <?php endif; ?>
<?php if($gs->is_subscribe == 1): ?>
<?php if(isset($visited)): ?>
    <div style="display:none">
        <img src="<?php echo e(asset('assets/images/'.$gs->subscribe_image)); ?>">
    </div>
    <!--  Starting of subscribe-pre-loader Area   -->
    <div class="subscribe-preloader-wrap" id="subscriptionForm" style="display: none;">
        <div class="subscribePreloader__thumb" style="background-image: url(<?php echo e(asset('assets/images/'.$gs->subscribe_image)); ?>);">
            <span class="preload-close"><i class="fa fa-close"></i></span>
            <div class="subscribePreloader__text text-center">
                <h1><?php echo e($gs->subscribe_title); ?></h1>
                <p><?php echo e($gs->subscribe_text); ?></p>
                <form action="<?php echo e(route('front.subscribe.submit')); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <input type="email" name="email" id="" placeholder="<?php echo e($lang->supl); ?>" required="">
                        <button type="submit"><?php echo e($lang->s); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--  Ending of subscribe-pre-loader Area   -->

<?php endif; ?>
<?php endif; ?>
    <!--  Starting of header area   -->
    
                

                    

                
                
            </div>
            <div class="header-middle-area">
                <div class="container">
                    <h3 style="color:red;">This site is in testing phase the products may contains dummies.*</h3>
                    <div class="row">

                    

                    

                    <style>
                        @media  only screen and (max-width: 767px) {

                            #logodiv{
                                text-align:center !important;
                            }

                            #logoimg{
                                height:10rem !important;
                                width: 20rem !important;
                            }
                        }

                    </style>
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="header-middle-left-wrap">
                                <div id="logodiv" class="logo">
                                    <a href="<?php echo e(route('front.index')); ?>">
                                        <img id="logoimg" src="<?php echo e(asset('assets/images/'.$gs->logo)); ?>" style="height:4.5rem" alt="Logo">
                                    </a>
                                    

                                </div>
                            </div>
                        </div>

                        <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                            <div id="navbarmenu" class="header-middle-right-wrap text-right">
                                <ul>

                                  
                                <li class="">
                                <?php if(Auth::guard('user')->check()): ?>
                                <a href="<?php echo e(route('user-wishlists')); ?>" href="javascript:;" style="color: #2385aa; background:transparent; "><i class="icon-heart" style="font-size:20px;background:transparent; color: #2385aa; "></i> 

                                    <?php if($wishlist == 0): ?>
                                     <span class="cart-quantity1" style="top:-11px; left:25px; color: #2385aa; background:transparent; font-weight:400;"> </span>
                                    <?php else: ?>
                                    <span class="cart-quantity1" style="top:-11px; left:25px; color: #2385aa; background:transparent;font-weight:400; "><?php echo e($wishlist); ?></span>

                                    <?php endif; ?>
                                    </a>
                                <?php else: ?>
                                    <a style="cursor: pointer; color: #2385aa; " class="no-wish" href="javascript:;" data-toggle="modal" data-target="#loginModal"><i class="icon-heart" style="font-size:20px; color:#2385aa !important; background:transparent;"></i> <span> </span></a>
                                <?php endif; ?>
                                </li>
                                    




                                    <li class="myCart"><a href="javascript:void(0)"> <i class="icon-finance-100 u-line-icon-pro" style="font-size:20px; color: #2385aa; background:transparent;"></i></a> <span class="cart-quantity" style="left:25px; color: #2385aa; background:transparent;"><?php echo e(Session::has('cart') ? count(Session::get('cart')->items) : ' '); ?></span>
                                        <div class="addToMycart" style="left:-60px;">
                                            <div class="cart">
                                            <?php if(Session::has('cart')): ?>
                                            <?php $__currentLoopData = Session::get('cart')->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="single-myCart">
                                                <p class="cart-close" onclick="remove(<?php echo e($product['item']['id']); ?>)"><i class="fa fa-close"></i></p>
                                                <div class="cart-img">
                                                    <img src="<?php echo e(asset('assets/images/'.$product['item']['photo'])); ?>" alt="Product image">
                                                </div>
                                                <div class="cart-info">
                                                    <a href="<?php echo e(route('front.product',[$product['item']['id'],str_slug($product['item']['name'],'-')])); ?>" style="color: black; padding: 0 0;"><h5><?php echo e(strlen($product['item']['name']) > 45 ? substr($product['item']['name'],0,45).'...' : $product['item']['name']); ?></h5></a>
                                                <p><?php echo e($lang->cquantity); ?>: <span id="cqt<?php echo e($product['item']['id']); ?>"><?php echo e($product['qty']); ?></span> <span><?php echo e($product['item']['measure']); ?></span></p>
                                                <p>
                                                <?php if($gs->sign == 0): ?>
                                                    <?php echo e($curr->sign); ?><span id="prct<?php echo e($product['item']['id']); ?>"><?php echo e(round($product['price'] * $curr->value , 2)); ?></span>
                                                <?php else: ?>
                                                    <span id="prct<?php echo e($product['item']['id']); ?>"><?php echo e(round($product['price'] * $curr->value , 2)); ?></span><?php echo e($curr->sign); ?>

                                                <?php endif; ?>
                                                </p>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>                                            
                                            </div>
                                            <h5 class="empty"><?php echo e(Session::has('cart') ? '' :$lang->h); ?></h5>
                                            <hr/>
                                            <h4 class="text-right"><?php echo e($lang->vt); ?>

                                            <?php if($gs->sign == 0): ?>                                                   
                                             <?php echo e($curr->sign); ?><span class="total"><?php echo e(Session::has('cart') ? round(Session::get('cart')->totalPrice * $curr->value , 2) : '0.00'); ?></span>
                                            <?php else: ?>
                                             <span class="total"><?php echo e(Session::has('cart') ? round(Session::get('cart')->totalPrice * $curr->value , 2) : '0.00'); ?></span><?php echo e($curr->sign); ?>

                                            <?php endif; ?>
                                         </h4>
                                            <div class="addMyCart-btns">
                                                <a href="<?php echo e(route('front.cart')); ?>" class="black-btn"><?php echo e($lang->vdn); ?></a>
                                                <a href="<?php echo e(route('front.checkout')); ?>" class="black-btn"><?php echo e($lang->gt); ?></a>
                                            </div>
                                        </div>
                                    </li>
                                    
                                    

                                    
                                    <li class="mobile-search"><a href="javascript:void(0)" onclick="openNav()"><i class="g-pos-rel g-top-3 icon-education-045 u-line-icon-pro" style="background: transparent;
                                        color: #2385aa;
                                        font-size: 20px;"></i></a>
                                        
                                    </li>
                                    
                                   
                                    <li>


                                    <?php if($gs->reg_vendor == 1): ?>
                                    
                                        <li class="">
                                            <?php if(Auth::guard('user')->check()): ?>
                                            
                                            <?php else: ?>
                                            

                                             <a class="" style="color: #2385aa;border-radius: 0px;border-color: #2385aa;font-weight: 500;font-size: 14px;" href="https://www.pngitem.com/pimgs/m/270-2708193_website-under-construction-png-logo-png-download-website.png" target="__blank">
                                                
                                                <i class="icon-briefcase" style="font-size: 20px; background:transparent; color:#2385aa;"></i> <span id="business-text">Business</span>
                                            </a>
                                            <?php endif; ?>
                                        </li>

                                        
                                    <?php endif; ?>
                                    
                                    
                                        <li>
                                        <?php if(Auth::guard('user')->check()): ?>
                                            <a class="" style="color: #2385aa;border-radius: 0px;border-color: #2385aa;font-weight: 500;font-size: 14px;" href="<?php echo e(route('user-dashboard')); ?>">
                                                 <span><i class="icon-user" style="font-size:20px; background:transparent; color:#2385aa;"></i> <?php echo e(Auth::guard('user')->user()->name); ?></span>
                                            </a>

                                            <a class="" href="<?php echo e(route('user-logout')); ?>" style="padding: .375rem .75rem;border-radius: 0px;border-color: #2385aa;font-weight: 500;font-size: 14px; color:#2385aa;" onclick="event.preventDefault();document.getElementById('logout-form').submit();" ><i class="icon-logout" style="font-size:20px;background:transparent; color:#2385aa; "></i> Logout</a>
                                            <form id="logout-form" action="<?php echo e(route('user-logout')); ?>" method="POST" style="display: none;">
                                                <?php echo e(csrf_field()); ?>

                                            </form>
                                            
                                        <?php else: ?>
                                            <a class="" style="color: #2385aa;border-radius: 0px;border-color: #2385aa;font-weight: 500;font-size: 14px;" href="<?php echo e(route('user-login')); ?>">
                                                
                                                <i class="icon-user" style="font-size:20px; background:transparent; color:#2385aa;"></i> <span id="login-text">Login</span>
                                            </a>
                                        <?php endif; ?>
                                    </li>

                                    
                                   
                                </ul>

                                
                            </div>

                          
                              </div>

                              <div class="modal fade" id="askdoctor" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title" id="exampleModalLabel">Ask a Doctor ?</h5>
                                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                      </button>
                                    </div>
                                    <div class="modal-body">
                                      <div class="row">
                                          <div id="doctor" class="col-md-6 col-sm-12" >
                                              <img src="https://media.istockphoto.com/vectors/doctor-icon-vector-medical-consultation-male-physician-person-avatar-vector-id877515000?k=6&m=877515000&s=170667a&w=0&h=hj2wC9DFC7Ev9_xS5lTS05qevq8Tp-pFFj-vGnv4jOI=" height="200" width="200" />
                                          </div>
                                          <div id="doctor" class="col-md-6 col-sm-12">
                                            <div class="g-bg-white g-py-25">
                                                <div class="g-mb-15">
                                                  <h4 class="h5 g-color-black g-mb-5">Dr. ABC DEF</h4>
                                                  <em class="d-block u-info-v1-2__item g-font-style-normal g-font-size-11 text-uppercase g-color-primary">General Physician</em>
                                                </div>

                                                <ul class="list-unstyled g-color-gray-dark-v8">
                                                    <li class="g-font-size-14">
                                                        <strong>NMC No:</strong> 0000
                                                      </li>

                                                    <li class="g-font-size-14">
                                                      <strong>Email:</strong> something@example.com
                                                    </li>
                                                    
                                                  </ul>
                                             
                                              </div>
                                        </div>
                                      </div>

                                      
                                      <?php if(Auth::guard('user')->user()): ?>
                                      <div class="form-group g-mb-20">
                                          <div class="row">
                                              <div class="col-md-6">
                                                <div class="form-group g-mb-20">
                                                    <label class="g-mb-10" for="inputGroup1_1">Your Email : </label>
                                                    <input id="inputGroup1_1" value="<?php echo e(Auth::guard('user')->user()->email); ?>" class="form-control form-control-md rounded-0" type="email" placeholder="Enter email" required>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group g-mb-20">
                                                    <label class="g-mb-10" for="inputGroup1_1">Phone Number : </label>
                                                    <input id="inputGroup1_1" value="<?php echo e(Auth::guard('user')->user()->phone); ?>" class="form-control form-control-md rounded-0" type="email" placeholder="Enter phone" required>
                                                </div>
                                            </div>

                                          </div>
                                        <label class="g-mb-10" for="inputGroup2_2">What is your question ?</label>
                                        <textarea id="inputGroup2_3" class="form-control form-control-md u-textarea-expandable rounded-0" rows="3" placeholder="Write you queries..." required></textarea>
                                        <small class="form-text text-muted g-font-size-default g-mt-10">
                                              
                                            </small>
                                      </div>
                                      <?php else: ?>

                                      <div class="row">
                                        <div class="col-md-6">
                                          <div class="form-group g-mb-20">
                                              <label class="g-mb-10" for="inputGroup1_1">Your Email : </label>
                                              <input id="inputGroup1_1" value="" class="form-control form-control-md rounded-0" type="email" placeholder="Enter email" required>
                                          </div>
                                      </div>
                                      <div class="col-md-6">
                                          <div class="form-group g-mb-20">
                                              <label class="g-mb-10" for="inputGroup1_1">Phone Number : </label>
                                              <input id="inputGroup1_1" value="" class="form-control form-control-md rounded-0" type="email" placeholder="Enter Phone" required>
                                          </div>
                                      </div>

                                    </div>
                                    <label class="g-mb-10" for="inputGroup2_2">What is your question ?</label>
                                        <textarea id="inputGroup2_3" class="form-control form-control-md u-textarea-expandable rounded-0" rows="3" placeholder="Write you queries..." required></textarea>
                                        <small class="form-text text-muted g-font-size-default g-mt-10">
                                              
                                            </small>
                                      <?php endif; ?>
                                      <h6 class="text-center">Complete privacy and anonymity guaranteed • Quick responses </h6>


                                    </div>
                                    <div class="modal-footer ">
                                        <div class="text-center">
                                      <button type="button" class="btn btn-secondary text-center" data-dismiss="modal">Close</button>
                                      <button type="button" class="btn btn-primary"><i class="icon-cursor"></i> Ask Question Securely</button>
                                        </div>
                                    </div>
                                  </div>
                                </div>
                              </div>

                              <div id="myNav" class="overlay" style="z-index:10000;">
                                <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
                                <div class="overlay-content" >
                                    <div class="form-group container">
                                    <form action="<?php echo e(route('front.search')); ?>" method="GET">
                                    
                                        <input type="text" class="ss form-control" id="" name="product" placeholder="<?php echo e($lang->ec); ?>" required autocomplete="off" style="height:3rem;">
                                        <br/>
                                        <button type="submit" class="btn btn-block btn-primary" style="height:3rem;"><i class="fa fa-search"></i> Search</button>
                                    </form>
                                    
                                    </div>
                     
                                </div>
                        </div>

                              
                    


                        
                    </div>
                </div>
            </div>
        </div>
        <div id="lab" class="header-middle-right-wrap text-right" style="text-align:center !important; padding-top:0px; display:none;">
        <ul>
                               
            
            <li><a href="<?php echo e(route('lab.index')); ?>" style="text-transform: uppercase; color:#2385aa;">Lab Test</a></li>
            

            <li><a href="<?php echo e(route('front.promotions')); ?>" style="text-transform: uppercase; color:#2385aa;" >Promotions</a></li>
            <li><a href="" data-toggle="modal" data-target="#askdoctor" style="text-transform: uppercase; color:#2385aa;" >Ask Doctor <span class="u-badge-v1 g-color-white g-bg-primary" style="font-size:10px;">Free</span></a></li>
        </ul>
        </div>
        
        <div class="header-bottom-area">
            <div class="container">
                <div class="row">
                      
                </div>
                    
                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-5 text-center">
                        

                        
                        

                        <a href="<?php echo e(Auth::guard('user')->check() ? route('user-family.index') : '/upload-prescription'); ?>" style="font-size:14px" class="text-center btn btn-xl u-btn-outline-bluegray u-btn-hover-v1-4 g-letter-spacing-0_5 text-uppercase g-rounded-50 g-px-30 g-mr-10 g-mb-15 g-mt-15">
                            <span class="">
                                <i class="icon-cloud-upload"></i> Upload Prescription
                            </span>
                        </a>
                             
                    </div>
                    <div class="mobileMenuActive"></div>
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-5" style="padding:0px;">
                        <div class="header-menu-wrap">
                            <ul>
                               
                                
                                <li><a id="lab" href="<?php echo e(route('lab.index')); ?>" style="text-transform: uppercase">Lab Test</a></li>
                                

                                <li><a id="promotion" href="<?php echo e(route('front.promotions')); ?>" style="text-transform: uppercase">Promotions</a></li>
                                <li><a href="" id="ask" data-toggle="modal" data-target="#askdoctor" style="text-transform: uppercase; " >Ask Doctor <span class="u-label g-bg-primary u-label--sm ">Free</span></a></li>
                              
                                
                            </ul>
                        </div>

                    </div>

                    <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                        <div class="header-search-box text-right">
                            <form action="<?php echo e(route('front.search')); ?>" method="GET">
                                <input type="text"  style="width:90%;border-radius: 5px" class="ss" id="" name="product" placeholder="<?php echo e($lang->ec); ?>" required autocomplete="off">
                                <button type="submit" style="width:10%;border-top-right-radius: 5px; border-bottom-right-radius: 5px;"><i class="fa fa-search"></i></button>
                            </form>
                        </div>
                        <div class="header-searched-item-list-wrap" style="display: none; z-index:1000">
                            <ul>

                            </ul>
                        </div>
                    </div>
                    <div class="mobileSlickMenuActive"></div>

                    

                

                </div>
            </div>
        </div>
    

    </header>


      

      <script>
      function openNav() {
        document.getElementById("myNav").style.width = "100%";
      }
      
      function closeNav() {
        document.getElementById("myNav").style.width = "0%";
      }
      
      </script>

      
    <?php if(Request::segment(1)!='lab'): ?>
    <header id="js-header" class="u-header u-header--static">
       
        <div class="u-header__section u-header__section--light g-bg-white g-transition-0_3 ">
            <nav class="js-mega-menu navbar navbar-expand-lg hs-menu-initialized hs-menu-horizontal g-pa-0 mb-0 justify-content-center">
            <div class="">
                <h5 id="categories" style="padding-top:10px; color: #2385aa; display:none;
                font-weight: 600;">CATAGORIES</h5>
                <!-- Responsive Toggle Button -->
                <button class="navbar-toggler navbar-toggler-right btn g-line-height-1 g-brd-none g-pa-0 g-pos-abs g-top-minus-3 g-right-0 collapsed" type="button" aria-label="Toggle navigation" aria-expanded="false" aria-controls="navBar" data-toggle="collapse" data-target="#navBar">
                    <span class="hamburger hamburger--slider">
                  <span class="hamburger-box">
                    <span class="hamburger-inner"></span>
                    </span>
                    </span>
                  </button>
                <!-- End Responsive Toggle Button -->
    
                <div style="display:flex;margin:0rem 0rem">
                    <!-- Navigation -->
                    <div class="navbar-collapse align-items-center flex-sm-row g-pt-10 g-pt-5--lg g-mr-40--lg collapse" id="navBar" style="">
                        <ul id="tablet-navbar" class="navbar-nav  g-pos-rel g-font-weight-600 ml-auto">

                     
                               
                            <?php $__currentLoopData = $categories->sortBy('cat_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <li class="nav-item hs-has-sub-menu menu_hover g-px-10">
                                
                            <a id="nav-link--pages--about" class="nav-link g-color-black g-font-weight-400 g-font-size-14" href="#" aria-haspopup="true" aria-expanded="false" aria-controls="nav-submenu--pages--about"><?php echo e($category->cat_name); ?></a>
        
                            <!-- Submenu (level 2) -->
                            <ul class=" <?php echo e(count($category->subs) > 0?'hs-sub-menu':''); ?> list-unstyled g-bg-white u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2 animated" id="nav-submenu--pages--about" aria-labelledby="nav-link--pages--about" style="display: none;">
                                <?php $__currentLoopData = $category->subs()->where('status','=',1)->orderBy('sub_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
                                <li class="<?php echo e(count($subcategory->childs) > 0?'hs-has-sub-menu':''); ?> dropdown-item g-font-weight-600 g-px-10 g-py-7 menu_hover " aria-haspopup="true" aria-expanded="false" aria-controls="nav-submenu--pages--about">
                                <a class="nav-link  g-color-black g-font-weight-400 g-font-size-14" href="<?php echo e(route('front.subcategory',$subcategory->sub_slug)); ?>"><?php echo e($subcategory->sub_name); ?></a>
                                <ul class="hs-sub-menu list-unstyled u-shadow-v11 g-brd-top g-brd-primary g-brd-top-2 g-min-width-220 g-mt-minus-2 animated" id="nav-submenu--pages--about" aria-labelledby="nav-link--pages--about" style="display: none;">
                                        <?php $__currentLoopData = $subcategory->childs()->where('status','=',1)->orderBy('child_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <li class="dropdown-item menu_hover ">
                                        <a class="nav-link g-color-black g-font-weight-400 g-font-size-14" href="<?php echo e(route('front.childcategory',$childcategory->child_slug)); ?>"><?php echo e($childcategory->child_name); ?></a>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    
                            
                                    </ul>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            
                    
                            </ul>
                            <!-- End Submenu (level 2) -->
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>

                    
                        <!-- End Navigation -->
    
            
                </div>
            </div>
            </nav>
        </div>
    </header>
    <?php endif; ?>
            <?php 
            $i=1;
            $j=1;
             ?>