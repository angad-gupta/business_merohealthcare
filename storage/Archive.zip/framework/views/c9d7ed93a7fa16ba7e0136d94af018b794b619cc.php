<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="<?php echo e($seo->meta_keys); ?>">
    <meta name="author" content="GeniusOcean">

    <title><?php echo e($gs->title); ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/print/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/print/font-awesome/css/font-awesome.min.css')); ?>">
    <!-- Ionicons -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/print/Ionicons/css/ionicons.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/print/css/style.css')); ?>">
    <link href="<?php echo e(asset('assets/admin/css/style.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
          <link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/'.$gs->favicon)); ?>"> 
    <style type="text/css">
      @page  { size: auto;  margin: 0mm; }
      @page  {
        size: A4;
        margin: 0;
      }
      @media  print {
        html, body {
          width: 210mm;
          height: 287mm;
        }

        html {
            overflow: scroll;
            overflow-x: hidden;
        }
        ::-webkit-scrollbar {
            width: 0px;  /* remove scrollbar space */
            background: transparent;  /* optional: just make scrollbar invisible */
        }
      }
    </style>
  </head>
  <body onload="window.print();">
    <div class="invoice-wrap">
        <div class="invoice__title">
            <div class="row reorder-xs">
                <div class="col-sm-6">
                    <div class="invoice__logo text-center">
                        <img src="<?php echo e(asset('assets/images/'.$gs->logo)); ?>" alt="Mero Health Care" style="width:175px; height:100px;">
                    </div>
                </div>
                <div class="col-lg-6" style="text-align:right">
                  <?php if($order->payment_status == "paid"): ?>
                      <span class="btn-lg btn-success" style="cursor:default; border-radius:0">Paid</span>
                  <?php else: ?>
                      <span class="btn-lg btn-danger" style="cursor:default; border-radius:0">Unpaid</span> 
                  <?php endif; ?>
                </div>
            </div> 
        </div>
        <br>
        <div class="row">
            <div class="col-sm-12">
                <div class="invoice__metaInfo">
                    <div class="buyer" style="width: 60%;">
                        <p>Billing Address</p>
                        <strong><?php echo e($order->customer_name); ?></strong>
                        <address>
                            <?php echo e($order->customer_address); ?><br>
                            
                            <?php echo e($order->customer_country); ?><br>
                        </address>
                    </div>

                    <div class="invoce__date"  style="width: 20%;">
                      <p><strong>PAN</strong></p>
                        <strong>Invoice ID</strong>
                        <p>Order Date</p>
                        <p>Order ID</p>
                    </div>

                    <div class="invoce__number"  style="width: 20%;">
                      <p><strong>609680496</strong></p>
                        <strong><?php echo e(sprintf("%'.08d", $order->id)); ?></strong>
                        <p><?php echo e(date('d-M-Y',strtotime($order->created_at))); ?></p>
                        <p><?php echo e($order->order_number); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12">
                <div class="invoice__table">
                    <div class="table-responsive">
                      <table class="table table-hover">
                        <thead>
                          <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Line Total</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $subtotal = 0;
                            $discountedsubtotal = 0;
                            $tax = 0;
                             ?>                                   
                            <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td><?php echo e(strlen($product['item']['name']) > 45 ? substr($product['item']['name'],0,45).'...' : $product['item']['name']); ?></td>
                                  <td><?php echo e($order->currency_sign); ?><?php echo e(round($product['item']['cprice'] * $order->currency_value , 2)); ?></td>
                                  <td><?php echo e($product['qty']); ?> <?php echo e($product['item']['measure']); ?></td>
                                  <td><?php echo e($order->currency_sign); ?><?php echo e(round($product['item']['cprice'] * $product['qty'] * $order->currency_value , 2)); ?></td>
                                </tr>
                                <?php 
                                  $subtotal += $product['qty'] * $product['item']['cprice'];
                                  $discountedsubtotal += $product['price'];
                                 ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                          <tr>
                              <td colspan="3">Subtotal</td>
                              <td><?php echo e($order->currency_sign); ?><?php echo e(round($subtotal * $order->currency_value, 2)); ?></td>
                          </tr>
                          <?php if($subtotal > $discountedsubtotal): ?>
                              <td colspan="3">Price Discount</td>
                              <td><?php echo e($order->currency_sign); ?> <?php echo e(round(($subtotal - $discountedsubtotal) * $order->currency_value , 2)); ?></td>
                              
                          <?php endif; ?>
                          <?php if($order->coupon_discount != null): ?>
                            <tr>
                                <td colspan="3">Coupon Discount</td>
                                <td><?php echo e($order->currency_sign); ?> <?php echo e(round($order->coupon_discount * $order->currency_value, 2)); ?></td>
                            </tr>
                          <?php endif; ?>
                          <?php if($order->discount > 0): ?>
                              <tr>
                                  <td colspan="3">Payment Gateway Discount</td>
                                  <td><?php echo e($order->currency_sign); ?> <?php echo e($order->discount * $order->currency_value); ?></td>
                              </tr>
                          <?php endif; ?>
                          <?php if($order->shipping_cost != 0): ?>
                            <tr>
                                <td colspan="3">Delivery Cost</td>
                                <td><?php echo e($order->currency_sign); ?> <?php echo e(round($order->shipping_cost * $order->currency_value , 2)); ?></td>
                            </tr>
                          <?php endif; ?>
                          <?php if($order->tax != 0): ?>
                              <tr>
                                  <td colspan="3">VAT(13%)

                                  </td>
                                  <?php  
                                      $subtotal = $subtotal + $order->shipping_cost;
                                      $tax = ($subtotal / 100) * $order->tax;
                                   ?>
                                  <td><?php echo e($order->currency_sign); ?> <?php echo e(round($tax * $order->currency_value, 2)); ?></td>
                              </tr>
                          <?php endif; ?>
                          
                          <tr>
                              <td colspan="2"></td>
                              <td>Total</td>
                              <td><?php echo e($order->currency_sign); ?><?php echo e(round($order->pay_amount * $order->currency_value , 2)); ?></td>
                          </tr>
                        </tfoot>         
                      </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12">
                <div class="invoice__orderDetails">
                    <p><strong>Order Details</strong></p>
                    <?php if($order->dp == 0): ?>
                      <p>Delivery Method:                                   
                        <?php if($order->shipping == "pickup"): ?>
                            Pick Up
                        <?php else: ?>
                        Deliver To Address
                        <?php endif; ?>
                      </p>
                    <?php endif; ?>
                    <p>Payment Method: <?php echo e($order->method); ?></p>
                    <?php if($order->method != "Cash On Delivery"): ?>
                        
                        <p>Transaction ID: <?php echo e($order->txnid); ?></p>                         
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-6">
                <div class="invoice__shipping">
                <?php if($order->dp == 0): ?>
                    <p style="text-align: left;"><strong>Delivery Address</strong></p>
                    <p style="text-align: left;"><?php echo e($order->shipping_name == null ? $order->customer_name : $order->shipping_name); ?></p>
                    <address>
                        <?php echo e($order->shipping_address == null ? $order->customer_address : $order->shipping_address); ?><br>
                        
                        <?php echo e($order->shipping_country == null ? $order->customer_country : $order->shipping_country); ?><br>
                    </address>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
      setTimeout(function () {
            window.close();
          }, 500);
    </script>
  </body>
</html>
