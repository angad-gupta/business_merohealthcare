<?php $__env->startSection('title','Procceed to Payment'); ?>
<?php $__env->startSection('content'); ?>

<style>
    .box{
        
        padding: 20px;
        display: none;
        margin-top: 20px;
    }
    .Cash{ background: #f7f7f7 }
   
</style>
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>

    
 <!-- Starting of checkOut area -->
    <?php 
        $user = $order->user;
        $cart = unserialize(bzdecompress(utf8_decode($order->cart)));
        $products = $cart->items;
     ?>
    <div>

        <div class="section-padding product-checkOut-wrap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                        <h2 class="signIn-title"><?php echo e($lang->odetails); ?></h2>
                        
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th><?php echo e($user ? 'For Whom' : ''); ?></th>
                                        <th>Price</th>
                                        <th>Qty</th>
                                        <th>Total</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        $priceDiscount = 0;
                                     ?>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                            
                                            $price = $product['item']['pprice'] ? : $product['item']['cprice'];
                                            
                                         ?>
                                        <tr>
                                            <td><a href="<?php echo e(route('front.product',[$product['item']['id'],str_slug($product['item']['name'],'-')])); ?>" target="_blank" title="<?php echo e($product['item']['name']); ?>"><?php echo e($product['item']['name']); ?></a></td>
                                            <?php if($user): ?>
                                                <td><?php echo e($product['family']); ?></td>
                                            <?php else: ?>
                                                <td></td>
                                            <?php endif; ?>
                                            <td><?php echo e($order->currency_sign); ?><?php echo e(round($price * $order->currency_value , 2)); ?></td>
                                            <td><?php echo e($product['qty']); ?>  <?php echo e($product['item']['measure']); ?></td>
                                            <td>&nbsp;
                                                <?php if($gs->sign == 0): ?>
                                                    <?php echo e($order->currency_sign); ?><?php echo e(round($price * $product['qty'] * $order->currency_value , 2)); ?>

                                                <?php else: ?>
                                                    <?php echo e(round($price * $product['qty'] * $order->currency_value , 2)); ?><?php echo e($order->currency_sign); ?>

                                                <?php endif; ?>

                                                <?php 
                                                    $priceDiscount += round($price * $product['qty'] * $order->currency_value , 2) - round($product['price'] * $order->currency_value , 2);
                                                    
                                                 ?>
                                                
                                            </td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                                <tfoot>

                                    <?php if($priceDiscount > 0): ?>
                                        <tr id="">
                                            <th colspan="4">Price Discount:</th>
                                            <th>
                                                <?php if($gs->sign == 0): ?>
                                                    - <?php echo e($order->currency_sign); ?><span><?php echo e($priceDiscount); ?></span>
                                                <?php else: ?>
                                                    - <span><?php echo e($priceDiscount); ?></span><?php echo e($order->currency_sign); ?>

                                                <?php endif; ?>
                                            </th>
                                        </tr>
                                    <?php endif; ?>
                                    
                                    <?php if($order->coupon_code): ?>
                                        <tr id="discount">
                                            <th colspan="4"><?php echo e($lang->ds); ?>(<span id="sign"><?php echo e($order->coupon_code); ?></span>):</th>
                                            <th>
                                                <?php if($gs->sign == 0): ?>
                                                - <?php echo e($order->currency_sign); ?><span id="ds"><?php echo e($order->coupon_discount); ?></span>
                                                <?php else: ?>
                                                - <span id="ds"><?php echo e($order->coupon_discount); ?></span><?php echo e($order->currency_sign); ?>

                                                <?php endif; ?>
                                            </th>
                                        </tr>
                                    <?php endif; ?>

                                    <tr id="gatewaydiscount" style="display: none;">
                                        <th colspan="4">Payment Gateway Discount:</th>
                                        <th>
                                            <?php if($gs->sign == 0): ?>
                                            - <?php echo e($order->currency_sign); ?><span id="gatewayds">0</span>
                                            <?php else: ?>
                                            - <span id="gatewayds">0</span><?php echo e($order->currency_sign); ?>

                                            <?php endif; ?>
                                        </th>
                                    </tr>

                                    <tr id="shipshow">
                                        <th colspan="4"><?php echo e($lang->ship); ?>:</th>
                                        <th>&nbsp;
                                            <?php if($gs->sign == 0): ?>
                                            <?php echo e($order->currency_sign); ?><span id="ship-cost"><?php echo e(round($order->shipping_cost * $order->currency_value,2)); ?></span>
                                            <?php else: ?>
                                            <span id="ship-cost"><?php echo e(round($order->shipping_cost * $order->currency_value,2)); ?></span><?php echo e($order->currency_sign); ?>

                                            <?php endif; ?>
                                        </th>
                                    </tr>
                                    <?php if($order->tax != 0): ?>
                                        <tr id="taxshow">
                                            <th colspan="4"><?php echo e($lang->tax); ?>:</th>
                                            <th>
                                                &nbsp;
                                                <?php if($gs->sign == 0): ?>
                                                    <?php echo e($order->currency_sign); ?><span><?php echo e(round($order->tax * $order->currency_value,2)); ?></span>
                                                <?php else: ?>
                                                    <span><?php echo e(round($order->tax * $order->currency_value,2)); ?></span><?php echo e($order->currency_sign); ?>

                                                <?php endif; ?>
                                            </th>
                                        </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <td colspan="4"><h3><?php echo e($lang->vt); ?>:</h3></td>
                                        <td>
                                            <h3>
                                                <?php if($gs->sign == 0): ?>
                                                    <?php echo e($order->currency_sign); ?><span id="total-cost"><?php echo e(round($order->pay_amount * $order->currency_value ,2)); ?></span>
                                                <?php else: ?>
                                                    <span id="total-cost"><?php echo e(round($order->pay_amount * $order->currency_value,2)); ?></span><?php echo e($order->currency_sign); ?>

                                                <?php endif; ?>
                                            </h3>
                                        </td>
                                    </tr>

                                </tfoot>
                            </table>
                        </div>

                        <hr>

                        <h2 class="signIn-title"><?php echo e($lang->bdetails); ?></h2>
                        <span><?php echo e($order->customer_name); ?></span><br>
                        <span><?php echo e($order->customer_email); ?></span><br>
                        <span><?php echo e($order->customer_phone); ?></span><br>
                        <span><?php echo e($order->customer_landmark); ?></span><br>
                        <span><?php echo e($order->customer_address); ?></span><br>
                        <span><?php echo e($order->customer_city); ?></span><br>
                        <span><?php echo e($order->customer_country); ?></span><br>
                    </div>

                    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                        <div class="">
                            <h2 class="signIn-title">Payment Options</h2>
                            <hr/>

                            
                         
                            
                                
                               
                            <div class="form-group">
                                <label><?php echo e($lang->cup); ?> <span>*</span></label>
                                <select name="method" id="paymentMethod" class="form-control" required="">
                                    <option value="" disabled selected=""><?php echo e($lang->cup); ?></option>
                                    
                                    <?php if($gs->ccheck != 0): ?>
                                        <option value="Cash" discount="0"><?php echo e($lang->dolpl); ?></option>
                                    <?php endif; ?>
                                    <?php $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($gt->title); ?>" discount="<?php echo e($gt->discount); ?>">
                                            <?php echo e($gt->title); ?> <?php echo e($gt->discount > 0 ? '('.$gt->discount_text.')' : ''); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            
                                <div class="Cash box" >
                                     <h4 >Get Discounts on online Payment </h4> 
                                     <br/> 
                                     <img src="https://blog.khalti.com/wp-content/uploads/2019/09/%E0%A4%A0%E0%A5%82%E0%A4%B2%E0%A5%8B-%E0%A4%A6%E0%A4%B6%E0%A5%88%E0%A4%81%E0%A4%95%E0%A5%8B-%E0%A4%A0%E0%A5%82%E0%A4%B2%E0%A5%8B-%E0%A4%A7%E0%A4%AE%E0%A4%BE%E0%A4%95%E0%A4%BE_Order-online-at-thulo.com-and-pay-with-Khalti-and-get-cashback-instantly.jpg" style="height:120px;"/> 
                                     <img src="https://www.agmwebhosting.com/blog/wp-content/uploads/2020/01/Instant-cashback-blog-740x414.png" style="height:120px;"/> 
                                     <img src="https://www.offerayo.com/wp-content/uploads/2019/09/miniso-10_-3-outlets-fonepay.png" style="height:120px;"/> 
                                </div>
                            </div>
                            <div id="gateway" style="display: none;"></div>

                            <div class="text-right">
                                <div class="form-group">
                                    <button class="btn btn-md order-btn" id="pay-btn" type="button" disabled>Pay</button>
                                </div>
                                
                            </div>
                                
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!-- Ending of product shipping form -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://khalti.com/static/khalti-checkout.js"></script>
    
    <script type="text/javascript">
        var total = <?php echo e($order->pay_amount); ?>;
        var id = '<?php echo e($order->order_number); ?>';
        // var discount = option.attr('discount');
        // $('#total-cost').html((total - discount).toFixed(2))
        $("#paymentMethod").on('trigger',function(){
            
            var option = $('option:selected', this);
            var discount = option.attr('discount');
            var gateway = option.val();
    

            $('#pay-btn').attr('disabled','disabled');

            if(discount > 0){

                $("#gatewaydiscount").show("slow");
                $("#gatewayds").text(discount);

            }else{
                $("#gatewaydiscount").hide();

                $("#gatewayds").text(0);                       
            }

            $('#total-cost').html((total - discount).toFixed(2))

            if(gateway == 'Cash'){
                $('#pay-btn').removeAttr('disabled');
                $('#gateway').html('');

                var btn = document.getElementById("pay-btn");
                btn.onclick = function (e) {
                    e.preventDefault();
                    var form = '<form action="/checkout/<?php echo e($order->order_number); ?>/gateway/cod" method="POST"><?php echo e(csrf_field()); ?></form>';
                    $(form).appendTo('body').submit();
                }
                return;
            }
            else if(gateway == 'FonePay'){
                $('#pay-btn').removeAttr('disabled');
                $('#gateway').html('');

                var btn_fonepay = document.getElementById("pay-btn");
                btn_fonepay.onclick = function (e) {
                    e.preventDefault();
                    $('#pay-btn').attr('disabled','disabled');

                    $('#overlay').css('display','block');
                    $.ajax({
                        type: "POST",
                        url:"/checkout/"+id+"/gateway/fonepay",
                        data:{_token: "<?php echo e(csrf_token()); ?>"},
                        success:function(result){
                            location.href = result.url;
                            $('#pay-btn').removeAttr('disabled');
                        },
                        error: function(data){
                            $('#pay-btn').removeAttr('disabled');

                            $.notify("Something went wrong.","error");
                        }
                    });
                }
            }
            else if(gateway == 'IMEPay'){
                $('#pay-btn').removeAttr('disabled');
                $('#gateway').html('');

                var btn_imepay = document.getElementById("pay-btn");
                btn_imepay.onclick = function (e) {
                    e.preventDefault();
                    $('#overlay').css('display','block');
                    $('#pay-btn').attr('disabled','disabled');

                    $.ajax({
                        type: "POST",
                        url:"/checkout/"+id+"/gateway/imepay",
                        data:{_token: "<?php echo e(csrf_token()); ?>"},
                        success:function(result){
                            var html = '<form action="'+result.url+'" method="POST">'+
                                    '  <input type="hidden" name="TokenId" value="'+result.TokenId+'">'+
                                    '  <input type="hidden" name="MerchantCode" value="'+result.MerchantCode+'">'+
                                    '  <input type="hidden" name="RefId" value="'+result.RefId+'">'+
                                    '  <input type="hidden" name="TranAmount" value="'+result.TranAmount+'">'+
                                    '  <input type="hidden" name="Source" value="'+result.Source+'"></input>'+
                                    '</form>';
                            var form = $interpolate(html)($scope);
                        
                            jQuery(form).appendTo('body').submit();
                            $('#pay-btn').removeAttr('disabled');
                        },
                        error: function(data){
                            $('#pay-btn').removeAttr('disabled');

                            $.notify("Something went wrong.","error");
                        }
                    });  
                }
            }
            else if(gateway == 'Khalti'){
                $.ajax({
                    type: "POST",
                    url:"/checkout/"+id+"/gateway/khalti",
                    data:{_token: "<?php echo e(csrf_token()); ?>"},
                    success:function(data){
                        $('#gateway').html(data);
                        $("#gateway").show();
                        $('#pay-btn').removeAttr('disabled');
                    },
                    error: function(data){
                        $('#gateway').html('');
                        $.notify("Something went wrong.","error");
                    }
                });  
            }
            else
                $.notify('Select a valid payment gateway.','error')
        });

        var showErrors=function(response){
            

            if(response.message){
                $.notify(response.message,"error");
            }
            else if(response.error){
                $.notify(response.error,"error");
            }
        }

    </script>

<script>
    $(document).ready(function(){
        $("select").change(function(){
            $(this).find("option:selected").each(function(){
                var optionValue = $(this).attr("value");
                if(optionValue){
                    $(".box").not("." + optionValue).hide();
                    $("." + optionValue).show();
                } else{
                    $(".box").hide();
                }
            });
        }).change();
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>