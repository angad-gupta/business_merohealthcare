<?php $__env->startSection('content'); ?>
    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard area -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="product__header" style="border-bottom: none;">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title">
                                                    <h2>Order Invoice <a href="<?php echo e(url()->previous()); ?>" style="padding: 5px 12px;" class="btn add-back-btn"><i class="fa fa-arrow-left"></i> Back</a></h2>
                                                    <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Orders <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Order Invoice</p>
                                                </div>
                                            </div>
                                            <?php echo $__env->make('includes.notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </div>   
                                    </div>
                                    <main>
                                        <div class="invoice-wrap">
                                            <div class="invoice__title">
                                                <div class="row reorder-xs">
                                                    <div class="col-sm-6">
                                                        <div class="invoice__logo text-left">
                                                            <img src="<?php echo e(asset('assets/images/'.$gs->logo)); ?>" alt="Mero Health Care" style="width:175px; height:100px;">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6" style="text-align:right">
                                                        <?php if($order->payment_status == "paid"): ?>
                                                            <span class="btn-lg btn-success" style="cursor:default; border-radius:0">Paid</span>
                                                        <?php else: ?>
                                                            <span class="btn-lg btn-danger" style="cursor:default; border-radius:0">Unpaid</span> 
                                                        <?php endif; ?>
                                                    </div>
                                                </div> 
                                            </div>
                                            <br>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="invoice__metaInfo">
                                                        <div class="buyer">
                                                            <p>Billing Address</p>
                                                            <strong><?php echo e($order->customer_name); ?></strong>
                                                            <address>
                                                                <?php echo e($order->customer_address); ?><br>
                                                                
                                                                <?php echo e($order->customer_country); ?><br>
                                                            </address>
                                                        </div>

                                                        <div class="invoce__date">
                                                            <strong>Invoice Number</strong>
                                                            <p>Order Date</p>
                                                            <p>Order ID</p>
                                                        </div>

                                                        <div class="invoce__number">
                                                            <strong><?php echo e(sprintf("%'.08d", $order->id)); ?></strong>
                                                            <p><?php echo e(date('d-M-Y',strtotime($order->created_at))); ?></p>
                                                            <p><?php echo e($order->order_number); ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="invoice__table">
                                                        <div class="table-responsive">
                                                            <table class="table table-hover">
                                                                <thead>
                                                                <tr>
                                                                    <th>Product</th>
                                                                    <th>Price</th>
                                                                    <th>Quantity</th>
                                                                    <th>Line Total</th>
                                                                </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php 
                                                                        $subtotal = 0;
                                                                        $discountedsubtotal = 0;
                                                                        $tax = 0;
                                                                     ?>                                   
                                                                    <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <tr>
                                                                            <td><a target="_blank" href="<?php echo e(route('front.product',['id1' => $product['item']['id'], str_slug($product['item']['name'],'-')])); ?>"><?php echo e(strlen($product['item']['name']) > 45 ? substr($product['item']['name'],0,45).'...' : $product['item']['name']); ?></a></td>
                                                                            <td><?php echo e($order->currency_sign); ?><?php echo e(round($product['item']['cprice'] * $order->currency_value , 2)); ?></td>
                                                                            <td><?php echo e($product['qty']); ?> <?php echo e($product['item']['measure']); ?></td>
                                                                            <td><?php echo e($order->currency_sign); ?><?php echo e(round($product['item']['cprice'] * $product['qty'] * $order->currency_value , 2)); ?></td>
                                                                            
                                                                        </tr>
                                                                        <?php 
                                                                            $subtotal += $product['qty'] * $product['item']['cprice'];
                                                                            $discountedsubtotal += $product['price'];
                                                                         ?>

                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </tbody>
                                                                <tfoot>
                                                                    <tr>
                                                                        <td colspan="3">Subtotal</td>
                                                                        <td><?php echo e($order->currency_sign); ?><?php echo e(round($subtotal * $order->currency_value, 2)); ?></td>
                                                                    </tr>
                                                                    <?php if($subtotal > $discountedsubtotal): ?>
                                                                        <td colspan="3">Price Discount</td>
                                                                        <td><?php echo e($order->currency_sign); ?><?php echo e(round(($subtotal - $discountedsubtotal) * $order->currency_value , 2)); ?></td>
                                                                        
                                                                    <?php endif; ?>
                                                                    <?php if($order->coupon_discount != null): ?>
                                                                    <tr>
                                                                        <td colspan="3">Coupon Discount</td>
                                                                        <td><?php echo e($order->currency_sign); ?><?php echo e(round($order->coupon_discount * $order->currency_value, 2)); ?></td>
                                                                    </tr>
                                                                    <?php endif; ?>
                                                                    <?php if($order->discount > 0): ?>
                                                                        <tr>
                                                                            <td colspan="3">Payment Gateway Discount</td>
                                                                            <td><?php echo e($order->currency_sign); ?><?php echo e($order->discount * $order->currency_value); ?></td>
                                                                        </tr>
                                                                    <?php endif; ?>
                                                                    <?php if($order->shipping_cost != 0): ?>
                                                                    <tr>
                                                                        <td colspan="3">Delivery Cost</td>
                                                                        <td><?php echo e($order->currency_sign); ?><?php echo e(round($order->shipping_cost * $order->currency_value , 2)); ?></td>
                                                                    </tr>
                                                                    <?php endif; ?>
                                                                    <?php if($order->tax != 0): ?>
                                                                        <tr>
                                                                            <td colspan="3">TAX</td>
                                                                            <?php  
                                                                                $subtotal = $subtotal + $order->shipping_cost;
                                                                                $tax = ($subtotal / 100) * $order->tax;
                                                                             ?>
                                                                            <td><?php echo e($order->currency_sign); ?><?php echo e(round($tax * $order->currency_value, 2)); ?></td>
                                                                        </tr>
                                                                    <?php endif; ?>
                                                                    
                                                                    <tr>
                                                                        <td colspan="2"></td>
                                                                        <td>Total</td>
                                                                        <td><?php echo e($order->currency_sign); ?><?php echo e(round($order->pay_amount * $order->currency_value , 2)); ?></td>
                                                                    </tr>
                                                                </tfoot>         
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="invoice__orderDetails">
                                                        <p><strong>Order Details</strong></p>
                                                        <?php if($order->dp == 0): ?>

                                                            <p>Delivery Method:
                                                                <?php if($order->shipping == "pickup"): ?>
                                                                    Pick Up
                                                                <?php else: ?>
                                                                Deliver To Address
                                                                <?php endif; ?>
                                                            </p>
                                                        <?php endif; ?>
                                                        <p>Payment Method: <?php echo e($order->method); ?></p>
                                                        <?php if($order->method != "Cash On Delivery"): ?>
                                                            
                                                            <p>Transaction ID: <?php echo e($order->txnid); ?></p>                         
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-sm-6">
                                                <?php if($order->dp == 0): ?>
                                                    <div class="invoice__shipping">
                                                        <p style="text-align: left;"><strong>Delivery Address</strong></p>
                                                        <p style="text-align: left;"><?php echo e($order->shipping_name == null ? $order->customer_name : $order->shipping_name); ?></p>
                                                        <address>
                                                            <?php echo e($order->shipping_address == null ? $order->customer_address : $order->shipping_address); ?><br>
                                                            
                                                            <?php echo e($order->shipping_country == null ? $order->customer_country : $order->shipping_country); ?><br>
                                                        </address>
                                                    </div>
                                                <?php endif; ?>
                                                </div>
                                                <div class="col-sm-6 text-right">
                                                    <a class="btn  add-newProduct-btn print" href="<?php echo e(route('admin-order-print',$order->id)); ?>" target="_blank"><i class="fa fa-print"></i> Print Invoice</a>
                                                </div>
                                            </div>
                                        </div>
                                    </main>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard area --> 
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>