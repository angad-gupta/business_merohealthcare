

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php if(isset($page->meta_tag) && isset($page->meta_description)): ?>
        <meta name="keywords" content="<?php echo e($page->meta_tag); ?>">
        <meta name="description" content="<?php echo e($page->meta_description); ?>"> 
    <?php elseif(isset($blog->meta_tag) && isset($blog->meta_description)): ?>
        <meta name="keywords" content="<?php echo e($blog->meta_tag); ?>">
        <meta name="description" content="<?php echo e($blog->meta_description); ?>"> 
    <?php else: ?>
        <meta name="keywords" content="<?php echo e($seo->meta_keys); ?>">
    <?php endif; ?>
    <meta name="author" content="GeniusOcean">
    <title><?php echo $__env->yieldContent('title','Home'); ?> | <?php echo e($gs->title); ?></title>
    <!-- Font Awesome CSS -->
    <style type="text/css">
    @import  url('https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Rubik:300,400,500,700,900');
    </style>
    <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/all.css')); ?>">
    
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/'.$gs->favicon)); ?>"> 

    <?php echo $__env->make('styles.design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

    <?php echo $__env->yieldContent('styles'); ?>

    <style type="text/css">

        .login-form .form-control, .login-form button {
            height: 40px;
            border-radius: 30px;
        }

        .section-padding {
            padding: 10px 0;
        }
        .home-service-wrapper {
            box-shadow: 0 0 5px #fff;
        }
        .pac-container{
            z-index: 1050 !important;
        }
        .u-nav-v4-1.u-nav-primary .nav-link.active {
            background-color: white;
        }

        #drop-zone {
    width: 100%;
    min-height: 80px !important;
    border: 1px dashed rgba(0, 0, 0, .3);
    border-radius: 5px;
    font-family: Arial;
    text-align: center;
    position: relative;
    font-size: 20px;
    color: #7E7E7E;
}

        
    </style>
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
<link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
 
  <!-- Favicon -->
  <link rel="shortcut icon" href="/frontend-assets/main-assets/favicon.ico">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- CSS Global Compulsory -->
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/bootstrap/bootstrap.min.css">
  <!-- CSS Global Icons -->
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-line/css/simple-line-icons.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-etlinefont/style.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-line-pro/style.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-hs/style.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/slick-carousel/slick/slick.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/hs-megamenu/src/hs.megamenu.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/hamburgers/hamburgers.min.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/animate.css">
  <!-- CSS Unify -->
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/css/unify-core.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/css/unify-components.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/css/unify-globals.css">

  <!-- CSS Customization -->
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/css/custom.css">

  <style>
      .invalid-feedback{
        display:inline;
    }
    </style>
  <?php echo $__env->yieldContent('css'); ?>

  <script type='text/javascript' src='https://platform-api.sharethis.com/js/sharethis.js#property=5e8c318da1c1430012f50dc8&product=inline-share-buttons&cms=sop' async='async'></script>
</head>
