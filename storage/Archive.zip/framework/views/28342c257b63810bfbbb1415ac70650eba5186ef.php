
<?php $__env->startSection('content'); ?>   

<link rel="shortcut icon" href="/frontend-assets/main-assets/favicon.ico">
  <!-- Google Fonts -->
  
  <!-- CSS Global Compulsory -->
  
  <!-- CSS Global Icons -->
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-line/css/simple-line-icons.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-etlinefont/style.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-line-pro/style.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-hs/style.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/slick-carousel/slick/slick.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/hs-megamenu/src/hs.megamenu.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/hamburgers/hamburgers.min.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/animate.css">
  <!-- CSS Unify -->


  <!-- CSS Customization -->


<style>
    
.title-stats {
    position: relative;
    display: block;
    background-color: #303641;
    color: #777;
    padding: 10px 20px 20px;
    margin-bottom: 30px;
    border-radius: 5px;
    transition: .4s;
}

.title-stats .icon {
    color: #2385aa;
    position: absolute;
    right: 5px;
    bottom: 8px;
}
.title-stats:hover {color: #2385aa;}

.title-stats .icon i {
    font-size: 80px;
    line-height: 0;
}

h4{
    width:80%;
}

</style>



        <div class="right-side">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <!-- Starting of Dashboard header items area -->
                        <div class="panel panel-default admin">
                            <div class="panel-heading admin-title">
                                <div class="product__header" style="border-bottom: none;">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-8 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title">
                                                    <h2 style="font-size: 25px;"><?php echo e($lang->user_dashboard); ?> </h2>
                                                </div>
                                            </div>
                                              <?php echo $__env->make('includes.user-notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </div>   
                                    </div></div>
                            <div class="panel-body dashboard-body">
                                <div class="dashboard-header-area">
                                    <div class="row">
                                        <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        

                                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                            <a href="<?php echo e(route('user-orders')); ?>" class="title-stats title-cyan" style="background: transparent;
                                            border: 1px solid;
                                            
                                            border-color: lightgrey;">
                                                <div class="icon"><i class="icon-transport-069 u-line-icon-pro fa-5x"></i></div>
                                                <div class="number"><?php echo e($process); ?> </div>
                                                <h4><?php echo e($lang->order_processing); ?></h4>
                                                
                                            </a>
                                        </div>

                                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                            <a href="<?php echo e(route('user-orders')); ?>" class="title-stats title-green" style="background: transparent;
                                            border: 1px solid;
                                            
                                            border-color: lightgrey;">
                                                <div class="icon"><i class="icon-check fa-5x"></i></div>
                                                <div class="number"><?php echo e($complete); ?></div>
                                                <h4><?php echo e($lang->order_completed); ?></h4>
                                                
                                            </a>
                                        </div>
                                        
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Ending of Dashboard header items area -->


                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>