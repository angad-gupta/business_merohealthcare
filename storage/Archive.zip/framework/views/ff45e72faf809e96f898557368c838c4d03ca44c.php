<?php $__env->startSection('title','Lab Order Details - '.$order->order_number); ?>
        
<?php $__env->startSection('content'); ?>
    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard area -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="product__header" style="border-bottom: none;">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-8 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title">
                                                    <h2>Order Details <a href="<?php echo e(route('user-lab-order-index')); ?>" style="padding: 5px 12px;" class="btn add-back-btn"><i class="fa fa-arrow-left"></i> Back</a> <a href="<?php echo e(route('user-lab-order-invoice',$order->id)); ?>" style="padding: 5px 12px;" class="btn add-back-btn"><i class="fa fa-file"></i> Invoice</a></h2>
                                                    <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i>Lab Orders <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Order Details</p>
                                                </div>
                                            </div>
                                            <?php echo $__env->make('includes.user-notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </div>   
                                    </div>
                                    <main>

                                        <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                        <div class="order-table-wrap">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="table-responsive">
                                                        <table class="table">
                                                            <tbody>
                                                                <tr class="tr-head">
                                                                    <th class="order-th" width="45%">Order ID</th>
                                                                    <th width="10%">:</th>
                                                                    <th class="order-th" width="45%"><?php echo e($order->order_number); ?></th>
                                                                </tr>
                                                                <tr class="tr-head">
                                                                    <th width="45%">Provided By</th>
                                                                    <th width="10%">:</th>
                                                                    <th width="45%">
                                                                        <?php 
                                                                            $vendor = $order->vendor;
                                                                         ?>
                                                                        <?php echo e($vendor ? $vendor->name : '-'); ?> 
                                                                    </th>
                                                                </tr>
                                                                <tr>
                                                                    <th width="45%">Total Tests</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($order->totalQty); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th width="45%">Total Cost</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($order->currency_sign); ?> <?php echo e(round($order->pay_amount * $order->currency_value , 2)); ?></td>
                                                                </tr>
                                                                
                                                                <tr>
                                                                    <th width="45%">Ordered Date</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e(date('d-M-Y H:i:s a',strtotime($order->created_at))); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th width="45%">Payment Method</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($order->method); ?></td>
                                                                </tr>

                                                                <?php if($order->method != "Cash On Delivery"): ?>
                                                                    
                                                                    <tr>
                                                                        <th width="45%"><?php echo e($order->method); ?> Transaction ID</th>
                                                                        <th width="10%">:</th>
                                                                        <td width="45%"><?php echo e($order->txnid); ?></td>
                                                                    </tr>                         
                                                                <?php endif; ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6" style="text-align:right">
                                                    <?php if($order->payment_status == "completed"): ?>
                                                        <span class="btn-lg btn-success" style="cursor:default; border-radius:0">Paid</span>
                                                    <?php else: ?>
                                                        <span class="btn-lg btn-danger" style="cursor:default; border-radius:0">Unpaid</span> 
                                                    <?php endif; ?>
                                                </div>
                                            </div>
        
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="table-responsive">
                                                        <table class="table">
                                                            <tbody>
                                                                <tr class="tr-head">
                                                                    <th class="order-th" width="45%">User Details</th>
                                                                    <th width="10%"></th>
                                                                    <th width="45%"></th>
                                                                </tr>
                                                                <tr>
                                                                    <th width="45%">Name</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($order->customer_name); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th width="45%">Email</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($order->customer_email); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th width="45%">Phone</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($order->customer_phone); ?></td>
                                                                </tr>

                                                                
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="table-responsive">
                                                        <?php 
                                                            $patient = json_decode($order->customer_details);
                                                            
                                                         ?>
                                                        <table class="table">
                                                            <tbody>
                                                                <tr class="tr-head">
                                                                    <th class="order-th" width="45%">Patient Details</th>
                                                                    <th width="10%"></th>
                                                                    <th width="45%"></th>
                                                                </tr>
                                                                <tr>
                                                                    <th width="45%">Name</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($patient->name); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th width="45%">Date of Birth</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($patient->dob); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th width="45%">Gender</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($patient->gender); ?></td>
                                                                </tr>

                                                                <tr>
                                                                    <th width="45%">Address</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($order->customer_address); ?></td>
                                                                </tr>
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                        
                                        <br>
                                        <table id="example" class="table">
                                            <h4 class="text-center">Tests Booked</h4><hr>
                                            <thead>
                                                <tr>
                                                    <th width="10%">#</th>
                                                    <th>Test Name</th>
                                                    <th>Report</th>
                                                    <th>Test Cost</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                    $subtotal = 0;
                                                 ?>
                                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><?php echo e($product->test_name); ?></td>
                                                        
                                                        <td>
                                                            <?php if($product->report_file): ?>
                                                                <a href="<?php echo e(route('user-lab-order-report',[$product->id,$product->report_file])); ?>" target="_blank" title="View <?php echo e($product->report_file); ?>"><i class="fa fa-eye"></i> </a>
                                                                <a href="<?php echo e(route('user-lab-order-report',[$product->id,$product->report_file])); ?>" target="_blank" title="Download <?php echo e($product->report_file); ?>" download><i class="fa fa-download"></i> </a>
                                                            <?php else: ?>
                                                                -
                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?php echo e($order->currency_sign); ?> <?php echo e(round($product->test_price * $order->currency_value , 2)); ?></td>

                                                    </tr>
                                                    <?php 
                                                        $subtotal += $product->test_price;
                                                     ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <td align="right" colspan="3" style="font-weight:800;">
                                                        Sub Total                       
                                                    </td>
                                                    <td align="left" style="font-weight:800;">
                                                        <?php echo e($order->currency_sign); ?> <?php echo e(round($subtotal * $order->currency_value , 2)); ?>

                                                    </td>
                                                </tr>
                                                

                                                <?php if($order->discount > 0): ?>
                                                    <tr>
                                                        
                                                        
                                                        <td align="right" colspan="3" style="font-weight:800;border-top:0">
                                                            Payment Gateway Discount (<?php echo e($order->method); ?>)                  
                                                        </td>
                                                        <td align="left" style="font-weight:800;border-top:0">
                                                            <?php echo e($order->currency_sign); ?> <?php echo e($order->discount * $order->currency_value); ?>

                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                            
                                                <?php if($order->service_charge != 0): ?>
                                                    <tr>
                                                        
                                                        
                                                        <td align="right" colspan="3" style="font-weight:800;border-top:0">
                                                            Service Fee                  
                                                        </td>
                                                        <td align="left" style="font-weight:800;border-top:0">
                                                            <?php echo e($order->currency_sign); ?> <?php echo e($order->service_charge * $order->currency_value); ?>

                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                                <tr>
                                                    
                                                    
                                                    <td align="right" colspan="3" style="font-weight:800;border-top:0">
                                                        Total                       
                                                    </td>
                                                    <td align="left" style="font-weight:800;border-top:0">
                                                        <?php echo e($order->currency_sign); ?> <?php echo e(round($order->pay_amount * $order->currency_value , 2)); ?>

                                                    </td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </main>
                                    <hr>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard area --> 
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript">
        $('#example').dataTable( {
            "ordering": false,
            'paging'      : false,
            'lengthChange': false,
            'searching'   : false,
            'ordering'    : false,
            'info'        : false,
            'autoWidth'   : false,
            'responsive'  : true
        } );
    </script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>