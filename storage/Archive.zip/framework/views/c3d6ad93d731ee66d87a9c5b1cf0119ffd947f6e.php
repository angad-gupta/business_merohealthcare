<style>
.s_item:hover{
    color:#2385aa;
}
</style>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php 
    $product->pprice = $product->pprice ? : $product->cprice;
    $product->cprice = $product->getPrice(1);
     ?>
    <li>
        <a style="text-decoration:none" href="<?php echo e(route('front.product',[$product->id,str_slug($product->name,'-')])); ?>" class="s_item">
            <div class="row">
                <div class="col-md-2">
                    <img src="<?php echo e(asset('/assets/images/'.$product->photo)); ?>" style="height: 70px;width: 70px;" />
                </div>
                <div class="col-md-6">
                    <p class="g-font-size-16 mb-0"><?php echo e($product->name); ?> </p>
                    <p class="g-font-size-16 mb-0"><?php echo e($product->sub_title); ?> </p>

                    <?php if($gs->sign == 0): ?>
                        <h5 class="productDetails-price ">
                            
                            Rs.
                            <?php if($product->user_id != 0): ?>
                                <?php 

                                    $price = $product->cprice + $gs->fixed_commission + ($product->cprice/100) * $gs->percentage_commission ;
                                 ?>
                                <?php echo e(round($price * $curr->value,2)); ?>

                            <?php else: ?>
                                <?php echo e(round($product->cprice * $curr->value,2)); ?>

                            <?php endif; ?>                   
            
                            <?php if($product->pprice != null): ?>
                                <span style="font-size:12px;color:red"><del><?php echo e($curr->sign); ?><?php echo e(round($product->pprice * $curr->value,2)); ?></del></span>
                            <?php endif; ?>
                        </h5>
                    <?php else: ?>
                        <h5 class="productDetails-price">
                            <?php if($product->user_id != 0): ?>
                                <?php 
                                    $price = $product->cprice + $gs->fixed_commission + ($product->cprice/100) * $gs->percentage_commission ;
                                 ?>
                                <?php echo e(round($price * $curr->value,2)); ?>

                            <?php else: ?>
                                <?php echo e(round($product->cprice * $curr->value,2)); ?>

                            <?php endif; ?>                   
                            <?php echo e($curr->sign); ?>

                            <?php if($product->pprice != null): ?>
                                <span><del><?php echo e(round($product->pprice * $curr->value,2)); ?><?php echo e($curr->sign); ?></del></span>
                            <?php endif; ?>  
                        </h5>                 
                    <?php endif; ?>
                </div>
                <div class="col-md-4">
                    <input type="hidden" value="<?php echo e($product->id); ?>">
                    <?php 
                        $qty = $cart->getQty($product->id);
                     ?>
                    <div class="productDetails-quantity">
                        <?php if($qty == 0): ?>
                            <?php if($product->stock == "0"): ?>
                                <button class="btn btn-sm btn-primary" disabled><?php echo e($lang->dni); ?></button>

                            <?php else: ?>
                                <button class="btn btn-sm btn-primary addcartforSearch"><?php echo e($lang->hcs); ?></button>

                            <?php endif; ?>
                        <?php else: ?>
                            <span class="quantity-btn reducingforSearch"><i class="fa fa-minus"></i></span>
                            <span class="qtyforSearch"><?php echo e($qty); ?></span>   
                            <span class="quantity-btn addingforSearch"><i class="fa fa-plus"></i></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </a>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
