<?php $__env->startSection('title','Checkout - Lab'); ?>
<?php $__env->startSection('content'); ?>
<link  rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/animate.css">
                    <link  rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/custombox/custombox.min.css">
<style>
  #lab{
  font-weight: 700 !important;
  color:#2385aa !important; 

}

   .section-padding {
    padding: 20px 0;
}
    .select2-selection__rendered{
    
    height:35px !important;
  }
  .select2-container--default .select2-selection--single .select2-selection__arrow {
    height: 26px;
    position: absolute;
    top: 9px !important;
    right: 1px;
    width: 20px;
}
  .select2-selection__arrow{
    height:35px !important;
  }
  .select2-container .select2-selection--single {
    box-sizing: border-box;
    cursor: pointer;
    display: block;
    height: 35px !important;
    user-select: none;
    -webkit-user-select: none;
}
.section-padding.product-shoppingCart-wrapper .table>tbody>tr>td {
    padding: 10px 0;
    vertical-align: middle;
    color: #555;
    font-size: 16px;
    border: none;
    text-align: left;
}
.section-padding.product-shoppingCart-wrapper .table>thead>tr>th {
    padding: 30px 0px;
    text-align: left;
    color: #333;
}

.section-padding.product-shoppingCart-wrapper .table>thead>tr>th {
    padding: 15px 0px;
    text-align: left;
    color: #333;
}
.product-shoppingCart-wrapper .table>tfoot>tr>td {
    padding: 10px 0;
} 
</style>
<?php if(Session::has('defaultFamily')): ?>
<?php 
        $family=Session::get('defaultFamily');

 ?>

<?php endif; ?>
    <div class="section-padding product-shoppingCart-wrapper">
        <div class="container">
            <div class="row">
              <div class="col-lg-12 g-mb-20">
                <div class="view-cart-title pull-right">
                  <a style="color:black;" href="<?php echo e(route('front.index')); ?>"><?php echo e(ucfirst(strtolower($lang->home))); ?></a>
                  <i class="fa fa-angle-right"></i>
                  <a style="color:black;" href="<?php echo e(route('lab.cart')); ?>">Lab Test</a>
                  <i class="fa fa-angle-right"></i>
                  <a style="color:black;" href="#">Checkout</a>
                </div>
              </div>

              <div class="col-md-12 col-sm-12">
                   
                <label class="d-block g-color-gray-dark-v2 g-font-size-20">Test Details:</label>
                <hr class="g-my-10">
                <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
                <div class="table-responsive">
                    <table class="table " style="width:70%">
                    <thead>
                        <tr>
                        <th colspan="4"><?php echo e($lang->cproduct); ?></th>
                        <th><?php echo e($lang->cupice); ?></th>
                        </tr>
                    </thead>
                    <tbody id="testList">
                        <?php if(Session::has('lab_cart')): ?>
                            <?php echo $__env->make('lab::front.partials.checkout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php else: ?>
                            <tr>
                              <td colspan="9"><h2 class="text-center"><?php echo e($lang->h); ?></h2></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                    <tfoot> 
                        
                        
                    </tfoot>
                    </table>
                    <p class="g-font-size-17 g-mb-20"><b><?php echo e($lang->vt); ?>:</b> 
                      <?php if($gs->sign == 0): ?>
                          <?php echo e($curr->sign); ?><span class="lab-total" id="grandtotal"><?php echo e(round($totalPrice * $curr->value, 2)); ?></span>
                      <?php else: ?>
                          <span class="lab-total" id="grandtotal"><?php echo e(round($totalPrice * $curr->value, 2)); ?></span><?php echo e($curr->sign); ?>

                      <?php endif; ?>
                    </p>
                </div>
                
              </div>
              <div class="col-md-12 g-mb-30">
                    <form action="/lab/confirm" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <label class="d-block g-color-gray-dark-v2 g-font-size-13">This Test is for:</label>
                    
                    <select name="family_id" class="form-control g-mb-20" id="selectFamily" style="width:15%; display:inline-block">
                        <option value="" family-name="<?php echo e(Auth::user()->name); ?>" family-dob="<?php echo e(Auth::user()->dob); ?>" family-gender="<?php echo e(Auth::user()->gender); ?>">Self</option>
                        <?php $__currentLoopData = App\User::findOrFail(Auth::user()->id)->family; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(isset($family)): ?>
                                <option <?php echo e($family->id==$fam->id?'selected':''); ?> value="<?php echo e($fam->id); ?>" family-name="<?php echo e($fam->name); ?>" family-dob="<?php echo e($fam->dob); ?>" family-gender="<?php echo e($fam->gender); ?>"><?php echo e($fam->name); ?> (<?php echo e($fam->relation); ?>)</option>
                            <?php else: ?>
                                <option value="<?php echo e($fam->id); ?>" family-name="<?php echo e($fam->name); ?>" family-dob="<?php echo e($fam->dob); ?>" family-gender="<?php echo e($fam->gender); ?>"><?php echo e($fam->name); ?> (<?php echo e($fam->relation); ?>)</option>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                        
                    </select>
                    <span style="display:inline-block">&nbsp;&nbsp;<a href="#modal1" data-modal-target="#modal1" data-modal-effect="fadein" class="btn btn-primary"><i class="fa fa-plus"></i> Add Family Member</a> </span>
                  
                    <label class="d-block g-color-gray-dark-v2 g-font-size-20">Please fill up the following information</label>
                    <hr class="g-my-10">
                    <label class="d-block g-color-gray-dark-v2 g-font-size-13">Patients Details:</label>
                    <hr class="g-my-10">
                  <div class="row">
                    <div class="col-md-4 g-mb-20">
                      <div class="form-group">
                        <label class="d-block g-color-gray-dark-v2 g-font-size-13">Name</label>
                        <?php if(isset($family)): ?>
                      <input id="name" name="name" value="<?php echo e($family->name); ?>" class="form-control u-form-control g-placeholder-gray-light-v1 rounded-0 g-py-15"  type="text" placeholder="Alexander" required="" data-msg="This field is mandatory" data-error-class="u-has-error-v1" data-success-class="u-has-success-v1" aria-required="true">
                        <?php else: ?>
                      <input id="name" name="name" value="<?php echo e(Auth::user()->name); ?>" class="form-control u-form-control g-placeholder-gray-light-v1 rounded-0 g-py-15"  type="text" placeholder="Alexander" required="" data-msg="This field is mandatory" data-error-class="u-has-error-v1" data-success-class="u-has-success-v1" aria-required="true">

                        <?php endif; ?>
                    </div>
                    </div>

                    <div class="col-md-4 g-mb-20">
                      <div class="form-group">
                        <label class="d-block g-color-gray-dark-v2 g-font-size-13">Date Of Birth</label>
                        <?php if(isset($family)): ?>
                            <input type="date" id="dob" name="dob" <?php echo e($family->dob?'value='.$family->dob:''); ?> class="form-control u-form-control g-placeholder-gray-light-v1 rounded-0 g-py-15"  type="number" min="1" placeholder="Enter Patient's dob" required="" data-msg="This field is mandatory" data-error-class="u-has-error-v1" data-success-class="u-has-success-v1" aria-required="true">

                        <?php else: ?>
                            <input type="date" id="dob" name="dob" <?php echo e(Auth::user()->dob?'value='.Auth::user()->dob:''); ?> class="form-control u-form-control g-placeholder-gray-light-v1 rounded-0 g-py-15"  type="number" min="1" placeholder="Enter Patient's dob" required="" data-msg="This field is mandatory" data-error-class="u-has-error-v1" data-success-class="u-has-success-v1" aria-required="true">
                      
                        <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-4 g-mb-20">
                      <div class="form-group">
                        <label class="d-block g-color-gray-dark-v2 g-font-size-13">Gender</label>
                        
                        <?php if(isset($family)): ?>
                       
                        <select id="gender" name="gender"  class="form-control" required>
                                <option <?php echo e($family->gender=="Male"?'selected':''); ?>>Male</option>
                                <option <?php echo e($family->gender=="Female"?'selected':''); ?>>Female</option>
                                <option <?php echo e($family->gender=="Other"?'selected':''); ?>>Other</option>
    
                        </select>
                        <?php else: ?>
                        <select id="gender" name="gender"  class="form-control" required>
                            <option <?php echo e(Auth::user()->gender=="Male"?'selected':''); ?>>Male</option>
                            <option <?php echo e(Auth::user()->gender=="Female"?'selected':''); ?>>Female</option>
                            <option <?php echo e(Auth::user()->gender=="Other"?'selected':''); ?>>Other</option>

                        </select>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>

                  <label class="d-block g-color-gray-dark-v2 g-font-size-13">User Details:</label>
                  <hr class="g-my-10">
                  <div class="row">
                    <div class="col-sm-6 g-mb-20">
                      <div class="form-group">
                        <label class="d-block g-color-gray-dark-v2 g-font-size-13">Email Address</label>
                      <input readonly value="<?php echo e(Auth::user()->email); ?>"  id="inputGroup6" class="form-control u-form-control g-placeholder-gray-light-v1 rounded-0 g-py-15" name="email" type="email" placeholder="alex@gmail.com" required="" data-msg="This field is mandatory" data-error-class="u-has-error-v1" data-success-class="u-has-success-v1" aria-required="true">
                      </div>
                    </div>

                    <div class="col-sm-6 g-mb-20">
                      <div class="form-group">
                        <label class="d-block g-color-gray-dark-v2 g-font-size-13">Phone Number</label>
                      <input name="phone" value="<?php echo e(Auth::user()->phone); ?>" id="inputGroup7" class="form-control u-form-control g-placeholder-gray-light-v1 rounded-0 g-py-15"  type="text" placeholder="Phone No." required>
                      </div>
                    </div>
                  </div>
                  <label class="d-block g-color-gray-dark-v2 g-font-size-13">Service Address: (We will come to visit you in this address)</label>
                  <hr class="g-my-10">

                  <div class="row">
                    <div class="col-sm-12 g-mb-20">
                      <div class="form-group">
                        <label class="d-block g-color-gray-dark-v2 g-font-size-13">Address</label>
                        <input id="geolocation" name="address" value="<?php echo e(Auth::user()->address); ?>" id="inputGroup8" class="form-control u-form-control g-placeholder-gray-light-v1 rounded-0 g-py-15" type="text" placeholder="Enter your location" required="" data-msg="This field is mandatory" data-error-class="u-has-error-v1" data-success-class="u-has-success-v1" aria-required="true" onclick="$('.locationModal').modal('show');" autocomplete="off">
                        <input id="latlong" type="hidden" name="latlong" value="<?php echo e(Auth::user()->latlong); ?>">
                      </div>
                    </div>
                    

                  </div>

                  <div class="form-group g-mb-20">
                    <label class="g-mb-10" for="inputGroup2_2">Notes</label>
                    <textarea name="note" class="form-control form-control-md u-textarea-expandable rounded-0" rows="3" placeholder="Some Notes..."></textarea>
                    <small class="form-text text-muted g-font-size-default g-mt-10">
                     When is your preffered time to collect samples. <strong> Eg.Collect Sample After 3pm</strong>
                    </small>
                  </div>

               
                  <hr class="g-mt-10 g-mb-20">

                  <button class="btn u-btn-primary g-font-size-13 text-uppercase g-px-40 g-py-15" type="submit" data-next-step="#step3">Confirm Order</button>
                </form>
                </div>
            </div>
        </div>
    </div>
        
    <!-- Demo modal window -->
    <div id="modal1" class="text-left g-bg-white g-overflow-y-auto g-pa-20" style="display: none; max-width:600px!important">
      <button type="button" class="close" onclick="Custombox.modal.close();">
        <i class="hs-icon hs-icon-close"></i>
      </button>
      <h4 class="g-mb-20">Add Family Member</h4>
      <form action="<?php echo e(route('lab.addFamily')); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

            <div class="row">
                    <div class="col-sm-12 g-mb-10">
                      <div class="form-group">
                        <label class="d-block g-color-gray-dark-v2 g-font-size-13">Fist name *</label>
                        <input name="firstname" id="" class="form-control u-form-control g-placeholder-gray-light-v1 rounded-0 g-py-15" type="text" placeholder="First Name: Family/Friend member" required="" data-msg="This field is mandatory" data-error-class="u-has-error-v1" data-success-class="u-has-success-v1" aria-required="true">
                      </div>
                    </div>
                    <div class="col-sm-12 g-mb-10">
                      <div class="form-group">
                        <label class="d-block g-color-gray-dark-v2 g-font-size-13">Middle Name</label>
                        <input name="middlename" id="" class="form-control u-form-control g-placeholder-gray-light-v1 rounded-0 g-py-15" type="text" placeholder="Middle Name : Family/Friend member"  data-msg="This field is mandatory" data-error-class="u-has-error-v1" data-success-class="u-has-success-v1" aria-required="true">
                      </div>
                    </div>
                    <div class="col-sm-12 g-mb-10">
                      <div class="form-group">
                        <label class="d-block g-color-gray-dark-v2 g-font-size-13">Last Name *</label>
                        <input name="lastname" id="" class="form-control u-form-control g-placeholder-gray-light-v1 rounded-0 g-py-15" type="text" placeholder="Last Name : Family/Friend member"  data-msg="This field is mandatory" data-error-class="u-has-error-v1" data-success-class="u-has-success-v1" aria-required="true">
                      </div>
                    </div>

                    

                    <div class="col-sm-12 g-mb-10">
                      <div class="form-group">
                        <label class="d-block g-color-gray-dark-v2 g-font-size-13">Date Of Birth *</label>
                        <input type="date" name="dob" id="" class="form-control u-form-control g-placeholder-gray-light-v1 rounded-0 g-py-15"  min="1" placeholder="Dob" required="" data-msg="This field is mandatory" data-error-class="u-has-error-v1" data-success-class="u-has-success-v1" aria-required="true">
                      </div>
                    </div>


                    <div class="col-sm-12 g-mb-10">
                        <div class="form-group">
                            <label class="d-block g-color-gray-dark-v2 g-font-size-13">Gender *</label>
                            <select id="gender" name="gender" required class="form-control">
                                <option >Male</option>
                                <option >Female</option>
                                <option >Other</option>
    
                            </select>
                        </div>
                    </div>

                    <div class="col-sm-12 g-mb-10">
                      <div class="form-group">
                        <label class="d-block g-color-gray-dark-v2 g-font-size-13">Relation *</label>
                        <input name="relation" id="" class="form-control u-form-control g-placeholder-gray-light-v1 rounded-0 g-py-15"  type="text" placeholder="Mother, Father, Friend..." required="" data-msg="This field is mandatory" data-error-class="u-has-error-v1" data-success-class="u-has-success-v1" aria-required="true">
                      </div>
                    </div>

                    <div class="col-sm-12 g-mb-10">
                      <div class="form-group">
                        <label class="d-block g-color-gray-dark-v2 g-font-size-13">Email</label>
                        <input type="email" name="email" id="" class="form-control u-form-control g-placeholder-gray-light-v1 rounded-0 g-py-15"   placeholder="Email" required=""  data-error-class="u-has-error-v1" data-success-class="u-has-success-v1" >
                      </div>
                    </div>

                    <div class="col-sm-12 g-mb-10">
                      <div class="form-group">
                        <label class="d-block g-color-gray-dark-v2 g-font-size-13">Phone Number</label>
                        <input type="text" name="phone" id="" class="form-control u-form-control g-placeholder-gray-light-v1 rounded-0 g-py-15"   placeholder="Phone " required=""  data-error-class="u-has-error-v1" data-success-class="u-has-success-v1" >
                      </div>
                    </div>


                </div>
              <button class="btn u-btn-primary g-font-size-13 text-uppercase g-px-40 g-py-15" type="submit" data-next-step="#step3">Add Member</button>

      </form>
    </div>

    <div class="modal fade locationModal" ng-app="locationSelector" ng-controller="LocationController" tabindex="-1" role="dialog" data-keyboard="false" data-backdrop="static">
      <div class="modal-dialog" role="document">
        <div class="modal-content" style="margin-top: 0;">
          <div class="modal-header text-center" style="border-bottom: none;padding-bottom: 0">
              <h4><strong>SET A LOCATION</strong></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <i class="fa fa-times"></i>
              </button>
          </div>
          <h6 style="margin-left: 15px;">Drag the pin to your exact location Or Type your address.</h6>
  
          <div class="modal-body text-center">
     
            <div class="input-group g-pb-13 g-px-0 g-mb-10">
              
              <input 
                places-auto-complete size=80
                types="['establishment']"
                component-restrictions="{country:'np'}"
                on-place-changed="placeChanged()"
                id="googleLocation" 
                ng-model="address.Address" 
                class="form-control g-brd-none g-brd-bottom g-brd-black g-brd-primary--focus g-color-black g-bg-transparent rounded-0" type="text" placeholder="Select Area" autocomplete="off">
                
              <button class="btn  u-btn-neutral rounded-0" type="button" ng-click="getLocation()"><i class="fa fa-crosshairs"></i></button>
            </div>
              <p ng-if="error" style="color:red;text-align: left">{{ error }}</p>
  
              
  
              <ng-map center="[27.7041765,85.3044636]" zoom="15" draggable="true">
                  <marker position="27.7041765,85.3044636" title="Drag Me!" draggable="true" on-drdobnd="drdobnd($event)"></marker>
              </ng-map>
          </div>
          <div class="modal-footer" style="border-top: none; text-align: center; display: block;">
            <button type="button" ng-disabled="!isValidGooglePlace" class="btn btn-primary" style="width:100%" ng-click="confirmLocation()">Confirm</button>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.7.8/angular.min.js"></script>
<script src="/assets/front/js/ng-map.min.js"></script>
<script src="https://maps.google.com/maps/api/js?key=AIzaSyAcvyYLSF2ngh8GM7hX7EQ3dIcQGbGnx5Q&libraries=places"></script>
<script src="/assets/front/js/location.js"></script>

<script  src="/frontend-assets/main-assets/assets/vendor/custombox/custombox.min.js"></script>

<!-- JS Unify -->
<script  src="/frontend-assets/main-assets/assets/js/components/hs.modal-window.js"></script>

<!-- JS Plugins Init. -->
<script >
  $(document).on('ready', function () {
    // initialization of popups
    $.HSCore.components.HSModalWindow.init('[data-modal-target]');
  });
</script>
    <script>
        $(document).ready(function(){
            $('#selectFamily').on('change',function(){
                val=$(this).val();
                name=$('#selectFamily option:selected').attr('family-name');
                dob=$('#selectFamily option:selected').attr('family-dob');
                gender=$('#selectFamily option:selected').attr('family-gender');
                $('#name').val(name);
                $('#dob').val(dob);
                $('#gender').val(gender);


                console.log(val);
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>