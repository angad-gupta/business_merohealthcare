<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $vendor_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor_id => $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php 
            $vendor = $vendors->where('id',$vendor_id)->first();
            $price = 0;
            $pprice = 0;
            foreach ($products as $product) {
                $price += $product->cprice;
                $pprice += $product->pprice ? : $product->cprice;
            }
         ?>

        <?php if(!$vendor): ?> <?php continue; ?> <?php endif; ?>

        <div class="col-lg-4 g-mb-30">
            <!-- Article -->
            <article class="u-shadow-v21 g-bg-white rounded">
                <div class="g-pa-30">
                    <h3 class="g-font-weight-300 g-mb-15">
                        <a class="u-link-v5 g-color-main g-color-primary--hover" href="#"><?php echo e($vendor->name); ?></a>
                    </h3>
                    
                    <p style="font-size: 1.25rem;">Total Price:
                        <?php if($gs->sign == 0): ?>
                            <?php echo e($curr->sign); ?><?php echo e(round($price * $curr->value, 2)); ?>

                        <?php else: ?>
                            <?php echo e(round($price * $curr->value, 2)); ?><?php echo e($curr->sign); ?>

                        <?php endif; ?>
                    </p>
                </div>
            
                <div class=" g-font-size-12 g-brd-top g-brd-gray-light-v4 g-pa-15-30">
                    <input type="hidden" value="<?php echo e($vendor_id); ?>" />

                    <button class="btn btn-md u-btn-primary g-font-weight-600 g-font-size-11 text-uppercase g-py-10 addTestsCart">
                        <i class="g-mr-5 fa fa-heart"></i>
                        Book Now
                    </button>
                </div>
            </article>
            <!-- End Article -->
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="container text-center">
        <h1 style="margin: 20px;  text-align:center">No Tests found !</h1>
        </div>
    <?php endif; ?>          
</div>




