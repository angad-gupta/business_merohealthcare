<?php $__env->startSection('content'); ?>
<div class="right-side">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <!-- Starting of Dashboard Office Address -->
                        <div class="section-padding add-product-1">
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="add-product-box">
                                    <div class="product__header">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title">
                                                    <h2>Vendor Registration Option</h2>
                                                    <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i> General Settings <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Vendor Registration</p>
                                                </div>
                                            </div>
                                              <?php echo $__env->make('includes.notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </div>   
                                    </div>
                                        <hr>
                                          <?php echo $__env->make('includes.form-error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                          <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>      
                                          <?php echo e(csrf_field()); ?>


                                        <div class="form-group" style="padding: 20px 0;">

                                            <label class="control-label col-sm-4 text-right" for="Vendor">Select an Option *</label>
                                                        <span class="dropdown">
                                            <button id="Vendor" class="btn btn-<?php echo e($gs->reg_vendor == 1 ? 'primary':'danger'); ?> product-btn dropdown-toggle btn-xs" type="button" data-toggle="dropdown" style="font-size: 14px;"><?php echo e($gs->reg_vendor == 1 ? 'Vendor Registration Activated':'Vendor Registration Deactivated'); ?>

                                                <span class="caret"></span></button>
                                                        <ul class="dropdown-menu">
                                                            <li><a href="<?php echo e(route('admin-gs-regvendor',1)); ?>">Active</a></li>
                                                            <li><a href="<?php echo e(route('admin-gs-regvendor',0)); ?>">Deactive</a></li>
                                                        </ul>
                                                        </span>
                                          </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard Office Address -->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('assets/admin/js/nicEdit.js')); ?>"></script> 
<script type="text/javascript">
//<![CDATA[
        bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
  //]]>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>