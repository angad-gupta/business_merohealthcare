<?php $__env->startSection('title','My Businessorders'); ?>
<?php $__env->startSection('content'); ?>
  <div class="right-side">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <!-- Starting of Dashboard data-table area -->
          <div class="section-padding add-product-1">
            <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="add-product-box">
                  <div class="product__header">
                      <div class="row represcription-xs">
                          <div class="col-lg-8 col-md-5 col-sm-5 col-xs-12">
                              <div class="product-header-title">
                                  <h2>My Business Orders </h2>
                                  <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Business Orders</p>
                              </div>
                          </div>
                            <?php echo $__env->make('includes.user-notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                      </div>   
                  </div>
                  <div>
                    <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


                    
                     
                  
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="table-responsive">
                          
                            <table id=" " class="table table-striped table-hover products dt-responsive" cellspacing="0" width="100%">
                            <thead>
                              <tr class="table-header-row">
                                <th>#</th>
                                <th>Title</th>
                                <th>Date</th>
                                
                                <th>Business Orders files</th>
                                <th>Status</th>
                                
                              </tr>
                            </thead>
                            <tbody>
                              <?php $__currentLoopData = $businessorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $businessorder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                              <?php 
                              $p = App\Product::findOrFail($businessorder->product_id);
                                  
                               ?>
                                <tr>
                                  <td><?php echo e($loop->iteration); ?></td>
                                  <td><a href="<?php echo e(route('front.product',[$p->id,$p->name ])); ?>"><?php echo e($p->name); ?></a></td>
                                  <td><?php echo e(date('d M Y',strtotime($businessorder->created_at))); ?></td>
                                  
                                  <td>
                                    <?php $__currentLoopData = $businessorder->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('user-businessorders.file',[$businessorder->id,$file->file,$file->id])); ?>" target="_blank" title="<?php echo e($file->file); ?>"><?php echo $file->file  ? : '<i class="fa fa-file"></i>'; ?></a>
                                      <br/>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </td>
                                  <td>
            
                                     <?php if($businessorder->status == 'processing'): ?>
                                    <span class="label label-primary" style="border-radius: 30px;padding: 4px 8px;font-size: 12px;"><?php echo e(ucfirst($businessorder->status)); ?></span> 
                                    <?php elseif($businessorder->status == 'cancelled'): ?>
                                    <span class="label label-danger" style="border-radius: 30px;padding: 4px 8px;font-size: 12px;"><?php echo e(ucfirst($businessorder->status)); ?></span> 

                                    <?php endif; ?>

                                    <?php if($businessorder->status == 'cancelled'): ?>
                                    
                                    <?php else: ?> 
                                    
                           
                                    <a href="javascript:;" data-href="<?php echo e(route('user-businessorder.update-status',$businessorder->id)); ?>" data-toggle="modal" data-target="#confirm-delete" class="btn btn-danger" style="border-radius : 30px;"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                    
                                    <?php endif; ?>

                     

                                  </td>
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Ending of Dashboard data-table area -->

        
      </div>
    </div>
  </div>

  <!-- Trigger the modal with a button -->
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content text-center">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Delete Business Order ?</h4>
      </div>
      <div class="modal-body">
        <p>Are you Sure u want to cancel?</p>

        

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

  <div class="modal fade" id="add-reminder" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title text-center" id="myModalLabel">Add Reminder</h4>
            </div>
            <div class="modal-body">

              <form class="form-horizontal btn-add" action="" method="POST" id="form2">

                <?php echo e(csrf_field()); ?>

                
                <div class="form-group">
                  <label class="control-label col-sm-4"> Duration *<span>(Repeated after every 'x' days from Order date)</span></label>
                  <div class="col-sm-6">
                    
                    <input class="form-control" name="duration" value="<?php echo e(old('duration')); ?>" placeholder="Duration in days" type="number" value="" min="1">
                    
                  </div>
                  
                </div>

                <hr>
                <div class="add-product-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>

                  <button name="add_product_btn" type="submit" class="btn btn-success">Submit</button>
                </div>
              </form>
            </div>
        </div>
    </div>
  </div>

  <div class="modal fade" id="edit-reminder" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title text-center" id="myModalLabel">Edit Reminder</h4>
            </div>
            <div class="modal-body">

              <form class="form-horizontal btn-edit" action="" method="POST" id="form2">

                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                  <label class="control-label col-sm-4"> Duration *<span>(Repeated after every 'x' days from Order date)</span></label>
                  <div class="col-sm-6">
                    
                    <input class="form-control" name="duration" value="" placeholder="Duration in days" type="number" value="" min="1">
                    
                  </div>
                  
                </div>

                <div class="form-group">
                    <label class="control-label col-sm-4"> Status *<span></span></label>
                    <div class="col-sm-6">
                      <label class="switch">
                        <input type="checkbox" name="status" value="1">
                        <span class="slider round"></span>
                      </label>
                      
                    </div>
                    
                </div>

                <hr>
                <div class="add-product-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                  <button type="button" class="btn btn-danger" data-href="" data-toggle="modal" data-target="#confirm-delete" style="float:left">Delete</button>

                  <button name="add_product_btn" type="submit" class="btn btn-success">Save</button>
                </div>
              </form>
            </div>
        </div>
    </div>
  </div>

  <div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title text-center" id="myModalLabel">Confirm Delete</h4>
            </div>
            <div class="modal-body">
                <p class="text-center">You are about to delete.</p>
                <p class="text-center">Do you want to proceed?</p>
            </div>
            <div class="modal-footer" style="text-align: center;">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <form class="btn-ok" action="" method="POST" style="display:inline-block">
                  <?php echo e(csrf_field()); ?>

                  <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>





<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">

  $( document ).ready(function() {
      $(".add-button").append('<div class="col-sm-4 add-product-btn text-right">'+
        '<a style="cursor: pointer;" href="<?php echo e(route("user-prescriptions.create")); ?>" class="add-newProduct-btn email2">'+
        '<i class="fa fa-plus"></i> Upload New Prescription</a>'+
        '</div>');                                                                       
  });

  $('#add-reminder').on('show.bs.modal', function(e) {
      
      $(this).find('.btn-add').attr('action', $(e.relatedTarget).data('href'));
  });

  $('#edit-reminder').on('show.bs.modal', function(e) {
      var reminder = $(e.relatedTarget).data('reminder');
      
      $(this).find('input[name="duration"]').val(reminder.duration);
      $(this).find('.btn-danger').attr('data-href',"/user/prescriptions/"+reminder.notifiable_id+"/reminder/delete");
      
      if(reminder.status)
        $(this).find('input[name="status"]').attr('checked','checked');
      else
        $(this).find('input[name="status"]').removeAttr('checked');

      if($(this).find('input[name="status"]')[0].checked != reminder.status)
        $(this).find('input[name="status"]').trigger("click");

      $(this).find('.btn-edit').attr('action', $(e.relatedTarget).data('href'));
  });

  $('#confirm-delete').on('show.bs.modal', function(e) {
      
      $(this).find('.btn-ok').attr('action', $(e.relatedTarget).data('href'));
  }); 


//   $(document).ready(function () {
// $('#dtOrderExample').DataTable({
// "order": [[4, "desc" ]]
// });
// $('.dataTables_length').addClass('bs-select');
// });
  
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>