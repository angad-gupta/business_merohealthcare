<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/dzsparallaxer/dzsparallaxer.css">
<link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/dzsparallaxer/dzsscroller/scroller.css">
<link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/dzsparallaxer/advancedscroller/plugin.css">


<section class="dzsparallaxer auto-init height-is-based-on-content use-loading mode-scroll dzsprx-readyall loaded" data-options="{direction: 'reverse', settings_mode_oneelement_max_offset: '150'}">
    <div class="divimage dzsparallaxer--target w-100 u-bg-overlay g-bg-bluegray-opacity-0_5--after" style="height: 130%; background-image: url('/medimage/lb2.jpg'); transform: translate3d(0px, -47.0242px, 0px);"></div>

    <!-- Promo Block Content -->
    <div class="container u-bg-overlay__inner text-center g-py-70">
      <h2 class="h1 g-color-white g-font-weight-600 text-uppercase g-mb-30">Mero Health Lab</h2>

      <!-- Search Form -->
      <form action="/lab/tests/search" method="GET">
         
        <!-- Search Field -->
        <div class="g-max-width-540 mx-auto g-mb-20">
          
          <div class="input-group">
            <input list="alltest" name="searchkey" type="text" class="form-control g-font-size-16 border-0" style="height:52px;" placeholder="Search test here. eg (Lipid Profile)" aria-label="Search your test">
            <datalist id="alltest">
              
                <?php $__currentLoopData = Modules\Lab\Entities\LabProduct::where('status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->name); ?>">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </datalist>
            <span class="input-group-btn">
              <button class="btn btn-primary g-font-size-18 g-py-12 g-px-25" type="submit">
                <i class="fa fa-search"></i>
              </button>
            </span>
          </div>
        </div>
      <a href="/lab/compare" class="btn btn-primary">Compare Prices</a>

        <!-- End Search Field -->

        <!-- Checkboxes -->
        
        <!-- End Checkboxes -->
      </form>
      <!-- End Search Form -->
    </div>
    <!-- End Promo Block Content -->
  </section>
 
  <div class="container g-mt-20">
    <div class="text-center">
      <h2>Trusted Diagnostics. Most Affordable Rates.</h2>
    </div>

      <div class="row g-mt-20">
          <div class="col-lg-4 g-mb-30">
            <!-- Icon Blocks -->
            <div class="text-center u-icon-block--hover">
              <img class="u-image-icon-size-2xl rounded-circle g-mb-25" src="/frontend-assets/main-assets/assets/img/icons/set-1/01.png" alt="Image Description">
              <h3 style="font-size: 1.25rem;"  class="h5 g-color-black g-font-weight-600 mb-3">Assured Home Service</h3>
              <p style="font-size: 1.25rem;" class="g-color-gray-dark-v4">Medlife expert technician visits your home to collect blood sample. All samples have a Unique-ID. You cant rack your sample in real time.</p>
            </div>
            <!-- End Icon Blocks -->
          </div>
        
          <div class="col-lg-4 g-mb-30">
            <!-- Icon Blocks -->
            <div class="text-center u-icon-block--hover">
              <img class="u-image-icon-size-2xl rounded-circle g-mb-25" src="/frontend-assets/main-assets/assets/img/icons/set-1/02.png" alt="Image Description">
              <h3 class="h5 g-color-black mb-3 g-font-weight-600">High Quality Reports</h3>
              <p style="font-size: 1.25rem;" class="g-color-gray-dark-v4">Sample with Unique-ID is deposited in accredited Lab and you receive the reports immediately after our Pathologist reviews it.</p>
            </div>
            <!-- End Icon Blocks -->
          </div>
        
          <div class="col-lg-4 g-mb-30">
            <!-- Icon Blocks -->
            <div class="text-center u-icon-block--hover">
              <img class="u-image-icon-size-2xl rounded-circle g-mb-25" src="/frontend-assets/main-assets/assets/img/icons/set-1/03.png" alt="Image Description">
              <h3 class="h5 g-color-black mb-3 g-font-weight-600">Expert Review</h3>
              <p style="font-size: 1.25rem;" class="g-color-gray-dark-v4">Get review from expert doctors and dietician on your report at the comfort of your home.</p>
            </div>
            <!-- End Icon Blocks -->
          </div>
      </div>
      
      <div class="text-center">
        <h2>Categories:</h2>
      </div>
      <div class="g-mx-minus-15">
          <div class="row">
              <?php $__currentLoopData = $labcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <div class="col-md-6 col-lg-3 g-pt-20 g-mb-30">
                <!-- Article -->
                <article class="u-block-hover u-block-hover--uncroped text-center">
                  <!-- Article Image -->
                <a class="d-block u-block-hover__additional--jump g-mb-10" href="/lab/category/<?php echo e($c->cat_slug); ?>">
                  <img  style="height:6rem;" src="/assets/images/<?php echo e($c->photo); ?>" alt="Image Description">
                  </a>
                  <!-- End Article Image -->
            
                  <!-- Article Info -->
                  <em class="d-block g-color-gray-dark-v5 g-font-style-normal g-font-size-12 g-mb-0">(<?php echo e($c->products->count()); ?> tests)</em>
                  <h3 class="h5">
                    <a class="g-color-main g-color-primary--hover g-text-underline--none--hover" href="/lab/category/<?php echo e($c->cat_slug); ?>"><?php echo e($c->cat_name); ?></a>
                  </h3>
                  <!-- End Article Info -->
                </article>
                <!-- End Article -->
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </div>
         
        </div>
    <!-- End Nav tabs -->
    
    <!-- Tab panes -->


  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script src="/frontend-assets/main-assets/assets/vendor/dzsparallaxer/dzsparallaxer.js"></script>
<script src="/frontend-assets/main-assets/assets/vendor/dzsparallaxer/dzsscroller/scroller.js"></script>
<script src="/frontend-assets/main-assets/assets/vendor/dzsparallaxer/advancedscroller/plugin.js"></script>
<script >
    $(document).ready(function () {
    
      // initialization of carousel
      $.HSCore.components.HSCarousel.init('.js-carousel');
    });
  </script>
<script>
  $(document).on("click", ".addTest" , function(){
      var pid = $(this).parent().find('input[type=hidden]').val();
      var button = $(this);
      button.attr('disabled','disabled');

      $.ajax({
          type: "POST",
          url:"<?php echo e(URL::to('/lab/json/addcart')); ?>",
          data:{ test_id: pid, reset_cart: true, _token: '<?php echo e(csrf_token()); ?>' },
          success:function(data){
            if(data == 0)
            {
                $.notify("<?php echo e($gs->cart_error); ?>","error");
            }
            else
            {
              location.href = "<?php echo e(route('lab.cart')); ?>";
            }
          },
          error: function(data){
            button.removeAttr('disabled');

            $.notify("Something went wrong.","error");
          }
      }); 
      return false;
  });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>