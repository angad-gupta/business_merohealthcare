<?php $__env->startSection('title','File manager'); ?>
<?php $__env->startSection('styles'); ?>
  <style>
    .invalid-feedback{
      color: red
    }

    @media  only screen and (max-width: 600px) {
        #filesubmit{
            margin-top: 10px !important;
        }
        
    }
  </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
  <div class="right-side">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <!-- Starting of Dashboard data-table area -->
          <div class="section-padding add-product-1">
            <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="add-product-box">
                  <div class="product__header">
                      <div class="row represcription-xs">
                          <div class="col-lg-8 col-md-5 col-sm-5 col-xs-12">
                              <div class="product-header-title">
                                  <h2>Presciption File Manager <a href="<?php echo e(route('user-family.index')); ?>" style="padding: 5px 12px;" class="btn add-back-btn"><i class="fa fa-arrow-left"></i> Back</a></h2>
                                  <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i> File manager</p>
                              </div>
                          </div>
                            <?php echo $__env->make('includes.user-notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                      </div>   
                  </div>
                  <div>

                    
                    <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <br/>
                    <div class="container">
                      <h4>Manage Your Prescription Files. </h4>
                      </div>
                    <div class="row">
                      <div class="col-sm-12">

                        
                        
                        
                        <form method="POST" action="<?php echo e(route('user-prescriptions.filestorefamilysingle',$user->id)); ?>" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                         <div class="row" style="padding:20px;">    
                           
                          <div class="col-lg-4 col-md-4 col-sm-12">

                            <label class="g-color-gray-dark-v2 g-font-size-13">Prescription Title</label>
                            <input type="text" name="title" class="form-control" placeholder="Prescription Title" />
                          </div>
                     
                        <div class="col-lg-4 col-md-2 col-sm-12">
                         
                          
                            <label class="g-color-gray-dark-v2 g-font-size-13">Prescription File(s) Upload </label>
                            <input type="file" name="filename[]" class="form-control" multiple>
                       
                        
                    </div>

                    <div class="col-lg-2 col-md-2 col-sm-12">
                      <label class="g-color-gray-dark-v2 g-font-size-13">Family</label>
                
                      <select name="family" class="form-control" id="selectFamily" style="width: 100%; display: inline-block;">
                  
                          <?php $__currentLoopData = App\User::findOrFail(Auth::user()->id)->family; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if(isset($f_id)): ?>
                                  <option <?php echo e($f_id == $fam->id ? 'selected' : ''); ?> value="<?php echo e($fam->id); ?>" ><?php echo e($fam->name); ?> (<?php echo e($fam->relation); ?>)</option>
                              <?php else: ?>
                                  <option value="<?php echo e($fam->id); ?>" <?php echo e(old('family') == $fam->id ? 'selected' : ''); ?>><?php echo e($fam->name); ?> (<?php echo e($fam->relation); ?>)</option>

                              <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                   
                    </div>

                    <div class="col-lg-2 col-md-2 col-sm-12">
                      <label class="g-color-gray-dark-v2 g-font-size-13"></label>
                      <button id="filesubmit" class="btn btn-primary form-control " type="submit">Submit</button>
                      </div>
                         

                 
                        
                        
                  
                </div>
                       
                </form>

                

                

                
        
                        <div class="table-responsive" style="margin-top:15px;">
                          <table id="product-table_wrapper" class="table table-striped table-hover products dt-responsive" cellspacing="0" width="100%">
                            <div class="container">
                            <h4>Presciption Group File Details</h4>
                            </div>
                            
                            <thead>
                              
                              <tr class="table-header-row">
                                <th>#</th>
                                <th>Prescription Title</th>
                                <th>Prescription File</th>
                                <th>Name </th>
                                <th>Date </th>
                                <th>Relation </th>
                                
                                <th>Actions</th>
                                
                              </tr>
                            </thead>
                            <tbody>
                              
                            <?php $__currentLoopData = $p_folder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        
                            <?php if($pf->status == 'active'): ?>
                     
                            

                       
                          
                                <tr>
                                  <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($pf->title); ?></td>
                                <td>
                                  
                                    
                                    

                                  <?php $__currentLoopData = $pf->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($f->status == 'active'): ?>
                                      <a href="<?php echo e(route('user-file',[$f->file])); ?>"><i class="fa fa-picture-o" aria-hidden="true" style="font-size:25px;"></i></a>
                                    <?php endif; ?>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                             
                                <td>
                                  <?php 
                                  $family_name = App\Family::where('id','=', $pf->family_id)->get(); 
                                   ?>
                                 
                                    <?php if($pf->family_id == null): ?>
                                      <p>Self</p>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $family_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php echo e($fn->name); ?>

                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                 
                              </td>

                              <td><?php echo e(date('d M Y',strtotime($pf->created_at))); ?></td>

                              <td>
                              
                                <?php 
                                $family_name = App\Family::where('id','=', $pf->family_id)->get(); 
                              
                                 ?>

                              <?php if($pf->family_id == null): ?>
                              <p>Self</p>
                              <?php else: ?>
                                <?php $__currentLoopData = $family_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($fn->relation); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php endif; ?>
                              
                              </td> 
                            
                              

                                 <td>
                                    <a href="javascript:;" data-toggle="modal" data-target="#update-title" data-href="<?php echo e(route('user-filemanagertitleupdate', $pf->id)); ?>" class="btn btn-primary" style="border-radius:30px;"><i class="fa fa-edit" aria-hidden="true"></i></a>
                                  <?php if($pf->status == 'active'): ?>
                                  <a href="javascript:;" data-toggle="modal" data-target="#confirm-delete" data-href="<?php echo e(route('user-filemanagerupdate', $pf->id)); ?>" class="btn btn-danger" style="border-radius:30px;"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                  <?php endif; ?>
                                 
        
                                </td>
                      
                                </tr>
                       
                               
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                            </tbody>
                          </table>
                        </div>

                        <div class="container" style="margin-top:20px;">
                          <h4>Presciption All File Details</h2>
                          
                          <button onclick="change()" id="myButton1" type="button" class="btn btn-primary" data-toggle="collapse" data-target="#demo" style="margin-bottom:20px;">Show</button>
                          <div id="demo" class="collapse">
                            <div class="table-responsive">
                              <table id="product-table_wrapper" class="table table-striped table-hover products dt-responsive" cellspacing="0" width="100%">
                                <div class="container">
                                  <br/>
                              
                                <h4>Presciption Each Files Details</h4>
                                </div>
                                
                                <thead>
                                  
                                  <tr class="table-header-row">
                                    <th>#</th>
                                    <th>Prescription Title</th>
                                    <th>Prescription File</th>
                                    <th>Name </th>
                                    <th>Date </th>
                                    <th>Relation </th>
                                    
                                    <th>Actions</th>
                                    
                                  </tr>
                                </thead>
                                <tbody>
                                  
                                <?php $__currentLoopData = $pfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                            
                                <?php if($pf->status == 'active'): ?>

                                
                         
                                
    
                                
                              
                                    <tr>
                                      <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($pf->title); ?></td>
                                    <td>
                                      
                                        
                                        
    
                               
                                       <a href="<?php echo e(route('user-file',[$pf->file])); ?>"><i class="fa fa-picture-o" aria-hidden="true" style="font-size:25px;"></i></a>
                                
                                    </td>
                                 
                                    <td>
                                      <?php 
                                      $family_name = App\Family::where('id','=', $pf->family_id)->get(); 
                                       ?>
                                     
                                        <?php if($pf->family_id == null): ?>
                                          <p>Self</p>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $family_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <?php echo e($fn->name); ?>

                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                     
                                  </td>
    
                                  <td><?php echo e(date('d M Y',strtotime($pf->created_at))); ?></td>
    
                                  <td>
                                  
                                    <?php 
                                    $family_name = App\Family::where('id','=', $pf->family_id)->get(); 
                                  
                                     ?>
    
                                  <?php if($pf->family_id == null): ?>
                                  <p>Self</p>
                                  <?php else: ?>
                                    <?php $__currentLoopData = $family_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($fn->relation); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php endif; ?>
                                  
                                  </td> 
                                
                                  
    
                                     <td>
                                        <a href="javascript:;" data-toggle="modal" data-target="#update-title-single" data-href="<?php echo e(route('user-filemanagertitleupdatesingle', $pf->id)); ?>" class="btn btn-primary" style="border-radius:30px;"><i class="fa fa-edit" aria-hidden="true"></i></a>
                                      <?php if($pf->status == 'active'): ?>
                                      <a href="javascript:;" data-toggle="modal" data-target="#confirm-delete-single" data-href="<?php echo e(route('user-filemanagerupdatesingle', $pf->id)); ?>" class="btn btn-danger" style="border-radius:30px;"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                      <?php endif; ?>
                                     
            
                                    </td>
                          
                                    </tr>
                           
                                   
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>

                       


                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Ending of Dashboard data-table area -->
      </div>
    </div>
  </div>

  <div class="modal fade" id="update-title" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title text-center" id="myModalLabel">Update Title</h4>
            </div>
            <div class="modal-body">
                <label>Prescription Title : </label>
                <form class="btn-update" action="" method="POST" style="display:inline-block" >
                  <?php echo e(csrf_field()); ?>

                  <input type="text" name="title" value="" placeholder="Prescription Title" >
                
            </div>
            <div class="modal-footer" style="text-align: center;">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                
                  
                  <button type="submit" class="btn btn-success">Update</button>
               
            </div>
          </form>
        </div>
    </div>
</div>

  <div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title text-center" id="myModalLabel">Confirm Delete</h4>
            </div>
            <div class="modal-body">
                <p class="text-center">You are about to delete.</p>
                <p class="text-center">Do you want to proceed?</p>
            </div>
            <div class="modal-footer" style="text-align: center;">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <form class="btn-ok" action="" method="POST" style="display:inline-block" enctype="multipart/form-data">
                  <?php echo e(csrf_field()); ?>

                  <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="update-title-single" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
              <h4 class="modal-title text-center" id="myModalLabel">Update Title</h4>
          </div>
          <div class="modal-body">
              <label>Prescription Title : </label>
              <form class="btn-update-single" action="" method="POST" style="display:inline-block" >
                <?php echo e(csrf_field()); ?>

                <input type="text" name="title" value="" placeholder="Prescription Title" >
              
          </div>
          <div class="modal-footer" style="text-align: center;">
              <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
              
                
                <button type="submit" class="btn btn-success">Update</button>
             
          </div>
        </form>
      </div>
  </div>
</div>

<div class="modal fade" id="confirm-delete-single" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
              <h4 class="modal-title text-center" id="myModalLabel">Confirm Delete</h4>
          </div>
          <div class="modal-body">
              <p class="text-center">You are about to delete.</p>
              <p class="text-center">Do you want to proceed?</p>
          </div>
          <div class="modal-footer" style="text-align: center;">
              <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
              <form class="btn-ok-single" action="" method="POST" style="display:inline-block" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <button type="submit" class="btn btn-danger">Delete</button>
              </form>
          </div>
      </div>
  </div>
</div>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">

$(document).ready(function(){
        $("#myButton1").click(function(){
            $(this).text($(this).text() == 'Show' ? 'Hide' : 'Show');
        });
    });

    
  $(document).ready(function() {


    $('#confirm-delete').on('show.bs.modal', function(e) {
    
    $(this).find('.btn-ok').attr('action', $(e.relatedTarget).data('href'));
}); 

$('#update-title').on('show.bs.modal', function(e) {
    
    $(this).find('.btn-update').attr('action', $(e.relatedTarget).data('href'));
}); 

$('#confirm-delete-single').on('show.bs.modal', function(e) {
    
    $(this).find('.btn-ok-single').attr('action', $(e.relatedTarget).data('href'));
}); 

$('#update-title-single').on('show.bs.modal', function(e) {
    
    $(this).find('.btn-update-single').attr('action', $(e.relatedTarget).data('href'));
}); 


});

  

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>