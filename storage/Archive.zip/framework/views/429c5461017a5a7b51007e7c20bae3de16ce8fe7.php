














<script>
    //---------Countdown-----------
    // $('#clock').countdown('<?php echo e($gs->count_date); ?>', function(event) {
    //     $(this).html(event.strftime('<span class="countdown-timer-wrap"></span><span class="single-countdown-item">%w <br/><span><?php echo e($lang->week); ?></span></span> <span class="single-countdown-item">%d <br/><span><?php echo e($lang->day); ?></span></span> <span class="single-countdown-item">%H <br/><span><?php echo e($lang->hour); ?></span></span> <span class="single-countdown-item">%M <br/><span><?php echo e($lang->minute); ?></span></span> <span class="single-countdown-item">%S <br/><span><?php echo e($lang->second); ?></span></span> </span>'));
    // });
</script>
