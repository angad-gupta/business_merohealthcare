<?php $__env->startSection('content'); ?>

  <div class="section-padding compare-wrap">
    <div class="container-fluid">
      <?php if(Session::has('compare')): ?>
        <div class="row">
          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
            <h3 class="compare-h3"><?php echo e($lang->compare_title); ?></h3>
          </div>
          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
            <div class="clear-area text-right">
            <a href="" class="btn clear-btn"><?php echo e($lang->clear); ?></a>
          </div>
          </div>
        </div>

        <div class="compare-content-wrap">
          <div class="singleComapre__area">
            <div class="singleCompare__title image"><?php echo e($lang->cimage); ?></div>
            <div class="singleCompare__title"><?php echo e($lang->cproduct); ?></div>
            <div class="singleCompare__title"><?php echo e($lang->cupice); ?></div>
            <div class="singleCompare__title"><?php echo e($lang->compare_rating); ?></div>
            <div class="singleCompare__title"><?php echo e($lang->compare_vendor); ?></div>
            <div class="singleCompare__title description"><?php echo e($lang->compare_description); ?></div>
            <div class="singleCompare__title"><?php echo e($lang->compare_available); ?></div>
            <div class="singleCompare__title"><?php echo e($lang->compare_cart); ?></div>
          </div>

          <div class="singleCompare__content-wrap">
            <?php if(Session::has('compare')): ?>
              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="singleCompare__content">
                  <div class="compare__img">
                    <input type="hidden" value="<?php echo e($product['item']['id']); ?>">
                    <i class="fa fa-close compare-remove" style="cursor: pointer;"></i>
                    <img src="<?php echo e(asset('assets/images/'.$product['item']['photo'])); ?>" alt="product image">
                  </div>
                  <p><strong><a style="color: black;" href="<?php echo e(route('front.product',[$product['item']['id'],str_slug($product['item']['name'],'-')])); ?>"><?php echo e(strlen($product['item']['name']) > 70 ? substr($product['item']['name'],0,70).'...' : $product['item']['name']); ?></a></strong></p>
                  <p>              
                    <?php if($gs->sign == 0): ?>
                    <?php echo e($curr->sign); ?><?php echo e(round($product['item']['cprice'] * $curr->value, 2)); ?>

                    <?php else: ?>
                    <?php echo e(round($product['item']['cprice'] * $curr->value, 2)); ?><?php echo e($curr->sign); ?>

                    <?php endif; ?>
                  </p>
                  <div class="ratings">
                    <div class="empty-stars"></div>
                      <div class="full-stars" style="width:<?php echo e(App\Review::ratings($product['item']['id'])); ?>%"></div>
                  </div>
                  <p style=" padding: 0; height: 17px;"></p>
                  <?php if($product['item']['user_id'] != 0): ?>
                  <?php  
                  $user = App\User::findOrFail($product['item']['user_id']);
                   ?>   
                  <?php if(isset($user)): ?>                
                  <p><?php echo e($user->shop_name); ?></p>
                  <?php else: ?>
                  <p>No Vendor.</p>
                  <?php endif; ?>
                  <?php else: ?>
                  <p>No Vendor.</p>
                  <?php endif; ?>
                  <p class="description"><?php echo e(strip_tags($product['item']['description'])); ?></p>
                  <?php 
                    $stk = (string)$product['item']['stock'];
                   ?>
                  <?php if($stk == "0"): ?>
                    <p class="productDetails-status" style="color: red;">
                      <i class="fa fa-times-circle-o"></i>
                      <span><?php echo e($lang->dni); ?></span>
                    </p>
                  <?php else: ?>
                    <p class="productDetails-status" style="color: green;">
                      <i class="fa fa-check-square-o"></i>
                      <span><?php echo e($lang->sbg); ?></span>
                    </p>
                  <?php endif; ?>
                  <p class="text-center">
                    <input type="hidden" value="<?php echo e($product['item']['id']); ?>">
                    <a href="" class="btn compare-cartBtn addcart"><?php echo e($lang->hcs); ?></a>
                  </p>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

          </div>
        </div>
      <?php else: ?>
        <h2 class="text-center"><?php echo e($lang->no_compare); ?></h2>
      <?php endif; ?>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>