
<?php $__env->startSection('title','Reset Password'); ?>
<?php $__env->startSection('content'); ?>
<div class="section-padding login-area-wrapper">
           <div class="container">
               <div class="row">
                   <div class="col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1  col-xs-12">
                       <div class="signIn-area">
                           <h2 class="signIn-title text-center"><?php echo e($lang->fpt); ?></h2>
                           <hr>
                            <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                           <?php echo $__env->make('includes.form-error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                           <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                           <div class="login-form">
                           <form action="<?php echo e(route('user-forgot-submit')); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>


                               <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                                   <label for="forgot_email"><?php echo e($lang->fpe); ?> <span>*</span></label>
                                   <input class="form-control" placeholder="<?php echo e($lang->fpe); ?>" type="email" name="email" id="forgot_email" required="">
                               </div>
                               <div class="form-group">
                                   <button type="submit" class="btn btn-default btn-block"><?php echo e($lang->fpb); ?></button>
                               </div>
                               <div class="form-group">
                                   <div class="row">
                                       <div class="col-md-12 col-sm-12 col-xs-12 text-right">
                                            <a href="<?php echo e(route('user-login')); ?>"><?php echo e($lang->al); ?></a>
                                       </div>
                                   </div>
                               </div>
                           </form>
                       </div>
                       </div>
                   </div>
               </div>
           </div>
       </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>