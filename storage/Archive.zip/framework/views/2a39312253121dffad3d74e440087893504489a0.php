<?php $__env->startSection('title','Upload Prescription'); ?>

<?php $__env->startSection('styles'); ?>
  <style>
    .invalid-feedback{
      color: red;
    }

    @media(min-width:320px) and (max-width:768px){
    #history-prescription{
      height:40px !important;
    }
    }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
  <?php if(Session::has('defaultFamily')): ?>
    <?php 
            $family=Session::get('defaultFamily');

     ?>

  <?php endif; ?>
  <div class="right-side">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <!-- Starting of Dashboard area -->
            <div class="section-padding add-product-1">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="add-product-box">
                          <div class="product__header"  style="border-bottom: none;">
                              <div class="row reorder-xs">
                                  <div class="col-lg-8 col-md-5 col-sm-5 col-xs-12">
                                      <div class="product-header-title">
                                          <h2>Upload Prescription <a href="<?php echo e(route('user-prescriptions.index')); ?>" style="padding: 5px 12px;" class="btn add-back-btn"><i class="fa fa-arrow-left"></i> Back</a></h2>
                                          <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i> My Prescriptions <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Add
                                      </div>
                                  </div>
                                    <?php echo $__env->make('includes.user-notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                              </div>   
                          </div>
                          <hr>
                          <div>
                            
                            <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
                            <!-- Tab panes -->
                            <div class="tab-content">

                              <div class="tab-pane fade active in" id="digital">
                                <form class="form-horizontal" action="<?php echo e(route('user-prescriptions.store')); ?>" method="POST" enctype="multipart/form-data"  id="form2" >

                                    <?php echo e(csrf_field()); ?>


                                    <div class="form-group">
                                      <label class="control-label col-sm-4" for="title"> Order Title*</label>
                                      <div class="col-sm-6">
                                        <input class="form-control" name="title" id="title" value="<?php echo e(old('title')); ?>" placeholder="Enter Title" required="" type="text" >
                                        <?php if($errors->has('title')): ?>
                                          <span class="invalid-feedback" role="alert">
                                              <strong><?php echo e($errors->first('title')); ?></strong>
                                          </span>
                                        <?php endif; ?>
                                      </div>
                                      
                                    </div>

                                    <div class="form-group">
                                      <label class="control-label col-sm-4" for="geolocation"> Delivery Location *</label>
                                      <div class="col-sm-6">
                                        <input class="form-control" name="location" id="geolocation" placeholder="Enter Delivery Location" value="<?php echo e(old('location') ? : Auth::guard('user')->user()->address); ?>" required="" type="text" onclick="$('.locationModal').modal('show');" autocomplete="off">
                                        <input id="latlong" type="hidden" name="latlong" value="<?php echo e(old('latlong') ? : Auth::guard('user')->user()->latlong); ?>">
                                        
                                        <?php if($errors->has('location')): ?>
                                          <span class="invalid-feedback" role="alert">
                                              <strong><?php echo e($errors->first('location')); ?></strong>
                                          </span>
                                        <?php endif; ?>
                                      </div>
                                      
                                    </div>

                                    <div class="form-group">
                                      <label class="control-label col-sm-4" for="phone"> Contact No. *<span></span></label>
                                      <div class="col-sm-6">
                                        <input class="form-control" name="phone" id="phone" value="<?php echo e(old('phone') ? : Auth::guard('user')->user()->phone); ?>" placeholder="Enter Contact No." required="" type="text" >
                                        <?php if($errors->has('phone')): ?>
                                          <span class="invalid-feedback" role="alert">
                                              <strong><?php echo e($errors->first('phone')); ?></strong>
                                          </span>
                                        <?php endif; ?>
                                      </div>
                                    </div>

                                    <div class="form-group">
                                      <label class="control-label col-sm-4">This Prescription is for:</label>
                                      <div class="col-sm-6">
                                        <select name="family" class="form-control" id="selectFamily" style="width: 50%; display: inline-block;">
                                            <option value="">Self</option>
                                            <?php $__currentLoopData = App\User::findOrFail(Auth::user()->id)->family; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(isset($family)): ?>
                                                    <option <?php echo e($family->id == $fam->id ? 'selected' : ''); ?> value="<?php echo e($fam->id); ?>" ><?php echo e($fam->name); ?> (<?php echo e($fam->relation); ?>)</option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($fam->id); ?>" <?php echo e(old('family') == $fam->id ? 'selected' : ''); ?>><?php echo e($fam->name); ?> (<?php echo e($fam->relation); ?>)</option>

                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span style="display:inline-block">&nbsp;&nbsp;<a href="javascript:;" data-toggle="modal" data-target="#add-family" data-modal-effect="fadein" class="btn btn-primary"><i class="fa fa-plus"></i> Add Family Member</a> </span>
                                        <?php if($errors->has('family')): ?>
                                          <br>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('family')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                      </div>
                                    </div>

                                    

                                    <div class="form-group" id="file">
                                      <label class="control-label col-sm-4" for="edit_profile_photo">Select File *</label>
                                      <div class="col-sm-6">
                                        <h5>Select from Previous Prescription History</h5>
                                        <select id="history-prescription" name="fileid[]" class="form-control" multiple="multiple" style="height:180px" >
                                          
                                          

                                          <?php $__currentLoopData = $prescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prescription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($prescription->status == 'active'): ?>
                                            <option value="<?php echo e($prescription->id); ?>" ><?php echo e(date('d M Y',strtotime($prescription->created_at))); ?> |  <?php echo e($prescription->title); ?>  </option>
                                            <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        

                                          
                                          
                                      </select> 
                                           
                                      <br/> 


                                        <label class="g-color-gray-dark-v2 g-font-size-13">OR, Select Fresh Prescription(s) (Can be Multiple)</label>
                                        
                                        <input type="file" name="filename[]" class="form-control" multiple >
                                          <div class="input-group control-group increment" >
                                            
                                            
                                          <p>File type: jpeg,jpg,png,pdf</p>

                                          
                                          
                                       

                                      </div>
                                      
                                    </div>

                                    <div class="form-group">
                                      <label class="control-label col-sm-4" for="additional_info">Additional Information <span></span></label>
                                      <div class="col-sm-6">
                                        <textarea class="form-control" name="additional_info" id="additional_info" placeholder="Enter Additional Information (if any)"><?php echo e(old('additional_info')); ?></textarea>
                                        <?php if($errors->has('additional_info')): ?>
                                          <span class="invalid-feedback" role="alert">
                                              <strong><?php echo e($errors->first('additional_info')); ?></strong>
                                          </span>
                                        <?php endif; ?>
                                      </div>
                                      
                                    </div>

                                    

                                    <hr>
                                    <div class="add-product-footer">
                                        <button name="add_product_btn" type="submit" class="btn add-product_btn">Submit</button>
                                    </div>
                                </form>
                              </div>

                            </div>

                          </div>

                        </div>
                    </div>
                </div>
            </div>
            <!-- Ending of Dashboard area --> 
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="add-family" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title text-center" id="myModalLabel">Add new Member</h4>
            </div>
            <div class="modal-body">

              <form class="form-horizontal" action="<?php echo e(route('user-family.store')); ?>" method="POST" id="form2">

                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                  <label class="control-label col-sm-4"> First Name *<span></span></label>
                  <div class="col-sm-6">
                    <input class="form-control" name="firstname" value="<?php echo e(old('name')); ?>" placeholder="First Name" required="" type="text" >
                    <?php if($errors->has('name')): ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($errors->first('name')); ?></strong>
                      </span>
                    <?php endif; ?>
                  </div>
                  
                </div>

                <div class="form-group">
                  <label class="control-label col-sm-4"> Middle Name <span></span></label>
                  <div class="col-sm-6">
                    <input class="form-control" name="middlename" value="<?php echo e(old('name')); ?>" placeholder="Middle Name"  type="text" >
                    <?php if($errors->has('name')): ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($errors->first('name')); ?></strong>
                      </span>
                    <?php endif; ?>
                  </div>
                  
                </div>

                <div class="form-group">
                  <label class="control-label col-sm-4">Last Name *<span></span></label>
                  <div class="col-sm-6">
                    <input class="form-control" name="lastname" value="<?php echo e(old('name')); ?>" placeholder="Last Name"  type="text" >
                    <?php if($errors->has('name')): ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($errors->first('name')); ?></strong>
                      </span>
                    <?php endif; ?>
                  </div>
                  
                </div>

                <div class="form-group">
                    <label class="control-label col-sm-4"> Date of Birth *<span></span></label>
                    <div class="col-sm-6">
                      <input class="form-control" name="dob" value="<?php echo e(old('dob')); ?>" placeholder="Dob" required="" type="date" >
                      
                    </div>
                    
                </div>

                <div class="form-group">
                    <label class="control-label col-sm-4"> Gender *<span></span></label>
                    <div class="col-sm-6">
                      <select class="form-control" name="gender" required="" >
                        <option value="" <?php echo e(!old('gender') ? 'selected' : ''); ?> disabled>Choose an option</option>
                        <option value="Male" <?php echo e(old('gender') == 'Male' ? 'selected' : ''); ?>>Male</option>
                        <option value="Female" <?php echo e(old('gender') == 'Female' ? 'selected' : ''); ?>>Female</option>
                        <option value="Other" <?php echo e(old('gender') == 'Other' ? 'selected' : ''); ?>>Other</option>
                      </select>
                      <?php if($errors->has('gender')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('gender')); ?></strong>
                        </span>
                      <?php endif; ?>
                    </div>
                    
                </div>

                <div class="form-group">
                    <label class="control-label col-sm-4"> Relation *<span></span></label>
                    <div class="col-sm-6">
                      <input class="form-control" name="relation" value="<?php echo e(old('relation')); ?>" placeholder="Relation" required="" type="text">
                      <?php if($errors->has('relation')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('relation')); ?></strong>
                        </span>
                      <?php endif; ?>
                    </div>
                    
                </div>

                <div class="form-group">
                  <label class="control-label col-sm-4">Email<span></span></label>
                  <div class="col-sm-6">
                    <input class="form-control" name="email" value="<?php echo e(old('email')); ?> " placeholder="Email"  type="text" >
                  
                  </div>
                  
                </div>

                <div class="form-group">
                  <label class="control-label col-sm-4">Phone Number<span></span></label>
                  <div class="col-sm-6">
                    <input class="form-control" name="phone" value="<?php echo e(old('phone')); ?>" placeholder="phone number"  type="text" >
                
                  </div>
                  
                </div>

                <hr>
                <div class="add-product-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>

                  <button name="add_product_btn" type="submit" class="btn btn-success">Submit</button>
                </div>
              </form>
            </div>
        </div>
    </div>
  </div>

  <div class="modal fade locationModal" ng-app="locationSelector" ng-controller="LocationController" tabindex="-1" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog" role="document">
      <div class="modal-content" style="margin-top: 0;">
        <div class="modal-header text-center" style="border-bottom: none;padding-bottom: 0">
            <h4><strong>SET A LOCATION</strong></h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <i class="fa fa-times"></i>
            </button>
        </div>
        <h6 style="margin-left: 15px; font-size:18px;">Drag the pin to your exact location</h6>
        <h6 style="margin-left: 15px; font-size:18px;">Or, Simply type your address below.</h6>

        <div class="modal-body text-center">
          <div class="input-group g-pb-13 g-px-0 g-mb-10" style="display:inline-flex;">
            
            <input 
              places-auto-complete size=80
              types="['establishment']"
              component-restrictions="{country:'np'}"
              on-place-changed="placeChanged()"
              id="googleLocation" 
              ng-model="address.Address" 
              class="form-control g-brd-none g-brd-bottom g-brd-black g-brd-primary--focus g-color-black g-bg-transparent rounded-0" type="text" placeholder="Select Area" autocomplete="off" style="background-color:#d8f4ff;">
              
            <button class="btn  u-btn-neutral rounded-0" type="button" ng-click="getLocation()"><i class="fa fa-crosshairs"></i></button>
          </div>
          <br/>
          
          <p ng-if="error" style="color:red;text-align: left">{{ error }}</p>

          

          <ng-map center="[27.7041765,85.3044636]" zoom="15" draggable="true">
              <marker position="27.7041765,85.3044636" title="Drag Me!" draggable="true" on-dragend="dragEnd($event)"></marker>
          </ng-map>
      </div>
        <div class="modal-footer" style="border-top: none; text-align: center; display: block;">
          <button type="button" ng-disabled="!isValidGooglePlace" class="btn btn-primary" style="width:100%" ng-click="confirmLocation()">Confirm</button>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script type="text/javascript">
// $( document ).ready(function() {
//     console.log( "ready!" );
//       $( "#form2" ).submit(function( event ) {
//          event.preventDefault();
//          var hasInput=false;
//           $('.f').each(function () {
//            if($(this).val()  !== ""){
//             hasInput=true;
//            }
//           }); 
//           console.log(hasInput);
//           if(!hasInput){
//             alert("need fileinput");
//            }else{
//               alert("good input");
//            }
//       }); 
// });


  function uploadclick(){
      $("#uploadFile").click();
      $("#uploadFile").change(function(event) {
          readURL(this);
          $("#uploadTrigger").html($("#uploadFile").val());
      });

  }

  function readURL(input) {
      if (input.files && input.files[0]) {
          var reader = new FileReader();
          reader.onload = function (e) {
          }
          reader.readAsDataURL(input.files[0]);
      }
  }

  $("#reminderCheck").change(function() {
      if(this.checked) {
          $("#reminderSection").show();
          $('.reminderCheck').attr('required','required')
      }
      else
      {
          $("#reminderSection").hide();
          $('.reminderCheck').removeAttr('required')

      }
  });
</script>

<script type="text/javascript">
    
  $(document).ready(function() {

    $(".btn-success").click(function(){ 
        var html = $(".clone").html();
        $(".increment").after(html);
    });

    $("body").on("click",".btn-danger",function(){ 
        $(this).parents(".control-group").remove();
    });

  });

</script>

<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.7.8/angular.min.js"></script>
<script src="/assets/front/js/ng-map.min.js"></script>
<script src="https://maps.google.com/maps/api/js?key=AIzaSyAcvyYLSF2ngh8GM7hX7EQ3dIcQGbGnx5Q&libraries=places"></script>
<script src="/assets/front/js/location.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>