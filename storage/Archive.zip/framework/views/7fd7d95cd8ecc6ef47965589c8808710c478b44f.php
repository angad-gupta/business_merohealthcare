<?php $__env->startSection('title','Upload Prescription'); ?>
<?php $__env->startSection('content'); ?>
  <div class="section-padding blog-wrap">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 g-mb-30">
          <!-- Icon Blocks -->
          <div class="media g-mb-15">
            <div class="d-flex mr-4">
              <span class="u-icon-v4 u-icon-v4-rounded-10 u-icon-v4-bg-primary g-color-white">
                <span class="u-icon-v4-inner">
                  <i class="icon-education-087 u-line-icon-pro"></i>
                </span>
              </span>
            </div>
            <div class="media-body">
              <h3 class="h5 g-color-black mb-15">Upload Prescription</h3>
              <p class="g-color-gray-dark-v4">Upload image of prescription given by your doctor.</p>
            </div>
          </div>
          <!-- End Icon Blocks -->
        </div>
      
        <div class="col-lg-4 g-mb-30">
          <!-- Icon Blocks -->
          <div class="media g-mb-15">
            <div class="d-flex mr-4">
              <span class="u-icon-v4 u-icon-v4-rounded-10 u-icon-v4-bg-primary g-color-white">
                <span class="u-icon-v4-inner">
                  <i class="icon-education-035 u-line-icon-pro"></i>
                </span>
              </span>
            </div>
            <div class="media-body">
              <h3 class="h5 g-color-black mb-15">Analyze</h3>
              <p class="g-color-gray-dark-v4">We analyze your prescription and process your order</p>
            </div>
          </div>
          <!-- End Icon Blocks -->
        </div>
      
        <div class="col-lg-4 g-mb-30">
          <!-- Icon Blocks -->
          <div class="media g-mb-15">
            <div class="d-flex mr-4">
              <span class="u-icon-v4 u-icon-v4-rounded-10 u-icon-v4-bg-primary g-color-white">
                <span class="u-icon-v4-inner">
                  <i class="icon-education-141 u-line-icon-pro"></i>
                </span>
              </span>
            </div>
            <div class="media-body">
              <h3 class="h5 g-color-black mb-15">Delivery</h3>
              <p class="g-color-gray-dark-v4">We deliver your medicine at your doorsteps.</p>
            </div>
          </div>
          <!-- End Icon Blocks -->
        </div>
      </div>
      <div class="row justify-content-center">
        <div class="col-lg-12" style="background: white; padding:1rem 3rem">
          <h3 class="g-color-black g-font-weight-600 text-center mb-5">Sucessfully Uploaded Prescription</h3>
          <h4 class="g-color-black g-font-weight-600 text-center mb-5">Thank you for your order.</h5>
            <h4 class="g-color-black g-font-weight-600 text-center mb-5">Our staff will be in touch with you.</h5>
          

          <div class="text-center">
           
          <a href="<?php echo e(route('front.index')); ?>" class="btn u-btn-primary g-font-weight-600 g-font-size-13 text-uppercase g-rounded-25 g-py-15 g-px-30 " role="button">Back to Home</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade locationModal" ng-app="locationSelector" ng-controller="LocationController" tabindex="-1" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog" role="document">
      <div class="modal-content" style="margin-top: 0;">
        <div class="modal-header text-center" style="border-bottom: none;padding-bottom: 0">
            <h4><strong>SET A LOCATION</strong></h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <i class="fa fa-times"></i>
            </button>
        </div>
        <h6 style="margin-left: 15px;">Drag the pin to your exact location</h6>
        <h6 style="margin-left: 15px;">Or, Simply type your address below.</h6>

        <div class="modal-body text-center">
            <div class="input-group g-pb-13 g-px-0 g-mb-10">
              
              <input 
                places-auto-complete size=80
                types="['geocode']"
                component-restrictions="{country:'np'}"
                on-place-changed="placeChanged()"
                id="googleLocation" 
                ng-model="address.Address" 
                class="form-control g-brd-none g-brd-bottom g-brd-black g-brd-primary--focus g-color-black g-bg-transparent rounded-0" type="text" placeholder="Select Area" autocomplete="off">
                
              <button class="btn  u-btn-neutral rounded-0" type="button" ng-click="getLocation()"><i class="fa fa-crosshairs"></i></button>
            </div>
            
            <p ng-if="error" style="color:red;text-align: left">{{ error }}</p>

            

            <ng-map center="[27.7041765,85.3044636]" zoom="15" draggable="true">
                <marker position="27.7041765,85.3044636" title="Drag Me!" draggable="true" on-dragend="dragEnd($event)"></marker>
            </ng-map>
        </div>
        <div class="modal-footer" style="border-top: none; text-align: center; display: block;">
          <button type="button" ng-disabled="!isValidGooglePlace" class="btn btn-primary" style="width:100%" ng-click="confirmLocation()">Confirm</button>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.7.8/angular.min.js"></script>
  <script src="/assets/front/js/ng-map.min.js"></script>
  <script src="https://maps.google.com/maps/api/js?key=AIzaSyAcvyYLSF2ngh8GM7hX7EQ3dIcQGbGnx5Q&libraries=places"></script>
  <script src="/assets/front/js/location.js"></script>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>