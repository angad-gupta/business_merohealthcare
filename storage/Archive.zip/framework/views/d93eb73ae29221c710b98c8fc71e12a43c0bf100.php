<?php $__env->startSection('content'); ?>
    <!-- Starting of Login/registration area -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <div class="section-padding login-wrap">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2 col-xs-12">
          <div class="login-tab">
            <ul class="nav nav-tabs">
              <li class="active"><a data-toggle="tab" href="#login"><?php echo e($lang->signin); ?></a></li>
              <li><a data-toggle="tab" href="#signup"><?php echo e($lang->signup); ?></a></li>
            </ul>
            
            <div class="tab-content">
              <div id="login" class="tab-pane fade in active">
                <div class="login-title text-center">
                  <h3><?php echo e($lang->signin); ?></h3>
                </div>

                <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php if(Session::has('error')): ?>
                  <div class="alert alert-danger validation">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <p><?php echo e(Session::get('error')); ?></p>
                  </div>
                <?php endif; ?>

                <div class="login-form">
                  <form action="<?php echo e(route('user-login-submit')); ?>" method="POST">
                              <?php echo e(csrf_field()); ?>


                    <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                      <label for="login_email"><?php echo e($lang->doeml); ?></label>
            <input type="email" name="email" class="form-control" id="login_email" placeholder="<?php echo e($lang->doeml); ?>" required>
                    </div>
                    <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                      <label for="login_pwd"><?php echo e($lang->sup); ?></label>
            <input type="password" name="password" class="form-control" id="login_pwd" placeholder="<?php echo e($lang->sup); ?>" required>
                    </div>

                    <div class="row forgot-area">
                        <div class="col-md-6 col-sm-6">
                          <label class="">
                            <input class="" type="checkbox" name="remember" id="remember" value="1" <?php echo e(old('remember') ? 'checked' : ''); ?> />
                            
                            Keep signed in
                          </label>
                        </div>
                        <div class="col-md-6 col-sm-6 text-right">
                          <a href="<?php echo e(route('user-forgot')); ?>" target="_blank"><?php echo e($lang->fpw); ?></a>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-default btn-block"><?php echo e($lang->sie); ?></button>
                    
                    <?php if($sl->fcheck == 1  || $sl->gcheck == 1): ?>
                    <div class="login-social-btn-area">

                        <?php if($sl->fcheck ==1): ?>
                      <a href="<?php echo e(route('social-provider','facebook')); ?>" class="social-btn"><i class="fa fa-facebook"></i> <span><?php echo e($lang->facebook_login); ?></span></a>
                        <?php endif; ?>
                        <?php if($sl->gcheck ==1): ?>
                      <a href="<?php echo e(route('social-provider','google')); ?>" class="social-btn last-child"><i class="fa fa-google"></i> <span><?php echo e($lang->google_login); ?></span></a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                  </form>
                </div>
              </div>
              <div id="signup" class="tab-pane fade">
                <div class="login-title text-center">
                  <h3><?php echo e($lang->signup); ?></h3>
                </div>
                  <?php echo $__env->make('includes.form-error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="login-form">
                  <form action="<?php echo e(route('user-register-submit')); ?>" method="POST">
                      <?php echo e(csrf_field()); ?>


                      <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                          <label for="reg_email"><?php echo e($lang->doeml); ?> <span>*</span></label>
                          <input class="form-control" placeholder="<?php echo e($lang->doeml); ?>" type="email" name="email" id="reg_email" required>
                      </div>
                      <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                          <label for="reg_name"><?php echo e($lang->fname); ?> <span>*</span></label>
                          <input class="form-control" placeholder="<?php echo e($lang->fname); ?>" type="text" name="name" id="reg_name" required>
                      </div>
                      <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                          <label for="reg_Pnumber"><?php echo e($lang->doph); ?> <span>*</span></label>
                          <input class="form-control" placeholder="<?php echo e($lang->doph); ?>" type="text" name="phone" id="reg_Pnumber" required>
                      </div>
                      <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                          <label for="reg_Padd"><?php echo e($lang->doad); ?> <span>*</span></label>
                          <input class="form-control" placeholder="<?php echo e($lang->doad); ?>" type="text" name="address" id="reg_Padd" required>
                      </div>
                      <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                          <label for="reg_password"><?php echo e($lang->sup); ?> <span>*</span></label>
                          <input class="form-control" placeholder="<?php echo e($lang->sup); ?>" type="password" name="password" id="reg_password" required>
                      </div>
                      <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                          <label for="confirm_password"><?php echo e($lang->sucp); ?> <span>*</span></label>
                          <input class="form-control" placeholder="<?php echo e($lang->sucp); ?>" type="password" name="password_confirmation" id="confirm_password" required>
                      </div>
                    <button type="submit" class="btn btn-default btn-block"><?php echo e($lang->spe); ?></button>
                  </form>
                </div>
              </div>
            </div>
          </div>    
                </div>
            </div>
        </div>
    </div>

    
    <!-- Ending of Login/registration area -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>