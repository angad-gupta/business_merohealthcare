<?php $__env->startSection('content'); ?>
<div class="right-side">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <!-- Starting of Dashboard Office Address -->
                        <div class="section-padding add-product-1">
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="add-product-box">
                                    <div class="product__header">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title">
                                                    <h2>Conversation with <?php echo e($conv->user->name); ?> <a href="<?php echo e(route('admin-message-index')); ?>" style="padding: 5px 12px;" class="btn add-back-btn"><i class="fa fa-arrow-left"></i> Back</a>
                            </h2>
                                                    <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Messages <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Conversations Details</p>
                                                </div>
                                            </div>
                                              <?php echo $__env->make('includes.notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </div>   
                                    </div>

                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard Office Address -->
                </div>
<div class="row">
                        <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                          <?php echo $__env->make('includes.form-error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <!-- Starting of Wrong Invoice area -->

                        <div class="section-padding support-ticket-wrapper padding-top-0">
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="panel panel-primary">
                                        <div class="panel-body">
                                            <?php $__currentLoopData = $conv->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($message->user_id != null): ?>
                                            <div class="single-reply-area user">
                                                <div class="row">
                                                    <div class="col-lg-2 col-lg-push-10 col-md-3 col-md-push-9 col-sm-3 col-sm-push-9 col-xs-4 col-xs-push-8">
                                                        <img class="img-circle" src="<?php echo e($message->conversation->user->photo != null ? asset('assets/images/'.$message->conversation->user->photo) : asset('assets/images/noimage.png')); ?>" alt="">
                                                        <p class="ticket-date"><?php echo e($message->conversation->user->name); ?></p>
                                                    </div>
                                                    <div class="col-lg-10 col-lg-pull-2 col-md-9 col-md-pull-3 col-sm-9 col-sm-pull-3 col-xs-8 col-xs-pull-4">
                                                        <p><?php echo e($message->message); ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php else: ?>
                                            <div class="single-reply-area">
                                                <div class="row">
                                                    <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4">
                                                        <img class="img-circle" src="<?php echo e(asset('assets/images/admin.jpg')); ?>" alt="">
                                                        <p class="ticket-date">Admin</p>
                                                    </div>
                                                    <div class="col-lg-10 col-md-9 col-sm-9 col-xs-8">
                                                        <p><?php echo e($message->message); ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                      <div class="panel-footer">
                                          <form action="<?php echo e(route('admin-message-store')); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                              <div class="form-group">
                                                <input type="hidden" name="conversation_id" value="<?php echo e($conv->id); ?>">
                                                  <textarea class="form-control" name="message" id="wrong-invoice" rows="5"  style="resize: vertical;" required placeholder="Message"></textarea>
                                              </div>
                                              <div class="form-group">
                                                  <button class="btn btn-primary invoice-btn">
                                                      Add Reply
                                                  </button>
                                              </div>
                                          </form>
                                      </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Ending of Wrong Invoice area -->
                        </div>
                    </div>                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>