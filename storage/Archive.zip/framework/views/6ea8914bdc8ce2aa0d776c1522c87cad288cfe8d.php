        
<?php $__env->startSection('content'); ?>
<style>
    .text-bold-800{
        font-weight: 800;
    }
</style>
    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard area -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="product__header" style="border-bottom: none;">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title">
                                                    <h2>Prescription Details <a href="<?php echo e(route('admin-prescription-show',$prescription->id)); ?>" style="padding: 5px 12px;" class="btn add-back-btn"><i class="fa fa-arrow-left"></i> Back</a> </h2>
                                                    <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Prescriptions <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Prescription Invoice</p>
                                                </div>
                                            </div>
                                            <?php echo $__env->make('includes.notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </div>   
                                    </div>

                                    <main>

                                        <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                        <div class="order-table-wrap">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div class="table-responsive">
                                                        <table class="table">
                                                            <tbody>
                                                                <tr class="tr-head">
                                                                    <th class="order-th" width="45%">Prescription Details</th>
                                                                    <th width="10%"></th>
                                                                    <th class="order-th" width="45%"></th>
                                                                </tr>

                                                                <tr>
                                                                    <th width="45%">Ordered By</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo $prescription->user_id ? '<a href="'.route('admin-user-show',$prescription->user_id).'" target="_blank">'.$prescription->user->name.'</a>' : 'Guest'; ?></td>
                                                                </tr>
                                                                
                                                                <tr>
                                                                    <th width="45%">Ordered Date</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e(date('d-M-Y H:i:s a',strtotime($prescription->created_at))); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th width="45%">Prescription File</th>
                                                                    <th width="10%">:</th>
                                                                    <th width="45%">
                                                                        <?php $__currentLoopData = $prescription->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                        <a href="<?php echo e(route('admin-prescription-file',[$prescription->id,$file->file,$file->id])); ?>" target="_blank"><?php echo e($file->file); ?>  </a>
                                                                       <br/>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                                                    </th>
                                                                </tr>

                                                                <tr>
                                                                    <th width="45%">Status</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%">
                                                                        <button class="btn btn-danger product-btn dropdown-toggle btn-xs" type="button" data-toggle="dropdown" style="font-size: 14px;
                                                            
                                                                            <?php if($prescription->status == "completed"): ?>
                                                                            <?php echo e("background-color: #01c004;"); ?>

                                                                            <?php elseif($prescription->status == "processing"): ?>
                                                                            <?php echo e("background-color: #02abff;"); ?>

                                                                            <?php elseif($prescription->status == "declined"): ?>
                                                                            <?php echo e("background-color: #d9534f;"); ?>

                                                                            <?php else: ?>
                                                                            <?php echo e("background-color: #ff9600;"); ?>

                                                                            <?php endif; ?>
                                                                        
                                                                        "><?php echo e(ucfirst($prescription->status)); ?> <span class="caret"></span></button>
                                                                            <ul class="dropdown-menu" style="position: unset;">
                                                                                <li><a href="javascript:;" data-href="<?php echo e(route('admin-prescription-status',['id1' => $prescription->id, 'status' => 'processing'])); ?>" data-toggle="modal" data-target="#confirm-delete">Processing</a></li>
                                                                                <li><a href="javascript:;" data-href="<?php echo e(route('admin-prescription-status',['id1' => $prescription->id, 'status' => 'completed'])); ?>" data-toggle="modal" data-target="#confirm-delete">Completed</a></li>
                                                                                <li><a href="javascript:;" data-href="<?php echo e(route('admin-prescription-status',['id1' => $prescription->id, 'status' => 'declined'])); ?>" data-toggle="modal" data-target="#confirm-delete">Declined</a></li>
                                                                            </ul>
                                                                        </span>
                                                                    </td>
                                                                </tr>
    
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                
                                            </div>

                                            <div class="row">
                                                <div class="col-lg-12 col-sm-12">
                                                    <form action="<?php echo e(route('admin-prescription-invoice',$prescription->id)); ?>" method="POST">
                                                        <?php echo e(csrf_field()); ?>

                                                        <h4 style="padding: 5px; margin-bottom: 0">Items</h4>
                                                            
                                                        <p style="border-top: 2px solid #0165cbc2;width: 10%;margin-left: 5px;"></p>
                                                        <div class="table-responsive">
                                                            <?php 
                                                                $items = old('items') ? old('items') : ($invoice ? json_decode($invoice->items,true) : []);
                                                                
                                                                $total = 0;
                                                                $shipping_cost = old('shipping_cost') ? : ($invoice ? $invoice->shipping_cost : 0);
                                                             ?>
                                                            <table class="table">
                                                                <thead>
                                                                    <tr>
                                                                        <th scope="col" width="30%">Product Name</th>
                                                                        <th scope="col">Batch No.(s)</th>
                                                                        <th scope="col">Expiry Date(s)</th>
                                                                        <th scope="col" width="8%">Qty</th>
                                                                        <th scope="col" width="10%">Price per item</th>
                                                                        <th scope="col" width="10%">Total</th>
                                                                        <th scope="col" width="5%"></th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody class="item-list">
                                                                    <?php if($invoice): ?>
                                                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <tr>
                                                                                <td scope="row"><?php echo e($item['name']); ?></td>
                                                                                <td>
                                                                                    <?php if(isset($item['batch_nos'])): ?>
                                                                                        <?php $__currentLoopData = explode(",",$item['batch_nos']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                            <?php echo e($i); ?><br>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php endif; ?>
                                                                                </td>
                                                                                <td>
                                                                                    <?php if(isset($item['batch_nos'])): ?>

                                                                                        <?php $__currentLoopData = explode(",",$item['exp_dates']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                            <?php echo e($i); ?><br>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php endif; ?>
                                                                                </td>
                                                                                
                                                                                <td>
                                                                                    <?php echo e($item['qty']); ?>

                                                                                </td>
                                                                                <td><?php echo e($item['price']); ?></td>
                                                                                <td style="vertical-align: middle;">Rs. <?php echo e($item['qty'] * $item['price']); ?></td>
                                                                            </tr>
                                                                            <?php 
                                                                                $total += $item['qty'] * $item['price']; 
                                                                             ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php else: ?>
                                                                        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                            <tr class="item-list-area">
                                                                                <input type="hidden" name="items[<?php echo e($loop->iteration - 1); ?>][id]" value="<?php echo e($item['id']); ?>" id="item-id-<?php echo e($loop->iteration - 1); ?>"/>
                                                                                <td scope="row"><input class="form-control typeahead" name="items[<?php echo e($loop->iteration - 1); ?>][name]" id="item-name-<?php echo e($loop->iteration - 1); ?>" placeholder="Product Name" type="text" value="<?php echo e($item['name']); ?>" autocomplete="off" required></td>
                                                                                <td><textarea rows="1" class="form-control" name="items[<?php echo e($loop->iteration - 1); ?>][batch_nos]" id="item-batch-<?php echo e($loop->iteration - 1); ?>" placeholder="Separated By ','"></textarea></td>
                                                                                <td><textarea rows="1" class="form-control" name="items[<?php echo e($loop->iteration - 1); ?>][exp_dates]" id="item-exp-<?php echo e($loop->iteration - 1); ?>" placeholder="Separated By ','"></textarea></td>
                                                                                <td>
                                                                                    <input class="form-control toupdate" name="items[<?php echo e($loop->iteration - 1); ?>][qty]" id="item-qty-<?php echo e($loop->iteration - 1); ?>" placeholder="Quantity" type="number" value="<?php echo e($item['qty']); ?>" min="1" required>
                                                                                </td>
                                                                                <td width="15%"><input class="form-control toupdate" name="items[<?php echo e($loop->iteration - 1); ?>][price]" id="item-price-<?php echo e($loop->iteration - 1); ?>" placeholder="Price" type="number" value="<?php echo e($item['price']); ?>" min="0" required></td>
                                                                                <td style="vertical-align: middle;">Rs. <span class="item-total" id="item-total-<?php echo e($loop->iteration - 1); ?>"><?php echo e($item['qty'] * $item['price']); ?></span></td>
                                                                                <td><button class="btn btn-danger item-close" type="button"><i class="fa fa-trash"></i></td>
                                                                            </tr>
                                                                            <?php 
                                                                                $total += $item['qty'] * $item['price']; 
                                                                             ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                            <tr class="item-list-area">
                                                                                <input type="hidden" name="items[0][id]" id="item-id-0" />
                                                                                <td scope="row"><input class="form-control typeahead" name="items[0][name]" id="item-name-0" placeholder="Product Name" type="text" value="" autocomplete="off" required></td>
                                                                                <td><textarea rows="1" class="form-control" name="items[0][batch_nos]" id="item-batch-0" placeholder="Separated By ','"></textarea></td>
                                                                                <td><textarea rows="1" class="form-control" name="items[0][exp_dates]" id="item-exp-0" placeholder="Separated By ','"></textarea></td>
                                                                                <td>
                                                                                    <input class="form-control toupdate" name="items[0][qty]" id="item-qty-0" placeholder="Quantity" type="number" value="1" min="1" required>
                                                                                </td>
                                                                                <td><input class="form-control toupdate" name="items[0][price]" id="item-price-0" placeholder="Price" type="number" value="0" min="0" required></td>
                                                                                <td width="15%" style="vertical-align: middle;">Rs. <span class="item-total" id="item-total-0">0.00</span></td>
                                                                                <td><button class="btn btn-danger item-close" type="button"><i class="fa fa-trash"></i></td>
                                                                            </tr>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                </tbody>
                                                                <?php if(!$invoice): ?>
                                                                    <button style="float:right" class="btn btn-success featured-btn" type="button" name="add-item-btn" id="add-item-btn"><i class="fa fa-plus"></i> Add </button>
                                                                <?php endif; ?>
                                                            
                                                                <tfoot>
                                                                    <tr>
                                                                        
                                                                        <td colspan="5" style="text-align: right;vertical-align: middle;border:0" class="text-bold-800">Sub Total</td>
                                                                        <td class="text-xs-right" style="border:0">Rs. <span id="subtotal"><?php echo e($total); ?></span></td>
                                                                    </tr>
                                                                    
                                                                    <tr>
                                                                        
                                                                        <td colspan="5" style="text-align: right;vertical-align: middle;border:0" class="text-bold-800">Delivary Fee</td>
                                                                        <?php if($invoice): ?>
                                                                            <td class=" text-xs-right" style="border:0">Rs. <?php echo e($shipping_cost); ?></td>
                                                                        <?php else: ?>
                                                                            <td class=" text-xs-right" style="border:0"> <input class="form-control" type="number"  name="shipping_cost" id="shipping" min="0" value="<?php echo e($shipping_cost); ?>" /></td>
                                                                        <?php endif; ?>
                                                                    </tr>
                                
                                                                    <tr>
                                                                        
                                                                        <td colspan="5" style="text-align: right;vertical-align: middle;border:0" class="text-bold-800">Total</td>
                                                                        <td class="text-bold-800 text-xs-right" style="border:0"> Rs. <span id="totalAmount"><?php echo e($total + $shipping_cost); ?></span></td>
                                                                    </tr>
                                                                </tfoot>
                                                            </table>
                                                        
                                                        </div>

                                                        <h5>Note:</h5>
                                                        <?php if($invoice): ?>
                                                            <?php echo e($invoice->note ? : '-'); ?>

                                                        <?php else: ?>
                                                            <textarea class="form-control" name="note" ><?php echo e(old('note') ? : ($invoice ? $invoice->note : '')); ?></textarea>
                                                            <div class="text-center" style="margin:30px">
                                                                <button class="btn btn-primary"><i class="fa fa-file"></i> Save Invoice</button>
                                                            </div>
                                                        <?php endif; ?>
                                                        
                                                    </form>
                                                </div>

                                            </div>
                                        </div>
                                        
                                        <br>
                                        
                                    </main>
                                    <hr>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard area --> 
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="/assets/admin/js/bootstrap3-typeahead.js"></script>
    <script type="text/javascript">
        
        var total = <?php echo e($total + $shipping_cost); ?>;
        var shipping_cost = <?php echo e($shipping_cost); ?>;
        
        $(document).on('click','#add-item-btn',function() {
            var index = $('.item-list').children().length;      
                        
            $(".item-list").append('<tr class="item-list-area">'+
                    '<input type="hidden" name="items['+index+'][id]" id="item-id-'+index+'" />'+
                    '<td scope="row"><input class="form-control typeahead" name="items['+index+'][name]" id="item-name-'+index+'" placeholder="Product Name" type="text" value="" autocomplete="off" required></td>'+
                    '<td><textarea rows="1" class="form-control" name="items['+index+'][batch_nos]" id="item-batch-'+index+'" placeholder="Separated By \',\'"></textarea></td>'+
                    '<td><textarea rows="1" class="form-control" name="items['+index+'][exp_dates]" id="item-exp-'+index+'" placeholder="Separated By \',\'"></textarea></td>'+
                    '<td>'+
                    '    <input class="form-control toupdate" name="items['+index+'][qty]" id="item-qty-'+index+'" placeholder="Quantity" type="number" value="1" min="1" required>'+
                    '</td>'+
                    '<td><input class="form-control toupdate" name="items['+index+'][price]" id="item-price-'+index+'" placeholder="Price" type="number" value="0" min="0" required></td>'+
                    '<td style="vertical-align: middle;">Rs. <span class="item-total" id="item-total-'+index+'">0.00</span></td>'+
                    '<td><button class="btn btn-danger item-close" type="button"><i class="fa fa-trash"></i></td>'+
                '</tr>'
            );

        });

        $(document).on('click', '.item-close' ,function() {
            var input_id = $(this).parent().parent().find('.item-total').attr('id').split('-');
            var item_id = parseInt(input_id[input_id.length-1]);
            total -= parseFloat($('#item-total-' + item_id).text());
            
            $('#totalAmount').text(total);
            $('#subtotal').text(total - shipping_cost);

            $(this.parentNode.parentNode).hide();
            $(this.parentNode.parentNode).remove();

            if (isEmpty($('.item-list'))) {
                $(".item-list").append('<tr class="item-list-area">'+
                    '<input type="hidden" name="items[0][id]" id="item-id-0" />'+
                    '<td scope="row"><input class="form-control typeahead" name="items[0][name]" id="item-name-0" placeholder="Product Name" type="text" value="" autocomplete="off" required></td>'+
                    '<td><textarea rows="1" class="form-control" name="items[0][batch_nos]" id="item-batch-0" placeholder="Separated By \',\'"></textarea></td>'+
                    '<td><textarea rows="1" class="form-control" name="items[0][exp_dates]" id="item-exp-0" placeholder="Separated By \',\'"></textarea></td>'+
                    '<td>'+
                    '    <input class="form-control toupdate" name="items[0][qty]" id="item-qty-0" placeholder="Quantity" type="number" value="1" min="1" required>'+
                    '</td>'+
                    '<td><input class="form-control toupdate" name="items[0][price]" id="item-price-0" placeholder="Price" type="number" value="0" min="0" required></td>'+
                    '<td style="vertical-align: middle;">Rs. <span class="item-total" id="item-total-0">0.00</span></td>'+
                    '<td><button class="btn btn-danger item-close" type="button"><i class="fa fa-trash"></i></td>'+
                '</tr>');
            }

        });

        function isEmpty(el){
            return !$.trim(el.html())
        }

        $(document).on('click', '.typeahead', function() {
            if(!$(this).attr('id')) return;
            var input_id = $(this).attr('id').split('-');

            var item_id = parseInt(input_id[input_id.length-1]);

            $(this).typeahead({
                minLength: 3,
                displayText:function (data) {
                    return data.name + ' ( ' + data.orig_stock + ' in stock )';
                },
                source: function (query, process) {
                    $.ajax({
                        url: '/json/search',
                        type: 'GET',
                        dataType: 'JSON',
                        data: 'query=' + query,
                        success: function(data) {
                            return process(data);
                        }
                    });
                },
                afterSelect: function (data) {
                    this.$element[0].value = data.name;

                    var prev = parseFloat($('#item-total-' + item_id).text());

                    $('#item-id-' + item_id).val(data.id);
                    $('#item-qty-' + item_id).val('1');
                    $('#item-qty-' + item_id).attr('max',data.orig_stock);
                    $('#item-price-' + item_id).val(data.cprice);

                    // This event Select2 Stylesheet
                    $('#item-price-' + item_id).trigger('focusout');
                    $('#item-total-' + item_id).html(data.cprice);

                    total = total - prev + parseFloat(data.cprice);
            
                    $('#totalAmount').text(total);
                    $('#subtotal').text(total - shipping_cost);

                }
            });
        });

        $(document).on('change', '.typeahead', function() {
            var current = $(this).typeahead("getActive");

            var input_id = $(this).attr('id').split('-');
            var item_id = parseInt(input_id[input_id.length-1]);

            if(current){
                if (current.name != $(this).val()) {
                    $('#item-id-' + item_id).val('');
                    $('#item-qty-' + item_id).removeAttr('max');

                }else
                    $('#item-id-' + item_id).val(current.id);

            } else {
                $('#item-id-' + item_id).val('');
                $('#item-qty-' + item_id).removeAttr('max');

            }
            
            
        });

        $('.item-list').on('change', '.toupdate', function() {
            
            var input_id = $(this).attr('id').split('-');

            var item_id = parseInt(input_id[input_id.length-1]);

            var qty = parseInt($('#item-qty-' + item_id).val());
            var price = parseFloat($('#item-price-' + item_id).val()).toFixed(2);

            if(!isNaN(qty) && !isNaN(price)){
                var prev = parseFloat($('#item-total-' + item_id).text());
                
                $('#item-total-' + item_id).html(qty*price);

                total = total - prev + qty*price;
            
                $('#totalAmount').text(total);
                $('#subtotal').text(total - shipping_cost);

            } 
        });

        $('#shipping').on('change', function() {
            var prev = shipping_cost;
            shipping_cost = parseInt($('#shipping').val());

            if(!isNaN(shipping_cost)){

                total = total - prev + shipping_cost;
                
                $('#totalAmount').text(total);
                $('#subtotal').text(total - shipping_cost);
            }else{
                $('#shipping').val(0);
                shipping_cost = 0;

            }
        })

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>