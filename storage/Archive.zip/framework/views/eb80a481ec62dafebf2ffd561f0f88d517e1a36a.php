<?php $__env->startSection('title','My Family'); ?>
<?php $__env->startSection('styles'); ?>
  <style>
    .invalid-feedback{
      color: red
    }

    @media(max-width:768px){
    #h5text{
      margin-top:10px !important;
    }
    }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php 

  $now = Carbon\Carbon::now()->format('Y-m-d  ');

   ?>
  <div class="right-side">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <!-- Starting of Dashboard data-table area -->
          <div class="section-padding add-product-1">
            <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="add-product-box">
                  <div class="product__header">
                      <div class="row represcription-xs">
                          <div class="col-lg-8 col-md-5 col-sm-5 col-xs-12">
                              <div class="product-header-title">
                                  <h2>My Family</h2>
                                  <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Family</p>
                              </div>
                          </div>
                            <?php echo $__env->make('includes.user-notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                      </div>   
                  </div>
                  <div>

                    
                    <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="table-responsive">
                          <table id="product-table_wrapper" class="table table-striped table-hover products dt-responsive" cellspacing="0" width="100%">
                            <thead>
                              <tr class="table-header-row">
                                <th>#</th>
                                <th>Name</th>
                                <th>Age</th>
                                <th>Gender</th>
                                <th>Relation</th>
                                
                                <th>Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              <?php $__currentLoopData = $family; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td><?php echo e($loop->iteration); ?></td>
                                  <td><?php echo e($member->name); ?></td>
                                  <td><?php echo e(\Carbon\Carbon::parse($member->dob)->diff(\Carbon\Carbon::now())->format('%y years')); ?></td>
                                  <td><?php echo e($member->gender); ?></td>
                                  <td><?php echo e($member->relation); ?></td>
                                  
                                  <td>
                                    <input type="hidden" value="<?php echo e($member->id); ?>">
                                    <a href="javascript:;" data-href="<?php echo e(route('user-family.delete',$member->id)); ?>" data-toggle="modal" data-target="#confirm-delete" class="btn btn-danger product-btn"><i class="fa fa-trash"></i></a>
                                    <a href="<?php echo e(route('user-family.edit',$member->id)); ?>"  class="btn btn-primary product-btn"><i class="fa fa-edit"></i> Edit</a>
   
                                    <a href="<?php echo e(route('user-prescriptions.family-filter',$member->id)); ?>"  class="btn btn-primary product-btn"><i class="fa fa-list"></i> List Order</a>
                                    <a href="<?php echo e(route('user-prescriptions.family-create',$member->id)); ?>"  class="btn btn-primary product-btn"><i class="fa fa-plus"></i> New Order</a>
                                  <a href="javascript:;" data-href="<?php echo e(route('user-prescriptions.filestorefamily',[$user->id,$member->id])); ?>" data-toggle="modal" data-target="#add-file" class="btn btn-primary product-btn"><i class="fa fa-file"></i> Add File</a>
                                    <a href="<?php echo e(route('user-prescriptions.family-file-filter',$member->id)); ?>"  class="btn btn-primary product-btn"><i class="fa fa-eye"></i> View file</a>
                                 
                                  </td>
                 
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                    


                    

                    

                    <div class="container" style="display:none;">
                    <div class="table-responsive">
                      <table id="product-table_wrapper" class="table table-striped table-hover products dt-responsive" cellspacing="0" width="100%">
                        
                        <div class="container">
                        <h4>Famililes Prescriptions List </h4>
                        </div>
                        
                        <thead>
                          
                          <tr class="table-header-row">
                            <th>#</th>
                            <th>Filename</th>
                            <th>Family Name</th>
                            <th>Family Relation</th>
                            <th>Date</th>
                            
                            
                            
                          </tr>
                        </thead>
                        <tbody>

                          
                        <?php $__currentLoopData = $p_file; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($loop->iteration); ?></td>
                            <td><a href="<?php echo e(route('user-file',[$pf->file])); ?>"><?php echo e($pf->file); ?></a></td>
                           

                            <td>
                              <?php 
                              $family_name = App\Family::where('id','=', $pf->family_id)->get(); 
                              $user = Auth::user();
                               ?>

                              <?php if($pf->family_id == null): ?>
                              <?php echo e($user->name); ?>

                              <?php else: ?>
                                <?php $__currentLoopData = $family_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($fn->name); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php endif; ?>
                          </td>
                            <td>
                              
                                <?php 
                                $family_name = App\Family::where('id','=', $pf->family_id)->get(); 
                              
                                 ?>
                                <?php if($pf->family_id == null): ?>
                                 Self
                               <?php else: ?>
                                    <?php $__currentLoopData = $family_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($fn->relation); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                              
                              </td>

                                <td>
                                  <?php echo e($pf->created_at); ?>

                                </td>
                                

                              
                           
                              
                              
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                        </tbody>
                      </table>
                    </div>
                    </div>


                    
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Ending of Dashboard data-table area -->
      </div>
    </div>
  </div>

  <div class="modal fade" id="add-family" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                  <h4 class="modal-title text-center" id="myModalLabel">Add new Member</h4>
              </div>
              <div class="modal-body">

                <form class="form-horizontal" action="<?php echo e(route('user-family.store')); ?>" method="POST" id="form2">

                  <?php echo e(csrf_field()); ?>


                  

                  <div class="form-group">
                    <label class="control-label col-sm-4">First Name *<span></span></label>
                    <div class="col-sm-6">
                      <input class="form-control" name="firstname" value="<?php echo e(old('firstname')); ?>" placeholder="First Name" required="" type="text" >
                      <?php if($errors->has('name')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                      <?php endif; ?>
                    </div>
                    
                  </div>
                  <div class="form-group">
                    <label class="control-label col-sm-4">Middle Name <span></span></label>
                    <div class="col-sm-6">
                      <input class="form-control" name="middlename" value="<?php echo e(old('middlename')); ?>" placeholder="Middle Name" type="text" >
                      <?php if($errors->has('name')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                      <?php endif; ?>
                    </div>
                    
                  </div>
                  <div class="form-group">
                    <label class="control-label col-sm-4">Last Name *<span></span></label>
                    <div class="col-sm-6">
                      <input class="form-control" name="lastname" value="<?php echo e(old('lastname')); ?>" placeholder="LastName" type="text" >
                      <?php if($errors->has('name')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                      <?php endif; ?>
                    </div>
                  </div>
                    

                  

                  <div class="form-group">
                    <label class="control-label col-sm-4"> Date of Birth *<span></span></label>
                    <div class="col-sm-6">
                      <input class="form-control" placeholder="Date of Birth" type="date" name="dob" id="reg_name" required>
                        
                    </div>
                    
                </div>

                  <div class="form-group">
                      <label class="control-label col-sm-4"> Gender *<span></span></label>
                      <div class="col-sm-6">
                        <select class="form-control" name="gender" required="" >
                          <option value="" <?php echo e(!old('gender') ? 'selected' : ''); ?> disabled>Choose an option</option>
                          <option value="Male" <?php echo e(old('gender') == 'Male' ? 'selected' : ''); ?>>Male</option>
                          <option value="Female" <?php echo e(old('gender') == 'Female' ? 'selected' : ''); ?>>Female</option>
                          <option value="Other" <?php echo e(old('gender') == 'Other' ? 'selected' : ''); ?>>Other</option>
                        </select>
                        <?php if($errors->has('gender')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('gender')); ?></strong>
                          </span>
                        <?php endif; ?>
                      </div>
                      
                  </div>

                  <div class="form-group">
                      <label class="control-label col-sm-4"> Relation *<span></span></label>
                      <div class="col-sm-6">
                        <input class="form-control" name="relation" value="<?php echo e(old('relation')); ?>" placeholder="Relation" required="" type="text">
                        <?php if($errors->has('relation')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('relation')); ?></strong>
                          </span>
                        <?php endif; ?>
                      </div>
                      
                  </div>

                  <div class="form-group">
                    <label class="control-label col-sm-4">Email<span></span></label>
                    <div class="col-sm-6">
                      <input class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email"  type="text" >
                    
                    </div>
                    
                  </div>
  
                  <div class="form-group">
                    <label class="control-label col-sm-4">Phone Number<span></span></label>
                    <div class="col-sm-6">
                      <input class="form-control" name="phone" value="<?php echo e(old('phone')); ?>" placeholder="phone number"  type="text" >
                  
                    </div>
                    
                  </div>

                  <hr>
                  <div class="add-product-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>

                    <button name="add_product_btn" type="submit" class="btn btn-success" >Submit</button>
                  </div>
                </form>
              </div>
          </div>
      </div>
  </div>

  <div class="modal fade" id="add-many-family" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="width: 80%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title text-center" id="myModalLabel">Add new Members</h4>
            </div>
            <div class="modal-body">

              <form class="form-horizontal" action="<?php echo e(route('user-family.storemany')); ?>" method="POST" id="form2">

                <?php echo e(csrf_field()); ?>


                <table class="table">
                    <thead>
                      <tr>
                        <th scope="col" width="40%">Name</th>
                        <th scope="col" width="10%">Age</th>
                        <th scope="col" width="20%">Gender</th>
                        <th scope="col">Relation</th>
                        <th scope="col"></th>
                      </tr>
                    </thead>
                    <tbody class="family">
                      <?php 
                          $old_family = old('familys') ? : [];
                       ?>

                      
                      <?php $__empty_1 = true; $__currentLoopData = $old_family; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="family-area">
                          <td scope="row">
                              <input class="form-control" name="familys[<?php echo e($loop->iteration -1); ?>][name]" value="<?php echo e($item['name']); ?>" placeholder="Name" required="" type="text" >
                              <?php if($errors->familys->has('familys.'.($loop->iteration-1).'.name')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->familys->first('familys.'.($loop->iteration-1).'.name')); ?></strong>
                                </span>
                              <?php endif; ?>
                          </td>
                          <td scope="row">
                            <input class="form-control" name="familys[<?php echo e($loop->iteration -1); ?>][age]" placeholder="Age" type="number" value="<?php echo e($item['age']); ?>" min="1" step="1"></td>
                            <?php if($errors->familys->has('familys.'.($loop->iteration-1).'.age')): ?>
                              <span class="invalid-feedback" role="alert">
                                  <strong><?php echo e($errors->familys->first('familys.'.($loop->iteration-1).'.age')); ?></strong>
                              </span>
                            <?php endif; ?>
                          <td>
                            <select class="form-control" name="familys[<?php echo e($loop->iteration -1); ?>][gender]" required="" >
                              <option value="" <?php echo e(!$item['gender'] ? 'selected' : ''); ?> disabled>Choose an option</option>
                              <option value="Male" <?php echo e($item['gender'] == 'Male' ? 'selected' : ''); ?>>Male</option>
                              <option value="Female" <?php echo e($item['gender'] == 'Female' ? 'selected' : ''); ?>>Female</option>
                              <option value="Other" <?php echo e($item['gender'] == 'Other' ? 'selected' : ''); ?>>Other</option>
                            </select>
                            <?php if($errors->familys->has('familys.'.($loop->iteration-1).'.gender')): ?>
                              <span class="invalid-feedback" role="alert">
                                  <strong><?php echo e($errors->familys->first('familys.'.($loop->iteration-1).'.gender')); ?></strong>
                              </span>
                            <?php endif; ?>
                          </td>
                          <td>
                              <input class="form-control" name="familys[<?php echo e($loop->iteration -1); ?>][relation]" value="<?php echo e($item['relation']); ?>" placeholder="Relation" required="" type="text">
                              <?php if($errors->familys->has('familys.'.($loop->iteration-1).'.relation')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->familys->first('familys.'.($loop->iteration-1).'.relation')); ?></strong>
                                </span>
                              <?php endif; ?>
                          </td>
                          <td width="5%"><button class="btn btn-danger family-close" type="button"><i class="fa fa-trash"></i></td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr class="family-area">
                          <td scope="row">
                              <input class="form-control" name="familys[0][name]" value="<?php echo e(old('familys[0].name')); ?>" placeholder="Name" required="" type="text" >
                              
                          </td>
                          <td scope="row">
                            <input class="form-control" name="familys[0][age]" placeholder="Age" type="number" value="" min="1" step="1"></td>
                            
                          <td>
                            <select class="form-control" name="familys[0][gender]" required="" >
                              <option value="" <?php echo e(!old('gender') ? 'selected' : ''); ?> disabled>Choose an option</option>
                              <option value="Male" <?php echo e(old('gender') == 'Male' ? 'selected' : ''); ?>>Male</option>
                              <option value="Female" <?php echo e(old('gender') == 'Female' ? 'selected' : ''); ?>>Female</option>
                              <option value="Other" <?php echo e(old('gender') == 'Other' ? 'selected' : ''); ?>>Other</option>
                            </select>
                            
                          </td>
                          <td>
                              <input class="form-control" name="familys[0][relation]" value="<?php echo e(old('relation')); ?>" placeholder="Relation" required="" type="text">
                              
                          </td>
                          <td width="5%"><button class="btn btn-danger family-close" type="button"><i class="fa fa-trash"></i></td>
                        </tr>
                      <?php endif; ?>
                      
                    </tbody>
                  </table>

                  <div class="form-group">
                    <label class="control-label col-sm-3" for=""></label>
                    <div class="col-sm-12 text-center">
                      <button class="btn btn-default featured-btn" type="button" name="add-family-btn" id="add-family-btn"><i class="fa fa-plus"></i> Add More Field</button>
                    </div>
                  </div>

                <hr>
                <div class="add-product-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>

                  <button name="add_product_btn" type="submit" class="btn btn-success">Submit</button>
                </div>
              </form>
            </div>
        </div>
    </div>
  </div>

  <div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                  <h4 class="modal-title text-center" id="myModalLabel">Confirm Delete</h4>
              </div>
              <div class="modal-body">
                  <p class="text-center">You are about to delete.</p>
                  <p class="text-center">Do you want to proceed?</p>
              </div>
              <div class="modal-footer" style="text-align: center;">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                  <form class="btn-ok" action="" method="POST" style="display:inline-block">
                    <?php echo e(csrf_field()); ?>

                    <button type="submit" class="btn btn-danger">Delete</button>
                  </form>
              </div>
          </div>
      </div>
  </div>
  <div class="modal fade" id="add-file" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title text-center" id="myModalLabel">Add Prescription File</h4>
            </div>
            <div class="modal-body">
          
                <form class="btn-submit" method="POST" action="" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                

                <label class="g-color-gray-dark-v2 g-font-size-13">Prescription Title</label>
                  <div class="control-group ">
                    <input class="form-control" name="title" value="<?php echo e(old('title')); ?>" placeholder="Prescription Title"  type="text" required >
                  </div>
            
                  <br/>
         
     

                  <label class="g-color-gray-dark-v2 g-font-size-13">Family Prescription File Upload (Can be Multiple Files)</label>
                  <input type="file" name="filename[]" class="form-control" required multiple>
                  
                   
                     
                  
                        
                
                      <div class="control-group text-center">
                      <button type="submit" class="btn btn-primary" style="margin-top:15px;">Submit</button>
                      </div>

      
                </form>
         
            </div>
            
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">

  $( document ).ready(function() {
      $(".add-button").append('<div class="col-sm-4 add-product-btn text-right">'+
        '<a style="cursor: pointer;" href="javascript:;" data-toggle="modal" data-target="#add-family" data-effect="fadein" class="add-newProduct-btn email2">'+
        '<i class="fa fa-plus"></i> Add New Member</a>'+
        '</div>');  

    $('#confirm-delete').on('show.bs.modal', function(e) {
      
        $(this).find('.btn-ok').attr('action', $(e.relatedTarget).data('href'));
    }); 

    $('#add-file').on('show.bs.modal', function(e) {
      
      $(this).find('.btn-submit').attr('action', $(e.relatedTarget).data('href'));
  }); 

    $(document).on('click','#add-family-btn',function() {
      var index = $('.family').children().length;      
                  
      $(".family").append('<tr class="family-area">'+
        '<td scope="row">'+
            '<input class="form-control" name="familys['+index+'][name]" value="" placeholder="Name" required="" type="text" >'+
        '</td>'+
        '<td scope="row">'+
          '<input class="form-control" name="familys['+index+'][age]" placeholder="Age" type="number" value="" min="1" step="1"></td>'+
        '<td>'+
          '<select class="form-control" name="familys['+index+'][gender]" required="" >'+
            '<option value="" selected disabled>Choose an option</option>'+
            '<option value="Male">Male</option>'+
            '<option value="Female">Female</option>'+
            '<option value="Other">Other</option>'+
          '</select>'+
        '</td>'+
        '<td>'+
            '<input class="form-control" name="familys['+index+'][relation]" placeholder="Relation" required="" type="text">'+
        '</td>'+
        '<td width="5%"><button class="btn btn-danger family-close" type="button"><i class="fa fa-trash"></i></td>'+
      '</tr>');

    });   

    $(document).on('click', '.family-close' ,function() {
      
      $(this.parentNode.parentNode).hide();
      $(this.parentNode.parentNode).remove();

      if (isEmpty($('.family'))) {
        $(".family").append('<tr class="family-area">'+
          '<td scope="row">'+
              '<input class="form-control" name="familys[0][name]" value="" placeholder="Name" required="" type="text" >'+
          '</td>'+
          '<td scope="row">'+
            '<input class="form-control" name="familys[0][age]" placeholder="Age" type="number" value="" min="1" step="1"></td>'+
          '<td>'+
            '<select class="form-control" name="familys[0][gender]" required="" >'+
              '<option value="" selected disabled>Choose an option</option>'+
              '<option value="Male">Male</option>'+
              '<option value="Female">Female</option>'+
              '<option value="Other">Other</option>'+
            '</select>'+
          '</td>'+
          '<td>'+
              '<input class="form-control" name="familys[0][relation]" placeholder="Relation" required="" type="text">'+
          '</td>'+
          '<td width="5%"><button class="btn btn-danger family-close" type="button"><i class="fa fa-trash"></i></td>'+
        '</tr>');
      }
    });

    function isEmpty(el){
        return !$.trim(el.html())
    }
                                                                 
  });

</script>

<script type="text/javascript">
    
  $(document).ready(function() {

    // $(".btn-default").click(function(){ 
    //     var html = $(".clone").html();
    //     $(".increment").after(html);
    // });

    // $("body").on("click",".btn-danger",function(){ 
    //     $(this).parents(".control-group").remove();
    // });

  });

</script>

<?php if(count($errors) > 0): ?>
  <script>
    $('#add-family').modal('show');
  </script>
<?php elseif(count($errors->familys) > 0): ?>
  <script>
    $('#add-many-family').modal('show');
  </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>