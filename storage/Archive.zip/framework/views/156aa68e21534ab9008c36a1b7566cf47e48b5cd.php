

<?php $__env->startSection('styles'); ?>
<style type="text/css">
.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
    border-top: none;
}
.add-product-box {
    box-shadow: none;
}
.add-product-1
{
    padding-bottom: 30px;
}
</style>
<?php $__env->stopSection(); ?>
        
<?php $__env->startSection('content'); ?>
<div class="right-side">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <!-- Starting of Dashboard area -->
                        <div class="section-padding add-product-1">
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="add-product-box">
                                    <div class="product__header"  style="border-bottom: none;">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title">
                                                    <h2>Customer Details <a href="<?php echo e(route('admin-user-index')); ?>" style="padding: 5px 12px;" class="btn add-back-btn"><i class="fa fa-arrow-left"></i> Back</a></h2>
                                                    <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Customers <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Customer Details
                                                </div>
                                            </div>
                                              <?php echo $__env->make('includes.notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </div>   
                                    </div>
                                        <hr>

                        <table class="table" style="border-color: transparent;">
                            <tbody>
                            <tr>
                                <td width="49%" style="text-align: right;"><strong>Customer ID#</strong></td>
                                <td><?php echo e($user->id); ?></td>
                            </tr>
                            <tr>
                                <td width="49%" style="text-align: right;"><strong>Name:</strong></td>
                                <td><?php echo e($user->name); ?></td>
                            </tr>
                            <tr>
                                <td width="49%" style="text-align: right;"><strong>Email:</strong></td>
                                <td><?php echo e($user->email); ?></td>
                            </tr>
                            <?php if($user->phone != ""): ?>
                            <tr>
                                <td width="49%" style="text-align: right;"><strong>Phone:</strong></td>
                                <td><?php echo e($user->phone); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if($user->fax != ""): ?>
                            <tr>
                                <td width="49%" style="text-align: right;"><strong>Fax:</strong></td>
                                <td><?php echo e($user->fax); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if($user->address != ""): ?>
                            <tr>
                                <td width="49%" style="text-align: right;"><strong>Address:</strong></td>
                                <td><?php echo e($user->address); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if($user->city != ""): ?>
                            <tr>
                                <td width="49%" style="text-align: right;"><strong>City:</strong></td>
                                <td><?php echo e($user->city); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if($user->zip != ""): ?>
                            <tr>
                                <td width="49%" style="text-align: right;"><strong>Zip:</strong></td>
                                <td><?php echo e($user->zip); ?></td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <td width="49%" style="text-align: right;"><strong>Joined:</strong></td>
                                <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                            </tr>

                            </tbody>
                        </table>

                                    </div>
                                    <div class="text-center">
                                                      <input type="hidden" value="<?php echo e($user->email); ?>"><a style="cursor: pointer;" data-toggle="modal" data-target="#emailModal1" class="btn btn-primary email1"><i class="fa fa-send"></i> Contact Customer</a>
                                    </div>
                                </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard area --> 
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>