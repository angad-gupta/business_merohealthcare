<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="<?php echo e($seo->meta_keys); ?>">

    <title><?php echo $__env->yieldContent('title','Dashboard'); ?> | <?php echo e($gs->title); ?></title>
    <link href="<?php echo e(asset('assets/user/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/user/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/user/css/themify-icon.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/user/css/perfect-scrollbar.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/user/css/bootstrap-colorpicker.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/user/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/user/css/responsive.bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/user/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/user/css/responsive.css')); ?>" rel="stylesheet">
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/'.$gs->favicon)); ?>">

    <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-line/css/simple-line-icons.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-etlinefont/style.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-line-pro/style.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/icon-hs/style.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/slick-carousel/slick/slick.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/hs-megamenu/src/hs.megamenu.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/hamburgers/hamburgers.min.css">
  <link rel="stylesheet" href="/frontend-assets/main-assets/assets/vendor/animate.css">

        <style type="text/css">

@media  only screen and (max-width: 991px) and (min-width: 768px){
.dashboard-sidebar-area, .sidebar-menu-body {
    width: 32%;
}}

@media    and (max-width: 991px) and (min-width: 768px){}
#sidebar-width,  {
    width: 36% !important;
}}
        .form-control {
        box-shadow: inset 0px 0px 0px rgba(0,0,0,.075);            
        }
        .vendor-btn {
            display: inline-block !important;
            background-color: #00b16a !important;
            color: #ffffff !important;
            padding: 8px 25px !important;
            border-radius: 30px !important;
            margin-right: 20px !important;
            cursor: pointer;
            font-weight: 500 !important;
            transition: all 0.3s;
        }
        .pac-container{
            z-index: 1050 !important;
        }
        #sidebar-menu ul li a.vendor-btn:hover {
            background-color: #333333 !important;
        }

        .profile-order-content {
            width: 350px;
            padding: 20px;
            max-height: 300px;
            position: absolute;
            left: auto;
            background: #ffffff;
            box-shadow: 0 0 5px #cccccc;
            right: 0;
            z-index: 9999 !important;
            margin-top: 20px;
        }
        </style>
    <?php echo $__env->make('styles.admin-design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
<div class="dashboard-wrapper">
    <div class="left-side">
        <!-- Starting of Dashboard Sidebar menu area -->
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-right">
                    <button type="button" id="sidebarCollapse" class="navbar-btn">
                        <span></span>
                        <span></span>
                        <span></span>
                    </button>
                </div>
            </div>
        </nav>

        <div id="sidebar-width" class="dashboard-sidebar-area" >
            
            <img src="<?php echo e(asset('assets/images/sidebar_bg.jfif')); ?>" alt="">
           
            <div id="sidebar-width" class="sidebar-menu-body">
                <nav id="sidebar-menu">
                    <ul class="list-unstyled profile">
                        <li class="active">
                            <div class="row">
                                <?php if($lang->rtl == 1): ?>

                                <div class="col-lg-9 col-md-9 col-sm-9 col-xs-9">
                                    <a dir="rtl"><?php echo e(Auth::guard('user')->user()->name); ?>

                                        
                                        
                                    </a>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                            <?php if(Auth::guard('user')->user()->is_provider == 1): ?>
                            <a href="<?php echo e(route('front.index')); ?>"> <img src="<?php echo e(Auth::guard('user')->user()->photo ? Auth::guard('user')->user()->photo:asset('assets/images/user.png')); ?>" alt="profile image"></a>
                                    <?php else: ?>
                                    <a href="<?php echo e(route('front.index')); ?>"> <img src="<?php echo e(Auth::guard('user')->user()->photo ? asset('assets/images/'.Auth::guard('user')->user()->photo):asset('assets/images/user.png')); ?>" alt="profile image"></a>
                            <?php endif; ?>
                                </div>
                                <?php else: ?>
                                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                            <?php if(Auth::guard('user')->user()->is_provider == 1): ?>
                            <a href="<?php echo e(route('front.index')); ?>"> <img src="<?php echo e(Auth::guard('user')->user()->photo ? Auth::guard('user')->user()->photo:asset('assets/images/user.png')); ?>" alt="profile image"></a>
                                    <?php else: ?>
                                    <a href="<?php echo e(route('front.index')); ?>">  <img src="<?php echo e(Auth::guard('user')->user()->photo ? asset('assets/images/'.Auth::guard('user')->user()->photo):asset('assets/images/user.png')); ?>" alt="profile image"></a>
                                    <?php endif; ?>
                                </div>
                                <div class="col-lg-9 col-md-9 col-sm-9 col-xs-9" style="margin-top: 15px;">
                                    <a href="<?php echo e(route('front.index')); ?>"><?php echo e(Auth::guard('user')->user()->name); ?>

                                        <span><?php echo e(Auth::guard('user')->user()->email); ?> </span>
                                        
                                    </a>
                                </div>
                                <?php endif; ?>
                            </div>
                        </li>
                    </ul>
                    <ul class="list-unstyled components">
                        
                        <li>
                            <a href="<?php echo e(route('user-dashboard')); ?>"><i class="icon-home"></i> <?php echo e($lang->dashboard); ?></a>
                        </li>
                        <?php if(!Auth::guard('user')->user()->IsVendor()): ?> 
                            <li>
                                <a href="<?php echo e(route('user-family.index')); ?>"><i class="icon-real-estate-075 u-line-icon-pro"></i> Family</a>
                            </li>

                            
                        <?php endif; ?>

                        <?php 
                        $user = Auth::guard('user')->user();
                            
                         ?>

                        

                        

                        <li>
                            <a href="<?php echo e(route('user-wishlist')); ?>"><i class="icon-heart"></i> <?php echo e($lang->wish_list); ?></a>
                        </li>
                        
                        <li>
                            <a href="<?php echo e(route('user-messages')); ?>"><i class="fa fa-envelope-o"></i><?php echo e($lang->messages); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('user-orders')); ?>"><i class="fa fa-fw fa-usd" style="margin-right:0px;margin-left:0px;"></i><?php echo e($lang->purchased_item); ?></a>
                        </li>
                        <?php if(!Auth::guard('user')->user()->IsVendor()): ?> 
                            <li>
                                <a href="<?php echo e(route('user-lab-order-index')); ?>"><i class="icon-medical-010 u-line-icon-pro"></i> Lab Orders and Reports</a>
                            </li>
                        <?php endif; ?>
                        
                        
                        <?php if(Auth::guard('user')->user()->IsVendor()): ?> 
                            
                            <li>
                                <a href="<?php echo e(route('user-lab-prod-index')); ?>"><i class="fa fa-fw fa-medkit"></i><?php echo e($lang->vendor_products); ?></a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('vendor-lab-order-index')); ?>"><i class="fa fa-fw fa-money"></i><?php echo e($lang->vendor_orders); ?></a>
                            </li>
                            
                            <li>
                                <a href="#generalSettings" data-toggle="collapse" aria-expanded="false"><i class="fa fa-fw fa-cogs"></i> <?php echo e($lang->settings); ?></a>
                                <ul class="collapse list-unstyled submenu" id="generalSettings">
                                    
                                    <li><a href="<?php echo e(route('user-service-location')); ?>"><i class="fa fa-angle-<?php echo e($lang->rtl == 1 ? 'left':'right'); ?>"></i> Service Locations</a></li>
                                    
                                    
                                </ul>
                            </li>
                        <?php endif; ?>
                        

                    </ul>
                </nav>
            </div>
        </div>
        <!-- Ending of Dashboard Sidebar menu area -->
    </div>
    <?php echo $__env->yieldContent('content'); ?>
</div>

<?php if($lang->rtl == 1): ?>
<style type="text/css">
#sidebar-menu ul.profile a {text-align: right;}
    ul.profile li.active img {
        margin-left: -10px;
    }
.components a[aria-expanded="false"]::before, a[aria-expanded="true"]::before {
    right: auto;
    left: 20px;
    }
#sidebar-menu ul li a {
    text-align: right;
    direction: rtl;
}
#sidebar-menu ul li a i.fa {margin-right: 0;margin-left: 5px;}
</style>
<?php endif; ?>
<script src="<?php echo e(asset('assets/user/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/perfect-scrollbar.jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/jquery.canvasjs.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/bootstrap-colorpicker.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/dataTables.bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/notify.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/user-main.js')); ?>"></script>

<?php if(Auth::guard('user')->user()->IsVendor()): ?> 
    <script>
        setInterval(function(){
            $.ajax({
                    type: "GET",
                    url:"<?php echo e(URL::to('/json/vendor/order/notf')); ?>",
                    success:function(data){
                        $("#notf_order").html(data);
                    }
            }); 
        }, 5000);
    </script>
<?php endif; ?>

<script type="text/javascript">
        $(document).on("click", ".email2" , function(){
        $(".modal-backdrop, .modal.vendor").css('background-color','rgba(0,0,0,0)');
    });
    $(document).ready(function(){
        setInterval(function(){
                $.ajax({
                        type: "GET",
                        url:"<?php echo e(URL::to('/json/conv/notf')); ?>",
                        success:function(data){
                            $("#notf_conv").html(data);
                        }
                }); 
        }, 5000);
        
        
    });
            $(document).on("click", "#conv_notf" , function(){
                $("#notf_conv").html('0');
                $('.profile-notifi-content').load('<?php echo e(URL::to('conv/notf')); ?>');
            });

            $(document).on("click", "#order_notf" , function(){
                $("#notf_order").html('0');
                $('.profile-order-content').load('<?php echo e(URL::to('vendor/order/notf')); ?>');
            });
            $(document).on("click", "#conv_clear" , function(){

                $.ajax({
                    type: "GET",
                    url:"<?php echo e(URL::to('/json/conv/notf/clear')); ?>"
                }); 
            });
            $(document).on("click", "#order_clear" , function(){

                $.ajax({
                    type: "GET",
                    url:"<?php echo e(URL::to('/json/vendor/order/notf/clear')); ?>"
                }); 
            });
</script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
