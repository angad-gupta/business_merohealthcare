<?php $__env->startSection('title','My Cart - Lab'); ?>
<?php $__env->startSection('content'); ?>
<style>
  #lab{
  font-weight: 700 !important;
  color:#2385aa !important; 

}
    .section-padding {
    padding: 20px 0;
}
  .select2-selection__rendered{
    
    height:35px !important;
  }
  .select2-container--default .select2-selection--single .select2-selection__arrow {
    height: 26px;
    position: absolute;
    top: 9px !important;
    right: 1px;
    width: 20px;
}
.section-padding.product-shoppingCart-wrapper .table>thead>tr>th {
    padding: 10px 0px !important;
    text-align: left;
    color: #333;
}
.select2-container--default .select2-selection--single .select2-selection__rendered {
    /* color: #444; */
    line-height: 23px !important;
}
  .select2-selection__arrow{
    height:35px !important;
  }
  .select2-container .select2-selection--single {
    box-sizing: border-box;
    cursor: pointer;
    display: block;
    height: 35px !important;
    user-select: none;
    -webkit-user-select: none;
}
.section-padding.product-shoppingCart-wrapper .table>tbody>tr>td {
    padding: 10px 0;
    vertical-align: middle;
    color: #555;
    font-size: 16px;
    border: none;
    text-align: left;
}
.section-padding.product-shoppingCart-wrapper .table>thead>tr>th {
    padding: 30px 0px;
    text-align: left;
    color: #333;
}

.product-shoppingCart-wrapper .table>tfoot>tr>td {
    padding: 10px 0;
}
  </style>
  <link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" />
    <!-- Starting of ViewCart area -->
    <div class="section-padding product-shoppingCart-wrapper">
        <div class="container">
            <div class="row">
              <div class="col-lg-12">
                <div class="view-cart-title pull-right">
                  <a style="color:black;" href="<?php echo e(route('front.index')); ?>"><?php echo e(ucfirst(strtolower($lang->home))); ?></a>
                  <i class="fa fa-angle-right"></i>
                  <a style="color:black;" href="<?php echo e(route('lab.cart')); ?>">Lab Test</a>
                </div>
              </div>
              <div class="col-md-12 col-sm-12">
                <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
                <div class="table-responsive">
                  <table class="table " style="width:100%">
                    <thead>
                      <tr>
                        <th colspan="4"><?php echo e($lang->cproduct); ?></th>
                        <th><?php echo e($lang->cupice); ?></th>
                        <th><?php echo e($lang->cremove); ?></th>
                      </tr>
                    </thead>
                    <tbody id="testList">
                        <?php if(Session::has('lab_cart')): ?>
                          <?php echo $__env->make('lab::front.partials.cart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php else: ?>
                          <tr>
                            <td colspan="9"><h2 class="text-center"><?php echo e($lang->h); ?></h2></td>
                          </tr>
                        <?php endif; ?>
                    </tbody>
                    <tfoot>
                      <tr>
                        <td colspan="5">
                            <select class="js-example-basic" id="allTests" style="height:37px"><option></option></select>                          
                        </td>
                        <td colspan="4" style="text-align: center;">
                            <button class="btn btn-success" type="button" id="addTest" class="btn"><i class="fa fa-plus"></i> Add Test</button>                          
                        </td>
                      </tr>
                     
                    </tfoot>
                  </table>
                  
                  <?php if(Session::has('lab_cart')): ?>
                    <p class="g-font-size-17"><b><?php echo e($lang->vt); ?>:</b> 
                      <?php if($gs->sign == 0): ?>
                        <?php echo e($curr->sign); ?><span class="lab-total" id="grandtotal"><?php echo e(round($totalPrice * $curr->value, 2)); ?></span>
                      <?php else: ?>
                        <span class="lab-total" id="grandtotal"><?php echo e(round($totalPrice * $curr->value, 2)); ?></span><?php echo e($curr->sign); ?>

                      <?php endif; ?>
                    </p>
                    <?php if(Auth::guard('user')->check()): ?>
                      <?php if(Auth::guard('user')->user()->is_vendor == 0): ?>
                        <a href="<?php echo e(route('lab.checkout')); ?>" class="btn btn-primary"><?php echo e($lang->cpc); ?></a>
                      <?php else: ?>
                        <a data-toggle="modal" data-target="#invalidUserModal" href="javascript:;" class="btn btn-primary"><?php echo e($lang->cpc); ?></a>
                      <?php endif; ?>
                    <?php else: ?>
                      <a data-toggle="modal" data-target="#loginModal" href="javascript:;" class="btn btn-primary"><?php echo e($lang->cpc); ?></a>
                    <?php endif; ?>
                  <?php endif; ?>
                </div>
              </div>
            </div>
        </div>
    </div>
    <!-- Ending of ViewCart area -->
    
    <div class="modal fade" id="invalidUserModal" role="dialog">
        <div class="modal-dialog">
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header" style="margin-right:10px;">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
      
            </div>
      
            <div class="modal-body">
                <div class="row" style="margin: 15px;">
                  You cannot use vendor account to book lab tests. You must have a normal user account.<br><br>
                  <a href="<?php echo e(route('user-logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><i class="fa fa-fw fa-power-off"></i>Logout</a>
                  <form id="logout-form" action="<?php echo e(route('user-logout')); ?>" method="POST" style="display: none;">
                      <?php echo e(csrf_field()); ?>

                  </form>
                </div>
            </div>
          </div>
      </div>
      </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>
  <script type="text/javascript">
    var allTests = JSON.parse('<?php echo $tests ?>');

    $('#allTests').select2({
        placeholder: "Search Your Desired Test",
        width: '100%',
        height: '45px',
        data : allTests,
        escapeMarkup: function (markup) { return markup; }, // let our custom formatter work
        minimumInputLength: 1,
        templateResult: formatData
    });

    function formatData (data) {
        // if(data.data!='')
        //     var $result= $(
        //         '<span> ' + data.text + '</span>'
        //     );
        // else
            var $result= $(
                '<span>' + data.text + ' </span>'
            );
        return $result;
    }

    $(document).on("click", ".removeTest" , function(){
      var button = $(this);
      button.attr('disabled','disabled');

      var pid =  $(this).parent().find('input[type=hidden]').val();

      $.ajax({
        type: "POST",
        url:"<?php echo e(URL::to('/lab/json/removecart')); ?>",
        data:{test_id: pid, _token: '<?php echo e(csrf_token()); ?>'},
        success:function(data){
          $(".delTest"+pid).remove();

          $('#allTests').find("[value='"+pid+"']").removeAttr('disabled');

          $(".lab-total").html((data[0] * <?php echo e($curr->value); ?>).toFixed(2));
          $(".lab-cart-quantity").html(data[2]);
          $(".lab-cart").html("");
          if(data[1] == null)
          {
            $(".lab-total").html("0.00");
            $(".lab-cart-quantity").html("0");

            location.reload();
          }                           
                                    
        },
        error: function(data){
          button.removeAttr('disabled');

          $.notify("Something went wrong.","error");
        }
      }); 
    });

    $(document).on("click", "#addTest" , function(){
      var selected = $('#allTests').select2('data')[0];
      var pid = selected.id;

      if(pid == ''){
        $.notify("Select a test first","error");
        return;
      }
      $('#addTest').attr('disabled','disabled');

      $.ajax({
        type: "POST",
        url:"<?php echo e(URL::to('/lab/json/addcart')); ?>",
        data:{ test_id: pid, _token: '<?php echo e(csrf_token()); ?>'},
        success:function(data){
          if(data == 0)
          {
              $.notify("<?php echo e($gs->cart_error); ?>","error");
          }
          else
          {
            $('#allTests').find("[value='"+pid+"']").attr('disabled','disabled');
            $('#allTests').val('').trigger('change');
            $('#testList').html(data[1]);
            $(".lab-total").html((data[0] * <?php echo e($curr->value); ?>).toFixed(2));
            $(".lab-cart-quantity").html(data[2]);
            $(".lab-cart").html("");
          }
          $('#addTest').removeAttr('disabled');

        },
        error: function(data){
          $('#addTest').removeAttr('disabled');

          if(data.status == 422 && data.responseJSON.error)
            $.notify(data.responseJSON.error,"error");
          else
            $.notify("Something went wrong.","error");
        }
      }); 
      return false;
    });
  </script>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>