                <div class="col-lg-3 col-md-4 col-sm-12 col-xs-12">
                    <div class="product-filter-option">
                        <h2 class="filter-title"><?php echo e($lang->doa); ?> </h2>

                            <div class="form-group">
                              <select id="sortby" class="form-control">
                                <?php if($sort == "new"): ?>
                                    <option value="new" selected><?php echo e($lang->doe); ?></option>
                                <?php else: ?>
                                    <option value="new"><?php echo e($lang->doe); ?></option>
                                <?php endif; ?>
                                <?php if($sort == "old"): ?>
                                    <option value="old" selected><?php echo e($lang->dor); ?></option>
                                <?php else: ?>
                                    <option value="old"><?php echo e($lang->dor); ?></option>
                                <?php endif; ?>
                                <?php if($sort == "low"): ?>
                                    <option value="low" selected><?php echo e($lang->dopr); ?></option>
                                <?php else: ?>
                                    <option value="low"><?php echo e($lang->dopr); ?></option>
                                <?php endif; ?>
                                <?php if($sort == "high"): ?>
                                    <option value="high" selected><?php echo e($lang->doc); ?></option>
                                <?php else: ?>
                                    <option value="high"><?php echo e($lang->doc); ?></option>
                                <?php endif; ?>
                              </select>
                            </div>
                    </div>

<?php if($lang->rtl == 1): ?>

<?php if(isset($vendor)): ?>
    <div class="product-filter-option">
        <h2 class="filter-title"><?php echo e($lang->doci); ?> </h2>
            <ul style="text-align: right;">
<?php 
$x=0;
$s = 0;
$c = 0;
 ?>
        <?php $__currentLoopData = $categories->sortBy('cat_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ctgry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($ctgry->products()->where('user_id','=',$vendor->id)->get()) > 0): ?>
        <li>
         <?php if(count($ctgry->subs) > 0): ?>
          <?php $__currentLoopData = $ctgry->subs()->where('status','=',1)->orderBy('sub_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subctgry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if(count($subctgry->products()->where('user_id','=',$vendor->id)->get()) > 0): ?>
            <?php 
            $s = 1;
            break;
             ?>
           <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php if($s == 1): ?>
        <span href="#filter<?php echo e(++$x); ?>" aria-expanded="false" data-toggle="collapse">
                <i class="fa fa-plus"></i><i class="fa fa-minus"></i> </span>
         <?php else: ?>
                &nbsp;<i class="fa fa-angle-left"></i>
         <?php endif; ?>
        <?php 
        $s = 0;
         ?>
        <?php else: ?>
        &nbsp;<i class="fa fa-angle-left"></i>&nbsp;&nbsp;&nbsp;
        <?php endif; ?>
        <a href="<?php echo e(route('front.vendor.category',['slug1' => str_replace(' ', '-',($vendor->shop_name)), 'slug2' => $ctgry->cat_slug])); ?>"><?php echo e($ctgry->cat_name); ?></a>
         <?php if(count($ctgry->subs) > 0): ?>
           <ul id="filter<?php echo e($x); ?>" class="collapse">

    <?php $__currentLoopData = $ctgry->subs()->where('status','=',1)->orderBy('sub_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subctgry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($subctgry->products()->where('user_id','=',$vendor->id)->get()) > 0): ?>
            <li>
        <?php if(count($subctgry->childs) > 0): ?>
           <?php $__currentLoopData = $subctgry->childs()->where('status','=',1)->orderBy('child_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childctgry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if(count($childctgry->products()->where('user_id','=',$vendor->id)->get()) > 0): ?>
             <?php 
               $c = 1;
               break;
               ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($c == 1): ?>
          <span href="#filter<?php echo e(++$x); ?>" aria-expanded="false" data-toggle="collapse">
                <i class="fa fa-plus"></i><i class="fa fa-minus"></i> </span>
         <?php else: ?>
          <i class="fa fa-angle-left"></i>
         <?php endif; ?>
        <?php 
        $c=0;
         ?>
        <?php else: ?>
        <i class="fa fa-angle-left"></i>
        <?php endif; ?>
<a href="<?php echo e(route('front.vendor.subcategory',['slug1' => str_replace(' ', '-',($vendor->shop_name)), 'slug2' => $subctgry->sub_slug])); ?>"><?php echo e($subctgry->sub_name); ?></a>
    <?php if(count($subctgry->childs) > 0): ?>
    <ul id="filter<?php echo e($x); ?>" class="collapse">


    <?php $__currentLoopData = $subctgry->childs()->where('status','=',1)->orderBy('child_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childctgry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($childctgry->products()->where('user_id','=',$vendor->id)->get()) > 0): ?>
    <li><i class="fa fa-angle-left"></i><a href="<?php echo e(route('front.vendor.childcategory',['slug1' => str_replace(' ', '-',($vendor->shop_name)), 'slug2' =>$childctgry->child_slug])); ?>"><?php echo e($childctgry->child_name); ?></a></li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
 <?php endif; ?>
            </li>
          <?php endif; ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul>
        <?php endif; ?>
       </li>
      <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </ul>
  </div>
                    <?php else: ?>

                                    <div class="product-filter-option">
                                        <h2 class="filter-title"><?php echo e($lang->doci); ?></h2>
                                        <ul style="text-align: right;">
                                            <?php 
                                            $x=0;
                                             ?>
                                         <?php $__currentLoopData = $categories->sortBy('cat_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ctgry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                    <?php if(count($ctgry->subs) > 0): ?>
                                                <span href="#filter<?php echo e(++$x); ?>" aria-expanded="false" data-toggle="collapse">
                                                    <i class="fa fa-plus"></i><i class="fa fa-minus"></i> 
                                                    <?php else: ?>
                                                    &nbsp;<i class="fa fa-angle-left"></i>&nbsp;&nbsp;&nbsp;
                                                    <?php endif; ?>
                                                </span>
                                                <a href="<?php echo e(route('front.category',$ctgry->cat_slug)); ?>"><?php echo e($ctgry->cat_name); ?></a>
                                                <?php if(count($ctgry->subs) > 0): ?>
                                                <ul id="filter<?php echo e($x); ?>" class="collapse">
                                                    <?php $__currentLoopData = $ctgry->subs()->where('status','=',1)->orderBy('sub_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subctgry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <?php if(count($subctgry->childs) > 0): ?>
                                                        <span href="#filter<?php echo e(++$x); ?>" aria-expanded="false" data-toggle="collapse">
                                                        <i class="fa fa-plus"></i><i class="fa fa-minus"></i> 
                                                        </span>
                                                        <?php else: ?>
                                                        <i class="fa fa-angle-left"></i>
                                                        <?php endif; ?>
                                                        <a href="<?php echo e(route('front.subcategory',$subctgry->sub_slug)); ?>"><?php echo e($subctgry->sub_name); ?></a>
                                                        <?php if(count($subctgry->childs) > 0): ?>
                                                        <ul id="filter<?php echo e($x); ?>" class="collapse">
                                                            <?php $__currentLoopData = $subctgry->childs()->where('status','=',1)->orderBy('child_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childctgry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li><i class="fa fa-angle-left"></i><a href="<?php echo e(route('front.childcategory',$childctgry->child_slug)); ?>"><?php echo e($childctgry->child_name); ?></a></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                        <?php endif; ?>
                                                    </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                                <?php endif; ?>
                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </ul>
                                    </div>
                    <?php endif; ?>

<?php else: ?>

<?php if(isset($vendor)): ?>
    <div class="product-filter-option">
        <h2 class="filter-title"><?php echo e($lang->doci); ?></h2>
            <ul style="direction: ltr;">
<?php 
$x=0;
$s = 0;
$c = 0;
 ?>
        <?php $__currentLoopData = $categories->sortBy('cat_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ctgry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($ctgry->products()->where('user_id','=',$vendor->id)->get()) > 0): ?>
        <li>
         <?php if(count($ctgry->subs) > 0): ?>
          <?php $__currentLoopData = $ctgry->subs()->where('status','=',1)->orderBy('sub_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subctgry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if(count($subctgry->products()->where('user_id','=',$vendor->id)->get()) > 0): ?>
            <?php 
            $s = 1;
            break;
             ?>
           <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php if($s == 1): ?>
        <span href="#filter<?php echo e(++$x); ?>" aria-expanded="false" data-toggle="collapse">
                <i class="fa fa-plus"></i><i class="fa fa-minus"></i> </span>
         <?php else: ?>
                &nbsp;<i class="fa fa-angle-right"></i>
         <?php endif; ?>
        <?php 
        $s = 0;
         ?>
        <?php else: ?>
        &nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;&nbsp;
        <?php endif; ?>
        <a href="<?php echo e(route('front.vendor.category',['slug1' => str_replace(' ', '-',($vendor->shop_name)), 'slug2' => $ctgry->cat_slug])); ?>"><?php echo e($ctgry->cat_name); ?></a>
         <?php if(count($ctgry->subs) > 0): ?>
           <ul id="filter<?php echo e($x); ?>" class="collapse">

    <?php $__currentLoopData = $ctgry->subs()->where('status','=',1)->orderBy('sub_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subctgry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($subctgry->products()->where('user_id','=',$vendor->id)->get()) > 0): ?>
            <li>
        <?php if(count($subctgry->childs) > 0): ?>
           <?php $__currentLoopData = $subctgry->childs()->where('status','=',1)->orderBy('child_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childctgry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if(count($childctgry->products()->where('user_id','=',$vendocater->id)->get()) > 0): ?>
             <?php 
               $c = 1;
               break;
               ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($c == 1): ?>
          <span href="#filter<?php echo e(++$x); ?>" aria-expanded="false" data-toggle="collapse">
                <i class="fa fa-plus"></i><i class="fa fa-minus"></i> </span>
         <?php else: ?>
          <i class="fa fa-angle-right"></i>
         <?php endif; ?>
        <?php 
        $c=0;
         ?>
        <?php else: ?>
        <i class="fa fa-angle-right"></i>
        <?php endif; ?>
<a href="<?php echo e(route('front.vendor.subcategory',['slug1' => str_replace(' ', '-',($vendor->shop_name)), 'slug2' => $subctgry->sub_slug])); ?>"><?php echo e($subctgry->sub_name); ?></a>
    <?php if(count($subctgry->childs) > 0): ?>
    <ul id="filter<?php echo e($x); ?>" class="collapse">


    <?php $__currentLoopData = $subctgry->childs()->where('status','=',1)->orderBy('child_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childctgry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($childctgry->products()->where('user_id','=',$vendor->id)->get()) > 0): ?>
    <li><i class="fa fa-angle-right"></i><a href="<?php echo e(route('front.vendor.childcategory',['slug1' => str_replace(' ', '-',($vendor->shop_name)), 'slug2' =>$childctgry->child_slug])); ?>"><?php echo e($childctgry->child_name); ?></a></li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
 <?php endif; ?>
            </li>
          <?php endif; ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul>
        <?php endif; ?>
       </li>
      <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </ul>
  </div>
                    <?php else: ?>

                                    <div class="product-filter-option">
                                        <h2 class="filter-title"><?php echo e($lang->doci); ?></h2>
                                        <ul style="direction: ltr;">
                                            <?php 
                                            $x=0;
                                             ?>
                                         <?php $__currentLoopData = $categories->sortBy('cat_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ctgry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                    <?php if(count($ctgry->subs) > 0): ?>
                                                <span href="#filter<?php echo e(++$x); ?>" aria-expanded="false" data-toggle="collapse">
                                                    <i class="fa fa-plus"></i><i class="fa fa-minus"></i> 
                                                    <?php else: ?>
                                                    &nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;&nbsp;
                                                    <?php endif; ?>
                                                </span>
                                                <a href="<?php echo e(route('front.category',$ctgry->cat_slug)); ?>"><?php echo e($ctgry->cat_name); ?></a>
                                                <?php if(count($ctgry->subs) > 0): ?>
                                                <ul id="filter<?php echo e($x); ?>" class="collapse">
                                                    <?php $__currentLoopData = $ctgry->subs()->where('status','=',1)->orderBy('sub_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subctgry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <?php if(count($subctgry->childs) > 0): ?>
                                                        <span href="#filter<?php echo e(++$x); ?>" aria-expanded="false" data-toggle="collapse">
                                                        <i class="fa fa-plus"></i><i class="fa fa-minus"></i> 
                                                        </span>
                                                        <?php else: ?>
                                                        <i class="fa fa-angle-right"></i>
                                                        <?php endif; ?>
                                                        <a href="<?php echo e(route('front.subcategory',$subctgry->sub_slug)); ?>"><?php echo e($subctgry->sub_name); ?></a>
                                                        <?php if(count($subctgry->childs) > 0): ?>
                                                        <ul id="filter<?php echo e($x); ?>" class="collapse">
                                                            <?php $__currentLoopData = $subctgry->childs()->where('status','=',1)->orderBy('child_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childctgry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li><i class="fa fa-angle-right"></i><a href="<?php echo e(route('front.childcategory',$childctgry->child_slug)); ?>"><?php echo e($childctgry->child_name); ?></a></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                        <?php endif; ?>
                                                    </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                                <?php endif; ?>
                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </ul>
                                    </div>
                    <?php endif; ?>

<?php endif; ?>


                    <div class="product-filter-option">
                        <h2 class="filter-title"><?php echo e($lang->dosp); ?></h2>
                        <?php if(isset($cat)): ?>
                            <form action="<?php echo e(route('front.category',$cat->cat_slug)); ?>" method="GET">

                        <?php elseif(isset($subcat)): ?>
                            <form action="<?php echo e(route('front.subcategory',$subcat->sub_slug)); ?>" method="GET">
                        
                        <?php elseif(isset($childcat)): ?>
                            <form action="<?php echo e(route('front.childcategory',$childcat->child_slug)); ?>" method="GET">
                        
                        <?php elseif(isset($vcats)): ?>
                            <form action="<?php echo e(route('front.vendor.category',['slug1' => str_replace(' ', '-',($vendor->shop_name)), 'slug2' => $vcat->cat_slug])); ?>" method="GET">
                        
                        <?php elseif(isset($vsubcats)): ?>
                            <form action="<?php echo e(route('front.vendor.subcategory',['slug1' => str_replace(' ', '-',($vendor->shop_name)), 'slug2' => $vsubcat->sub_slug])); ?>" method="GET">
                        
                        <?php elseif(isset($vchildcats)): ?>
                            <form action="<?php echo e(route('front.vendor.childcategory',['slug1' => str_replace(' ', '-',($vendor->shop_name)), 'slug2' =>$vchildcat->child_slug])); ?>" method="GET">
                        
                        <?php elseif(isset($sproducts)): ?>
                            <form action="<?php echo e(route('front.searchs',$search)); ?>" method="GET">
                        
                        <?php elseif(isset($wproducts)): ?>
                            <form action="<?php echo e(route('user-wishlists')); ?>" method="GET">
                        
                        <?php elseif(isset($vprods)): ?>
                            <form action="<?php echo e(route('front.vendor',str_replace(' ', '-',($vendor->shop_name)))); ?>" method="GET">
                        <?php endif; ?>
                                
                                <div class="form-group">
                                    <input style="direction: ltr;" type="text" id="price-min" name="min" class="price-input" value="<?php echo e(isset($min) ? $min:'0'); ?>">
                                    <i class="fa fa-minus"></i>
                                    <input style="direction: ltr;" type="text" id="price-max" name="max" class="price-input" value="<?php echo e(isset($max) ? $max:'250'); ?>">
                                    <input style="direction: ltr;" type="submit" class="price-search-btn" value="<?php echo e($lang->don); ?>">
                                </div>
                            </form>
                    </div>



                    <?php if(!isset($vendor)): ?>

                    
                    <?php endif; ?>
                    <?php if(isset($vendor)): ?>
          <div class="product-filter-option description">
            <h2 class="filter-title"><?php echo e($lang->vendor_description); ?></h2>
            <p><?php echo $vendor->shop_details; ?></p>
            <hr/>

            <h3 class="filter-title"><?php echo e($lang->linked_accounts); ?></h3>
            <ul style="direction: ltr;">
              <?php if($vendor->f_check != 0): ?>
              <li><a href="<?php echo e($vendor->f_url); ?>"><i class="fa fa-facebook"></i> Facebook</a></li>
              <?php endif; ?>
              <?php if($vendor->g_check != 0): ?>
              <li><a href="<?php echo e($vendor->g_url); ?>"><i class="fa fa-google-plus"></i> Google</a></li>
              <?php endif; ?>
              <?php if($vendor->t_check != 0): ?>
              <li><a href="<?php echo e($vendor->t_url); ?>"><i class="fa fa-twitter"></i> Twitter</a></li>
              <?php endif; ?>
              <?php if($vendor->l_check != 0): ?>
              <li><a href="<?php echo e($vendor->l_url); ?>"><i class="fa fa-linkedin"></i> Linkedin</a></li>
              <?php endif; ?>
            </ul>
          </div>
          <?php if(Auth::guard('user')->check()): ?>
                    <div class="product-filter-option description">
            <div class="product-contact-info">
                         <div class="product-contact-info-buttons">
                           <div class="row">
                             <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12">
                               <a id="product-phone" class="btn btn-success btn-block" href="javascript:void(0)"><i class="fa fa-phone"></i> <?php echo e($lang->phone_number); ?></a>

                               <div class="contact-phone-details">
                                  <strong><?php echo e($lang->phone_number); ?>:</strong> <?php echo e($vendor->shop_number); ?>

                              </div>
                             </div>
                             <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12">
                              <a id="product_email" class="btn btn-primary btn-block" data-toggle="modal" data-target="#emailModal" style="cursor: pointer;"><i class="fa fa-envelope"></i> <?php echo e($lang->send_message); ?></a>
                            </div>
                           </div>
                         </div>
                       </div>
                     </div>
              <?php else: ?>
                    <div class="product-filter-option description">
            <div class="product-contact-info">
                         <div class="product-contact-info-buttons">
                           <div class="row">
                             <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12">
                               <a style="cursor: pointer;" class="btn btn-success btn-block no-wish" data-toggle="modal" data-target="#loginModal"><i class="fa fa-phone"></i> <?php echo e($lang->contact_seller); ?></a>
                             </div>
                           </div>
                         </div>
                       </div>
                     </div>
              <?php endif; ?>
                <?php endif; ?>
                </div>