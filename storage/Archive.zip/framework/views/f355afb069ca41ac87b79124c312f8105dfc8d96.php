
<style>
    .s_item:hover{
        color:#2385aa;
    }
    
    .product-details-wrapper .productDetails-quantity span, .productDetails-quantity span {
        margin-top: 10px;
        display: inline-block;
        width: 30px;
        height: 30px;
        line-height: 30px;
        border: 1px #d9d9d9 solid;
        text-align: center;
        font-size: 12px;
        color: #4c4c4c;
        font-weight: 500;
        margin-right: -5px;
        position: relative;
        margin-bottom: 10px;
    }
    hr {
    margin-top: 0.25rem;
    margin-bottom: 0.25rem;
    }

    @media (max-width: 767px) and (min-width: 320px){}
    .header-searched-item-list-wrap-mobile {
        right: 4%;
        width: 90% !important;
        top: 120px;
        z-index: 99999;
    }
    }
    
    </style>

    <h6><b>Available Product :</b> <span style="color:#28a745"><?php echo e(count($products)); ?>/<?php echo e(count($product_count)); ?> Showing</span></h6>
    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php 
        $product->pprice = $product->pprice ? : $product->cprice;
        $product->cprice = $product->getPrice(1);
        // dd('asdfasdfas');
         ?>
    
    
        <li>
            <a class="g-pt-0" style="text-decoration:gold;" href="<?php echo e(route('front.product',[$product->id,str_slug($product->name,'-')])); ?>" class="s_item">
                <div class="row">
                    
                    <div class="col-xs-12" style="padding-left:0px;padding-right:0px;">
                        <h1 class="g-font-size-12 mb-0 h6 g-mt-0 g-font-weight-700"><?php echo e(ucwords(strtolower($product->name))); ?> </h1>
                        
                        <p class="g-color-gray-dark-v5 g-font-size-11 mb-0"><?php echo e(ucwords(strtolower($product->company_name))); ?></p>
                        <hr/>
                        
                    </div>
                    
                </div>
            </a>
        </li>

    
     
   

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        
    <h6 class="text-center">No product found!</h6>

    <?php endif; ?>

    