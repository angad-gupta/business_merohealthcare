<?php $__env->startSection('title','Order Details - '.$order->order_number); ?>
<?php $__env->startSection('styles'); ?>

    <style>
        @page  { size: auto;  margin: 0mm; }
        @page  {
            size: A4;
            margin: 0;
        }
        @media  print {
                a[href]:after {
                    content: none !important;
                }

            html, body {
                width: 210mm;
                height: 287mm;
            }

            html {
                overflow: scroll;
                overflow-x: hidden;
            }
            ::-webkit-scrollbar {
                width: 0px;  /* remove scrollbar space */
                background: transparent;  /* optional: just make scrollbar invisible */
            }

            .footer {
                display: block;
                position: fixed;
                bottom: 0;
            }
            .table-row{
                height: 170px;
            }

            .order-date {
                font-size: 24px;
            }
        }

        @media(min-width:320px) and (max-width:720px){
            #table-mobile{
               display:block !important;
            }

            #table-desktop{
            display: none !important;

            
        }

        td, th {
    padding: 5px !important;
}

        }

       


    </style>
<?php $__env->startSection('content'); ?>
    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard data-table area -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="product__header">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-8 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title">
                                                    <h2 style="text-transform:uppercase;">Order #<?php echo e($order->order_number); ?> [<?php echo e($order->status); ?>]  <a href="<?php echo e(route('user-orders')); ?>" class="btn add-newProduct-btn" style="padding: 5px 12px;"  class="print-order-btn">
                                                    <i class="fa fa-arrow-left"></i> Back
                                                </a>  <a class="btn add-newProduct-btn" href="<?php echo e(route('user-order-print',$order->id)); ?>" target="_blank" style=" padding: 5px 12px;" class="print-order-btn">
                                                    <i class="fa fa-print"></i> print invoice
                                                </a></h2>
                                                    <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Purchased Items <i class="fa fa-angle-right" style="margin: 0 2px;"></i>Purchase Details</p>
                                                </div>
                                            </div>
                                              <?php echo $__env->make('includes.user-notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </div>   
                                    </div>
                                    <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    <div class="row">
                                        <div class="col-md-10" style="margin-left: 2.5%;">
                                            <div class="dashboard-content">
                                                <div class="view-order-page" id="print">
                                                    <p class="order-date">Order Date <?php echo e(date('d-M-Y',strtotime($order->created_at))); ?></p>

                                                    <?php if($order->dp == 1): ?>

                                                        <div class="billing-add-area">
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <h5>Billing Address</h5>
                                                                    <address>
                                                                        Name: <?php echo e($order->customer_name); ?><br>
                                                                        Email: <?php echo e($order->customer_email); ?><br>
                                                                        Phone: <?php echo e($order->customer_phone); ?><br>
                                                                        Address: <?php echo e($order->customer_address); ?><br>
                                                                        
                                                                    </address>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <h5>Payment Information</h5>
                                                                    <p>Paid Amount: <?php echo e($order->currency_sign); ?><?php echo e(round($order->pay_amount * $order->currency_value , 2)); ?></p>
                                                                    <p>Payment Method: <?php echo e($order->method); ?></p>

                                                                    <?php if($order->method != "Cash On Delivery"): ?>
                                                                        <?php if($order->method=="Stripe"): ?>
                                                                            <?php echo e($order->method); ?> Charge ID: <p><?php echo e($order->charge_id); ?></p>
                                                                        <?php endif; ?>
                                                                        <?php echo e($order->method); ?> Transaction ID: <p id="ttn"><?php echo e($order->txnid); ?></p>
                                                                        
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    <?php else: ?>
                                                        <div class="shipping-add-area">
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <?php if($order->shipping == "shipto"): ?>
                                                                        <h5>Delivery Address</h5>
                                                                        <address>
                                                                            Name: <?php echo e($order->shipping_name == null ? $order->customer_name : $order->shipping_name); ?><br>
                                                                            Email: <?php echo e($order->shipping_email == null ? $order->customer_email : $order->shipping_email); ?><br>
                                                                            Phone: <?php echo e($order->shipping_phone == null ? $order->customer_phone : $order->shipping_phone); ?><br>
                                                                            Address: <?php echo e($order->shipping_address == null ? $order->customer_address : $order->shipping_address); ?><br>
                                                                            
                                                                        </address>
                                                                    <?php else: ?>
                                                                        <h5>PickUp Location</h5>
                                                                        <address>
                                                                            Address: <?php echo e($order->pickup_location); ?><br>
                                                                        </address>
                                                                    <?php endif; ?>

                                                                </div>
                                                                <div class="col-md-6">
                                                                    <h5>Delivery Method</h5>
                                                                    <?php if($order->shipping == "shipto"): ?>
                                                                        <p>Delivery To Address</p>
                                                                    <?php else: ?>
                                                                        <p>Pick Up</p>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="billing-add-area">
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <h5>Billing Address</h5>
                                                                    <address>
                                                                        Name: <?php echo e($order->customer_name); ?><br>
                                                                        Email: <?php echo e($order->customer_email); ?><br>
                                                                        Phone: <?php echo e($order->customer_phone); ?><br>
                                                                        Address: <?php echo e($order->customer_address); ?><br>
                                                                        
                                                                    </address>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <h5>Payment Information
                                                                        <?php if($order->payment_status == "paid"): ?>
                                                                            <span class="btn-sm btn-success" style="cursor:default">Paid</span>
                                                                        <?php else: ?>
                                                                            <span class="btn-sm btn-danger" style="cursor:default">Unpaid</span> 
                                                                        <?php endif; ?>
                                                                    </h5>
                                                                    <p>Paid Amount: <?php echo e($order->currency_sign); ?><?php echo e(round($order->pay_amount * $order->currency_value , 2)); ?></p>
                                                                    <p>Payment Method: <?php echo e($order->method); ?></p>

                                                                    <?php if($order->method != "Cash On Delivery"): ?>
                                                                        <?php if($order->method=="Stripe"): ?>
                                                                            <?php echo e($order->method); ?> Charge ID: <p><?php echo e($order->charge_id); ?></p>
                                                                        <?php endif; ?>
                                                                        <?php echo e($order->method); ?> Transaction ID: <p id="ttn"><?php echo e($order->txnid); ?></p>
                                                                        
                                                                    <?php endif; ?>
                                                                    
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                    <br>
                                                    <div class="table-responsive">
                                                        <table id="example" class="table">
                                                            <h4 class="text-center" style="margin-top:10px;">Products Ordered</h4><hr>
                                                            <thead>
                                                                <tr>
                                                                    <th width="10%">ID#</th>
                                                                    <th>Product Title</th>
                                                                    <th></th>
                                                                    <th width="10%">Quantity</th>
                                                                    <th width="20%">Product Price</th>
                                                                    <th width="20%">Total Price</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php 
                                                                    $subtotal = 0;
                                                                    $discountedsubtotal = 0;
                                                                 ?>

                                                                <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <td><?php echo e($product['item']['id']); ?></td>
                                                                        <td>
                                                                            <input type="hidden" value="<?php echo e($product['license']); ?>">
                                                                            <a target="_blank" href="<?php echo e(route('front.product',['id1' => $product['item']['id'], str_slug($product['item']['name'],'-')])); ?>" title="<?php echo e($product['item']['name']); ?>"><?php echo e(strlen($product['item']['name']) > 30 ? substr($product['item']['name'],0,30).'...' : $product['item']['name']); ?></a>
                                                                            
                                                                        </td>
                                                                        <td>
                                                                            
                                                                        </td>
                                                                        <td><?php echo e($product['qty']); ?> <?php echo e($product['item']['measure']); ?></td>
                                                                        <td><?php echo e($order->currency_sign); ?><?php echo e(round($product['item']['cprice'] * $order->currency_value,2)); ?></td>
                                                                        <td><?php echo e($order->currency_sign); ?><?php echo e(round($product['item']['cprice'] * $product['qty'] * $order->currency_value,2)); ?></td>

                                                                    </tr>
                                                                    <?php 
                                                                        $subtotal += $product['qty'] * $product['item']['cprice'];
                                                                        $discountedsubtotal += $product['price'];
                                                                     ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                            </tbody>
                                                            <tfoot id="table-desktop">
                                                                <tr>
                                                                    <td align="right" colspan="5" style="font-weight:600;">
                                                                        Sub Total :                     
                                                                    </td>
                                                                    <td align="left" style="font-weight:600;">
                                                                        <?php echo e($order->currency_sign); ?> <?php echo e(round($subtotal * $order->currency_value , 2)); ?>

                                                                    </td>
                                                                </tr>
                                                                <?php if($subtotal > $discountedsubtotal): ?>
                                                                    <tr>
                                                                        
                                                                        
                                                                        <td align="right" colspan="5" style="font-weight:600;border-top:0">
                                                                            Price Discount :                       
                                                                        </td>
                                                                        <td align="left" style="font-weight:600;border-top:0">
                                                                            <?php echo e($order->currency_sign); ?> <?php echo e(round(($subtotal - $discountedsubtotal) * $order->currency_value , 2)); ?>

                                                                        </td>
                                                                    </tr>
                                                                <?php endif; ?>
                                                                
                                                                <?php if($order->coupon_code != null): ?>
                                                                    <tr>
                                                                        
                                                                        
                                                                        <td align="right" colspan="5" style="font-weight:600;border-top:0">
                                                                            Discount Coupon : (<?php echo e($order->coupon_code); ?>)                   
                                                                        </td>
                                                                        <td align="left" style="font-weight:600;border-top:0">
                                                                            <?php echo e($order->currency_sign); ?> <?php echo e($order->coupon_discount * $order->currency_value); ?>

                                                                        </td>
                                                                    </tr>
                                                                <?php endif; ?>
                
                                                                <?php if($order->discount > 0): ?>
                                                                    <tr>
                                                                        
                                                                        
                                                                        <td align="right" colspan="5" style="font-weight:600;border-top:0">
                                                                            Payment Gateway Discount : (<?php echo e($order->method); ?>)                  
                                                                        </td>
                                                                        <td align="left" style="font-weight:600;border-top:0">
                                                                            <?php echo e($order->currency_sign); ?> <?php echo e($order->discount * $order->currency_value); ?>

                                                                        </td>
                                                                    </tr>
                                                                <?php endif; ?>
                                            
                                                                <?php if($order->shipping_cost != 0): ?>
                                                                    <tr>
                                                                        
                                                                        
                                                                        <td align="right" colspan="5" style="font-weight:600;border-top:0">
                                                                            Delivery Fee :                
                                                                        </td>
                                                                        <td align="left" style="font-weight:600;border-top:0">
                                                                            <?php echo e($order->currency_sign); ?> <?php echo e($order->shipping_cost * $order->currency_value); ?>

                                                                        </td>
                                                                    </tr>
                                                                <?php endif; ?>
                                            
                                                                <?php if($order->tax != 0): ?>
                                                                    <tr>
                                                                        
                                                                        
                                                                        <td align="right" colspan="5" style="font-weight:600;border-top:0">
                                                                            Tax :             
                                                                        </td>
                                                                        <td align="left" style="font-weight:600;border-top:0">
                                                                            <?php echo e($order->currency_sign); ?> <?php echo e($order->tax * $order->currency_value); ?>

                                                                        </td>
                                                                    </tr>
                                                                <?php endif; ?>
                                                                <tr>
                                                                    
                                                                    
                                                                    <td align="right" colspan="5" style="font-weight:600;border-top:0">
                                                                        Total :                    
                                                                    </td>
                                                                    <td align="left" style="font-weight:600;border-top:0">
                                                                        <?php echo e($order->currency_sign); ?> <?php echo e(round($order->pay_amount * $order->currency_value , 2)); ?>

                                                                    </td>
                                                                </tr>
                                                            </tfoot>

                                                            
                                                        </table>

                                                        
                                                        

                                                        <table id="table-mobile" class="pull-right" style="display:none; padding:10px">
                                                     
                                                            <tr>
                                                                <td style="font-weight:600;">
                                                                    Sub Total :                     
                                                                </td>
                                                                <td style="font-weight:600; display:block !important; ">
                                                                    <?php echo e($order->currency_sign); ?> <?php echo e(round($subtotal * $order->currency_value , 2)); ?>

                                                                </td>
                                                            </tr>
                                                            <?php if($subtotal > $discountedsubtotal): ?>
                                                                <tr>
                                                                    
                                                                    
                                                                    <td style="font-weight:600;border-top:0">
                                                                        Price Discount :                       
                                                                    </td>
                                                                    <td style="font-weight:600;border-top:0;">
                                                                        <?php echo e($order->currency_sign); ?> <?php echo e(round(($subtotal - $discountedsubtotal) * $order->currency_value , 2)); ?>

                                                                    </td>
                                                                </tr>
                                                            <?php endif; ?>
                                                            
                                                            <?php if($order->coupon_code != null): ?>
                                                                <tr>
                                                                    
                                                                    
                                                                    <td style="font-weight:600;border-top:0">
                                                                        Discount Coupon : (<?php echo e($order->coupon_code); ?>)                   
                                                                    </td>
                                                                    <td  style="font-weight:600;border-top:0;  ">
                                                                        <?php echo e($order->currency_sign); ?> <?php echo e($order->coupon_discount * $order->currency_value); ?>

                                                                    </td>
                                                                </tr>
                                                            <?php endif; ?>
            
                                                            <?php if($order->discount > 0): ?>
                                                                <tr>
                                                                    
                                                                    
                                                                    <td style="font-weight:600;border-top:0">
                                                                        Payment Gateway Discount : (<?php echo e($order->method); ?>)                  
                                                                    </td>
                                                                    <td style="font-weight:600;border-top:0; ">
                                                                        <?php echo e($order->currency_sign); ?> <?php echo e($order->discount * $order->currency_value); ?>

                                                                    </td>
                                                                </tr>
                                                            <?php endif; ?>
                                        
                                                            <?php if($order->shipping_cost != 0): ?>
                                                                <tr>
                                                                    
                                                                    
                                                                    <td style="font-weight:600;border-top:0">
                                                                        Delivery Fee :                
                                                                    </td>
                                                                    <td style="font-weight:600;border-top:0; ">
                                                                        <?php echo e($order->currency_sign); ?> <?php echo e($order->shipping_cost * $order->currency_value); ?>

                                                                    </td>
                                                                </tr>
                                                            <?php endif; ?>
                                        
                                                            <?php if($order->tax != 0): ?>
                                                                <tr>
                                                                    
                                                                    
                                                                    <td style="font-weight:600;border-top:0">
                                                                        Tax :             
                                                                    </td>
                                                                    <td style="font-weight:600;border-top:0; ">
                                                                        <?php echo e($order->currency_sign); ?> <?php echo e($order->tax * $order->currency_value); ?>

                                                                    </td>
                                                                </tr>
                                                            <?php endif; ?>
                                                            <tr>
                                                                
                                                                
                                                                <td style="font-weight:600;border-top:0">
                                                                    Total :                    
                                                                </td>
                                                                <td style="font-weight:600;border-top:0;">
                                                                    <?php echo e($order->currency_sign); ?> <?php echo e(round($order->pay_amount * $order->currency_value , 2)); ?>

                                                                </td>
                                                            </tr>
                                                  
                                                        </table>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                <!-- Ending of Dashboard data-table area -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
$('#example').dataTable( {
  "ordering": false,
      'paging'      : false,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : false,
      'info'        : false,
      'autoWidth'   : false,
      'responsive'  : true
} );
</script>
    <script type="text/javascript">
        function printDiv(divName){
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>