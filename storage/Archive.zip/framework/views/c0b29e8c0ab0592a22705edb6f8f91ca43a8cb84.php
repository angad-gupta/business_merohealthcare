
<?php $__env->startSection('title','Career'); ?>
<?php $__env->startSection('content'); ?>


<style>

.g-bg-darkgray-radialgradient-circle {
    background-image: radial-gradient(circle farthest-side at 110% 0, #18ba9b, #2385aa);
    background-repeat: no-repeat;
}
</style>

  <div class="container" style="padding:20px;">

  <div class="row">
    <div class="col-lg-6 g-mb-50 g-mb-0--lg">
    <img class="img-fluid" src="<?php echo e(url('assets/images/logo.jpg')); ?>" style="" alt="Image Description">
    </div>
  
    <div class="col-lg-6 align-self-center">
      <header class="u-heading-v2-3--bottom g-brd-primary g-mb-20">
        <h2 class="h3 u-heading-v2__title text-uppercase g-font-weight-300">About Mero Health Care</h2>
      </header>
  
      <p class="lead g-mb-30">Web Health company is seeking to change the health e-commerce market with the launch of merohealthcare.com. We are a team of young entrepreneurs seeking to contribute to the economy of Nepal.</p>
  
      <ul class="list-unstyled g-color-gray-dark-v4 g-mb-40">
        <li class="d-flex g-mb-10">
          <i class="icon-check g-color-primary g-mt-5 g-mr-10"></i>
          Over 8000+ Products
        </li>
        <li class="d-flex g-mb-10">
          <i class="icon-check g-color-primary g-mt-5 g-mr-10"></i>
          Online Pharmacy E-commerce
        </li>
        <li class="d-flex g-mb-10">
          <i class="icon-check g-color-primary g-mt-5 g-mr-10"></i>
          Online Doctor Questionaries
        </li>
        <li class="d-flex g-mb-10">
          <i class="icon-check g-color-primary g-mt-5 g-mr-10"></i>
          Valuable Customers
        </li>
      </ul>
  
      
    </div>
  </div>
  </div>

  

 
  <div class="shortcode-html">
    <section class="g-flex-centered g-height-450 g-bg-darkgray-radialgradient-circle g-color-white-opacity-0_7 g-py-30">
      <div class="container">
        <div class="row">
          <div class="col-md-6 align-self-center g-py-20">
            <div class="u-heading-v2-5--bottom g-brd-primary g-mb-30">
                <h2 class="u-heading-v2__title text-uppercase g-font-weight-300 mb-0">We are hiring</h2>
              </div>
            <p class="lead mb-0 g-line-height-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin hendrerit rhoncus tempus. Donec id orci malesuada, finibus odio quis, tincidunt libero. Fusce in venenatis ligula. Etiam eget lacus id erat scelerisque tempor.</p>
          </div>

          <div class="col-md-6 align-self-center g-py-20">
            <img class="w-100" src="https://htmlstream.com/preview/unify-v2.6.2/assets/img-temp/400x270/img3.jpg" alt="Iamge Description">
          </div>
        </div>
      </div>
    </section>
  </div>

  
  <div class="container" style="padding:20px;">

    <h2 class="h3 u-heading-v2__title text-uppercase g-font-weight-300 text-center">Current Openings</h2>
    <br/>
    <div class="row">
      <div class="col-lg-6 g-mb-30">
        <!-- Event Listing -->
        <article class="u-shadow-v39">
          <div class="row">
            <div class="col-4">
              <div class="g-min-height-170 g-bg-img-hero" style="background-image: url(https://htmlstream.com/preview/unify-v2.6.2/assets/img-temp/400x270/img10.jpg);"></div>
            </div>

            <div class="col-8 g-min-height-170 g-flex-centered">
              <div class="media align-items-center g-py-40">
                <div class="d-flex col-8">
                  <h3 class="g-line-height-1 mb-0"><a class="u-link-v5 g-color-black g-color-primary--hover g-font-size-18" href="#">Camino de Santiago: treading the ancient path to the end of the earth</a></h3>
                </div>
                <div class="media-body col-4">
                  <span class="g-color-primary g-font-weight-500 g-font-size-40 g-line-height-0_7">13</span>
                  <span class="g-line-height-0_7">Nov</span>
                </div>
              </div>
            </div>
          </div>
        </article>
        <!-- End Event Listing -->
      </div>

      <div class="col-lg-6 g-mb-30">
        <!-- Event Listing -->
        <article class="u-shadow-v39">
          <div class="row">
            <div class="col-4">
              <div class="g-min-height-170 g-bg-img-hero" style="background-image: url(https://htmlstream.com/preview/unify-v2.6.2/assets/img-temp/400x270/img10.jpg);"></div>
            </div>

            <div class="col-8 g-min-height-170 g-flex-centered">
              <div class="media align-items-center g-py-40">
                <div class="d-flex col-8">
                  <h3 class="g-line-height-1 mb-0"><a class="u-link-v5 g-color-black g-color-primary--hover g-font-size-18" href="#">Kopernik X Navicula: Music and Technology for Change</a></h3>
                </div>
                <div class="media-body col-4">
                  <span class="g-color-primary g-font-weight-500 g-font-size-40 g-line-height-0_7">05</span>
                  <span class="g-line-height-0_7">Dec</span>
                </div>
              </div>
            </div>
          </div>
        </article>
        <!-- End Event Listing -->
      </div>

      <div class="w-100"></div>

      <div class="col-lg-6 g-mb-30">
        <!-- Event Listing -->
        <article class="u-shadow-v39">
          <div class="row">
            <div class="col-4">
              <div class="g-min-height-170 g-bg-img-hero" style="background-image: url(https://htmlstream.com/preview/unify-v2.6.2/assets/img-temp/400x270/img10.jpg);"></div>
            </div>

            <div class="col-8 g-min-height-170 g-flex-centered">
              <div class="media align-items-center g-py-40">
                <div class="d-flex col-8">
                  <h3 class="g-line-height-1 mb-0"><a class="u-link-v5 g-color-black g-color-primary--hover g-font-size-18" href="#">From Euclid to the Computer: tracing a line through mathematics</a></h3>
                </div>
                <div class="media-body col-4">
                  <span class="g-color-primary g-font-weight-500 g-font-size-40 g-line-height-0_7">09</span>
                  <span class="g-line-height-0_7">Dec</span>
                </div>
              </div>
            </div>
          </div>
        </article>
        <!-- End Event Listing -->
      </div>

      <div class="col-lg-6 g-mb-30">
        <!-- Event Listing -->
        <article class="u-shadow-v39">
          <div class="row">
            <div class="col-4">
              <div class="g-min-height-170 g-bg-img-hero" style="background-image: url(https://htmlstream.com/preview/unify-v2.6.2/assets/img-temp/400x270/img10.jpg);"></div>
            </div>

            <div class="col-8 g-min-height-170 g-flex-centered">
              <div class="media align-items-center g-py-40">
                <div class="d-flex col-8">
                  <h3 class="g-line-height-1 mb-0"><a class="u-link-v5 g-color-black g-color-primary--hover g-font-size-18" href="#">Satellite Remote Sensing Summer School - SRSSS</a></h3>
                </div>
                <div class="media-body col-4">
                  <span class="g-color-primary g-font-weight-500 g-font-size-40 g-line-height-0_7">17</span>
                  <span class="g-line-height-0_7">Jan</span>
                </div>
              </div>
            </div>
          </div>
        </article>
        <!-- End Event Listing -->
      </div>

     
    </div>
  </div>



  <section class="g-py-100--md g-py-80">
    <div class="container text-center">
      <div class="row">
        <div class="col-md-8 ml-md-auto mr-md-auto">
          <div class="u-heading-v7-2 g-mb-30">
            <h2 class="display-4 u-heading-v7__title g-mb-20">Build a Great
              <span class="g-color-primary">Product!</span>
            </h2>
            <i class="fa fa-star g-color-primary g-font-size-70x"></i>
            <i class="fa fa-star g-font-size-95x g-color-primary"></i>
            <i class="fa fa-star g-color-primary"></i>
            <i class="fa fa-star g-font-size-95x g-color-primary"></i>
            <i class="fa fa-star g-font-size-70x g-color-primary"></i>
          </div>
  
          <p class="lead g-mb-60">Sed feugiat porttitor nunc, non dignissim ipsum vestibulum in. Donec in blandit dolor. Vivamus a fringilla lorem, vel faucibus ante. Nunc ullamcorper, justo a iaculis elementum, enim orci viverra eros, fringilla porttitor lorem eros
            vel.</p>
  
          <a class="js-fancybox-media btn btn-xl u-btn-primary g-rounded-15" href="<?php echo e(route('front.contact')); ?>" data-src="//vimeo.com/14220611" data-animate-in="flipInY" data-animate-out="flipOutY" data-speed="1000">
            <i class="fa fa-phone" aria-hidden="true"></i>
            Contact Us
          </a>
        </div>
      </div>
    </div>
  </section>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>