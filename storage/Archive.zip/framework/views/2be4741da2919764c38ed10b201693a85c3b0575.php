        
<?php $__env->startSection('content'); ?>
    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard area -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="product__header" style="border-bottom: none;">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title">
                                                    <h2>Order Details <a href="<?php echo e(route('admin-order-index')); ?>" style="padding: 5px 12px;" class="btn add-back-btn"><i class="fa fa-arrow-left"></i> Back</a> <a href="<?php echo e(route('admin-order-invoice',$order->id)); ?>" style="padding: 5px 12px;" class="btn add-back-btn"><i class="fa fa-file"></i> Invoice</a></h2>
                                                    <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Orders <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Order Details</p>
                                                </div>
                                            </div>
                                            <?php echo $__env->make('includes.notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </div>   
                                    </div>
                                    <main>

                                        <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                        <div class="order-table-wrap">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="table-responsive">
                                                        <table class="table">
                                                            <tbody>
                                                                <tr class="tr-head">
                                                                    <th class="order-th" width="45%">Order ID</th>
                                                                    <th width="10%">:</th>
                                                                    <th class="order-th" width="45%" style="text-transform: uppercase;"><?php echo e($order->order_number); ?></th>
                                                                </tr>
                                                                <tr>
                                                                    <th width="45%">Total Product</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($order->totalQty); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th width="45%">Total Cost</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($order->currency_sign); ?><?php echo e(round($order->pay_amount * $order->currency_value , 2)); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th width="45%">Ordered Date</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e(date('d-M-Y H:i:s a',strtotime($order->created_at))); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th width="45%">Payment Method</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($order->method); ?></td>
                                                                </tr>
                                                                <?php if($order->method != "Cash On Delivery"): ?>
                                                                    <?php if($order->method=="Stripe"): ?>
                                                                        <tr>
                                                                            <th width="45%"><?php echo e($order->method); ?> Charge ID</th>
                                                                            <th width="10%">:</th>
                                                                            <td width="45%"><?php echo e($order->charge_id); ?></td>
                                                                        </tr>                        
                                                                    <?php endif; ?>
                                                                    <tr>
                                                                        <th width="45%"><?php echo e($order->method); ?> Transaction ID</th>
                                                                        <th width="10%">:</th>
                                                                        <td width="45%"><?php echo e($order->txnid); ?></td>
                                                                    </tr>                         
                                                                <?php endif; ?>

        
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6" style="text-align:right">
                                                    <?php if($order->payment_status == "Completed"): ?>
                                                        <span class="btn-lg btn-success" style="cursor:default; border-radius:0">Paid</span>
                                                    <?php else: ?>
                                                        <span class="btn-lg btn-danger" style="cursor:default; border-radius:0">Unpaid</span> 
                                                    <?php endif; ?>
                                                </div>
                                            </div>
        
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="table-responsive">
                                                        <table class="table">
                                                            <tbody>
                                                                <tr class="tr-head">
                                                                    <th class="order-th" width="45%">Billing Address</th>
                                                                    <th width="10%"></th>
                                                                    <th width="45%">
                                                                        <?php if($order->customer_latlong): ?>
                                                                            <a href="javascript:;" title="View in Map" data-toggle="modal" data-target="#billingLocationModal" style="font-size: 20px;"><i class="fa fa-map-marker"></i></a>
                                                                        <?php endif; ?>

                                                                    </th>
                                                                </tr>
                                                                <tr>
                                                                    <th width="45%">Name</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($order->customer_name); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th width="45%">Email</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($order->customer_email); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th width="45%">Phone</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($order->customer_phone); ?></td>
                                                                </tr>
                                                                <?php if($order->customer_pan_number): ?>
                                                                    <tr>
                                                                        <th width="45%">PAN Number</th>
                                                                        <th width="10%">:</th>
                                                                        <td width="45%"><?php echo e($order->customer_pan_number); ?></td>
                                                                    </tr>
                                                                <?php endif; ?>
                                                                <tr>
                                                                    <th width="45%">Address Type</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($order->customer_address_type); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th width="45%">Address</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($order->customer_address); ?></td>
                                                                </tr>
                                                                
                                                                <tr>
                                                                    <th width="45%">Country</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($order->customer_country); ?></td>
                                                                </tr>
                                                                
                                                                <?php if($order->customer_zip): ?>
                                                                    <tr>
                                                                        <th width="45%">Postal Code</th>
                                                                        <th width="10%">:</th>
                                                                        <td width="45%"><?php echo e($order->customer_zip); ?></td>
                                                                    </tr>
                                                                <?php endif; ?>
                                                                <?php if($order->coupon_code != null): ?>
                                                                <tr>
                                                                    <th width="45%">Coupon Code</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($order->coupon_code); ?></td>
                                                                </tr>
                                                                <?php endif; ?>
                                                                
                                                                <?php if($order->affilate_user != null): ?>
                                                                <tr>
                                                                    <th width="45%">Affilate User</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($order->affilate_user); ?></td>
                                                                </tr>
                                                                <?php endif; ?>
                                                                <?php if($order->affilate_charge != null): ?>
                                                                <tr>
                                                                    <th width="45%">Affilate Charge</th>
                                                                    <th width="10%">:</th>
                                                                    <td width="45%"><?php echo e($order->affilate_charge); ?></td>
                                                                </tr>
                                                                <?php endif; ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <?php if($order->dp == 0): ?>
                                                    <div class="col-lg-6">
                                                        <div class="table-responsive">
                                                            <table class="table">
                                                                <tbody>
                                                                    <tr class="tr-head">
                                                                        <th class="order-th" width="45%"><strong>Delivery Address</strong></th>
                                                                        <th width="10%"></th>
                                                                        <td width="45%">
                                                                            <?php if($order->shipping_latlong): ?>
                                                                                <a href="javascript:;" title="View in Map" data-toggle="modal" data-target="#shippingLocationModal" style="font-size: 20px;"><i class="fa fa-map-marker"></i></a>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <?php if($order->shipping == "pickup"): ?>
                                                                        <tr>
                                                                            <th width="45%"><strong>Pickup Location:</strong></th>
                                                                            <th width="10%">:</th>
                                                                            <td width="45%"><?php echo e($order->pickup_location); ?></td>
                                                                        </tr>
                                                                    <?php else: ?>
                                                                        <tr>
                                                                            <th width="45%"><strong>Name:</strong></th>
                                                                            <th width="10%">:</th>
                                                                            <td><?php echo e($order->shipping_name == null ? $order->customer_name : $order->shipping_name); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th width="45%"><strong>Email:</strong></th>
                                                                            <th width="10%">:</th>
                                                                            <td width="45%"><?php echo e($order->shipping_email == null ? $order->customer_email : $order->shipping_email); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th width="45%"><strong>Phone:</strong></th>
                                                                            <th width="10%">:</th>
                                                                            <td width="45%"><?php echo e($order->shipping_phone == null ? $order->customer_phone : $order->shipping_phone); ?></td>
                                                                        </tr>
                                                                        <?php if($order->shipping_pan_number): ?>
                                                                            <tr>
                                                                                <th width="45%">PAN Number</th>
                                                                                <th width="10%">:</th>
                                                                                <td width="45%"><?php echo e($order->shipping_pan_number ? $order->shipping_pan_number: $order->customer_pan_number); ?></td>
                                                                            </tr>
                                                                        <?php endif; ?>
                                                                        <tr>
                                                                            <th width="45%">Address Type</th>
                                                                            <th width="10%">:</th>
                                                                            <td width="45%"><?php echo e($order->shipping_address_type ? $order->shipping_address_type: $order->customer_address_type); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th width="45%"><strong>Address:</strong></th>
                                                                            <th width="10%">:</th>
                                                                            <td width="45%"><?php echo e($order->shipping_address == null ? $order->customer_address : $order->shipping_address); ?></td>
                                                                        </tr>
                                                                        
                                                                        <tr>
                                                                            <th width="45%"><strong>Country:</strong></th>
                                                                            <th width="10%">:</th>
                                                                            <td width="45%"><?php echo e($order->shipping_country == null ? $order->customer_country : $order->shipping_country); ?></td>
                                                                        </tr>
                                                                        
                                                                    <?php endif; ?>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        

                                        <div class="" style="padding-left:30px;">

                                        <h3>Notes</h3>
                                            <?php if($order->order_note): ?>
                                            <p><?php echo e($order->order_note); ?></p>
                                            <?php else: ?>
                                            <p>No Notes Found.</p>

                                            <?php endif; ?>
    
                                                                                            
                                                 
    
                                           
                                            </div>
                                        
                                        <br>
                                        <table id="example" class="table">
                                            <h4 class="text-center">Products Ordered</h4><hr>
                                            <thead>
                                                <tr>
                                                    <th width="10%">Product ID#</th>
                                                    
                                                    
                                                    <th>Product Title</th>
                                                  
                                                    <th width="10%">Quantity</th>
                                                    
                                                    <th width="20%">Total Price</th>
                                                    
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                    $subtotal = 0;
                                                    $discountedsubtotal = 0;
                                                 ?>
                                                <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <input type="hidden" value="<?php echo e($key); ?>">
                                                        <td><?php echo e($product['item']['id']); ?></td>
                                                        
                                                        <td>
                                                            <input type="hidden" value="<?php echo e($product['license']); ?>">
                                                            <a target="_blank" href="<?php echo e(route('front.product',['id1' => $product['item']['id'], str_slug($product['item']['name'],'-')])); ?>"><?php echo e(strlen($product['item']['name']) > 60 ? substr($product['item']['name'],0,60).'...' : $product['item']['name']); ?></a>
                                                            <?php if($product['license'] != ''): ?>
                                                                <a href="javascript:;" data-toggle="modal" data-target="#confirm-delete" class="btn btn-info product-btn" id="license" style="padding: 5px 12px;"><i class="fa fa-eye"></i> View License</a>
                                                            <?php endif; ?>

                                                        </td>
                                
                                                        <td><?php echo e($product['qty']); ?> <?php echo e($product['item']['measure']); ?></td>
                                                        

                                                        <td><?php echo e($order->currency_sign); ?><?php echo e(round($product['item']['cprice'] * $product['qty']  * $order->currency_value , 2)); ?></td>

                                                    </tr>
                                                    <?php 
                                                        $subtotal += $product['qty'] * $product['item']['cprice'];
                                                        $discountedsubtotal += $product['price'];
                                                     ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <td align="right" colspan="3" style="font-weight:800;">
                                                        Sub Total                       
                                                    </td>
                                                    <td align="left" style="font-weight:800;">
                                                        <?php echo e($order->currency_sign); ?> <?php echo e(round($subtotal * $order->currency_value , 2)); ?>

                                                    </td>
                                                </tr>
                                                <?php if($subtotal > $discountedsubtotal): ?>
                                                    <tr>
                                                        
                                                        
                                                        <td align="right" colspan="3" style="font-weight:800;border-top:0">
                                                            Price Discount                       
                                                        </td>
                                                        <td align="left" style="font-weight:800;border-top:0">
                                                            <?php echo e($order->currency_sign); ?> <?php echo e(round(($subtotal - $discountedsubtotal) * $order->currency_value , 2)); ?>

                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                                
                                                <?php if($order->coupon_code != null): ?>
                                                    <tr>
                                                        
                                                        
                                                        <td align="right" colspan="3" style="font-weight:800;border-top:0">
                                                            Discount Coupon (<?php echo e($order->coupon_code); ?>)                   
                                                        </td>
                                                        <td align="left" style="font-weight:800;border-top:0">
                                                            <?php echo e($order->currency_sign); ?> <?php echo e($order->coupon_discount * $order->currency_value); ?>

                                                        </td>
                                                    </tr>
                                                <?php endif; ?>

                                                <?php if($order->discount > 0): ?>
                                                    <tr>
                                                        
                                                        
                                                        <td align="right" colspan="3" style="font-weight:800;border-top:0">
                                                            Payment Gateway Discount (<?php echo e($order->method); ?>)                  
                                                        </td>
                                                        <td align="left" style="font-weight:800;border-top:0">
                                                            <?php echo e($order->currency_sign); ?> <?php echo e($order->discount * $order->currency_value); ?>

                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                            
                                                <?php if($order->shipping_cost != 0): ?>
                                                    <tr>
                                                        
                                                        
                                                        <td align="right" colspan="3" style="font-weight:800;border-top:0">
                                                            Delivery Fee                  
                                                        </td>
                                                        <td align="left" style="font-weight:800;border-top:0">
                                                            <?php echo e($order->currency_sign); ?> <?php echo e($order->shipping_cost * $order->currency_value); ?>

                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                            
                                                <?php if($order->tax != 0): ?>
                                                    <tr>
                                                        
                                                        
                                                        <td align="right" colspan="3" style="font-weight:800;border-top:0">
                                                            Tax               
                                                        </td>
                                                        <td align="left" style="font-weight:800;border-top:0">
                                                            <?php echo e($order->currency_sign); ?> <?php echo e($order->tax * $order->currency_value); ?>

                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                                <tr>
                                                    
                                                    
                                                    <td align="right" colspan="3" style="font-weight:800;border-top:0">
                                                        Total                       
                                                    </td>
                                                    <td align="left" style="font-weight:800;border-top:0">
                                                        <?php echo e($order->currency_sign); ?> <?php echo e(round($order->pay_amount * $order->currency_value , 2)); ?>

                                                    </td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </main>
                                    <hr>
                                    <div class="text-center">
                                        <input type="hidden" value="<?php echo e($order->customer_email); ?>">
                                        <a style="cursor: pointer;" data-toggle="modal" data-target="#emailModal"class="btn btn-success email"><i class="fa fa-send"></i> Send Email</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard area --> 
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="billingLocationModal" tabindex="-1" role="dialog" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog" role="document">
          <div class="modal-content" style="margin-top: 0;">
            <div class="modal-header text-center" style="border-bottom: none;padding-bottom: 0">
                <h4><strong>Billing Location</strong></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="fa fa-times"></i>
                </button>
            </div>
    
            <div class="modal-body text-center">
                
                 <div id="map1" style="height: 500px"></div>
                
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-neutral" data-dismiss="modal" aria-label="Close">OK</button>
            </div>
          </div>
        </div>
    </div>

    <div class="modal fade" id="shippingLocationModal" tabindex="-1" role="dialog" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog" role="document">
          <div class="modal-content" style="margin-top: 0;">
            <div class="modal-header text-center" style="border-bottom: none;padding-bottom: 0">
                <h4><strong>Shipping Location</strong></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="fa fa-times"></i>
                </button>
            </div>
    
            <div class="modal-body text-center">
                
                 <div id="map2" style="height: 500px"></div>
                
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-neutral" data-dismiss="modal" aria-label="Close">OK</button>
            </div>
          </div>
        </div>
    </div>

    <div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title text-center" id="myModalLabel">License Key</h4>
                </div>
                <div class="modal-body">
                    <p class="text-center">The Licenes Key is :  <span id="key"></span> <a id="license-edit" style="cursor: pointer;">Edit License</a><a id="license-cancel" style="cursor: pointer; display: none;">Cancel</a></p>
                    <form method="POST" action="<?php echo e(route('admin-order-license',$order->id)); ?>" id="edit-license" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="license_key" id="license-key" value="">
                        <div class="form-group text-center">
                    <input type="text" name="license" placeholder="Enter New License Key" style="width: 40%;" required=""><input type="submit" name="submit" class="btn btn-primary" style="border-radius: 0; padding: 2px; margin-bottom: 2px;">
                        </div>
                    </form>
                </div>
                <div class="modal-footer" style="text-align: center;">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript">
        $('#example').dataTable( {
        "ordering": false,
            'paging'      : false,
            'lengthChange': false,
            'searching'   : false,
            'ordering'    : false,
            'info'        : false,
            'autoWidth'   : false,
            'responsive'  : true
        } );
    </script>
    
    <script>

        function initMap() {
            var myLatLng1 = JSON.parse('<?php echo $order->customer_latlong ?>');
            var myLatLng2 = null;

            if('<?php echo $order->shipping_latlong ?>')
                myLatLng2 = JSON.parse('<?php echo $order->shipping_latlong ?>');

            var map = new google.maps.Map(document.getElementById('map1'), {
                zoom: 17,
                center: myLatLng1
            });
    
            var marker = new google.maps.Marker({
                position: myLatLng1,
                map: map,
                title: '<?php echo e($order->customer_address); ?>'
            });

            if(myLatLng2){
                
                var map = new google.maps.Map(document.getElementById('map2'), {
                    zoom: 17,
                    center: myLatLng2
                });
        
                var marker = new google.maps.Marker({
                    position: myLatLng2,
                    map: map,
                    title: '<?php echo e($order->shipping_latlong); ?>'
                });
            }
        }
    </script>

    <?php if($order->customer_latlong || $order->shipping_latlong): ?>
        <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAcvyYLSF2ngh8GM7hX7EQ3dIcQGbGnx5Q&callback=initMap">
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>