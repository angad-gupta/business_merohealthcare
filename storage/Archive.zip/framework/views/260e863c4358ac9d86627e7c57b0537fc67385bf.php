<?php $__env->startSection('title',$childcat->child_name.' - Shop Category'); ?>
<?php $__env->startSection('content'); ?>

<?php 
$i=1;
$j=1;
$now = Carbon\Carbon::now()->format('Y/m/d h:i A');

 ?>

<style>
  .js-countdown {
      font-size:15px;
    }
  .g-color-black{
    color: 555 !important;
  }


  @media  only screen and (max-width: 1200px) and (min-width: 992px){
.category-wrap .product-image-area {
    width: 100%;
    height: 220px;
}
}

@media  only screen and (max-width: 991px) and (min-width: 768px){
.category-wrap .product-image-area {
    width: 100%;
    height: 200px;
}
}

@media  only screen and (max-width: 767px){
.category-wrap .product-image-area {
    height: 175px;
    width: 100%;
}
.js-countdown {
      font-size:12px !important;
    }
}

.gallery-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 2;
    opacity: 0;
    transition: all .4s ease-in;
}

.product-hover-area {
    position: absolute;
    width: 101%;
    left: 0;
    bottom: -15%;
    opacity: 0;
    visibility: hidden;
    z-index: 3;
    -webkit-transition: all .4s ease-in;
    transition: all .4s ease-in;
    z-index: 36;
}

.single-product-area {
    border: 0px solid #e0e0e0;
    box-shadow: 0 0 0px 1px #dedede;
    display: block;
    -webkit-transform: perspective(1px) translateZ(0);
    transform: perspective(1px) translateZ(0);
    position: relative;
    overflow: hidden;
    -webkit-transition: all .3s ease-in;
    transition: all .3s ease-in;
    margin-bottom: 30px;
}
</style>
<?php 
$i=1;
$j=1;
 ?>
<!-- Starting of Section title overlay area -->
    <div class="title-overlay-wrap overlay" style="background-image: url(<?php echo e(asset('assets/images/'.$gs->bgimg)); ?>);">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 text-center">
            <h1><?php echo e($childcat->child_name); ?></h1>
          </div>
        </div>
      </div>
    </div>
    <!-- Ending of Section title overlay area -->

    <!-- Starting of product category area -->
    <div class="section-padding product-category-wrap">
        <div class="container">
            <div class="row">


       

                <?php echo $__env->make('includes.catalog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="col-lg-9 col-md-8 col-sm-12 col-xs-12">
                    <div class="category-wrap">
                        <div class="row">
                                <?php $__empty_1 = true; $__currentLoopData = $childcats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                  <?php 
                                  $prod->pprice = $prod->pprice ? : $prod->cprice;
                                  $prod->cprice = $prod->getPrice(1);
                                   ?>

    
                                
                                <?php if($prod->user_id != 0): ?>

                                
                                <?php if($prod->user->is_vendor == 2): ?>
                      <?php 
                      $price = $prod->cprice + $gs->fixed_commission + ($prod->cprice/100) * $gs->percentage_commission ;
                       ?>

                            <?php if(isset($max)): ?>  
                            <?php if($price < $max): ?>
                            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                                      <?php 
                                          $name = str_replace(" ","-",$prod->name);
                                       ?>
                        <div class="single-product-area text-center" style="margin-bottom:0px;">
                          <div class="product-image-area">
                                            <?php if($prod->features!=null && $prod->colors!=null): ?>
                                            <?php 
                                            $title = explode(',', $prod->features);
                                            $details = explode(',', $prod->colors);
                                             ?>
                                            <div class="featured-tag" style="width: 100%;">
                                              <?php $__currentLoopData = array_combine($title,$details); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ttl => $dtl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <style type="text/css">
                                                span#d<?php echo e($j++); ?>:after {
                                                    border-left: 10px solid <?php echo e($dtl); ?>;
                                                }
                                              </style>
                                              <span id="d<?php echo e($i++); ?>" style="background: <?php echo e($dtl); ?>"><?php echo e($ttl); ?></span>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <?php endif; ?>
                            <img src="<?php echo e(asset('assets/images/'.$prod->photo)); ?>" alt="featured product">
                            <?php if($prod->youtube != null): ?>
                            <div class="product-hover-top">
                              <span class="fancybox" data-fancybox href="<?php echo e($prod->youtube); ?>"><i class="fa fa-play-circle"></i></span>
                            </div>
                            <?php endif; ?>

                            <div class="gallery-overlay"></div>
<div class="gallery-border"></div>
<div class="product-hover-area">
                    <input type="hidden" value="<?php echo e($prod->id); ?>">
                    
                              <span class="hovertip addcart" rel-toggle="tooltip" title="<?php echo e($lang->hcs); ?>"><a class="productDetails-addCart-btn" id="addcrt" href="javascript:;" style="cursor: pointer;">
                              </a>
                              <i class="icon-finance-100 u-line-icon-pro"></i> 
                              </span>
                              
                            </div>



                          </div>
                        </div>
                          <div class="product-description text-center single-product-area" style="margin-top:0px;">
                            <div class="product-name" style="margin-bottom: 35px;"><a href="<?php echo e(route('front.product',['id' => $prod->id, 'slug' => str_slug($name,'-')])); ?>" class="text-center" style="margin-bottom:0px;"><?php echo e(strlen($prod->name) > 65 ? substr($prod->name,0,65)."..." : $prod->name); ?></a></div>
                            

                                    <?php if($gs->sign == 0): ?>
                                        <div class="product-price"><?php echo e($curr->sign); ?>

                      <?php echo e(round($price * $curr->value,2)); ?>

                    <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?>
                    <?php 
                                                      $pprice = $prod->pprice + $gs->fixed_commission + ($prod->pprice/100) * $gs->percentage_commission ;
                                                        
                                                     ?> 
                      <span style="display:inline; font-size:12px ;color:green;"><del class="offer-price" style="color:red;"><?php echo e($curr->sign); ?><?php echo e(round($pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>  
                      <?php endif; ?>

                                        </div>
                                    <?php else: ?>
                                        <div class="product-price">
                      <?php echo e(round($price * $curr->value,2)); ?>

                    <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?>
                    <?php 
                                                      $pprice = $prod->pprice + $gs->fixed_commission + ($prod->pprice/100) * $gs->percentage_commission ;
                                                        
                                                     ?> 
                      <span style="display:inline; font-size:12px; color:green"><del class="offer-price" style="color:red;"><?php echo e($curr->sign); ?><?php echo e(round($pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>  
                      <?php endif; ?>
<?php echo e($curr->sign); ?>

                                        </div>
                                    <?php endif; ?>
                          </div>
                        

                            </div>
                            <?php endif; ?>
                            <?php else: ?>                  
                            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                                      <?php 
                                          $name = str_replace(" ","-",$prod->name);
                                       ?>
                                      <div class="single-product-area text-center" style="margin-bottom:0px;" >
                        
                          <div class="product-image-area">
                                            <?php if($prod->features!=null && $prod->colors!=null): ?>
                                            <?php 
                                            $title = explode(',', $prod->features);
                                            $details = explode(',', $prod->colors);
                                             ?>
                                            <div class="featured-tag" style="width: 100%;">
                                              <?php $__currentLoopData = array_combine($title,$details); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ttl => $dtl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <style type="text/css">
                                                span#d<?php echo e($j++); ?>:after {
                                                    border-left: 10px solid <?php echo e($dtl); ?>;
                                                }
                                              </style>
                                              <span id="d<?php echo e($i++); ?>" style="background: <?php echo e($dtl); ?>"><?php echo e($ttl); ?></span>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <?php endif; ?>
                            <img src="<?php echo e(asset('assets/images/'.$prod->photo)); ?>" alt="featured product">
                            <?php if($prod->youtube != null): ?>
                            <div class="product-hover-top">
                              <span class="fancybox" data-fancybox href="<?php echo e($prod->youtube); ?>"><i class="fa fa-play-circle"></i></span>
                            </div>
                            <?php endif; ?>

                            <div class="gallery-overlay"></div>
<div class="gallery-border"></div>
<div class="product-hover-area">
                    <input type="hidden" value="<?php echo e($prod->id); ?>">
                    
                              <span class="hovertip addcart" rel-toggle="tooltip" title="<?php echo e($lang->hcs); ?>"><a class="productDetails-addCart-btn" id="addcrt" href="javascript:;" style="cursor: pointer;">
                              </a>
                              <i class="icon-finance-100 u-line-icon-pro"></i> 
                              </span>
                              
                            </div>



                          </div>
                        </div>
                          <div class="product-description text-center single-product-area" style="margin-top:0px;">
                            <div class="product-name" style="margin-bottom: 35px;"><a href="<?php echo e(route('front.product',['id' => $prod->id, 'slug' => $name])); ?>" class="text-center" style="margin-bottom:0px;"><?php echo e(strlen($prod->name) > 65 ? substr($prod->name,0,65)."..." : $prod->name); ?></a></div>
                            

                                    <?php if($gs->sign == 0): ?>
                                        <div class="product-price"><?php echo e($curr->sign); ?>

                      <?php echo e(round($price * $curr->value,2)); ?>

                    <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?>
                    <?php 
                                                      $pprice = $prod->pprice + $gs->fixed_commission + ($prod->pprice/100) * $gs->percentage_commission ;
                                                        
                                                     ?> 
                      <span style="display:inline; font-size:12px;color:green;"><del class="offer-price" style="color:red;"><?php echo e($curr->sign); ?><?php echo e(round($pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>  
                      <?php endif; ?>

                                        </div>
                                    <?php else: ?>
                                        <div class="product-price">
                      <?php echo e(round($price * $curr->value,2)); ?>

                    <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?>
                    <?php 
                                                      $pprice = $prod->pprice + $gs->fixed_commission + ($prod->pprice/100) * $gs->percentage_commission ;
                                                        
                                                     ?> 
                      <span style="display:inline; font-size:12px; color:green;"><del class="offer-price" style="color:red;"><?php echo e($curr->sign); ?><?php echo e(round($pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>  
                      <?php endif; ?>
<?php echo e($curr->sign); ?>

                                        </div>
                                    <?php endif; ?>
                          </div>
                       

                            </div>
                            <?php endif; ?>
                            <?php endif; ?>

                                

                                <?php else: ?>


                            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 " style="width: 50%;">
                                      <?php 
                                          $name = str_replace(" ","-",$prod->name);
                                       ?>
                        
                        <div class="single-product-area text-center" style="margin-bottom:0px;" >
                          <div class="product-image-area">
                                            <?php if($prod->features!=null && $prod->colors!=null): ?>
                                            <?php 
                                            $title = explode(',', $prod->features);
                                            $details = explode(',', $prod->colors);
                                             ?>
                                            <div class="featured-tag" style="width: 100%;">
                                              <?php $__currentLoopData = array_combine($title,$details); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ttl => $dtl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <style type="text/css">
                                                span#d<?php echo e($j++); ?>:after {
                                                    border-left: 10px solid <?php echo e($dtl); ?>;
                                                }
                                              </style>
                                              <span id="d<?php echo e($i++); ?>" style="background: <?php echo e($dtl); ?>"><?php echo e($ttl); ?></span>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <?php endif; ?>
                            <img src="<?php echo e(asset('assets/images/'.$prod->photo)); ?>" alt="featured product">
                            <?php if($prod->youtube != null): ?>
                            <div class="product-hover-top">
                              <span class="fancybox" data-fancybox href="<?php echo e($prod->youtube); ?>"><i class="fa fa-play-circle"></i></span>
                            </div>
                            <?php endif; ?>

                            <div class="gallery-overlay"></div>
<div class="gallery-border"></div>
<div class="product-hover-area">
                    <input type="hidden" value="<?php echo e($prod->id); ?>">
                    
                              <span class="hovertip addcart" rel-toggle="tooltip" title="<?php echo e($lang->hcs); ?>"><a class="productDetails-addCart-btn" id="addcrt" href="javascript:;" style="cursor: pointer;">
                              </a>
                              <i class="icon-finance-100 u-line-icon-pro"></i> 
                              </span>
                              
                            </div>



                          </div>
                        </div>
                          
                          <div class="product-description text-center single-product-area" style="margin-top:0px;">
                            
                            <div class="product-name" style="margin-bottom: 35px;"><a href="<?php echo e(route('front.product',['id' => $prod->id, 'slug' => $name])); ?>" class=" text-center"><?php echo e(strlen($prod->name) > 65 ? substr($prod->name,0,65)."..." : $prod->name); ?></a>
                              <?php if($prod->sale_from && $prod->sale_from <= $now && $prod->sale_to >= $now): ?>
                              <!--  Starting of countdown area   -->
                  
                              
                                  <div class="js-countdown u-countdown-v3 g-line-height-1_2 g-font-weight-300 g-color-black text-center text-uppercase" data-end-date="<?php echo e($prod->sale_to); ?>" data-month-format="%m" data-days-format="%D" data-hours-format="%H" data-minutes-format="%M" data-seconds-format="%S" style="">
                  
                  
                  
                                 <i class="et-icon-alarmclock u-icon-effect-v4--hover"></i>
                                <div class="d-inline-block" style="font-weight:600; font-size:14px;">
                                  <div class="js-cd-days mb-0" id="dayss" style="color:green;">00 </div>
                                  
                                </div>
                  
                                <div class="hidden-down d-inline-block align-top g-mt-1 " style="font-weight:600; ">D :</div>
                  
                                <div class="d-inline-block " style="font-weight:600; font-size:14px;">
                                  <div class="js-cd-hours mb-0" id="hourss">00 H</div>
                                  
                                </div>
                  
                                <div class="hidden-down d-inline-block align-top g-mt-1" style="font-weight:600;">H :</div>
                  
                                <div class="d-inline-block " style="font-weight:600; font-size:14px;">
                                  <div class="js-cd-minutes mb-0" id="minutess">00 M</div>
                                  
                                </div>
                  
                                <div class="hidden-down d-inline-block align-top g-mt-1" style="font-weight:600;">M :</div>
                  
                                <div class="d-inline-block " style="font-weight:600; font-size:14px;">
                                  <div class="js-cd-seconds mb-0" id="secondss" style="color:red;">00 </div>
                                  
                                </div>
                                <div class="hidden-down d-inline-block align-top g-mt-1" style="font-weight:600; color:red;">S </div>
                              </div>
                  
                              <!--  Ending of countdown area   -->
                          <?php endif; ?>
                            </div>
                            
                                    <?php if($gs->sign == 0): ?>
                                        <div class="product-price"><?php echo e($curr->sign); ?>

                      <?php echo e(round($prod->cprice * $curr->value,2)); ?>

                    <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?>
                      <span style="display:inline; font-size:12px; color:green;"><del class="offer-price" style="color:red;"><?php echo e($curr->sign); ?><?php echo e(round($prod->pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>  
                      <?php endif; ?>

                                        </div>
                                    <?php else: ?>
                                        <div class="product-price">
                      <?php echo e(round($prod->cprice * $curr->value,2)); ?>

                    <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?>
                      <span style="display:inline; font-size:12px; color:green;"><del class="offer-price" style="color:red;"><?php echo e($curr->sign); ?><?php echo e(round($prod->pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>  
                      <?php endif; ?>
<?php echo e($curr->sign); ?>

                                        </div>
                                    <?php endif; ?>
                          </div>
                   
                            </div>

                            <?php endif; ?>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <img src="<?php echo e(url('assets/images/not_found.png')); ?>" />
                            <?php endif; ?>

                        </div>

                <?php if(isset($min) || isset($max)): ?>
                    <div class="row">
                        <div class="col-md-12 text-center"> 
                            <?php echo $childcats->appends(['min' => $min, 'max' => $max])->links(); ?>               
                        </div>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <div class="col-md-12 text-center"> 
                            <?php echo $childcats->links(); ?>               
                        </div>
                    </div>
                <?php endif; ?>
                    </div>
                </div>              
            </div>
        </div>
    </div>
    <!-- Ending of product category area -->
          

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>



<script type="text/javascript">
        $("#sortby").change(function () {
        var sort = $("#sortby").val();
        window.location = "<?php echo e(url('/childcategory')); ?>/<?php echo e($childcat->child_slug); ?>/"+sort;
    });
</script>




<script type="text/javascript">
            $("#ex2").slider({});
        $("#ex2").on("slide", function(slideRange) {
            var totals = slideRange.value;
            var value = totals.toString().split(',');
            $("#price-min").val(value[0]);
            $("#price-max").val(value[1]);
        });
</script>

<script>
  $(document).on("click", ".addcart" , function(){
      var pid = $(this).parent().find('input[type=hidden]').val();
          $.ajax({
                  type: "GET",
                  url:"<?php echo e(URL::to('/json/addcart')); ?>",
                  data:{id:pid},
                  success:function(data){
                      if(data == 0)
                      {
                          $.notify("<?php echo e($gs->cart_error); ?>","error");
                      }
                      else
                      {
                      $(".empty").html("");
                      $(".total").html((data[0] * <?php echo e($curr->value); ?>).toFixed(2));
                      $(".cart-quantity").html(data[2]);
                      var arr = $.map(data[1], function(el) {
                      return el });
                      $(".cart").html("");
                      for(var k in arr)
                      {
                          var x = arr[k]['item']['name'];
                          var p = x.length  > 45 ? x.substring(0,45)+'...' : x;
                          var measure = arr[k]['item']['measure'] != null ? arr[k]['item']['measure'] : "";
                          $(".cart").append(
                          '<div class="single-myCart">'+
          '<p class="cart-close" onclick="remove('+arr[k]['item']['id']+')"><i class="fa fa-close"></i></p>'+
                          '<div class="cart-img">'+
                  '<img src="<?php echo e(asset('assets/images/')); ?>/'+arr[k]['item']['photo']+'" alt="Product image">'+
                          '</div>'+
                          '<div class="cart-info">'+
      '<a href="<?php echo e(url('/')); ?>/product/'+arr[k]['item']['id']+'/'+arr[k]['item']['name']+'" style="color: black; padding: 0 0;">'+'<h5>'+p+'</h5></a>'+
                      '<p><?php echo e($lang->cquantity); ?>: <span id="cqt'+arr[k]['item']['id']+'">'+arr[k]['qty']+'</span> '+measure+'</p>'+
                      <?php if($gs->sign == 0): ?>
                      '<p><?php echo e($curr->sign); ?><span id="prct'+arr[k]['item']['id']+'">'+(arr[k]['price'] * <?php echo e($curr->value); ?>).toFixed(2)+'</span></p>'+
                      <?php else: ?>
                      '<p><span id="prct'+arr[k]['item']['id']+'">'+(arr[k]['price'] * <?php echo e($curr->value); ?>).toFixed(2)+'</span><?php echo e($curr->sign); ?></p>'+
                      <?php endif; ?>
                      '</div>'+
                      '</div>');
                        }
                      $.notify("<?php echo e($gs->cart_success); ?>","success");
                      }
                  },
                  error: function(data){
                      if(data.responseJSON)
                      $.notify(data.responseJSON.error,"error");
                      else
                      $.notify('Something went wrong',"error");

                  }
            }); 
      return false;
  });

  $(document).on("click", ".addcartforSearch" , function(){
      
      var pid = $(this).parent().parent().find('input[type=hidden]').val();
      var quantityDiv = $(this).parent();

      $.ajax({
          type: "GET",
          url:"<?php echo e(URL::to('/json/addcart')); ?>",
          data:{id:pid},
          success:function(data){
              if(data == 0)
              {
                  $.notify("<?php echo e($gs->cart_error); ?>","error");
              }
              else
              {
                  var qty = 1;

                  $(".empty").html("");
                  $(".total").html((data[0] * <?php echo e($curr->value); ?>).toFixed(2));
                  $(".cart-quantity").html(data[2]);
                  var arr = $.map(data[1], function(el) {
                      return el 
                  });
                  $(".cart").html("");
                  for(var k in arr)
                  {
                      if(arr[k]['item']['id'] == pid) qty = arr[k]['qty'];

                      var x = arr[k]['item']['name'];
                      var p = x.length  > 45 ? x.substring(0,45)+'...' : x;
                      var measure = arr[k]['item']['measure'] != null ? arr[k]['item']['measure'] : "";
                      $(".cart").append(
                          '<div class="single-myCart">'+
                              '<p class="cart-close" onclick="remove('+arr[k]['item']['id']+')"><i class="fa fa-close"></i></p>'+
                              '<div class="cart-img">'+
                                  '<img src="<?php echo e(asset('assets/images/')); ?>/'+arr[k]['item']['photo']+'" alt="Product image">'+
                              '</div>'+
                              '<div class="cart-info">'+
                                  '<a href="<?php echo e(url('/')); ?>/product/'+arr[k]['item']['id']+'/'+arr[k]['item']['name']+'" style="color: black; padding: 0 0;">'+'<h5>'+p+'</h5></a>'+
                                  '<p><?php echo e($lang->cquantity); ?>: <span id="cqt'+arr[k]['item']['id']+'">'+arr[k]['qty']+'</span> '+measure+'</p>'+
                                  <?php if($gs->sign == 0): ?>
                                  '<p><?php echo e($curr->sign); ?> <span id="prct'+arr[k]['item']['id']+'">'+(arr[k]['price'] * <?php echo e($curr->value); ?>).toFixed(2)+'</span></p>'+
                                  <?php else: ?>
                                  '<p><span id="prct'+arr[k]['item']['id']+'">'+(arr[k]['price'] * <?php echo e($curr->value); ?>).toFixed(2)+'</span><?php echo e($curr->sign); ?></p>'+
                                  <?php endif; ?>
                              '</div>'+
                          '</div>'
                      );
                  }
                  
                  quantityDiv.html(
                      '<span class="quantity-btn reducingforSearch"><i class="fa fa-minus"></i></span>'+
                      '<span class="qtyforSearch">'+qty+'</span>'+
                      '<span class="quantity-btn addingforSearch"><i class="fa fa-plus"></i></span>'
                  );
                  $.notify("<?php echo e($gs->cart_success); ?>","success");
              }
          },
          error: function(data){
              if(data.responseJSON)
              $.notify(data.responseJSON.error,"error");
            else
              $.notify('Something went wrong',"error");

          }
      }); 
      return false;
  });

  $(document).on("click", ".addingforSearch" , function(e){
      e.preventDefault()
      var pid =  $(this).parent().parent().find('input[type=hidden]').val();
      var qty = $(this).parent().find(".qtyforSearch").html();
      var quantityDiv = $(this).parent();

      $.ajax({
          type: "GET",
          url:"<?php echo e(URL::to('/json/addbyone')); ?>",
          data:{id:pid},
          success:function(data){
              if(data == 0)
              {
                  $.notify("<?php echo e($gs->cart_error); ?>","error");
              }
              else
              {
                  $(".total").html((data[0] * <?php echo e($curr->value); ?>).toFixed(2));                        
                  $(".cart-quantity").html(data[3]);
                  $("#cqty"+pid).val("1");
                  $("#prc"+pid).html((data[2] * <?php echo e($curr->value); ?>).toFixed(2));
                  $('.cart-info').find("#prct"+pid).html((data[2] * <?php echo e($curr->value); ?>).toFixed(2));
                  $('.cart-info').find("#cqt"+pid).html(data[1]);
                  quantityDiv.find(".qtyforSearch").html(data[1]);
              }
          },
          error: function(data){
          if(data.responseJSON)
              $.notify(data.responseJSON.error,"error");
            else
              $.notify('Something went wrong',"error");

          }
      }); 
  });

  $(document).on("click", ".reducingforSearch" , function(e){
      e.preventDefault()
      var id =  $(this).parent().parent().find('input[type=hidden]').val();
      var qty = $(this).parent().find(".qtyforSearch").html();
      var quantityDiv = $(this).parent();
      qty--;
      if(qty < 1)
      {
          remove(id);
          quantityDiv.html('<button class="btn btn-sm btn-primary addcartforSearch">Add to Cart</button>');
      }
      else{
       
          $.ajax({
              type: "GET",
              url:"<?php echo e(URL::to('/json/reducebyone')); ?>",
              data:{id:id},
              success:function(data){
                  $(".total").html((data[0] * <?php echo e($curr->value); ?>).toFixed(2));
                  $(".cart-quantity").html(data[3]);
                  $("#cqty"+id).val("1");
                  $("#prc"+id).html((data[2] * <?php echo e($curr->value); ?>).toFixed(2));
                  
                  $('.cart-info').find("#prct"+id).html((data[2] * <?php echo e($curr->value); ?>).toFixed(2));
                  $('.cart-info').find("#cqt"+id).html(data[1]);
                  quantityDiv.find(".qtyforSearch").html(data[1]);
                  
              },
              error: function(data){
                  $.notify('Something went wrong',"error");

              }
          }); 
      }
  });

  </script>

<script  src="<?php echo e(asset('frontend-assets/main-assets/assets/vendor/jquery.countdown.min.js')); ?>"></script>

<!-- JS Unify -->
<script  src="<?php echo e(asset('frontend-assets/main-assets/assets/js/components/hs.countdown.js')); ?>"></script>

<!-- JS Plugins Init. -->
<script >
  $(document).on('ready', function () {
    // initialization of countdowns
    var countdowns = $.HSCore.components.HSCountdown.init('.js-countdown', {
      yearsElSelector: '.js-cd-years',
      monthElSelector: '.js-cd-month',
      daysElSelector: '.js-cd-days',
      hoursElSelector: '.js-cd-hours',
      minutesElSelector: '.js-cd-minutes',
      secondsElSelector: '.js-cd-seconds'
    });
  });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>