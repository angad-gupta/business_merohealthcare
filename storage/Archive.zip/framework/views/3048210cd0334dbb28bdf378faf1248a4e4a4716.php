
<?php $__env->startSection('title',$product->name); ?>
<?php $__env->startSection('styles'); ?>

<style>
p{
    margin:0px !important;
}

.rounded-0 {
    border-radius: 30px !important;
}

.u-nav-v1-1.u-nav-primary .nav-link.active {
   
    background-color: #ffffff !important;
    color: #2385aa !important;
    border: 1px solid;
    border-color: #2385aa;
}

#st-el-3 .st-btns {
    bottom: 56px;
    left: 0;
    margin: 100px auto 0;
    max-width: 90%;
    position: absolute;
    right: 0;
    text-align: center;
    top: 10px !important;
    z-index: 20;
    overflow-y: auto;
}

.product-details-wrapper .productDetails-addCart-btn {
    padding: 5px 15px !important;
}

.product-details-wrapper .productDetails-size, .productDetails-color {
    padding-bottom: 0px;
}

.product-details-wrapper .productDetails-price {
    padding: 0px 0;
}

.product-details-wrapper .productDetails-addCart-btn {
 
    padding: 10px 15px;

}

.jssocials-share-link { border-radius: 50%; }
  .product-price{
      font-size:18px;
  }
  
  


@media  only screen and (max-width: 767px){

  #offer{
    margin-top: 30px;
  }
.product-image-area {
  height: 175px !important;
  width: 100%;
  padding:1.5rem;
}
}

  .js-countdown {
        font-size:15px;
      }
  
    .g-color-black{
      color: 555 !important;
    }
  
  @media  only screen and (max-width: 1200px) and (min-width: 992px){
  .category-wrap .product-image-area {
      width: 100%;
      height: 220px;
  }
  }
  
  @media  only screen and (max-width: 991px) and (min-width: 768px){
  .category-wrap .product-image-area {
      width: 100%;
      height: 200px;
  }

  
  }

  @media (max-width: 1024px) and (min-width: 768px){
.g-mt-1 {
  margin-top: 0px!important;
}
  }

 
  
  
    @media  only screen and (max-width: 767px){

      
      .product-name{
          margin-bottom:50px !important;
      }
    .category-wrap .product-image-area {
        height: 175px;
        width: 100% ;
    }
    .js-countdown {
        font-size:12px !important;
      }
    }
    
    .gallery-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 2;
        opacity: 0;
        transition: all .4s ease-in;
    }
    
    .product-hover-area {
        position: absolute;
        width: 101%;
        left: 0;
        bottom: -15%;
        opacity: 0;
        visibility: hidden;
        z-index: 3;
        -webkit-transition: all .4s ease-in;
        transition: all .4s ease-in;
        z-index: 36;
    }
    
    .single-product-area {
        border: 0px solid #e0e0e0;
        box-shadow: 0 0 0px 0px #dedede;
        display: block;
        -webkit-transform: perspective(1px) translateZ(0);
        transform: perspective(1px) translateZ(0);
        position: relative;
        overflow: hidden;
        -webkit-transition: all .3s ease-in;
        transition: all .3s ease-in;
        margin-bottom: 30px;
    }

    .product-image-area {
  height: 220px ;
  width: 100%;
  padding:1.5rem;
}
    </style>





<style>
  <style type="text/css">

@media  only screen and (max-width: 767px){
.g-font-size-16{
    font-size: 10px !important;
}
.g-font-size-15{
    font-size: 10px !important;
}
.g-mt-1 {
    margin-top: 4px!important;
}
.et-icon-alarmclock{
    font-size: 10px;
}
#card-height{
    height: 24rem !important;
}

}



  .productDetails-size span.pselected-size {
    border: 3px #2485a9 solid;
  }
    .replay-btn, .replay-btn-edit, .replay-btn-delete, .replay-btn-edit1, .replay-btn-delete1, .replay-btn-edit2, .replay-btn-delete2, .subreplay-btn, .view-replay-btn {
      color: <?php echo e($gs->colors == null ? 'gray' : $gs->colors); ?>;
      font-weight: 700;
    }
    #comments .reply {
      padding-left: 52px;
    }
    .product-details-wrapper .productDetails-size a {
      display: inline-block;
      height: 40px;
      line-height: 40px;
      border: 1px #d9d9d9 solid;
      text-align: center;
      font-size: 12px;
      color: #4c4c4c;
      font-weight: 500;
      margin-right: 12px;
      position: relative;
      cursor: pointer;
      margin-bottom: 12px;
    }

    /* .product-details-wrapper .productDetails-size span {
    display: inline-block;
    width: 40px;
    height: 40px;
    line-height: 40px;
    border: 0px #d9d9d9 solid;
    text-align: center;
    font-size: 12px;
    color: #4c4c4c;
    font-weight: 500;
    margin-right: 12px;
    position: relative;
    cursor: pointer;
    margin-bottom: 12px;
} */
  </style>
  <?php if($lang->rtl == 1): ?>
    <style>
      #comments .reply {
        padding-left: 0;
        padding-right: 52px;
      }
      .single-blog-comments-wrap.replay {margin-left: 0; margin-right: 40px;}
    </style>
  <?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<link type="text/css" rel="stylesheet" href="https://cdn.jsdelivr.net/jquery.jssocials/1.4.0/jssocials.css" />

<link type="text/css" rel="stylesheet" href="https://cdn.jsdelivr.net/jquery.jssocials/1.4.0/jssocials-theme-flat.css" />
  <?php 
  $i=1;
  $j=1;
  $now = Carbon\Carbon::now()->format('Y/m/d h:i A');
  $product->pprice = $product->pprice ? : $product->cprice;
  $product->cprice = $product->getPrice(1);
   ?>
    <!--  Starting of product description area   -->
    <div class="section-padding product-details-wrapper" style="padding-top: 20px; padding-bottom: 15px;">
      <div class="container">
        <div class="breadcrumb-box" style="margin-bottom: 15px;">
          <?php if($product->requires_prescription): ?>
            <a href="<?php echo e(route('front.index')); ?>"><?php echo e(ucfirst(strtolower($lang->home))); ?></a>
            <a href="javascript:;" style="cursor:default"><?php echo e($product->categories()->first()->cat_name); ?></a>
            <?php if(count($product->subcategories) > 0): ?>
              <a href="javascript:;" style="cursor:default"><?php echo e($product->subcategories()->first()->sub_name); ?></a>
            <?php endif; ?>
            <?php if(count($product->childcategories) > 0): ?>
              <a href="javascript:;" style="cursor:default"><?php echo e($product->childcategories()->first()->child_name); ?></a>
            <?php endif; ?>
            <a href="<?php echo e(route('front.product',['id1' => $product->id , 'id2' => str_slug($product->name,'-')])); ?>"><?php echo e($product->name); ?></a>
            <span><?php echo e($product->name); ?></span>
          <?php else: ?>
            <a href="<?php echo e(route('front.index')); ?>"><?php echo e(ucfirst(strtolower($lang->home))); ?></a>
            <a href="<?php echo e(route('front.category',$product->categories()->first()->cat_slug)); ?>"><?php echo e($product->categories()->first()->cat_name); ?></a>
            <?php if(count($product->subcategories) > 0): ?>
              <a href="<?php echo e(route('front.subcategory',$product->subcategories()->first()->sub_slug)); ?>"><?php echo e($product->subcategories()->first()->sub_name); ?></a>
            <?php endif; ?>
            <?php if(count($product->childcategories) > 0): ?>
              <a href="<?php echo e(route('front.childcategory',$product->childcategories()->first()->child_slug)); ?>"><?php echo e($product->childcategories()->first()->child_name); ?></a>
            <?php endif; ?>
            <a href="<?php echo e(route('front.product',['id1' => $product->id , 'id2' => str_slug($product->name,'-')])); ?>"><?php echo e($product->name); ?></a>
          <?php endif; ?>
        </div>

       
          
          <div class="row">
            <div class="col-md-4 col-sm-4 col-xs-12">
           
                <div id="carousel-08-1" class="js-carousel text-center g-mb-20" data-infinite="true" data-arrows-classes="u-arrow-v1 g-absolute-centered--y g-width-35 g-height-40 g-font-size-18 g-color-gray g-bg-white g-mt-minus-10" data-arrow-left-classes="fa fa-angle-left g-left-0" data-arrow-right-classes="fa fa-angle-right g-right-0" data-nav-for="#carousel-08-2">
                  <div class="js-slide">

                    <a class="js-fancybox d-block g-pos-rel" href="javascript:;" data-fancybox="lightbox-gallery--08-1" data-src="<?php echo e(asset('assets/images/'.$product->photo)); ?>" data-caption="Lightbox Gallery" data-animate-in="bounceInDown" data-animate-out="bounceOutDown" data-speed="1000" data-overlay-blur-bg="true">
                      <img class="img-fluid" style="max-height:30rem;" src="<?php echo e(asset('assets/images/'.$product->photo)); ?>" alt="Image Description">
   
                    </a>
                    
                  </div>
                  
                  <?php $__currentLoopData = $product->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                 
                  
                  <div class="js-slide">

                    <a class="js-fancybox d-block g-pos-rel" href="javascript:;" data-fancybox="lightbox-gallery--08-1" data-src="<?php echo e(asset('assets/images/'.$gallery->photo)); ?>" data-caption="Lightbox Gallery" data-animate-in="bounceInDown" data-animate-out="bounceOutDown" data-speed="1000" data-overlay-blur-bg="true">
                      <img class="img-fluid" style="max-height:30rem;" src="<?php echo e(asset('assets/images/gallery/'.$gallery->photo)); ?>" alt="Image Description">
   
                    </a>
                    
                  </div>
               
                  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
                </div>
                
                <div id="carousel-08-2" class="js-carousel text-center g-mx-minus-10 u-carousel-v3" data-infinite="true" data-center-mode="true" data-slides-show="4" data-is-thumbs="true" data-nav-for="#carousel-08-1">
                 <div class="js-slide g-px-10">
                    <img class="img-fluid" style="height:6rem" src="<?php echo e($product->photo ? asset('assets/images/'.$product->photo):asset('assets/images/default.png')); ?>" alt="Image Description">
                  </div>
                  <?php $__currentLoopData = $product->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                  <div class="js-slide g-px-10">
                    <img class="img-fluid" style="height:6rem" src="<?php echo e($gallery->photo ? asset('assets/images/gallery/'.$gallery->photo):asset('assets/images/default.png')); ?>" alt="Image Description">
                  </div> 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>

            <div class="col-md-4 col-sm-4 col-xs-12">
              <?php if(strlen($product->name) > 40): ?>
                <h4 class="productDetails-header"><?php echo e($product->name); ?></h4>
              <?php else: ?>
                <h4 class="productDetails-header"><?php echo e($product->name); ?></h4>
              <?php endif; ?>
              
              <h6><?php echo e($product->company_name); ?></h6>

              <?php if($product->highlights != null): ?>
              <h5 style="font-weight:700; font-size:14px;">Product Highlights:</h5>
              <h6 style="font-size:14px;"><?php echo $product->highlights; ?></h6>
              <?php endif; ?>

              <?php if($product->user_id != 0): ?>

                <?php if(isset($product->user)): ?>
                  

                    
                    


                  
                <?php endif; ?>
              <?php else: ?>

                


                

              <?php endif; ?>
              <?php if($product->youtube != null): ?>                    
                <div class="productVideo__title">
                  <?php echo e($lang->watch_video); ?>: <a style=" color:<?php echo e($gs->colors == null ? '#337ab7':$gs->colors); ?>;" class="fancybox" data-fancybox="" href="<?php echo e($product->youtube); ?>"><i class="fa fa-play-circle"></i></a>
                </div>

              <?php endif; ?>
              <?php if($product->type == 2): ?>
                  <div class="productVideo__title">
                      <?php echo e($lang->platform); ?><?php echo e($product->platform); ?>

                  </div>
                  <div class="productVideo__title">
                      <?php echo e($lang->region); ?><?php echo e($product->region); ?>

                  </div>
                  <div class="productVideo__title">
                      <?php echo e($lang->licence_type); ?><?php echo e($product->licence_type); ?>

                  </div>
              <?php endif; ?>
              <?php if($product->product_condition != 0): ?>
                <div class="productDetails-header-info">

                          <div class="product-headerInfo__title">
                    <?php echo e($lang->product_condition); ?>: <span style="font-weight: 400;"><?php echo e($product->product_condition == 1 ?'Used' : 'New'); ?>.<span>
                  </div>
                </div>
              <?php endif; ?>
              <?php if($product->ship != null): ?>
                <div class="productDetails-header-info">

                  <div class="product-headerInfo__title">
                    <?php echo e($lang->shipping_time); ?>: <span style="font-weight: 400;"><?php echo e($product->ship); ?>.</span>
                  </div>
                </div>
              <?php endif; ?>
                  
              <?php 
                $stk = (string)$product->stock;
               ?>

              
              

              
             
              <?php if($similars->count() > 0): ?>
                <div class="productDetails-size">
                  <h5 style="font-weight:700; font-size:14px;">Available Variants: </h5>

                  <?php $__currentLoopData = $similars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($similar->id == $product->id): ?>
                      <span class="psize pselected-size" style="width: auto;padding: 5px;cursor:default;line-height: 27px; font-size: 14px; margin-bottom:0px; margin-right:0px;"><?php echo e($product->sub_title); ?></span>
                    <?php else: ?>
                      <a href="<?php echo e(route('front.product',[$similar->id,str_slug($similar->name,'-')])); ?>" class="psize" style="text-decoration:none;width: auto;padding: 5px; line-height: 27px; font-size: 14px; margin-right:0px; border: 3px #d9d9d9 solid; margin-bottom:0px !important;"><?php echo e($similar->sub_title); ?></a>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              <?php endif; ?>

               <div class="productDetails-size">

                <p class="mb-0" style="font-size:14px;">Price: </p>
               

                <?php if($gs->sign == 0): ?>
                
                <div class="container row" style=" ">
                  <h5 class="productDetails-price" style="margin-bottom: 0px; padding-bottom:0px;">
                    <?php echo e($curr->sign); ?> 
                    
                    
                    <?php if($product->user_id != 0): ?>

                      <?php 
                      $price = $product->cprice + $gs->fixed_commission + ($product->cprice/100) * $gs->percentage_commission ;
                       ?>
                     <?php echo e(round($price * $curr->value,2)); ?> <em class="g-font-style-normal g-font-weight-300 g-font-size-12">/ <?php echo e($product->product_quantity); ?></em>
                      <?php if($product->pprice != null && $product->pprice != 0  && $product->pprice > $product->cprice): ?>
                        <?php 
                          $pprice = $product->pprice + $gs->fixed_commission + ($product->pprice/100) * $gs->percentage_commission ;
                            
                         ?>
                        <span style="display:inline; color:green;"><del style="color:red;"><?php echo e($curr->sign); ?><?php echo e(round($pprice * $curr->value,2)); ?> </del> -<?php echo e($product->discount_percent); ?>% </span> 
                      <?php endif; ?>
                    <?php else: ?>
                      <?php echo e(round($product->cprice * $curr->value,2)); ?> <em class="g-font-style-normal g-font-weight-300 g-font-size-12">/ <?php echo e($product->product_quantity); ?></em>
                      <?php if($product->pprice != null && $product->pprice != 0  && $product->pprice > $product->cprice): ?>
                    <span style="display:inline; color:green;"> <del style="color:red;"><?php echo e($curr->sign); ?><?php echo e(round($product->pprice * $curr->value,2)); ?></del> -<?php echo e($product->discount_percent); ?>%</span> 
                      <?php endif; ?>

                      
                    <?php endif; ?>     
                    
                    

                    
                  </h5>

                  
                </div>

                <?php else: ?>
                  <h3 class="productDetails-price">
                    <?php if($product->user_id != 0): ?>
                      <?php 
                      $price = $product->cprice + $gs->fixed_commission + ($product->cprice/100) * $gs->percentage_commission ;
                       ?>
                      <?php echo e(round($price * $curr->value,2)); ?>

                    <?php else: ?>
                      <?php echo e(round($product->cprice * $curr->value,2)); ?>

                    <?php endif; ?>                   
                    <?php echo e($curr->sign); ?>

                    
                  </h3>                 
                  <?php endif; ?>
                  
                  
              
                  
              
              <?php if($product->sale_from && $product->sale_from <= $now && $product->sale_to >= $now): ?>
              <p class="mb-2" style="font-weight: 700;font-size: 14px;">Discount Valid till: </p>
              <!--  Starting of countdown area   -->
                  
                  <div class="js-countdown u-countdown-v3 g-line-height-1_2 g-color-black text-uppercase" >
             
                    <div class="d-inline-block g-mb-5">
                      <div class="js-cd-days g-font-size-16 mb-0" id="days" style="color:green;">00</div>
                      <h6 class="" style="color:green; border:0px;font-size:10px;">Days</h6>
                    </div>
                  
                    <div class="hidden-down d-inline-block align-top g-font-size-20 g-mt-0">:</div>
                  
                    <div class="d-inline-block g-mx-10 g-mb-5">
                      <div class="js-cd-hours g-font-size-16 mb-0" id="hours">00</div>
                      <h6 class="" style="font-size:10px;">Hours</h6>
                    </div>
                  
                    <div class="hidden-down d-inline-block align-top g-font-size-20 g-mt-0">:</div>
                  
                    <div class="d-inline-block g-mx-10 g-mb-5">
                      <div class="js-cd-minutes g-font-size-16 mb-0" id="minutes">00</div>
                      <h6 class="" style="font-size:10px;">Minutes</h6>
                    </div>
                  
                    <div class="hidden-down d-inline-block align-top g-font-size-20 g-mt-0">:</div>
                  
                    <div class="d-inline-block g-mx-10 g-mb-5">
                      <div class="js-cd-seconds g-font-size-16 mb-0" id="seconds" style="color:red;">00</div>
                      <h6 class="" style="color:red;font-size:10px;">Seconds</h6>
                    </div>
                  </div>
                  
                  <!--  Ending of countdown area   -->
              <?php endif; ?>
              </div>

              <div class="productDetails-quantity" >
                <p class="mb-0" style="padding-bottom: 5px; font-size:14px;"><?php echo e($lang->cquantity); ?>:</p>
                
               <input type="hidden" id="stock" value="<?php echo e($product->stock); ?>">
                
              </div>

              <div class="center">
              
                <div class="input-group" style="width:100px;">
                    <span class="">
                        <button type="button" class="btn btn-danger btn-number"  data-type="minus" data-field="quant[2]" style="border-radius:0px; background-color:white; border-color:#bfbfbf; font-size: 14.5px; border-top-left-radius:10px;border-bottom-left-radius:10px; right:-1px; height:35px;">
                          <span class="glyphicon glyphicon-minus" style="color:black;"></span>
                        </button>
                    </span>
                    <input id="myqty" type="number" step="1" name="quant[2]" class="form-control input-number" onkeydown="if(event.key==='.'){event.preventDefault();}"  oninput="event.target.value = event.target.value.replace(/[^0-9]*/g,'');" value="1" min="1" max="100000" style="height:35px;">
                   


                    <span class="input-group-btn" >
                        <button type="button" class="btn btn-success btn-number" data-type="plus" data-field="quant[2]" style="border-radius:0px; background-color:white; border-color:#bfbfbf; border-top-right-radius:10px; border-bottom-right-radius:10px;">
                            <span class="glyphicon glyphicon-plus " style="color:black;"></span>
                        </button>
                    </span>
                    

                   
                    
                    
                </div>

                
            
          </div>
            <?php if(Auth::guard('user')->check()): ?>
              <?php if($stk == "0"): ?>
              <a class="productDetails-addCart-btn" href="javascript:;" style="cursor: no-drop; border-radius:30px;">
                <i class="icon-finance-100 u-line-icon-pro"></i> <span><?php echo e($lang->dni); ?></span>
              </a>
              <?php else: ?>
              <a class="productDetails-addCart-btn" id="addcrt" href="javascript:;" style="cursor: pointer;border-radius:30px;">
                <i class="icon-finance-100 u-line-icon-pro"></i> <span><?php echo e($lang->hcs); ?></span>
              </a>
              <?php endif; ?>
              

            <?php else: ?>
            <a class="productDetails-addCart-btn" href="<?php echo e(route('business-login')); ?>" style="cursor: pointer;border-radius:30px;">
              <i class="icon-finance-100 u-line-icon-pro"></i> <span><?php echo e($lang->hcs); ?></span>
            </a>
              
            <?php endif; ?>

            <a class="productDetails-addCart-btn" href="<?php echo e(route('front.cart')); ?>" style="border-radius:30px;">
              <i class="icon-eye"></i></i> <span>View Cart</span>
            </a>

          

               
              <?php if($product->adv_price): ?>
              <hr/>
                <div class="OtcPage__combo-pack___P9Cwj">
                  <div class="ComboPack__combo-heading___SnepS">
                    <h3 style="font-size: 16px;font-weight: 700;">Combo packs:</h3>
                  </div>
                  <ul class="list-unstyled">

                  <?php $__currentLoopData = $product->prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($pro->is_bonus_price == null): ?>
                    <?php 
                        $product->price = $product->getTotalPrice($pro->min_qty)
                     ?>
                      <li class="d-flex justify-content-start g-brd-around g-brd-gray-light-v4 g-pa-10 g-mb-minus-1">
                        <div class="align-self-center g-px-10">
                          <h5 class="h6 g-font-weight-600 g-color-black g-mb-3">
                            <span class="g-mr-5 mb-0">Pack of <?php echo e($pro->min_qty); ?></span>
                            
                          </h5>
                          <p class="m-0">
                              <?php if($gs->sign == 0): ?>
                              <h5 class="productDetails-price">
                                <?php echo e($curr->sign); ?>

                                
                                <?php if($product->user_id != 0): ?>
                                  <?php 
                                  $price = $product->price + $gs->fixed_commission + ($product->price/100) * $gs->percentage_commission ;
                                   ?>
                                  <?php echo e(round($price * $curr->value,2)); ?>

                                <?php else: ?>
                                  <?php echo e(round($product->price * $curr->value,2)); ?>

                                <?php endif; ?>                   
              
                                <?php if($product->price != round($product->cprice*$pro->min_qty,2)): ?>
                                  <span style="color:green;font-size:14px;" ><del style="color:red;"> <?php echo e($curr->sign); ?><?php echo e(round($product->cprice *$pro->min_qty* $curr->value,2)); ?></del> -<?php echo e($pro->value); ?>%</span>
                                <?php endif; ?>


                              </h5>
                            <?php else: ?>
                              <h5 class="productDetails-price">
                                <?php if($product->user_id != 0): ?>
                                  <?php 
                                  $price = $product->price + $gs->fixed_commission + ($product->price/100) * $gs->percentage_commission ;
                                   ?>
                                  <?php echo e(round($price * $curr->value,2)); ?>

                                <?php else: ?>
                                  <?php echo e(round($product->price * $curr->value,2)); ?>

                                <?php endif; ?>                   
                                <?php echo e($curr->sign); ?>


                                <?php if($product->price != round($product->cprice*$pro->min_qty,2)): ?>
                                  <span style="color:green; font-size:14px;"><del style="color:red;"><?php echo e(round($product->cprice *$pro->min_qty * $curr->value,2)); ?><?php echo e($curr->sign); ?></del></span>
                                <?php endif; ?>
                              </h5>
                            <?php endif; ?>
                          </p>
                        </div>
                        <div class="align-self-center ml-auto">
                          
                          <?php if(Auth::guard('user')->check()): ?>
                            <?php if($stk >= $pro->min_qty): ?>
                              <button class="productDetails-addCart-btn" onclick="addToCart(<?php echo e($pro->min_qty); ?>)" style="border-radius:30px;padding: 5px 10px;">Buy Pack</button>
                            <?php else: ?>
                              <button class="productDetails-addCart-btn" style="border-radius:30px;padding: 5px 10px;" disabled>Unavailable</button>
                            <?php endif; ?>
                          <?php else: ?>

                          <a class="productDetails-addCart-btn" href="<?php echo e(route('business-login')); ?>" style="border-radius:30px;padding: 5px 10px;">Buy Pack</a>
                          <?php endif; ?>
                          

                          
                        </div>
                      </li>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </ul>
                </div>

                
              <?php endif; ?>


              <?php if($product->adv_bonus_price): ?>
              <hr/>
                <div class="OtcPage__combo-pack___P9Cwj">
                  <div class="ComboPack__combo-heading___SnepS">
                    <h3 style="font-size: 16px;font-weight: 700;">Combo Bonus packs:</h3>
                  </div>
                  <ul class="list-unstyled">

                  <?php $__currentLoopData = $product->prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($pro->is_bonus_price == 1): ?>
                    <?php 
                        $product->price = $product->getTotalPrice($pro->min_qty);
                     ?>
                      <li class="d-flex justify-content-start g-brd-around g-brd-gray-light-v4 g-pa-10 g-mb-minus-1">
                        <div class="align-self-center g-px-10">
                          <h5 class="h6 g-font-weight-600 g-color-black g-mb-3">
                          <span class="g-mr-5 mb-0">Pack of <?php echo e($pro->min_qty); ?> Get <?php echo e($pro->product_free_quantity); ?> <?php echo e($pro->product_category); ?> Free</span>
                            
                          </h5>
                          <p class="m-0">
                              <?php if($gs->sign == 0): ?>
                              <h5 class="productDetails-price">
                                <?php echo e($curr->sign); ?>

                                
                                <?php if($product->user_id != 0): ?>
                                  <?php 
                                  $price = $pro->product_bonus_price ;
                                   ?>
                                  <?php echo e(round($price * $curr->value,2)); ?>

                                <?php else: ?>
                                  <?php if($product->sale_from && $product->sale_from <= $now && $product->sale_to >= $now): ?>
                                    <?php 
                                      $discount = 1;
                                      $discount = 1 - ($product->sale_percentage/100);
                                    
                                     ?>
                                    <?php echo e(round( $discount * ($pro->product_bonus_price * $curr->value),2)); ?>

                                  <?php else: ?>
                                    <?php echo e(round($pro->product_bonus_price * $curr->value,2)); ?>

                                  <?php endif; ?>
                                <?php endif; ?>                   
              
                                <?php if($product->sale_from && $product->sale_from <= $now && $product->sale_to >= $now): ?>
                                  <span style="color:green;font-size:14px;"><del style="color:red;"> <?php echo e($curr->sign); ?><?php echo e(round($pro->product_bonus_price * $curr->value,2)); ?></del> -<?php echo e($product->sale_percentage); ?>%</span>
                                <?php endif; ?>
                              </h5>
                            <?php else: ?>
                              <h5 class="productDetails-price">
                                <?php if($product->user_id != 0): ?>
                                  <?php 
                                  $price = $pro->product_bonus_price ;
                                   ?>
                                  <?php echo e(round($price * $curr->value,2)); ?>

                                <?php else: ?>
                                  <?php echo e(round($pro->product_bonus_price  * $curr->value,2)); ?>

                                <?php endif; ?>                   
                                <?php echo e($curr->sign); ?>


                                
                              </h5>
                            <?php endif; ?>
                          </p>
                        </div>
                        <div class="align-self-center ml-auto">
                          <?php if(Auth::guard('user')->check()): ?>
                            <?php if($stk >= $pro->min_qty): ?>
                              
                              <button class="productDetails-addCart-btn" onclick="addToCartBonus(<?php echo e($pro->min_qty); ?>)" style="border-radius:30px;padding: 5px 10px;">Buy Pack</button>
                             
                            <?php else: ?>
                              <button class="productDetails-addCart-btn" style="border-radius:30px;padding: 5px 10px;" disabled>Unavailable</button>
                            <?php endif; ?>
                          <?php else: ?>
                          <a class="productDetails-addCart-btn" href="<?php echo e(route('business-login')); ?>" style="border-radius:30px;padding: 5px 10px;">Buy Pack</a>
                          <?php endif; ?>
                        

                          
                        </div>
                      </li>
                    <?php endif; ?>
                    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div>

                
              <?php endif; ?>


              <?php if($product->size != null): ?>
                <div class="productDetails-size">
                  <p><?php echo e($lang->doo); ?></p>
                  <?php $__currentLoopData = $size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <span class="psize"><?php echo e($sz); ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              <?php endif; ?>
              <?php if($product->color != null): ?>
                <div class="productDetails-color">
                  <p><?php echo e($lang->colors); ?></p>
                  <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <span class="pcolor" style="background: <?php echo e($cl); ?>;"><?php echo e($cl); ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              <?php endif; ?>
 
              
                
              
              <input type="hidden" id="pid" value="<?php echo e($product->id); ?>">
            
              <?php 
              $user = Auth::guard('user')->user();
               ?>

              <?php if(Auth::guard('user')->check()): ?>
                <?php if($user->user_type == 'Business'): ?>
                
                <?php else: ?>
          
                
                
                <?php endif; ?>
              <?php endif; ?>

              
              

             
              <script async src="https://static.addtoany.com/menu/page.js"></script>
            </div>

            <?php 
            $offers = App\Offer::orderBy('id','desc')->get();
         ?>

        <div class="col-md-4 col-sm-4 col-xs-12">
          <div class="container" style="padding-top: 20px; margin-top:20px;
          border: 1px solid;
          border-color: #cacaca;
          border-radius: 15px;
          padding-left: 30px;">
          <span class="u-label g-rounded-3 g-bg-primary g-mr-10 g-mb-15" style="position:absolute; left:10px;">
            <i class="fa fa-bookmark g-mr-3"></i>
            Additional Offers
          </span>

            <ul class="list-unstyled g-color-gray-dark-v4 g-mb-40 g-mt-30">
              
              <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class=" g-mb-5">
                <i class="icon-tag g-color-primary g-mt-5 g-mr-10" style="position:absolute; left:25px;"></i>
                <strong><?php echo e($offer->title); ?></strong> <?php echo e($offer->description); ?>

              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
             
            </ul>
            </div>

               
               <h4 style="margin-top:1rem;" class="text-center">Share with</h4>
               
            

                <div class="sharethis-inline-share-buttons" >
                  <style>
                    #st-el-3 .st-btns {
                      bottom: 56px;
                      left: 0;
                      margin: 100px auto 0;
                      max-width: 90%;
                      position: absolute;
                      right: 0;
                      text-align: center;
                      top: 10px !important;
                      z-index: 20;
                      overflow-y: auto;
                  }
                  </style>
                </div>

                <div class="sharethis-inline-reaction-buttons"></div>

            </div>
          </div>



      </div>
    </div>
    <!--  Ending of product description area   -->

    <!--  Starting of product detail tab area   -->
    <div class="container g-mt-20">

      <div class="row">
          <div class="col-md-3" style="padding-top: 0px;" >
            <!-- Nav tabs -->
            <ul class="nav flex-column u-nav-v1-1 u-nav-primary" role="tablist" data-target="nav-1-1-primary-ver" data-tabs-mobile-type="slide-up-down" data-btn-classes="btn btn-md btn-block rounded-0 u-btn-outline-primary g-mb-20">
              <li class="nav-item ">
                <a class="nav-link  active" style="border-radius:30px;" data-toggle="tab" href="#nav-1-1-primary-ver--1" role="tab">Full Description</a>
              </li>

              <?php if($product['requires_prescription']): ?>
                
              <?php else: ?>
              
              <li class="nav-item" >
                <a class="nav-link " style="border-radius:30px;" data-toggle="tab" href="#nav-1-1-primary-ver--2" role="tab">Reviews</a>
              </li>
              <?php endif; ?>
            </ul>
            <!-- End Nav tabs -->
          </div>
        
          <div class="col-md-9">
            <!-- Tab panes -->
            <div id="nav-1-1-primary-ver" class="tab-content">

              
              <div class="tab-pane fade show active" id="nav-1-1-primary-ver--1" role="tabpanel">
                  <?php if(strlen($product->description) > 70): ?>

                        <p <?php echo $lang->rtl == 1 ? 'dir="rtl"' : ''; ?>><?php echo $product->description; ?></p>
                    
                  <?php else: ?>
                        <p <?php echo $lang->rtl == 1 ? 'dir="rtl"' : ''; ?>><?php echo $product->description; ?></p>
                  
                  <?php endif; ?>
              
              
              </div>
        
              <div class="tab-pane fade" id="nav-1-1-primary-ver--2" role="tabpanel">
                  <div>
                      <?php if(Auth::guard('user')->check()): ?>

                        <?php if(Auth::guard('user')->user()->orders()->count() > 0): ?>
                          <h5><?php echo e($lang->fpr); ?></h5>
                          
                          <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                          
                          <form class="product-review-form" action="<?php echo e(route('front.review.submit')); ?>" method="POST">
                              <?php echo e(csrf_field()); ?>

                              <input type="hidden" name="user_id" value="<?php echo e(Auth::guard('user')->user()->id); ?>">
                                <input type="hidden" name="rating" id="rate" value="5">
                                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                <div class="form-group">
                                  <textarea name="review" id="" rows="5" placeholder="<?php echo e($lang->suf); ?>" class="form-control" style="resize: vertical;border-radius:10px;" required></textarea>
                                </div>
                            <div class="form-group text-center">
                              <input name="btn" type="submit" class="btn-review" style="border-radius:30px;" value="Submit Review">
                            </div>
                          </form>
                        <?php else: ?>
                          <h5><?php echo e($lang->product_review); ?>.</h5>
                        <?php endif; ?>
                    
                          <h5><?php echo e($lang->dttl); ?>: </h5>
                      
                        <?php $__empty_1 = true; $__currentLoopData = $product->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>       
                          <div class="review-rating-description">
                            <div class="row">
                              <div class="col-md-3 col-sm-3">
                                <p><?php echo e($review->user->name); ?></p>
                                
                                <p><?php echo e(Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $review->review_date)->diffForHumans()); ?></p>
                              </div>
                              <div class="col-md-9 col-sm-9">
                                <p><?php echo e($review->review); ?></p>
                              </div>
                            </div>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <div class="row">
                              <div class="col-md-12">
                                  <h5><?php echo e($lang->md); ?></h5>
                              </div>
                          </div>
                        <?php endif; ?>
                        

                      <?php else: ?>


                          <div class="col-lg-12 pt-50">
                            <div class="blog-comments-area product">
                              <br/>
                              <h5 class="text-center">
                                <a href="<?php echo e(route('user-login')); ?>"><i class="icon-user"></i> <?php echo e($lang->comment_login); ?></a> <?php echo e($lang->to_review); ?>

                               </h5>
                            
                            </div>
                          </div>
                        
                            <h5><?php echo e($lang->dttl); ?>: </h5>
                       
                          <?php $__empty_1 = true; $__currentLoopData = $product->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>       
                            <div class="review-rating-description">
                              <div class="row">
                                <div class="col-md-3 col-sm-3">
                                  <p><?php echo e($review->user->name); ?></p>
                                  
                                  <p><?php echo e(Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $review->review_date)->diffForHumans()); ?></p>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                  <p><?php echo e($review->review); ?></p>
                                </div>
                              </div>
                            </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <h6><?php echo e($lang->md); ?></h6>
                                </div>
                            </div>
                          <?php endif; ?>
                          <hr>
                      <?php endif; ?>

                    </div>
            
            
            
              </div>
        
            </div>
            <!-- End Tab panes -->
          </div>
        </div>
  </div>
    <!--  Ending of product detail tab area   -->

    <br>

    
    <?php 
      // $related = $product->childcategories()->first()->products()->where('status','=',1)->where('products.id','!=',$product->id)->distinct()->get();
      $related = collect();
      $title = $lang->amf;
      if($product->requires_prescription && $product->sub_title){
        $title = 'Alternate Brands';
        foreach($product->childcategories()->where('status',1)->get() as $cat){
          $related = $related->merge($cat->products()->where('status','=',1)->where('products.id','!=',$product->id)->where('products.sub_title',$product->sub_title)->distinct()->get());
        }

      }else{
        foreach($product->childcategories()->where('status',1)->get() as $cat){
          $related = $related->merge($cat->products()->where('status','=',1)->where('products.id','!=',$product->id)->distinct()->get());
        }
      }

      $related = $related->unique('id')->take(10);
     ?>

    <?php if($related->count() > 0): ?>
      <!--  Starting of product detail carousel area   -->

      <style>
       
        
        @media  only screen and (max-width: 767px){
        .g-font-size-16{
            font-size: 10px !important;
        }
        .g-font-size-15{
            font-size: 10px !important;
        }
        .g-mt-1 {
            margin-top: 4px!important;
        }
        .et-icon-alarmclock{
            font-size: 10px;
        }
        
        }
        
        
        </style>
      <div class="section-padding productDetails-carousel-wrap">
        <div class="container">
            <div class="section-title">
                <h2><?php echo e($title); ?></h2>
            </div>
            <div class="js-carousel g-pb-40" data-autoplay="true" data-slides-show="5" data-slides-scroll="1" data-arrows-classes="u-arrow-v1 g-pos-abs g-bottom-0 g-width-45 g-height-45 g-font-size-default g-color-gray-dark-v5 g-bg-gray-light-v5 g-color-white--hover g-bg-primary--hover g-rounded-30" data-arrow-left-classes="fa fa-angle-left g-left-35x--lg g-left-15" data-arrow-right-classes="fa fa-angle-right g-right-35x--lg g-right-15" data-pagi-classes="u-carousel-indicators-v1 g-absolute-centered--x g-bottom-20 text-center" 
              data-responsive='[{
                "breakpoint": 1050,
                "settings": {
                "slidesToShow": 4
                }
            },{
                "breakpoint": 992,
                "settings": {
                "slidesToShow": 4
                  }
              }, {
                  "breakpoint": 768,
                  "settings": {
                  "slidesToShow": 2
                  }
              }, {
                  "breakpoint": 554,
                  "settings": {
                  "slidesToShow": 2
                  }
              }]'>
              
              <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="js-slide g-px-5">
                  <!-- Article -->
                  <div class="u-shadow-v19 u-shadow-v20--hover">
                    <?php 
                        $name = str_replace(" ","-",$prod->name);
                     ?>
                    <div class="single-product-area text-center" style="margin-bottom:0px;" >
                      <div class="product-image-area">
                        <?php if($prod->features!=null && $prod->colors!=null): ?>
                          <?php 
                          $title = explode(',', $prod->features);
                          $details = explode(',', $prod->colors);
                           ?>
                          
                        <?php endif; ?>
                        <img src="<?php echo e(asset('assets/images/'.$prod->photo)); ?>" alt="featured product">
                        <?php if($prod->youtube != null): ?>
                          <div class="product-hover-top">
                            <span class="fancybox" data-fancybox href="<?php echo e($prod->youtube); ?>"><i class="fa fa-play-circle"></i></span>
                          </div>
                        <?php endif; ?>
        
                        <div class="gallery-overlay"></div>
                        <div class="gallery-border"></div>
                        <div class="product-hover-area">
                    
        
                    
                         
                          <?php if(Auth::guard('user')->check()): ?>
                                <input type="hidden" value="<?php echo e($prod->id); ?>">
                                <span class="hovertip addcart text-center" rel-toggle="tooltip" title="<?php echo e($lang->hcs); ?>"><a class="productDetails-addCart-btn" id="addcrt" href="javascript:;" style="cursor: pointer;">
                                </a>
                                <i class="icon-finance-100 u-line-icon-pro"></i> 
                                </span>
                            <?php else: ?>
                    
        
                        <a class="productDetails-addCart-btn" href="<?php echo e(route('business-login')); ?>" style="cursor: pointer;">
                            <span class="hovertip text-center" rel-toggle="tooltip" title="<?php echo e($lang->hcs); ?>">
                                <i class="icon-finance-100 u-line-icon-pro"></i> 
                            </span>
                        </a>
                           
                            <?php endif; ?>
                        </div>
        
        
        
                      </div>
                    </div>
                      <div class="product-description text-center single-product-area" style="margin-top:0px;">
                        <div class="product-name" style="margin-bottom: 35px;"><a href="<?php echo e(route('front.product',['id' => $prod->id, 'slug' => str_slug($name,'-')])); ?>" class="text-center"><?php echo e(strlen($prod->name) > 65 ? substr($prod->name,0,65)."..." : $prod->name); ?></a>
                          <?php if($prod->sale_from && $prod->sale_from <= $now && $prod->sale_to >= $now): ?>
                         
                              <div class="js-countdown u-countdown-v3 g-line-height-1_2 g-font-weight-300 g-color-black text-center text-uppercase" data-end-date="<?php echo e($prod->sale_to); ?>" data-month-format="%m" data-days-format="%D" data-hours-format="%H" data-minutes-format="%M" data-seconds-format="%S" style="margin-top:5px;">
              
              
              
                             <i class="et-icon-alarmclock u-icon-effect-v4--hover"></i>
                            <div class="d-inline-block" style="font-weight:600; font-size:14px;">
                              <div class="js-cd-days mb-0" id="dayss" style="color:green;">00 </div>
                         
                            </div>
              
                            <div class="hidden-down d-inline-block align-top g-mt-1 " style="font-weight:600; ">D :</div>
              
                            <div class="d-inline-block " style="font-weight:600; font-size:14px;">
                              <div class="js-cd-hours mb-0" id="hourss">00 H</div>
                              
                            </div>
              
                            <div class="hidden-down d-inline-block align-top g-mt-1" style="font-weight:600;">H :</div>
              
                            <div class="d-inline-block " style="font-weight:600; font-size:14px;">
                              <div class="js-cd-minutes mb-0" id="minutess">00 M</div>
                              
                            </div>
              
                            <div class="hidden-down d-inline-block align-top g-mt-1" style="font-weight:600;">M :</div>
              
                            <div class="d-inline-block " style="font-weight:600; font-size:14px;">
                              <div class="js-cd-seconds mb-0" id="secondss" style="color:red;">00 </div>
                              
                            </div>
                            <div class="hidden-down d-inline-block align-top g-mt-1" style="font-weight:600; color:red;">S </div>
                          </div>
              
                          <!--  Ending of countdown area   -->
                      <?php endif; ?>
        
                        </div>
                 
                        <?php if($gs->sign == 0): ?>
                            <div class="product-price"><?php echo e($curr->sign); ?>

                              <?php echo e(round($prod->cprice * $curr->value,2)); ?>

                              <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?> 
                                <span style="display:inline; font-size:12px; color:green;"><del style="color:red;" class="offer-price"><?php echo e($curr->sign); ?><?php echo e(round($prod->pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>
        
                              <?php endif; ?>
        
                            </div>
                        <?php else: ?>
                            <div class="product-price">
                              <?php echo e(round($prod->cprice * $curr->value,2)); ?>

                              <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?> 
                                <span style="display:inline; font-size:12px; color:green;"><del style="color:red;" class="offer-price"><?php echo e($curr->sign); ?><?php echo e(round($prod->pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>
        
                              <?php endif; ?>
                              <?php echo e($curr->sign); ?>

                            </div>
                        <?php endif; ?>
                      </div>
                      </div>
                <!-- End Article -->
        
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        
        </div>
      </div>
      <!--  Ending of product detail carousel area   -->
    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>



<?php if($product->sale_from && $product->sale_from <= $now && $product->sale_to >= $now): ?>
  <script type="text/javascript">
    function makeTimer() {

      var endTime = new Date("<?php echo e($product->sale_to); ?>");			
        endTime = (Date.parse(endTime) / 1000);

        var now = new Date();
        now = (Date.parse(now) / 1000);

        var timeLeft = endTime - now;

        if(timeLeft<0) return;

        var days = Math.floor(timeLeft / 86400); 
        var hours = Math.floor((timeLeft - (days * 86400)) / 3600);
        var minutes = Math.floor((timeLeft - (days * 86400) - (hours * 3600 )) / 60);
        var seconds = Math.floor((timeLeft - (days * 86400) - (hours * 3600) - (minutes * 60)));

        if (hours < "10") { hours = "0" + hours; }
        if (minutes < "10") { minutes = "0" + minutes; }
        if (seconds < "10") { seconds = "0" + seconds; }

        $("#days").html(days);
        $("#hours").html(hours);
        $("#minutes").html(minutes);
        $("#seconds").html(seconds);

    }

    setInterval(function() { makeTimer(); }, 1000);
    
  </script>
<?php endif; ?>

<style type="text/css">
 img#imageDiv {
    height: 460px;
    width: 460px;
  }
  @media  only screen and (max-width: 768px) { 

  img#imageDiv {
      height: 280px;
      width: 280px;
    }
    
      }
  @media  only screen and (max-width: 767px) { 
  .product-review-carousel-img
  {
    max-width: 300px;
    margin: 30px auto;
  }
 img#imageDiv {
    height: 300px;
    width: 300px;
  }
   
    }
</style>

<script type="text/javascript">

  function productGallery(file){
    var image = $("#"+file).attr('src');
    $('#imageDiv').attr('src',image);
    $('.zoomImg').attr('src',image);
  }


    // var size = $(this).html();
    // $('#size').val(size);

    $('#star1').starrr({
        rating: 5,
        change: function(e, value){
            if (value) {
                $('.your-choice-was').show();
                $('.choice').text(value);
                $('#rate').val(value);
            } else {
                $('.your-choice-was').hide();
            }
        }
    });

</script>

<script type="text/javascript">
    var sizes = "";
    var colors = "";
    var stock = $("#stock").val();

  //   $(document).on("click", ".psize" , function(){
  //    $('.psize').removeClass('pselected-size');
  //    $(this).addClass('pselected-size');
  //    sizes = $(this).html();
  // });

    $(document).on("click", ".pcolor" , function(){
     $('.pcolor').removeClass('pselected-color');
     $(this).addClass('pselected-color');
     colors = $(this).html();
  });

    $(document).on("click", "#qsub" , function(){
         var qty = $("#qval").html();
         qty--;
         if(qty < 1)
         {
         $("#qval").html("1");            
         }
         else{
         $("#qval").html(qty);
         }
    });
    $(document).on("click", "#qadd" , function(){
        var qty = $("#qval").html();
        if(stock != "")
        {
        var stk = parseInt(stock);
          if(qty < stk)
          {
             qty++;
             $("#qval").html(qty);               
          }

        }
        else{
         qty++;
         $("#qval").html(qty);          
        }

    });

    $(document).on("click", "#addcrt" , function(){
      var qty = document.getElementById("myqty").value;
      $(".empty").html("");
      addToCart(qty);

    });

    function addToCart(qty){
      var pid = $("#pid").val();
      
      $.ajax({
          type: "GET",
          url:"<?php echo e(URL::to('/json/addnumcart')); ?>",
          data:{id:pid,qty:qty,size:sizes,color:colors},
          success:function(data){
              if(data == 0)
              {
                $.notify("<?php echo e($gs->cart_error); ?>","error");
              }
              else{
                $(".empty").html("");
                $(".total").html((data[0] * <?php echo e($curr->value); ?>).toFixed(2));
         
                $(".cart-quantity").html(data[2]);
                var arr = $.map(data[1], function(el) {
                return el 
              });
              console.log(arr);
              $(".cart").html("");
              for(var k in arr)
              {
                  var x = arr[k]['item']['name'];
                  var p = x.length  > 45 ? x.substring(0,45)+'...' : x;
                  var measure = arr[k]['item']['measure'] != null ? arr[k]['item']['measure'] : "";
                  $(".cart").append(
                    '<div class="single-myCart">'+
                    '<p class="cart-close" onclick="remove('+arr[k]['item']['id']+')"><i class="fa fa-close"></i></p>'+
                  '<div class="cart-img">'+
                    '<img src="<?php echo e(asset('assets/images/')); ?>/'+arr[k]['item']['photo']+'" alt="Product image">'+
                  '</div>'+
                  '<div class="cart-info">'+
                    '<a href="<?php echo e(url('/')); ?>/product/'+arr[k]['item']['id']+'/'+arr[k]['item']['name']+'" style="color: black; padding: 0 0;">'+'<h5>'+p+'</h5></a>'+
                    '<p><?php echo e($lang->cquantity); ?>: '+arr[k]['qty']+' '+measure+'</p>'+
                    <?php if($gs->sign == 0): ?>
                    '<p><?php echo e($curr->sign); ?>'+(arr[k]['price'] * <?php echo e($curr->value); ?>).toFixed(2)+'</p>'+
                    
                    <?php else: ?>
                    '<p>'+(arr[k]['price'] * <?php echo e($curr->value); ?>).toFixed(2)+'<?php echo e($curr->sign); ?></p>'+
                    <?php endif; ?>
                    '</div>'+
                    '</div>');
                    
                }
                $.notify("<?php echo e($gs->cart_success); ?>","success");
                $("#qval").html("1");
              }
          },
          error: function(data){
            if(data.responseJSON)
                $.notify(data.responseJSON.error,"error");
            else
              $.notify('Something went wrong',"error");

          }
      }); 
    }

    function addToCartBonus(qty){
      var pid = $("#pid").val();
      
      $.ajax({
          type: "GET",
          url:"<?php echo e(URL::to('/json/addnumcartBonus')); ?>",
          data:{id:pid,qty:qty,size:sizes,color:colors},
          success:function(data){
              if(data == 0)
              {
                $.notify("<?php echo e($gs->cart_error); ?>","error");
              }
              else{
                $(".empty").html("");
                $(".total").html((data[0] * <?php echo e($curr->value); ?>).toFixed(2));
         
                $(".cart-quantity").html(data[2]);
                var arr = $.map(data[1], function(el) {
                return el 
              });
              console.log(arr);
              $(".cart").html("");
              for(var k in arr)
              {
                  var x = arr[k]['item']['name'];
                  var p = x.length  > 45 ? x.substring(0,45)+'...' : x;
                  var measure = arr[k]['item']['measure'] != null ? arr[k]['item']['measure'] : "";
                  $(".cart").append(
                    '<div class="single-myCart">'+
                    '<p class="cart-close" onclick="remove('+arr[k]['item']['id']+')"><i class="fa fa-close"></i></p>'+
                  '<div class="cart-img">'+
                    '<img src="<?php echo e(asset('assets/images/')); ?>/'+arr[k]['item']['photo']+'" alt="Product image">'+
                  '</div>'+
                  '<div class="cart-info">'+
                    '<a href="<?php echo e(url('/')); ?>/product/'+arr[k]['item']['id']+'/'+arr[k]['item']['name']+'" style="color: black; padding: 0 0;">'+'<h5>'+p+'</h5></a>'+
                    '<p><?php echo e($lang->cquantity); ?>: '+arr[k]['qty']+' '+measure+'</p>'+
                    <?php if($gs->sign == 0): ?>
                    '<p><?php echo e($curr->sign); ?>'+(arr[k]['price'] * <?php echo e($curr->value); ?>).toFixed(2)+'</p>'+
                    
                    <?php else: ?>
                    '<p>'+(arr[k]['price'] * <?php echo e($curr->value); ?>).toFixed(2)+'<?php echo e($curr->sign); ?></p>'+
                    <?php endif; ?>
                    '</div>'+
                    '</div>');
                    
                }
                $.notify("<?php echo e($gs->cart_success); ?>","success");
                $("#qval").html("1");
              }
          },
          error: function(data){
            if(data.responseJSON)
                $.notify(data.responseJSON.error,"error");
            else
              $.notify('Something went wrong',"error");

          }
      }); 
    }

</script>


    <script>
        $(document).on("click", "#wish" , function(){
            var pid = $("#pid").val();
            $.ajax({
                    type: "GET",
                    url:"<?php echo e(URL::to('/json/wish')); ?>",
                    data:{id:pid},
                    success:function(data){
                        if(data == 1)
                        {
                            $.notify("<?php echo e($gs->wish_success); ?>","success");
                        }
                        else {
                            $.notify("<?php echo e($gs->wish_error); ?>","error");
                        }
                    },
                    error: function(data){
                      if(data.responseJSON)
                        $.notify(data.responseJSON.error,"error");
                      else
                        $.notify('Something went wrong',"error");

                    }
              }); 

            return false;
        });
    </script>
    <script>
        $(document).on("click", "#favorite" , function(){
          $("#favorite").hide();
            var pid = $("#fav").val();
            $.ajax({
                    type: "GET",
                    url:"<?php echo e(URL::to('/json/favorite')); ?>",
                    data:{id:pid},
                    success:function(data){
                      $('.product-headerInfo__btns').html('<a class="headerInfo__btn colored"><i class="fa fa-check"></i> <?php echo e($lang->product_favorite); ?></a>');
                    },
                    error: function(data){
                      if(data.responseJSON)
                        $.notify(data.responseJSON.error,"error");
                      else
                        $.notify('Something went wrong',"error");

                    }
              }); 

        });
    </script>



<script type="text/javascript">
//*****************************COMMENT******************************  
        $("#cmnt").submit(function(){
          var uid = $("#user_id").val();
          var pid = $("#product_id").val();
          var cmnt = $("#txtcmnt").val();
          $("#txtcmnt").prop('disabled', true);
          $('.btn blog-btn comments').prop('disabled', true);
     $.ajax({
            type: 'post',
            url: "<?php echo e(URL::to('json/comment')); ?>",
            data: {
                '_token': $('input[name=_token]').val(),
                'uid'   : uid,
                'pid'   : pid,
                'cmnt'  : cmnt
                  },
            success: function(data) {
              $("#comments").prepend(
                    '<div id="comment'+data[3]+'">'+
                        '<div class="row single-blog-comments-wrap">'+
                            '<div class="col-lg-12">'+
                              '<h4><a class="comments-title">'+data[0]+'</a></h4>'+
                                '<div class="comments-reply-area">'+data[1]+'</div>'+
                                 '<p id="cmntttl'+data[3]+'">'+data[2]+'</p>'+
                                '<div class="replay-form">'+
                    '<p class="text-right"><input type="hidden" value="'+data[3]+'"><button class="replay-btn"><?php echo e($lang->reply_button); ?> <i class="fa fa-reply-all"></i></button><button class="replay-btn-edit"><?php echo e($lang->edit_button); ?> <i class="fa fa-edit"></i></button><button class="replay-btn-delete"><?php echo e($lang->remove); ?> <i class="fa fa-trash"></i></button>'+
                    '</p>'+'<form action="" method="POST" class="comment-edit">'+
                                      '<?php echo e(csrf_field()); ?>'+
                                '<input type="hidden" name="comment_id" value="'+data[3]+'">'+
                                      '<div class="form-group">'+
                            '<textarea rows="2" id="editcmnt'+data[3]+'" name="text" class="form-control"'+ 
                            'placeholder="<?php echo e($lang->edit_comment); ?>" style="resize: vertical;" required=""></textarea>'+
                                      '</div>'+
                                      '<div class="form-group">'+
                    '<button type="submit" class="btn btn-no-border hvr-shutter-out-horizontal"><?php echo e($lang->update_comment); ?></button>&nbsp;'+
                        '<button type="button" class="btn btn-no-border hvr-shutter-out-horizontal cancel"><?php echo e($lang->cancel_edit); ?></button>'+
                                      '</div>'+
                                    '</form>'+
                                '</div>'+
                            '</div>'+
                        '</div>'+
                      '</div>');
                    $("#comment"+data[3]).append('<div id="replies'+data[3]+'" style="display: none;"></div>');
                     $("#replies"+data[3]).append('<div class="rapper" style="display: none;"></div>');
                     $("#replies"+data[3]).append('<form action="" method="POST" class="reply" style="display: none;">'+
                      '<?php echo e(csrf_field()); ?>'+
                      '<input type="hidden" name="comment_id" id="comment_id'+data[3]+'" value="'+data[3]+'">'+
                      '<input type="hidden" name="user_id" id="user_id'+data[4]+'" value="'+data[4]+'">'+
                        '<div class="form-group">'+
                          '<textarea rows="2" name="text" id="txtcmnt'+data[3]+'" class="form-control"'+ 'placeholder="<?php echo e($lang->write_reply); ?>" required="" style="resize: vertical;"></textarea>'+
                        '</div>'+
                      '<div class="form-group">'+
                        '<button type="submit" class="btn btn-no-border hvr-shutter-out-horizontal"><?php echo e($lang->reply_button); ?></button>'+
                      '</div>'+'</form>');                      
                      
                      



                    
                      //-----------Replay button details-----------
              if (data[5] > 1){
                $("#cmnt-text").html("<?php echo e($lang->comments); ?>(<span id='cmnt_count'>"+ data[5]+"</span>)");
              }
              else{
                $("#cmnt-text").html("<?php echo e($lang->comment); ?> (<span id='cmnt_count'>"+ data[5]+"</span>)");              
              }
              $("#txtcmnt").prop('disabled', false);
              $("#txtcmnt").val("");
              $('.btn blog-btn comments').prop('disabled', false);
            },
            error: function(data){
              if(data.responseJSON)
                $.notify(data.responseJSON.error,"error");
              else
                $.notify('Something went wrong',"error");

            }
        });          
          return false;
        });
//*****************************COMMENT ENDS******************************  
</script>

<script type="text/javascript">

//***************************** REPLY TOGGLE******************************
          $(document).on("click", ".replay-form p button.view-replay-btn" , function(){
          var id = $(this).parent().next().find('input[name=comment_id]').val();
          $("#replies"+id+" .rapper").show();
          $("#replies"+id).show();
          });

          $(document).on("click", ".replay-form p button.replay-btn, .replay-form p button.subreplay-btn" , function(){
          var id = $(this).parent().find('input[type=hidden]').val();
          $("#replies"+id).show();
          $("#replies"+id).find('.reply').show();
          $("#replies"+id).find('.reply textarea').focus();
          });
//*****************************REPLY******************************  
          $(document).on("submit", ".reply" , function(){
          var uid = $(this).find('input[name=user_id]').val();
          var cid = $(this).find('input[name=comment_id]').val();
          var rpl = $(this).find('textarea').val();
          $(this).find('textarea').prop('disabled', true);
          $('.btn btn-no-border hvr-shutter-out-horizontal').prop('disabled', true);
     $.ajax({
            type: 'post',
            url: "<?php echo e(URL::to('json/reply')); ?>",
            data: {
                '_token': $('input[name=_token]').val(),
                'uid'   : uid,
                'cid'   : cid,
                'rpl'  : rpl
                  },
            success: function(data) {
              $("#replies"+cid).prepend('<div id="reply'+data[3]+'">'+
                        '<div class="row single-blog-comments-wrap replay">'+
                            '<div class="col-lg-12">'+
                              '<h4><a class="comments-title">'+data[0]+'</a></h4>'+
                                '<div class="comments-reply-area">'+data[1]+'</div>'+
                                 '<p id="rplttl'+data[3]+'">'+data[2]+'</p>'+
                                '<div class="replay-form">'+
                    '<p class="text-right"><input type="hidden" value="'+cid+'"><button class="subreplay-btn"><?php echo e($lang->reply_button); ?> <i class="fa fa-reply-all"></i></button><button class="replay-btn-edit1"><?php echo e($lang->edit_button); ?> <i class="fa fa-edit"></i></button><button class="replay-btn-delete1"><?php echo e($lang->remove); ?> <i class="fa fa-trash"></i></button></p>'+
                                    '<form action="" method="POST" class="reply-edit">'+
                                      '<?php echo e(csrf_field()); ?>'+
                                  '<input type="hidden" name="reply_id" value="'+data[3]+'">'+
                                      '<div class="form-group">'+
                                    '<textarea rows="2" id="editrpl'+data[3]+'" name="text" class="form-control"'+ 'placeholder="<?php echo e($lang->edit_reply); ?>"  style="resize: vertical;" required=""></textarea>'+
                                      '</div>'+
                                      '<div class="form-group">'+
                                      '<button type="submit" class="btn btn-no-border hvr-shutter-out-horizontal">'+'<?php echo e($lang->update_comment); ?></button>&nbsp;'+
                                      '<button type="button" class="btn btn-no-border hvr-shutter-out-horizontal cancel"><?php echo e($lang->cancel_edit); ?></button>'+
                                      '</div>'+
                                    '</form>'+
                                '</div>'+
                            '</div>'+
                        '</div>'+
                        '</div>');
                      //-----------REPLY button details-----------
              $("#txtcmnt"+cid).prop('disabled', false);
              $("#txtcmnt"+cid).val("");
              $('.btn btn-no-border hvr-shutter-out-horizontal').prop('disabled', false);
            },
            error: function(data){
              if(data.responseJSON)
                $.notify(data.responseJSON.error,"error");
              else
                $.notify('Something went wrong',"error");

            }
        });          
          return false;
        });
//*****************************REPLY ENDS******************************  

</script>



<script>

  $(document).on("click", ".replay-btn-edit" , function(){
          var id = $(this).parent().find('input[type=hidden]').val();
          var txt = $("#cmntttl"+id).html(); 
          $(this).parent().parent().parent().find('.comment-edit textarea').val(txt);
          $(this).parent().parent().parent().find('.comment-edit').toggle();
  });
  $(document).on("click", ".cancel" , function(){
          $(this).parent().parent().hide();
  });
  //*****************************SUB REPLY******************************  
          $(document).on("submit", ".comment-edit" , function(){
          var cid = $(this).find('input[name=comment_id]').val();
          var text = $(this).find('textarea').val();
           $(this).find('textarea').prop('disabled', true);
          $('.hvr-shutter-out-horizontal').prop('disabled', true);
     $.ajax({
            type: 'post',
            url: "<?php echo e(URL::to('json/comment/edit')); ?>",
            data: {
                '_token': $('input[name=_token]').val(),
                'cid'   : cid,
                'text'  : text
                  },
            success: function(data) {
              $("#cmntttl"+cid).html(data);
              $("#editcmnt"+cid).prop('disabled', false);
              $("#editcmnt"+cid).val("");
              $('.hvr-shutter-out-horizontal').prop('disabled', false);
            },
            error: function(data){
              if(data.responseJSON)
                $.notify(data.responseJSON.error,"error");
              else
                $.notify('Something went wrong',"error");

            }
        });          
          return false;
        });

</script>

<script type="text/javascript">
  $(document).on("click", ".replay-btn-delete" , function(){
              var id = $(this).parent().next().find('input[name=comment_id]').val();
              $("#comment"+id).hide();
              var count = parseInt($("#cmnt_count").html());
              count--;
              if(count <= 1)
              {
              $("#cmnt-text").html("COMMENT (<span id='cmnt_count'>"+ count+"</span>)");
              }
              else
              {
              $("#cmnt-text").html("COMMENTS (<span id='cmnt_count'>"+ count+"</span>)");
              }
     $.ajax({
            type: 'get',
            url: "<?php echo e(URL::to('json/comment/delete')); ?>",
            data: {'id': id}
        }); 
  });
</script>


<script type="text/javascript">
  $(document).on("click", ".replay-btn-edit1" , function(){
          var id = $(this).parent().parent().parent().find('.reply-edit input[name=reply_id]').val();
          var txt = $("#rplttl"+id).html(); 
          $(this).parent().parent().parent().find('.reply-edit textarea').val(txt);
          $(this).parent().parent().parent().find('.reply-edit').toggle();
          var txt = $("#cmntttl"+id).html(); 
  });

  //*****************************SUB REPLY******************************  
          $(document).on("submit", ".reply-edit" , function(){
          var cid = $(this).find('input[name=reply_id]').val();
          var text = $(this).find('textarea').val();
           $(this).find('textarea').prop('disabled', true);
          $('.hvr-shutter-out-horizontal').prop('disabled', true);
     $.ajax({
            type: 'post',
            url: "<?php echo e(URL::to('json/reply/edit')); ?>",
            data: {
                '_token': $('input[name=_token]').val(),
                'cid'   : cid,
                'text'  : text
                  },
            success: function(data) {
              $("#rplttl"+cid).html(data);
              $("#editrpl"+cid).prop('disabled', false);
              $("#editrpl"+cid).val("");
              $('.hvr-shutter-out-horizontal').prop('disabled', false);
            },
            error: function(data){
              if(data.responseJSON)
                $.notify(data.responseJSON.error,"error");
              else
                $.notify('Something went wrong',"error");

            }
        });          
          return false;
        });

</script>

<script type="text/javascript">
  $(document).on("click", ".replay-btn-delete1" , function(){
              var id = $(this).parent().next().find('input[name=reply_id]').val();
              $("#reply"+id).hide();
     $.ajax({
            type: 'get',
            url: "<?php echo e(URL::to('json/reply/delete')); ?>",
            data: {'id': id}
        }); 
  });
</script>

<script >
    $(document).on('ready', function () {
      // initialization of tabs
      $.HSCore.components.HSTabs.init('[role="tablist"]');
    });

    $(window).on('resize', function () {
      setTimeout(function () {
        $.HSCore.components.HSTabs.init('[role="tablist"]');
      }, 200);
    });
  </script>

  <script>
  $('.btn-number').click(function(e){
    e.preventDefault();
    
    fieldName = $(this).attr('data-field');
    type      = $(this).attr('data-type');
    var input = $("input[name='"+fieldName+"']");
    var currentVal = parseInt(input.val());
    if (!isNaN(currentVal)) {
        if(type == 'minus') {
            
            if(currentVal > input.attr('min')) {
                input.val(currentVal - 1).change();
            } 
            if(parseInt(input.val()) == input.attr('min')) {
                $(this).attr('disabled', true);
            }

        } else if(type == 'plus') {

            if(currentVal < input.attr('max')) {
                input.val(currentVal + 1).change();
            }
            if(parseInt(input.val()) == input.attr('max')) {
                $(this).attr('disabled', true);
            }

        }
    } else {
        input.val(0);
    }
});
$('.input-number').focusin(function(){
   $(this).data('oldValue', $(this).val());
});
$('.input-number').change(function() {
    
    minValue =  parseInt($(this).attr('min'));
    maxValue =  parseInt($(this).attr('max'));
    valueCurrent = parseInt($(this).val());
    
    name = $(this).attr('name');
    if(valueCurrent >= minValue) {
        $(".btn-number[data-type='minus'][data-field='"+name+"']").removeAttr('disabled')
    } else {
        alert('Sorry, the minimum value was reached');
        $(this).val($(this).data('oldValue'));
    }
    if(valueCurrent <= maxValue) {
        $(".btn-number[data-type='plus'][data-field='"+name+"']").removeAttr('disabled')
    } else {
        alert('Sorry, the maximum value was reached');
        $(this).val($(this).data('oldValue'));
    }
    
    
});
$(".input-number").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 190]) !== -1 ||
             // Allow: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) || 
             // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
    </script>

<script  src="<?php echo e(asset('frontend-assets/main-assets/assets/vendor/jquery.countdown.min.js')); ?>"></script>

<!-- JS Unify -->
<script  src="<?php echo e(asset('frontend-assets/main-assets/assets/js/components/hs.countdown.js')); ?>"></script>

<!-- JS Plugins Init. -->
<script >
  $(document).on('ready', function () {
    // initialization of countdowns
    var countdowns = $.HSCore.components.HSCountdown.init('.js-countdown', {
      yearsElSelector: '.js-cd-years',
      monthElSelector: '.js-cd-month',
      daysElSelector: '.js-cd-days',
      hoursElSelector: '.js-cd-hours',
      minutesElSelector: '.js-cd-minutes',
      secondsElSelector: '.js-cd-seconds'
    });
  });
</script>

<script type="text/javascript">
  var specialKeys = new Array();
  specialKeys.push(8); //Backspace
  function IsNumeric(e) {
      var keyCode = e.which ? e.which : e.keyCode
      var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
      document.getElementById("error").style.display = ret ? "none" : "inline";
      return ret;
  }
</script>

<script type="text/javascript">
  function isNumberKey(evt) {
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;
        return true;
    }
</script>

<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery.jssocials/1.4.0/jssocials.min.js"></script>
<script src="jquery.js"></script>
<script src="jssocials.min.js"></script>
<script>
    $("#shareRoundIcons").jsSocials({
      showLabel: false,
      showCount: false,
        shares: ["facebook", "whatsapp", "twitter", "linkedin", "email"]
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.product', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>