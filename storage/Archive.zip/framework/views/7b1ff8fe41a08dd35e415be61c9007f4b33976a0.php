
<?php $__env->startSection('title',$page->title); ?>
<?php $__env->startSection('content'); ?>

    <!-- Starting of Section title overlay area -->
    <div class="title-overlay-wrap overlay" style="background-image: url(<?php echo e(asset('assets/images/'.$gs->bgimg)); ?>);">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 text-center">
            <h1><?php echo e(strtoupper($page->title)); ?></h1>
          </div>
        </div>
      </div>
    </div>
    <!-- Ending of Section title overlay area -->

      <div class="section-padding">
               <div class="container">
                   <div class="row">
                       <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"  dir="<?php echo e($lang->rtl == 1 ? 'rtl':''); ?>">
                        <?php echo $page->text; ?>

                       </div>
                   </div>
               </div>
           </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>