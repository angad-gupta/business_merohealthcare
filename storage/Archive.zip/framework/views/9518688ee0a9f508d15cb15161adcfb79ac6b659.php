<?php $__env->startSection('content'); ?>
<?php if($gs->slider == 1): ?>

<div class="row">
    <div class="col-md-12">
        <div class="js-carousel text-center g-pb-30" data-autoplay="true" data-ride="carousel" data-infinite="true" data-arrows-classes="u-arrow-v1 g-absolute-centered--y g-width-35 g-height-40 g-font-size-18 g-color-gray g-bg-white g-mt-minus-10" data-arrow-left-classes="fa fa-angle-left g-left-0" data-arrow-right-classes="fa fa-angle-right g-right-0">
               
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="js-slide">
                        <a class="js-fancybox" href="javascript:;" data-slide="prev" data-fancybox="lightbox-gallery--07-1" data-src="/frontend-assets/main-assets/assets/img-temp/900x600/img5.jpg" data-caption="Lightbox Gallery" data-animate-in="bounceInDown" data-animate-out="bounceOutDown" data-speed="1000" data-overlay-blur-bg="true">
                            <img style="width:100%; height:20rem" class="img-fluid g-rounded-6" src="<?php echo e(asset('assets/images/'.$slider->photo)); ?>" alt="Image Description">
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

      <!-- End Products Block -->
<?php endif; ?>
    
<div class="g-mx-minus-15">
    <div class="section-title text-center">
        <h2><?php echo e($lang->featured_product); ?></h2>
    </div>
    <div class="js-carousel g-pb-40" data-autoplay="true" data-slides-show="6" data-slides-scroll="6" data-arrows-classes="u-arrow-v1 g-pos-abs g-bottom-0 g-width-45 g-height-45 g-font-size-default g-color-gray-dark-v5 g-bg-gray-light-v5 g-color-white--hover g-bg-primary--hover rounded" data-arrow-left-classes="fa fa-angle-left g-left-35x--lg g-left-15" data-arrow-right-classes="fa fa-angle-right g-right-35x--lg g-right-15" data-pagi-classes="u-carousel-indicators-v1 g-absolute-centered--x g-bottom-20 text-center" 
        data-responsive='[{
            "breakpoint": 992,
            "settings": {
            "slidesToShow": 5
            }
        }, {
            "breakpoint": 768,
            "settings": {
            "slidesToShow": 2
            }
        }, {
            "breakpoint": 554,
            "settings": {
            "slidesToShow": 1
            }
        }]'>
    <?php $__currentLoopData = $fproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    <?php 
    $prod->pprice = $prod->pprice ? : $prod->cprice;
    $prod->cprice = $prod->getPrice(1);
     ?>
    <div class="js-slide g-px-15">
        <!-- Article -->
        <article class="u-shadow-v19 g-bg-white text-center rounded g-px-20 g-py-40 g-mb-5">
            <!-- Article Image -->
            <?php 
                $name = str_replace(" ","-",$prod->name);
             ?>
            <a href="<?php echo e(route('front.product',['id' => $prod->id, 'slug' => str_slug($name,'-')])); ?>">

            <img class="d-inline-block img-fluid mb-4" style="height:7rem;" src="<?php echo e(asset('assets/images/'.$prod->photo)); ?>" alt="">
            </a>
            <!-- End Article Image -->
           
            
            <!-- Article Content -->
        <h4 class="h5 g-color-black g-font-weight-600 g-mb-10"><a href="<?php echo e(route('front.product',['id' => $prod->id, 'slug' => str_slug($name,'-')])); ?>"><?php echo e($prod->name); ?></a></h4>
            
            <span class="d-block g-color-primary g-font-size-16">
                <?php echo e($curr->sign); ?>

                   
                <?php if($prod->user_id != 0): ?>
                    <?php 
                        $price = $prod->cprice + $gs->fixed_commission + ($prod->cprice/100) * $gs->percentage_commission ;
                     ?>
                    <?php echo e(round($price * $curr->value,2)); ?>

                    <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?>
                        <?php 
                          $pprice = $prod->pprice + $gs->fixed_commission + ($prod->pprice/100) * $gs->percentage_commission ;
                            
                         ?>
                        <span style="display:inline; font-size:12px"><del><?php echo e($curr->sign); ?><?php echo e(round($pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>
                    <?php endif; ?>
                <?php else: ?>
                    <?php echo e(round($prod->cprice * $curr->value,2)); ?>

                    <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?>
                        <span style="display:inline; font-size:12px"><del><?php echo e($curr->sign); ?><?php echo e(round($prod->pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>
                    <?php endif; ?>
                <?php endif; ?>
                

            </span>
            <!-- End Article Content -->
        </article>
        <!-- End Article -->
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<div class="g-mx-minus-15">
    <div class="section-title text-center">
        <h2><?php echo e($lang->lm); ?></h2>
    </div>
    <div class="js-carousel g-pb-40" data-autoplay="true" data-slides-show="6" data-slides-scroll="6" data-arrows-classes="u-arrow-v1 g-pos-abs g-bottom-0 g-width-45 g-height-45 g-font-size-default g-color-gray-dark-v5 g-bg-gray-light-v5 g-color-white--hover g-bg-primary--hover rounded" data-arrow-left-classes="fa fa-angle-left g-left-35x--lg g-left-15" data-arrow-right-classes="fa fa-angle-right g-right-35x--lg g-right-15" data-pagi-classes="u-carousel-indicators-v1 g-absolute-centered--x g-bottom-20 text-center" 
        data-responsive='[{
            "breakpoint": 992,
            "settings": {
            "slidesToShow": 5
            }
        }, {
            "breakpoint": 768,
            "settings": {
            "slidesToShow": 2
            }
        }, {
            "breakpoint": 554,
            "settings": {
            "slidesToShow": 1
            }
        }]'>
        <?php $__currentLoopData = $beproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php 
        $prod->pprice = $prod->pprice ? : $prod->cprice;
        $prod->cprice = $prod->getPrice(1);
         ?>

        <div class="js-slide g-px-15">
        <!-- Article -->
        <article class="u-shadow-v19 g-bg-white text-center rounded g-px-20 g-py-40 g-mb-5">
                <?php 
                    $name = str_replace(" ","-",$prod->name);
                 ?>
            <a href="<?php echo e(route('front.product',['id' => $prod->id, 'slug' => str_slug($name,'-')])); ?>">
                    <!-- Article Image -->
                <img class="d-inline-block img-fluid mb-4" style="height:7rem;" src="<?php echo e(asset('assets/images/'.$prod->photo)); ?>" alt="">
    
            <!-- End Article Image -->
            </a>
            <!-- Article Content -->
           
        <h4 class="h5 g-color-black g-font-weight-600 g-mb-10"><a href="<?php echo e(route('front.product',['id' => $prod->id, 'slug' => str_slug($name,'-')])); ?>"><?php echo e($prod->name); ?></a></h4>
            <span class="d-block g-color-primary g-font-size-16">
                    <?php echo e($curr->sign); ?>

                    
                <?php if($prod->user_id != 0): ?>
                    <?php 
                        $price = $prod->cprice + $gs->fixed_commission + ($prod->cprice/100) * $gs->percentage_commission ;
                     ?>
                    
                    <?php echo e(round($price * $curr->value,2)); ?>

                    <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?>
                        <?php 
                          $pprice = $prod->pprice + $gs->fixed_commission + ($prod->pprice/100) * $gs->percentage_commission ;
                            
                         ?>
                        <span style="display:inline; font-size:12px"><del><?php echo e($curr->sign); ?><?php echo e(round($pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>
                    <?php endif; ?>
                <?php else: ?>
                    <?php echo e(round($prod->cprice * $curr->value,2)); ?>

                    <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?>
                        <span style="display:inline; font-size:12px"><del><?php echo e($curr->sign); ?><?php echo e(round($prod->pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>
                    <?php endif; ?>
                <?php endif; ?>
            </span>
                    
            <!-- End Article Content -->
        </article>
        <!-- End Article -->
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
   
<div class="g-mx-minus-15">
    <div class="section-title text-center">
        <h2><?php echo e($lang->rds); ?></h2>
    </div>
    <div class="js-carousel g-pb-40" data-autoplay="true" data-slides-show="6" data-slides-scroll="6" data-arrows-classes="u-arrow-v1 g-pos-abs g-bottom-0 g-width-45 g-height-45 g-font-size-default g-color-gray-dark-v5 g-bg-gray-light-v5 g-color-white--hover g-bg-primary--hover rounded" data-arrow-left-classes="fa fa-angle-left g-left-35x--lg g-left-15" data-arrow-right-classes="fa fa-angle-right g-right-35x--lg g-right-15" data-pagi-classes="u-carousel-indicators-v1 g-absolute-centered--x g-bottom-20 text-center" 
        data-responsive='[{
            "breakpoint": 992,
            "settings": {
            "slidesToShow": 5
            }
        }, {
            "breakpoint": 768,
            "settings": {
            "slidesToShow": 2
            }
        }, {
            "breakpoint": 554,
            "settings": {
            "slidesToShow": 1
            }
        }]'>
    <?php $__currentLoopData = $tproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php 
    $prod->pprice = $prod->pprice ? : $prod->cprice;
    $prod->cprice = $prod->getPrice(1);
     ?>

    <div class="js-slide g-px-15">
        <!-- Article -->
        <article class="u-shadow-v19 g-bg-white text-center rounded g-px-20 g-py-40 g-mb-5">
            <!-- Article Image -->
             <?php 
                $name = str_replace(" ","-",$prod->name);
             ?>
            <a href="<?php echo e(route('front.product',['id' => $prod->id, 'slug' => str_slug($name,'-')])); ?>">
                <img class="d-inline-block img-fluid mb-4" style="height:7rem;" src="<?php echo e(asset('assets/images/'.$prod->photo)); ?>" alt="">
            </a>
            <!-- End Article Image -->
           
            <!-- Article Content -->
        <h4 class="h5 g-color-black g-font-weight-600 g-mb-10"><a href="<?php echo e(route('front.product',['id' => $prod->id, 'slug' => str_slug($name,'-')])); ?>"><?php echo e($prod->name); ?></a></h4>
            <span class="d-block g-color-primary g-font-size-16">
                    <?php echo e($curr->sign); ?>                    
                <?php if($prod->user_id != 0): ?>
                    <?php 
                        $price = $prod->cprice + $gs->fixed_commission + ($prod->cprice/100) * $gs->percentage_commission ;
                     ?>
                    <?php echo e(round($price * $curr->value,2)); ?>

                    <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?>
                        <?php 
                          $pprice = $prod->pprice + $gs->fixed_commission + ($prod->pprice/100) * $gs->percentage_commission ;
                            
                         ?>
                        <span style="display:inline; font-size:12px"><del><?php echo e($curr->sign); ?><?php echo e(round($pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>
                    <?php endif; ?>
                <?php else: ?>
                    <?php echo e(round($prod->cprice * $curr->value,2)); ?>

                    <?php if($prod->pprice != null && $prod->pprice != 0  && $prod->pprice > $prod->cprice): ?>
                        <span style="display:inline; font-size:12px"><del><?php echo e($curr->sign); ?><?php echo e(round($prod->pprice * $curr->value,2)); ?></del> -<?php echo e($prod->discount_percent); ?>%</span>
                    <?php endif; ?>
                <?php endif; ?>
            </span>
            <!-- End Article Content -->
        </article>
        <!-- End Article -->
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<div class="section-padding review-carousel-wrap overlay wow fadeInUp" data-wow-duration="1s" data-wow-delay=".3s" style="background-image: url(<?php echo e(asset('assets/images/'.$gs->cimg)); ?>)">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title text-center">
                    <h2><?php echo e($lang->review_title); ?></h2>
                </div>
            </div>
            <div class="col-lg-8 col-lg-offset-2 col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1">

                <div class="js-carousel g-pb-70" data-infinite="true" data-arrows-classes="u-arrow-v1 g-width-40 g-height-40 g-color-gray-dark-v5 g-bg-white g-color-white--hover g-bg-primary--hover rounded g-absolute-centered--x g-bottom-0" data-arrow-left-classes="fa fa-angle-left g-ml-minus-25" data-arrow-right-classes="fa fa-angle-right g-ml-25">
                        <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   
                    <div class="js-slide">
                        <!-- Testimonials Advanced -->
                        <div class="row justify-content-center">
                        <div class="col-lg-8">
                            <div class="text-center">
                            <img class="d-inline-block g-width-120 g-height-120 g-brd-around g-brd-5 g-brd-white rounded-circle" src="<?php echo e(asset('assets/images/'.$ad->photo)); ?>" alt="Image Description">

                            <div class="g-py-25">
                                <h4 class="h5 g-color-white text-uppercase g-mb-0"><?php echo e($ad->client); ?></h4>
                             </div>

                            <blockquote class="lead g-line-height-1_8 g-mb-25">"<?php echo e($ad->review); ?>"</blockquote>

                            <div class="js-rating align-self-center g-color-yellow" data-rating="5" data-spacing="5" data-backward-icons-classes="fa fa-star"></div>
                            </div>
                        </div>
                        </div>
                        <!-- End Testimonials Advanced -->
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<section class="section-padding client-logo-wrap wow fadeInUp" data-wow-duration="1s" data-wow-delay=".3s">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h2><?php echo e($lang->sue); ?></h2>
                </div>
            </div>
        </div>
        <div class="g-overflow-hidden">

            <div class="row text-center mx-0 g-ml-minus-1 g-mb-minus-1">
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-sm-3 col-md-2 px-0">
                    <div class="g-brd-left g-brd-bottom g-brd-gray-light-v4 g-py-30 g-px-15">
                  <a href="<?php echo e($brand->url); ?>">  <img class="img-fluid g-width-100 g-opacity-0_8--hover g-transition-0_2" src="<?php echo e(asset('assets/images/'.$brand->photo)); ?>" alt="Image Description"></a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
</section>
      <!-- End Products Block -->
    

    

    <section id="extraData">

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(window).on('load',function() {
            setTimeout(function(){

                $('#extraData').load('<?php echo e(route('front.extraIndex')); ?>');

            }, 500);
        });
        //---------Countdown-----------
        $('#clock').countdown('<?php echo e($gs->count_date); ?>', function(event) {
            $(this).html(event.strftime('<span class="countdown-timer-wrap"></span><span class="single-countdown-item">%w <br/><span><?php echo e($lang->week); ?></span></span> <span class="single-countdown-item">%d <br/><span><?php echo e($lang->day); ?></span></span> <span class="single-countdown-item">%H <br/><span><?php echo e($lang->hour); ?></span></span> <span class="single-countdown-item">%M <br/><span><?php echo e($lang->minute); ?></span></span> <span class="single-countdown-item">%S <br/><span><?php echo e($lang->second); ?></span></span> </span>'));
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>