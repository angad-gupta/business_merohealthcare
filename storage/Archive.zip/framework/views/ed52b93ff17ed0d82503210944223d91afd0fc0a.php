      <?php 
        $conv_notff = App\UserNotification::where('user_id','=',Auth::guard('user')->user()->id)->orderBy('id','desc')->get();
        if($conv_notff->count() > 0){
          foreach($conv_notff as $notf){
            $notf->is_read = 1;
            $notf->update();
          }
        }
       ?>   

                                                            <div class="profile-notifi-title">
                                                                <h5 style="color:#333;"><?php echo e($lang->conv); ?></h5>
                                                                <?php if($conv_notff->count() > 0): ?>
                                                                <p  style="cursor: pointer;" id="conv_clear">Clear All</p>
                                                                <?php endif; ?>
                                                            </div>

                                                            <?php if($conv_notff->count() > 0): ?>
                                                            <?php $__currentLoopData = $conv_notff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($notf->conversation_id != null): ?>
                                                            <div class="single-notifi-area">
                                                               <div class="notifi-img">
                                                                    <i class="fa fa-envelope"></i>
                                                               </div>
                                                               <div class="single-notifi-text">
                                                                   <h5><a href="<?php echo e(route('user-message',$notf->conversation->id)); ?>" style="color: #333;"><?php echo e($lang->new_conv); ?></a></h5>
                                                               </div>
                                                               </div>
                                                               <?php else: ?>
                                                            <div class="single-notifi-area">
                                                               <div class="notifi-img">
                                                                    <i class="fa fa-envelope"></i>
                                                               </div>
                                                               <div class="single-notifi-text">
                                                                   <h5><a href="<?php echo e(route('user-message-show',$notf->conv1->id)); ?>" style="color: #333;">New Message From Admin.</a></h5>
                                                               </div>
                                                               </div>
                                                               <?php endif; ?>
                                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php else: ?>
                                                            <div class="single-notifi-area">
                                                            <h5 style="color:gray;"><?php echo e($lang->no_conv); ?></h5> 
                                                            </div>  
                                                            <?php endif; ?>