<?php $__env->startSection('title','My Orders'); ?>
<?php $__env->startSection('content'); ?>
  <div class="right-side">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <!-- Starting of Dashboard data-table area -->
          <div class="section-padding add-product-1">
            <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="add-product-box">
                  <div class="product__header">
                      <div class="row reorder-xs">
                          <div class="col-lg-8 col-md-5 col-sm-5 col-xs-12">
                              <div class="product-header-title">
                                  <h2>Purchased Items</h2>
                                  <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Purchased Items</p>
                              </div>
                          </div>
                            <?php echo $__env->make('includes.user-notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                      </div>   
                  </div>
                  <div>
                    <?php echo $__env->make('includes.form-success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="table-responsive">
                          <table id="product-table_wrapper" class="table table-striped table-hover products dt-responsive" cellspacing="0" width="100%">
                            <thead>
                              <tr class="table-header-row">
                                <th>Order#</th>
                                <th>Date</th>
                                <th>Order Total</th>
                                <th>Order Status</th>
                                <th>Details</th>
                              </tr>
                            </thead>
                            <tbody>
                              <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td><?php echo e($order->order_number); ?></td>
                                  <td><?php echo e(date('d M Y',strtotime($order->created_at))); ?></td>

                                  
                                  <td><?php echo e($order->currency_sign); ?><?php echo e(round($order->pay_amount * $order->currency_value , 2)); ?></td>
                                  <td>
                                    <?php if($order->status == 'processing'): ?>
                                    <span class="label label-warning"><?php echo e(ucfirst($order->status)); ?></span>
                                    <?php elseif($order->status == 'cancelled'): ?>
                                    <span class="label label-danger"><?php echo e(ucfirst($order->status)); ?></span>
                                    <?php elseif($order->status == 'completed'): ?>
                                    <span class="label label-success"><?php echo e(ucfirst($order->status)); ?></span>
                                    <?php endif; ?>
                                  </td>
                                  <td>
                                    <a href="<?php echo e(route('user-order',$order->id)); ?>" class="btn btn-primary" style="border-radius:30px;"><i class="fa fa-eye" aria-hidden="true"></i> View Order</a><br>
                                    <?php if($order->status != 'completed'): ?>
                                        
                                        <?php if($order->status == 'cancellation request'): ?>
                                          <span class="badge" style=" background-color:orange; margin:5px;">Requested for cancellation</span>
                                        <?php elseif($order->status == 'processing'): ?>
                                          <a class="btn btn-danger" style="border-radius:30px; margin:5px;"  style="cursor:pointer" data-href="<?php echo e(route('user-order.cancellation',$order->id)); ?>" data-toggle="modal" data-target="#confirm-cancel" ><i class="fa fa-trash" aria-hidden="true"></i> Request Cancellation</a>
                                        <?php elseif($order->status == 'completed' && $order->completed_at > Carbon\Carbon::today()->subDays(1)): ?>
                                          <a class="btn btn-danger" style="border-radius:30px; margin:5px;" style="cursor:pointer" data-href="<?php echo e(route('user-order.cancellation',$order->id)); ?>" data-toggle="modal" data-target="#confirm-cancel" >Request Cancellation</a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                  </td>
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Ending of Dashboard data-table area -->
      </div>
    </div>
  </div>
  <div class="modal fade" id="confirm-cancel" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                  <h4 class="modal-title text-center" id="myModalLabel">Cancellation request for Order</h4>
              </div>
              <div class="modal-body">
                  <p class="text-center">Do you want to proceed?</p>
              </div>
              <div class="modal-footer" style="text-align: center;">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                  <form class="btn-ok" action="" method="POST" style="display:inline-block">
                      <?php echo e(csrf_field()); ?>

                      <button type="submit" class="btn btn-danger">Send Request</button>
                  </form>
              </div>
          </div>
      </div>
  </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

  <script type="text/javascript">

    $( document ).ready(function() {

      $('#confirm-cancel').on('show.bs.modal', function(e) {
        
          $(this).find('.btn-ok').attr('action', $(e.relatedTarget).data('href'));
      }); 
    });
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>