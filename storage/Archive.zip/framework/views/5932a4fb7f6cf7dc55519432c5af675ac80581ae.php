<?php $__currentLoopData = $multiple_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $multiple_img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="<?php echo e($multiple_img->file); ?>">asasas<?php echo e($multiple_img->file); ?>asasas</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $multiple_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <img src="<?php echo e(url('file/') . $image->file); ?>">
    <a href=""><?php echo e(url('file/') . $image->file); ?></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<h4><i class="glyphicon glyphicon-picture"></i> Display Data Image    </h4>
<table class="table table-bordered table-hover table-striped">
 <thead>
 <tr><th>#</th>
     <th>Picture</th>
 </tr>
 </thead>
 <tbody>
     <?php $__currentLoopData = $multiple_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr><td><?php echo e($image->id); ?></td>
        <td> <?php foreach (json_decode($image->file)as $picture) { ?>
              <img src="<?php echo e(asset('/files/'.$picture)); ?>" style="height:120px; width:200px"/>
            
        <a href="<?php echo e(asset('/files/'.$picture)); ?>"><?php echo e($picture); ?></a>
             <?php } ?>
        </td>
   </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </tbody>
</table>