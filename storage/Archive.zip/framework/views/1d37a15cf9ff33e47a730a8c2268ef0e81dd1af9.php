      <?php 
        $conv_notf = App\UserNotification::where('user_id','=',Auth::guard('user')->user()->id)->where('is_read','=',0)->orderBy('id','desc')->get();
        $order_notf = App\Notification::where('order_id','!=',null)->where('vendor_id',Auth::guard('user')->user()->id)->where('is_read','=',0)->orderBy('id','desc')->get();

       ?>                                      

                                            <div class="col-lg-4 col-md-7 col-sm-7 col-xs-12">
                                                
                                                <div class="profile-info dropdown">
                                                    <?php if(Auth::guard('user')->user()->IsVendor()): ?> 
                                                        <div class="profile-notifi" style="padding-left: 0;">
                                                            <a class="dropdown-toggle" id="order_notf" href="" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                                                <img src="<?php echo e(asset('assets/admin/img/notification.png')); ?>" alt="notification image">
                                                                <span id="notf_order"><?php echo e($order_notf->count()); ?></span>
                                                            </a>

                                                            <div class="profile-order-content dropdown-menu">
                                                            
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>

                                                    <div class="profile-comments">
                                                        <a class="dropdown-toggle" id="conv_notf" href="" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                                            <img src="<?php echo e(asset('assets/admin/img/message.png')); ?>" alt="list image">
                                                            <span id="notf_conv"><?php echo e($conv_notf->count()); ?></span>
                                                        </a>

                                                        <div class="profile-notifi-content dropdown-menu">
                                                            
                                                        </div>
                                                    </div>

                                                    <div class="view-profile">
                                                        <div class="profile__img dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <?php if(Auth::guard('user')->user()->is_provider == 1): ?>
                                    <img src="<?php echo e(Auth::guard('user')->user()->photo ? Auth::guard('user')->user()->photo:asset('assets/images/user.png')); ?>" alt="profile image">
                                    <?php else: ?>
                                    <img src="<?php echo e(Auth::guard('user')->user()->photo ? asset('assets/images/'.Auth::guard('user')->user()->photo):asset('assets/images/user.png')); ?>" alt="profile image">
                            <?php endif; ?> <span><?php echo e(Auth::guard('user')->user()->name); ?></span> <i class="fa fa-angle-down"></i>
                                                        </div>
                                                        <div class="profile-content dropdown-menu">
                                                            <h5><?php echo e($lang->welcome); ?></h5>
                                                            <a style="margin-left: 4px;" href="<?php echo e(route('user-profile')); ?>"><i class="fa fa-user"></i><?php echo e($lang->edit); ?></a>
                                                            <a href="<?php echo e(route('user-reset')); ?>"><i class="fa fa-fw fa-cog"></i><?php echo e($lang->reset); ?></a>

                                                            <a href="<?php echo e(route('user-logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><i class="fa fa-fw fa-power-off"></i><?php echo e($lang->logout); ?></a>
                                                            <form id="logout-form" action="<?php echo e(route('user-logout')); ?>" method="POST" style="display: none;">
                                                                <?php echo e(csrf_field()); ?>

                                                            </form>
                                                        </div>
                                                    </div>
                                                </div> 
                                            </div>